"""Managed, approximate glass preview. Does not change source image colour spaces."""
import bpy
TAG='reskate_glass_preview'
PREVIEW_VERSION='0.11.2'

def refresh(material):
    p=material.reskate_glass
    material['reskate_glass_preview_version']=PREVIEW_VERSION
    material.use_nodes=True
    tree=material.node_tree;nodes=tree.nodes
    node=next((n for n in nodes if n.type=='GROUP' and n.get(TAG)),None)
    if node is None:
        node=nodes.new('ShaderNodeGroup');node[TAG]=True;node.label='ReSkate Glass Preview';node.location=(260,80)
        node.node_tree=bpy.data.node_groups.new('ReSkate Glass Preview','ShaderNodeTree')
    elif node.node_tree.users>1:
        node.node_tree=node.node_tree.copy()
    group=node.node_tree;group.nodes.clear()
    if not group.interface.items_tree:
        group.interface.new_socket(name='Surface',in_out='OUTPUT',socket_type='NodeSocketShader')
    n=group.nodes;links=group.links
    def make(kind,name,x,y):
        q=n.new(kind);q.name=name;q.label=name;q.location=(x,y);return q
    def math(op,name,a,b=None,x=-400,y=0):
        q=make('ShaderNodeMath',name,x,y);q.operation=op
        for i,value in enumerate([a,b] if b is not None else [a]):
            if isinstance(value,(int,float)):q.inputs[i].default_value=value
            else:links.new(value,q.inputs[i])
        return q.outputs[0]
    geo=make('ShaderNodeNewGeometry','View angle',-1100,450)
    dot=make('ShaderNodeVectorMath','Normal dot view',-900,450);dot.operation='DOT_PRODUCT';links.new(geo.outputs['Normal'],dot.inputs[0]);links.new(geo.outputs['Incoming'],dot.inputs[1])
    cosine=math('ABSOLUTE','Both sides',dot.outputs['Value'],x=-700,y=450)
    grazing=math('SUBTRACT','Grazing angle',1,cosine,x=-500,y=450)
    fresnel=math('POWER','Angle response',grazing,5,x=-300,y=450)
    opacity=math('ADD','Clean opacity',p.face_opacity,math('MULTIPLY','Edge range',p.edge_opacity-p.face_opacity,fresnel,x=-100,y=450),x=100,y=450)
    dirt=0.0;rgba_color=None;rgba_coverage=None;tex=None
    if p.dirt_image is not None:
        uv=make('ShaderNodeUVMap','Active UV map',-1100,-200)
        tex=make('ShaderNodeTexImage','Dirt mask image',-900,-200);tex.image=p.dirt_image;tex.extension='REPEAT';tex.interpolation='Linear';links.new(uv.outputs['UV'],tex.inputs['Vector'])
        if p.dirt_mode=='RGBA':
            rgba_color=tex.outputs['Color']
            rgba_coverage=math('MULTIPLY','Dirt coverage',tex.outputs['Alpha'],p.dirt_coverage,x=-450,y=-200)
        else:
            red=make('ShaderNodeSeparateColor','Mask red channel',-650,-200);red.mode='RGB';links.new(tex.outputs['Color'],red.inputs['Color'])
            dirt=math('MULTIPLY','Dirt coverage',red.outputs['Red'],p.dirt_coverage,x=-450,y=-200)
    if rgba_coverage is not None:rgba_coverage=math('MINIMUM','Clamped image coverage',rgba_coverage,1,x=-200,y=-250)
    if not isinstance(dirt,(int,float)):dirt=math('MINIMUM','Clamped mask coverage',dirt,1,x=-200,y=-150)
    roughness=math('ADD','Dirty roughness',p.roughness,math('MULTIPLY','Roughness change',dirt,.7-p.roughness,x=-100,y=-100),x=100,y=-100)
    alpha=math('ADD','Dirt opacity',opacity,math('MULTIPLY','Opacity change',dirt,math('SUBTRACT','Opacity target',.95,opacity,x=300,y=450),x=500,y=450),x=700,y=450)
    reflection=math('MULTIPLY','Reflection strength',p.reflection_strength,math('SUBTRACT','Dirt reflection loss',1,math('MULTIPLY','Reflection loss',dirt,.7,x=-100,y=-350),x=100,y=-350),x=300,y=-350)
    bsdf=make('ShaderNodeBsdfPrincipled','Reflected environment',550,100);bsdf.inputs['Base Color'].default_value=(1,1,1,1);bsdf.inputs['Metallic'].default_value=1
    links.new(roughness,bsdf.inputs['Roughness'])
    # Scalar-to-colour conversion applies the same scale to R/G/B.
    links.new(reflection,bsdf.inputs['Base Color'])
    grime=make('ShaderNodeBsdfDiffuse','Neutral grime',550,-220);grime.inputs['Roughness'].default_value=.7
    links.new(math('MULTIPLY','Grime brightness',dirt,.08,x=300,y=-200),grime.inputs['Color'])
    add=make('ShaderNodeAddShader','Reflection and grime',800,50);links.new(bsdf.outputs['BSDF'],add.inputs[0]);links.new(grime.outputs[0],add.inputs[1])
    clear=make('ShaderNodeBsdfTransparent','Straight-through view',800,-150)
    mix=make('ShaderNodeMixShader','Glass coverage',1050,100);links.new(alpha,mix.inputs[0]);links.new(clear.outputs[0],mix.inputs[1]);links.new(add.outputs[0],mix.inputs[2])
    surface=mix.outputs[0]
    if rgba_color is not None:
        color=make('ShaderNodeBsdfDiffuse','Dirt image color',1050,-250);links.new(rgba_color,color.inputs['Color']);color.inputs['Roughness'].default_value=.7
        overlay=make('ShaderNodeMixShader','Color over glass',1280,100);links.new(rgba_coverage,overlay.inputs[0]);links.new(surface,overlay.inputs[1]);links.new(color.outputs[0],overlay.inputs[2]);surface=overlay.outputs[0]
    if tex is not None and p.preview_test != 'GLASS':
        inspect=make('ShaderNodeEmission','Dirt inspection',1280,-350)
        links.new(tex.outputs['Alpha' if p.preview_test=='ALPHA' else 'Color'],inspect.inputs['Color'])
        inspect.inputs['Strength'].default_value=1
        surface=inspect.outputs[0]
    output=make('NodeGroupOutput','Preview surface',1500,100);links.new(surface,output.inputs['Surface'])
    outputs=[q for q in nodes if q.type=='OUTPUT_MATERIAL' and q.is_active_output]
    if not outputs:outputs=[nodes.new('ShaderNodeOutputMaterial')]
    for out in outputs:
        tree.links.new(node.outputs['Surface'],out.inputs['Surface'])
    material.surface_render_method='DITHERED'
    material.diffuse_color=(.8,.85,.9,p.face_opacity)

def update(self,context):
    material=self.id_data
    if isinstance(material,bpy.types.Material) and self.enabled:
        refresh(material)
