"""Export one evaluated mesh in an isolated scene, preserving the source scene."""
import json,struct
from array import array
from pathlib import Path
import bpy


def export_object(context,obj,destination,exporter=None):
    from .builder.prepare_native import parse_glb
    destination=Path(destination);scene=None;mesh=None;temporary=None
    window=context.window
    if window is None:raise RuntimeError('Glass authoring export requires a Blender window')
    original_scene=window.scene if window else None
    original_layer=window.view_layer if window else None
    # Resolve dependencies and modifiers in the source scene before switching context.
    depsgraph=context.evaluated_depsgraph_get();evaluated=obj.evaluated_get(depsgraph)
    world=evaluated.matrix_world.copy()
    try:
        mesh=bpy.data.meshes.new_from_object(evaluated,preserve_all_data_layers=True,depsgraph=depsgraph)
        if not mesh or not len(mesh.polygons):raise ValueError('Glass object has no evaluated mesh faces: '+obj.name)
        # Object-linked materials override mesh-linked data; retain their slot indices.
        materials=list(mesh.materials)
        for index,slot in enumerate(obj.material_slots):
            if index<len(materials):materials[index]=slot.material
            else:materials.append(slot.material)
        indices=array('i',[0])*len(mesh.polygons);mesh.polygons.foreach_get('material_index',indices)
        mesh.materials.clear()
        for material in materials:mesh.materials.append(material)
        mesh.polygons.foreach_set('material_index',indices)
        scene=bpy.data.scenes.new('__ReSkate_Glass_Export__')
        temporary=bpy.data.objects.new('__ReSkate_Glass_Mesh__',mesh)
        scene.collection.objects.link(temporary);temporary.matrix_world=world
        layer=scene.view_layers[0];layer.objects.active=temporary;temporary.select_set(True,view_layer=layer)
        if window:window.scene=scene
        with context.temp_override(scene=scene,view_layer=layer):
            result=(exporter or bpy.ops.export_scene.gltf)(filepath=str(destination),export_format='GLB',use_selection=True,
                    use_active_scene=True,export_apply=False,export_materials='EXPORT',export_yup=True,
                    export_animations=False,export_cameras=False,export_lights=False)
        if result!={'FINISHED'} or not destination.is_file():raise RuntimeError('GLB export failed for '+obj.name)
        doc,binary=parse_glb(destination.read_bytes())
        nodes=[n for n in doc.get('nodes',[]) if 'mesh' in n]
        if len(nodes)!=1 or nodes[0].get('name')!=temporary.name:
            raise RuntimeError('Isolated export contains unexpected mesh objects for '+obj.name+': '+str([n.get('name') for n in nodes]))
        # Temporary IDs have unique Blender names. Restore only the exported name;
        # accessor bytes, material names/indices and world transforms stay intact.
        nodes[0]['name']=obj.name
        document=json.dumps(doc,ensure_ascii=False,separators=(',',':')).encode('utf-8');document+=b' '*(-len(document)%4)
        destination.write_bytes(struct.pack('<4sII',b'glTF',2,28+len(document)+len(binary))+
            struct.pack('<II',len(document),0x4e4f534a)+document+struct.pack('<II',len(binary),0x004e4942)+binary)
    finally:
        if window:
            window.scene=original_scene;window.view_layer=original_layer
        if temporary is not None:bpy.data.objects.remove(temporary,do_unlink=True)
        if scene is not None:bpy.data.scenes.remove(scene)
        if mesh is not None and mesh.users==0:bpy.data.meshes.remove(mesh)
