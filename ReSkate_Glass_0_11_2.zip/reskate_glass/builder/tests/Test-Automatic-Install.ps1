param([Parameter(Mandatory=$true)][string]$PackageFolder)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$package=(Resolve-Path -LiteralPath $PackageFolder).Path
$helper=Join-Path (Split-Path -Parent $PSScriptRoot) 'Install-Built-Glass.ps1'
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('glass-auto-install-test-'+[guid]::NewGuid().ToString('N'))
$game=Join-Path $testRoot 'game'
$history=Join-Path $testRoot 'history'
$mods=Join-Path $game 'Mods'
New-Item -ItemType Directory -Path $mods -Force | Out-Null
$spec=Get-Content -LiteralPath (Join-Path $package 'validation.json') -Raw | ConvertFrom-Json
$processState=@{blocked=$false}
Set-Item function:Get-Process -Value ({param($Name,$ErrorAction) if ($processState.blocked) { [pscustomobject]@{ProcessName='Skate'} }}.GetNewClosure())
function Assert-Installed {
 foreach ($entry in @(@($spec.map_id,$spec.modes.Compare),@($spec.support.map_id,$spec.support.hashes))) {
  foreach ($prop in $entry[1].PSObject.Properties) {
   $file=Join-Path (Join-Path $mods $entry[0]) $prop.Name
   if ((Get-FileHash -LiteralPath $file).Hash -ne $prop.Value) { throw 'Installed hash mismatch' }
  }
 }
}
try {
 & $helper -PackageFolder $package -GameRoot $game -WorkFolder $history
 Assert-Installed
 & $helper -PackageFolder $package -GameRoot $game -WorkFolder $history
 Assert-Installed
 if (@(Get-ChildItem $history -Directory -Filter 'Previous_*').Count -lt 2) { throw 'Previous paired build was not backed up' }
 $processState.blocked=$true
 $rejected=$false
 try { & $helper -PackageFolder $package -GameRoot $game -WorkFolder $history } catch { $rejected=$_.Exception.Message -like '*Close skate*' }
 if (-not $rejected) { throw 'Running game not refused' }
 Assert-Installed
 $processState.blocked=$false
 $artist=Join-Path (Join-Path $mods $spec.map_id) 'artist.txt'
 Set-Content -LiteralPath $artist -Value 'retain me'
 $rejected=$false
 try { & $helper -PackageFolder $package -GameRoot $game -WorkFolder $history } catch { $rejected=$_.Exception.Message -like '*edited*' }
 if (-not $rejected -or -not (Test-Path $artist)) { throw 'Edited map was not protected' }
 $rejected=$false
 try { & $helper -PackageFolder $package -GameRoot (Join-Path $testRoot 'absent') -WorkFolder $history } catch { $rejected=$_.Exception.Message -like '*Mods folder not found*' }
 if (-not $rejected) { throw 'Missing Mods folder not refused' }
 Write-Host 'PASS: automatic paired install, reinstall with backups, running-game refusal, edited-map protection, missing Mods refusal'
} finally { Remove-Item -LiteralPath $testRoot -Recurse -Force }
