import bpy,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
import addon_utils
addon=addon_utils.enable('reskate_glass',default_set=True)
assert addon and addon.bl_info['version']==(0,11,2)
entry=bpy.context.preferences.addons['reskate_glass']
with tempfile.TemporaryDirectory(prefix='glass paths with spaces ') as td:
    entry.preferences.cli_path=str(Path(td)/'Studio $test'/ 'reskate_cli.exe')
    entry.preferences.game_root=str(Path(td)/'Game')
    entry.preferences.build_root=str(Path(td)/'Builds')
    args=addon.builder_options(bpy.context)
    assert args[::2]==['-CliPath','-GameRoot','-OutputRoot']
    assert args[1]==entry.preferences.cli_path
    assert args[3]==entry.preferences.game_root and args[5]==entry.preferences.build_root
bpy.ops.mesh.primitive_plane_add();obj=bpy.context.object
mat=bpy.data.materials.new('Glass');obj.data.materials.append(mat)
p=mat.reskate_glass;p.enabled=True
p.dirt_image=bpy.data.images.new('Custom RGBA',width=2,height=2,alpha=True)
for mode in ['MASK','RGBA']:
    p.dirt_mode=mode;addon.preview(mat)
    group=next(n.node_tree for n in mat.node_tree.nodes if n.get('reskate_glass_preview'))
    assert group.nodes['Neutral grime'].bl_idname=='ShaderNodeBsdfDiffuse'
    if mode=='RGBA':assert group.nodes['Dirt image color'].bl_idname=='ShaderNodeBsdfDiffuse'
    p.preview_test='ALPHA';addon.preview(mat)
    assert group.nodes['Dirt inspection'].bl_idname=='ShaderNodeEmission'
    p.preview_test='GLASS'
addon_utils.disable('reskate_glass',default_set=True)
print('PASS: beta registration, persisted creator paths as separate process arguments, lit dirt previews and independent unlit inspection views')
