param(
 [Parameter(Mandatory=$true)][string]$PackageFolder,
 [Parameter(Mandatory=$true)][string]$OldPackageFolder,
 [Parameter(Mandatory=$true)][string]$DiagnosticSupportFolder
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$package=(Resolve-Path $PackageFolder).Path
$old=(Resolve-Path $OldPackageFolder).Path
$oldSpec=Get-Content (Join-Path $old 'validation.json') -Raw | ConvertFrom-Json
$newSpec=Get-Content (Join-Path $package 'validation.json') -Raw | ConvertFrom-Json
$root=Join-Path ([IO.Path]::GetTempPath()) ('glass-beta-upgrade-'+[guid]::NewGuid().ToString('N'))
$mods=Join-Path $root 'Mods';$history=Join-Path $root 'History'
New-Item -ItemType Directory -Path $mods | Out-Null
$state=@{fail=$false}
Set-Item function:Get-Process -Value {param($Name,$ErrorAction)}
Set-Item function:Move-Item -Value ({param([string]$LiteralPath,[string]$Destination,[switch]$Force)
 if ($state.fail -and $LiteralPath -like '*Prepared_glass_author_*') { $state.fail=$false;throw 'Injected map-stage failure' }
 Microsoft.PowerShell.Management\Move-Item @PSBoundParameters
}.GetNewClosure())
function Tree($folder) {
 $out=@{}
 foreach ($p in Get-ChildItem -LiteralPath $folder -Recurse -File -Force) { $out[$p.FullName.Substring($folder.Length+1)]=(Get-FileHash -LiteralPath $p.FullName).Hash }
 return $out
}
function Exact($folder,$hashes) {
 $actual=Tree $folder
 if ($actual.Count -ne $hashes.Count) {throw 'Wrong file count'}
 foreach ($name in $hashes.Keys) {if ($actual[$name] -ne $hashes[$name]) {throw 'Changed old files'}}
}
try {
 $oldMap=Join-Path $mods $oldSpec.map_id;$oldSupport=Join-Path $mods $oldSpec.support.map_id
 Copy-Item (Join-Path $old 'payload') $oldMap -Recurse
 Copy-Item $DiagnosticSupportFolder $oldSupport -Recurse
 $mapHashes=Tree $oldMap;$supportHashes=Tree $oldSupport
 $extra=Join-Path $oldSupport 'artist.txt';Set-Content $extra 'Keep this edit'
 $refused=$false
 try { & (Join-Path $package 'Install-Glass-Test.ps1') -ModsFolder $mods -WorkFolder $history } catch {$refused=$_.Exception.Message -like '*unknown/edited*'}
 if (-not $refused -or -not (Test-Path $extra)) {throw 'Edited diagnostic was not protected'}
 Exact $oldMap $mapHashes
 Remove-Item -LiteralPath $extra
 $state.fail=$true;$refused=$false
 try { & (Join-Path $package 'Install-Glass-Test.ps1') -ModsFolder $mods -WorkFolder $history } catch {$refused=$_.Exception.Message -like '*Injected*'}
 if (-not $refused) {throw 'Injected failure did not occur'}
 Exact $oldMap $mapHashes;Exact $oldSupport $supportHashes
 foreach ($id in @($newSpec.map_id,$newSpec.support.map_id)) {if (Test-Path (Join-Path $mods $id)) {throw 'Failed install left active new files'}}
 & (Join-Path $package 'Install-Glass-Test.ps1') -ModsFolder $mods -WorkFolder $history
 foreach ($entry in @(@($newSpec.map_id,$newSpec.modes.Compare),@($newSpec.support.map_id,$newSpec.support.hashes))) {
  $hashes=@{};foreach ($p in $entry[1].PSObject.Properties) {$hashes[$p.Name]=$p.Value.ToUpperInvariant()}
  Exact (Join-Path $mods $entry[0]) $hashes
 }
 if ((Test-Path $oldMap) -or (Test-Path $oldSupport)) {throw 'Old diagnostic still active'}
 Write-Host 'PASS: real test-11 support retirement, edited-file refusal, rollback after partial paired install and successful exact upgrade'
} finally {Remove-Item -LiteralPath $root -Recurse -Force}
