from pathlib import Path
import sys,json,hashlib,tempfile,zipfile,copy,struct
base=Path(__file__).resolve().parents[1];sys.path.insert(0,str(base))
from prepare_native import write_glb
from prepare_full_map import merge
profiles=json.loads((base/'profiles.json').read_text())
with tempfile.TemporaryDirectory() as td:
 p=Path(td);source=p/'base';source.mkdir();(source/'meshes').mkdir();(source/'textures').mkdir()
 glb=write_glb([(0,0,0),(2,0,0),(0,2,0)],[0,1,2]);(source/'meshes/original.glb').write_bytes(glb);(source/'textures/keep.bin').write_bytes(b'unchanged pixels')
 identity=[1,0,0,0,1,0,0,0,1,0,0,0]
 glass={'name':'original_pane','source_object':'Pane','source_material_slot':0,'mesh':'meshes/original.glb','material':'original_glass','transform':identity,'collision_mode':'triangle_mesh','collision_mesh':'meshes/original.glb','collision_material_packed':32}
 road={'name':'road','source_object':'Road','mesh':'meshes/original.glb','material':'road','transform':identity,'collision_mode':'triangle_mesh'}
 doc={'format':1,'name':'my_map','display_name':'My Map','units':'meters','up':'y','forward':'-z','source':{'scale':1},'objects':[glass,road], 'materials':{'original_glass':{'alpha':'blend'},'road':{'roughness_factor':.9}},'spawn':{'position':[0,2,0],'yaw':1},'lights':[{'name':'spot','intensity':22}], 'lighting':{'strategy':'native_frostbite_light_entities'},'reflection_probes':[{'name':'keep_probe'}], 'travel_points':[{'name':'keep_travel'}]}
 (source/'map.json').write_text(json.dumps(doc));before={str(x.relative_to(source)):hashlib.sha256(x.read_bytes()).hexdigest() for x in source.rglob('*') if x.is_file()}
 zpath=p/'glass.zip';manifest={'schema':1,'kind':'reskate-glass-authoring','objects':[{'name':'Pane','mesh':'pane.glb','material_slots':['g']}],'materials':{'g':{'settings':profiles['Balanced']}},'files':{'pane.glb':hashlib.sha256(glb).hexdigest()}}
 with zipfile.ZipFile(zpath,'w') as z:z.writestr('glass-authoring.json',json.dumps(manifest));z.writestr('pane.glb',glb)
 out=p/'combined';merge(source,zpath,out);result=json.loads((out/'map.json').read_text())
 for k in doc:
  if k not in ['name','display_name','materials','objects']:assert result[k]==doc[k],k
 assert result['objects'][1]==road
 collision=result['objects'][0];assert collision['render'] is False and collision['collision_mesh']==glass['collision_mesh'] and 'mesh' not in collision
 for k,v in glass.items():
  if k not in ['mesh','material']:assert collision[k]==v
 assert len(result['objects'])==3 and result['objects'][2]['name']=='glass_0000' and result['objects'][2]['collision_mode']=='none'
 assert result['materials']['road']==doc['materials']['road'] and 'rg_full_map_glass' in result['materials']
 assert (out/'meshes/glass_0000.glb').exists()
 assert before=={str(x.relative_to(source)):hashlib.sha256(x.read_bytes()).hexdigest() for x in source.rglob('*') if x.is_file()}
 for f,h in before.items():
  if f!='map.json':assert hashlib.sha256((out/f).read_bytes()).hexdigest()==h
 assert json.loads((out/'glass-build-recipe.json').read_text())['preserve_shared_lighting']
 # Missing mapping, scale mismatch and missing spawn must stop without creating output.
 for n,mutate in [('missing',lambda d:d['objects'].clear()),('scale',lambda d:d['source'].update(scale=2)),('spawn',lambda d:d.pop('spawn'))]:
  bad=copy.deepcopy(doc);mutate(bad);(source/'map.json').write_text(json.dumps(bad))
  try:merge(source,zpath,p/n)
  except ValueError:pass
  else:raise AssertionError(n+' accepted')
  assert not (p/n).exists()
 # No probe: add local generated probe, retaining all authored lights/spawn.
 doc['reflection_probes']=[];(source/'map.json').write_text(json.dumps(doc));merge(source,zpath,p/'no_probe')
 assert json.loads((p/'no_probe/map.json').read_text())['reflection_probes'][0]['name']=='AUTHORING_TEST_PROBE'
 print('PASS: full scene fields, opaque objects, collision, lights, probes, spawn and file bytes preserved; glass replaced once; invalid inputs refused')
