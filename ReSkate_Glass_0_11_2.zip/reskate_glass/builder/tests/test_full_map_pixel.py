from pathlib import Path
import sys,json,tempfile,zipfile,hashlib,struct
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from prepare_native import write_glb
from prepare_full_map import merge
from pixel_dirt import apply_private_mask,WATER_TEXTURE_KEY,FLOOR_TEXTURE_KEY
base=Path(__file__).resolve().parents[1];profiles=json.loads((base/'profiles.json').read_text())
glb=write_glb([(0,0,0),(2,0,0),(0,2,0)],[0,1,2],[(0,0),(1,0),(0,1)])
mask=bytes([0,64,128,255])
with tempfile.TemporaryDirectory() as td:
 p=Path(td);original=p/'base';original.mkdir();(original/'floor.glb').write_bytes(glb);(original/'floor.png').write_bytes(b'original floor bytes')
 floor={'name':'floor','source_object':'Floor','source_material_slot':0,'mesh':'floor.glb','material':'floor','collision_mode':'triangle_mesh'}
 doc={'format':1,'name':'test','units':'meters','up':'y','forward':'-z','spawn':{'position':[0,2,0]},'objects':[dict(floor,name='pane',source_object='Pane',collision_mode='none'),floor], 'materials':{'floor':{'texture':'floor.png'}},'reflection_probes':[{'name':'kept'}]}
 (original/'map.json').write_text(json.dumps(doc));archive=p/'author.zip'
 manifest={'schema':1,'kind':'reskate-glass-authoring','objects':[{'name':'Pane','mesh':'pane.glb','material_slots':['a']}],'materials':{'a':{'settings':profiles['Balanced'],'dirt_mask':{'file':'mask','width':2,'height':2,'strength':1,'sha256':hashlib.sha256(mask).hexdigest()}}},'files':{'pane.glb':hashlib.sha256(glb).hexdigest()}}
 with zipfile.ZipFile(archive,'w') as z:z.writestr('glass-authoring.json',json.dumps(manifest));z.writestr('pane.glb',glb);z.writestr('mask',mask)
 merge(original,archive,p/'normalized',True);out=json.loads((p/'normalized/map.json').read_text());recipe=json.loads((p/'normalized/glass-build-recipe.json').read_text())
 assert floor in out['objects'];assert out['materials']['floor']==doc['materials']['floor'];assert (p/'normalized/floor.png').read_bytes()==b'original floor bytes'
 assert out['reflection_probes']==doc['reflection_probes']
 spec=next(iter(recipe['pixel_materials'].values()))
 assert spec['width']==6 and spec['coverage']==1
 assert recipe['objects'][0]['dirt_samples'] is None
 carrier=next(o for o in out['objects'] if o['name']=='rg_carrier_mat_0000');assert carrier['collision_mode']=='none';assert out['materials']['rg_carrier_mat_0000']['cast_shadows'] is False
 # Three private materials: glass, ordinary water, and the carrier surface. Only glass changes.
 def texture(k,ref):return struct.pack('<QIHHB',k,0x14c5fc30,1,0,1)+ref
 values=[struct.pack('<I',1)+texture(WATER_TEXTURE_KEY,b'g'*32),struct.pack('<I',1)+texture(WATER_TEXTURE_KEY,b'w'*32),struct.pack('<I',1)+texture(FLOOR_TEXTURE_KEY,b'c'*32)]
 data=bytearray(64);records=[]
 for v in values:records.append(len(data));data.extend(v)
 blocks=[]
 for offset in records:blocks.append(len(data));data.extend(struct.pack('<QQQ',offset,0,0))
 for i,block in enumerate(blocks):struct.pack_into('<QQ',data,16+i*16,100+i,block)
 header=bytearray(180);header[40:56]=bytes(range(16));ebx=bytearray(64);ebx[:4]=b'RIFF';ebx[32:48]=b'c'*16
 import uuid
 guid=str(uuid.UUID(bytes_le=bytes(header[40:56])));bundle='owned'
 def row(kind,name,guid='none'):return [bundle,name,str(kind),name,guid,'180','2016875820','0','0','1','1']
 rows=[row(1,'x/textures/rg_dirt_carrier_basecolor_0'),row(0,'x/textures/rg_dirt_carrier_basecolor_0_ebx'),row(2,'pixels',guid),row(1,'levels/game/dingolevel_reskate_test/x/shaderblockdepot_1')]
 payloads={rows[0][1]:bytes(header),rows[1][1]:bytes(ebx),rows[2][1]:b'old',rows[3][1]:bytes(data)}
 # A duplicate surface base-colour key is not ambiguous when its file GUID differs.
 (p/'normalized/legacy.mask').write_bytes(mask)
 rec={'pixel_texture_mask':{'file':'normalized/legacy.mask','sha256':hashlib.sha256(mask).hexdigest(),'width':2,'height':2},'mask_carrier_texture':'rg_dirt_carrier_basecolor_'}
 changes={}
 apply_private_mask(rows,bundle,lambda r:payloads[r[1]],lambda r,b:changes.update({r[1]:b}),rec,p,{100})
 changed=changes[rows[3][1]];g=records[0]+4+17;w=records[1]+4+17
 assert changed[g:g+32]==b'c'*32 and changed[w:w+32]==b'w'*32
print('PASS: full-map pixel dirt retains floor/probes; private below-map carrier; only selected glass material retargeted')
