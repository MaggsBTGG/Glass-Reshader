import bpy,sys,tempfile,json,zipfile,importlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
import reskate_glass as addon
# Simulate Blender keeping an old preview module while loading a newer add-on root.
pv=importlib.import_module('reskate_glass.preview');pv.PREVIEW_VERSION='0.9.0';pv.refresh=lambda material:None
addon.register();assert pv.PREVIEW_VERSION=='0.11.2'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.mesh.primitive_plane_add();o=bpy.context.object;m=bpy.data.materials.new('Glass');o.data.materials.append(m)
p=m.reskate_glass;p.enabled=True;p.dirt_image=bpy.data.images.load(str((Path(__file__).resolve().parents[2]/'examples/Window_Dirt_RGBA.png')))
p.dirt_strength=1;p.dirt_boost=7.24
assert abs(p.dirt_coverage-7.24)<1e-5
for mode in ['MASK','RGBA']:
 p.dirt_mode=mode
 for value in [0,1,3,7.24,8]:
  p.dirt_coverage=value
  group=next(n.node_tree for n in m.node_tree.nodes if n.get('reskate_glass_preview'))
  assert abs(group.nodes['Dirt coverage'].inputs[1].default_value-value)<1e-5
 p.dirt_coverage=7.24
 with tempfile.TemporaryDirectory() as td:
  archive=Path(td)/'author.zip';assert bpy.ops.reskate_glass.export_authoring(filepath=str(archive))=={'FINISHED'}
  with zipfile.ZipFile(archive) as z:
   record=next(iter(json.loads(z.read('glass-authoring.json'))['materials'].values()));spec=record['dirt_mask' if mode=='MASK' else 'dirt_texture'];assert spec['strength']==1 and abs(spec['boost']-7.24)<1e-5
   diag=json.loads(z.read('glass-diagnostics.json'))['materials']['Glass'];assert diag['preview_version']=='0.11.2'
   assert abs(diag['preview_groups'][0]['math_values']['Dirt coverage']['defaults'][1]-7.24)<1e-5
addon.unregister()
print('PASS: stale-preview module reload, legacy coverage fallback, live direct Multiply value 0..8, both mode exports and actual node diagnostics')
