import copy,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from diagnostic_compat import recognized_support_trees,VS,PS
catalog=json.loads((root/'runtime-diagnostic-hashes.json').read_text())
build={'package_id':'glass-auto-builder-v1','map_id':'glass_author_1234abcd','support':{'map_id':'glass_shader_1234abcd'}}
audit={'patched_assets':[{'asset':VS,'sha256':catalog['vertex_shader_hash']},{'asset':PS,'sha256':catalog['baseline_pixel_hashes'][0]}]}
assert recognized_support_trees(build,audit,catalog)==catalog['variants']
for item in [dict(build,map_id='another_map'),dict(build,support={'map_id':'glass_shader_9876abcd'})]:
    assert recognized_support_trees(item,audit,catalog)==[]
for index in [0,1]:
    wrong=copy.deepcopy(audit);wrong['patched_assets'][index]['sha256']='0'*64
    assert recognized_support_trees(build,wrong,catalog)==[]
print('PASS: known temporary shader catalog restricted to matching build, map/support identity and original shader hashes')
