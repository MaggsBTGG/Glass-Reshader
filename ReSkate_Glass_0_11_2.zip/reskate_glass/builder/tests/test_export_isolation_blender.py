"""City hierarchy, other-scene selection, evaluated geometry and cleanup contracts."""
import bpy,sys,tempfile,json,zipfile
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
import reskate_glass as addon
from reskate_glass.export_isolation import export_object
from reskate_glass.builder.prepare_native import parse_glb,positions
addon.register();bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
source_scene=bpy.context.scene;layer=bpy.context.view_layer
bpy.ops.object.empty_add(location=(100,200,3));parent=bpy.context.object;parent.name='City Parent';parent.rotation_euler[2]=.3
bpy.ops.mesh.primitive_plane_add(size=2);pane=bpy.context.object;pane.name='KAMUROCHO_GBOX_P0059_M00012';pane.parent=parent;pane.location=(2,4,0);pane.scale=(-2,3,1)
base=bpy.data.materials.new('Data linked glass');override=bpy.data.materials.new('Object Override Glass');override.reskate_glass.enabled=True;addon.preview(override)
old_mesh=pane.data;pane.data=bpy.data.meshes.new('Mixed City Mesh');bpy.data.meshes.remove(old_mesh)
pane.data.from_pydata([(-1,-1,0),(1,-1,0),(1,1,0),(-1,1,0),(2,-1,0),(3,-1,0),(3,1,0),(2,1,0)],[],[(0,1,2,3),(4,5,6,7)]);pane.data.update()
uv=pane.data.uv_layers.new(name='City UV')
for i,loop in enumerate(uv.data):loop.uv=[(0,0),(1,0),(1,1),(0,1)][i%4]
frame=bpy.data.materials.new('Opaque Frame')
pane.data.materials.append(base);pane.data.materials.append(frame);pane.data.polygons[1].material_index=1
pane.material_slots[0].link='OBJECT';pane.material_slots[0].material=override
# Empty slots keep their indices; evaluated modifiers must be applied exactly once.
pane.data.materials.append(None)
solid=pane.modifiers.new('Source thickness','SOLIDIFY');solid.thickness=.25
bpy.ops.mesh.primitive_cube_add();child=bpy.context.object;child.name='KAMUROCHO_GBOX_P0074_M00127';child.parent=pane;child.location=(50,0,0)
other_scene=bpy.data.scenes.new('Other City Scene');other=bpy.data.objects.new('Other scene selected mesh',child.data.copy());other_scene.collection.objects.link(other);other.select_set(True,view_layer=other_scene.view_layers[0])
other_layer=source_scene.view_layers.new('Other City Layer');child.select_set(True,view_layer=other_layer)
child.hide_set(True,view_layer=layer);child.select_set(True,view_layer=layer);pane.select_set(True,view_layer=layer);layer.objects.active=pane
bpy.context.view_layer.update()

def snapshot():
 return {'scene':bpy.context.scene,'layer':bpy.context.view_layer,'active':layer.objects.active,
  'selection':{(s.name,v.name,o.name):o.select_get(view_layer=v) for s in bpy.data.scenes for v in s.view_layers for o in v.objects},
  'objects':set(bpy.data.objects),'meshes':set(bpy.data.meshes),'scenes':set(bpy.data.scenes),
  'parent':pane.parent,'matrix':[list(r) for r in pane.matrix_world],
  'slots':[(slot.link,slot.material) for slot in pane.material_slots],
  'modifiers':[(m.name,m.type) for m in pane.modifiers]}
original=snapshot();dg=bpy.context.evaluated_depsgraph_get();evaluated=pane.evaluated_get(dg);reference=evaluated.to_mesh(preserve_all_data_layers=True,depsgraph=dg)
expected=[evaluated.matrix_world@v.co for v in reference.vertices];evaluated.to_mesh_clear()
expected=[(p.x,p.z,-p.y) for p in expected]
with tempfile.TemporaryDirectory() as td:
 root=Path(td)
 # Run the previous selection-only export against this multi-scene fixture.
 for obj in layer.objects:obj.select_set(False,view_layer=layer)
 pane.select_set(True,view_layer=layer);layer.objects.active=pane
 bpy.ops.export_scene.gltf(filepath=str(root/'legacy.glb'),export_format='GLB',use_selection=True,export_apply=True,export_materials='EXPORT',export_yup=True)
 old,_=parse_glb((root/'legacy.glb').read_bytes());legacy_names=[n.get('name') for n in old['nodes'] if 'mesh' in n]
 print('PREVIOUS_SELECTION_ONLY_MESHES',legacy_names)
 # Restore the test's original user selections before checking the new route.
 for (s,v,n),value in original['selection'].items():bpy.data.objects[n].select_set(value,view_layer=bpy.data.scenes[s].view_layers[v])
 assert snapshot()==original
 export_object(bpy.context,pane,root/'isolated.glb')
 assert snapshot()==original,'source state or temporary datablocks leaked'
 doc,raw=parse_glb((root/'isolated.glb').read_bytes());assert [n.get('name') for n in doc['nodes'] if 'mesh' in n]==[pane.name]
 exported=[p for points,indices,uv in positions(doc,raw,True) for p in points]
 for point in exported:assert min(sum((point[i]-q[i])**2 for i in range(3)) for q in expected)<1e-8
 for point in expected:assert min(sum((point[i]-q[i])**2 for i in range(3)) for q in exported)<1e-8
 assert {m['name'] for m in doc['materials']}=={override.name,frame.name}
 assert all(entry[2] is not None for entry in positions(doc,raw,True))
 # An exporter error must clean up and return the exact original scene and selection.
 def fail(**kwargs):
  assert kwargs['use_active_scene'] is True
  assert len([o for o in bpy.context.scene.objects if o.type=='MESH'])==1
  assert pane.name not in bpy.context.scene.objects
  raise RuntimeError('Injected export failure')
 try:export_object(bpy.context,pane,root/'failed.glb',fail)
 except RuntimeError as e:assert 'Injected export failure' in str(e)
 else:raise AssertionError('Injected failure was swallowed')
 assert snapshot()==original,'failure did not restore source state'
 # Returning to a non-default source view layer must not select the first layer.
 bpy.context.window.view_layer=other_layer;alternate=snapshot()
 export_object(bpy.context,pane,root/'other_layer.glb')
 assert snapshot()==alternate
 bpy.context.window.view_layer=layer
 # The complete authoring operator also preserves the other scenes/layers.
 assert bpy.ops.reskate_glass.export_authoring(filepath=str(root/'author.zip'))=={'FINISHED'}
 assert snapshot()==original
 with zipfile.ZipFile(root/'author.zip') as z:
  manifest=json.loads(z.read('glass-authoring.json'));assert len(manifest['objects'])==1
  doc,_=parse_glb(z.read(manifest['objects'][0]['mesh']));assert [n.get('name') for n in doc['nodes'] if 'mesh' in n]==[pane.name]
  assert manifest['objects'][0]['material_slots'][2] is None
addon.unregister()
print('PASS: other scenes/view layers and parented meshes isolated; evaluated negative-scale geometry/world placement and UVs retained; object material override/empty slot preserved; successful and failing exports restore exact source state')
