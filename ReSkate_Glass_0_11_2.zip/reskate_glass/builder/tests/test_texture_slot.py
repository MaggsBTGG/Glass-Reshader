from pathlib import Path
import re,struct
root=Path(__file__).resolve().parents[1]
for prefix,folder in [('pixel','PixelDirt'),('rgba','RGBADirt'),('boost_mask','PixelDirtBoost'),('boost_rgba','RGBADirtBoost')]:
 for i in [6,7,8,9]:
  s=(root/f'shader_source/{prefix}_ps_{i}.ll').read_text()
  sample=next(l for l in s.splitlines() if '%pixelSample = call' in l)
  handle=re.findall(r'%dx.types.Handle %(\d+)',sample)[0]
  definition=next(l for l in s.splitlines() if l.lstrip().startswith('%'+handle+' = call %dx.types.Handle @dx.op.createHandle'))
  assert ', i32 33, i1 false)' in definition,(prefix,i,definition)
  sampler=re.findall(r'%dx.types.Handle %(\d+)',sample)[1]
  assert any(l.lstrip().startswith('%'+sampler+' = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3,') for l in s.splitlines())
print('PASS: all sixteen pixel dirt shader paths sample t33 using their original sampler handle')
