import bpy,sys,json,zipfile,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[3]));import reskate_glass as addon;addon.register()
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.mesh.primitive_plane_add();pane=bpy.context.object;pane.name='Pane'
m=bpy.data.materials.new('Glass');pane.data.materials.append(m);m.reskate_glass.enabled=True
im=bpy.data.images.load(str((Path(__file__).resolve().parents[2]/'examples/Window_Dirt_RGBA.png')))
p=m.reskate_glass;p.dirt_image=im;p.dirt_strength=1;p.dirt_boost=7
m.use_nodes=True
for target in ['CYCLES','EEVEE']:
 out=m.node_tree.nodes.new('ShaderNodeOutputMaterial');out.target=target;out.is_active_output=True
addon.preview(m)
for out in m.node_tree.nodes:
 if out.type=='OUTPUT_MATERIAL' and out.is_active_output:assert out.inputs['Surface'].links[0].from_node.get('reskate_glass_preview')
# Hidden selected objects must not leak into the single-pane GLB, and selection is restored.
bpy.ops.mesh.primitive_cube_add();hidden=bpy.context.object;hidden.name='Hidden unrelated';hidden.select_set(True);hidden.hide_set(True)
pane.select_set(True);bpy.context.view_layer.objects.active=pane
before={o.name:o.select_get() for o in bpy.context.view_layer.objects}
from reskate_glass.builder.prepare_native import parse_glb,prepare
with tempfile.TemporaryDirectory() as td:
 root=Path(td)
 for mode in ['MASK','RGBA']:
  p.dirt_mode=mode;addon.preview(m);a=root/(mode+'.zip')
  assert bpy.ops.reskate_glass.export_authoring(filepath=str(a))=={'FINISHED'}
  assert before=={o.name:o.select_get() for o in bpy.context.view_layer.objects}
  with zipfile.ZipFile(a) as z:
   doc=json.loads(z.read('glass-authoring.json'));r=next(iter(doc['materials'].values()));mask=r['dirt_texture' if mode=='RGBA' else 'dirt_mask']
   assert mask['boost']==7
   assert z.read(mask['file'])[0]==54
   glb,_=parse_glb(z.read('mesh_0000.glb'));assert [n['name'] for n in glb['nodes'] if 'mesh' in n]==['Pane']
   diag=json.loads(z.read('glass-diagnostics.json'));assert diag['materials']['Glass']['boost']==7
  prepare(a,root/mode,True);r=json.loads((root/mode/'glass-build-recipe.json').read_text());assert r['material_pipeline'] and r['objects'][0]['pixel_strength']==7 and len(r['pixel_materials'])==1
 p.preview_test='COLOR';g=next(n.node_tree for n in m.node_tree.nodes if n.get('reskate_glass_preview'));assert 'Dirt inspection' in g.nodes
 p.preview_test='GLASS';g=next(n.node_tree for n in m.node_tree.nodes if n.get('reskate_glass_preview'));assert 'Dirt inspection' not in g.nodes
addon.unregister()
print('PASS: hidden-selection isolation/restoration, all engine outputs, mask color-space match, gain 7 export/recipe, diagnostics and preview tests')
