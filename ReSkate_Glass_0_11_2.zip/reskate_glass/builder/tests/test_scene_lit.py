from pathlib import Path
import hashlib,json,struct,re
root=Path(__file__).resolve().parents[1]
def chunks(path):
    data=path.read_bytes();out={}
    for i in range(struct.unpack_from('<I',data,28)[0]):
        offset=struct.unpack_from('<I',data,32+i*4)[0];size=struct.unpack_from('<I',data,offset+4)[0]
        out[data[offset:offset+4]]=data[offset+8:offset+8+size]
    return out
reference=json.loads((root/'scene-lit-runtime-reference.json').read_text())
for name,sha in reference.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
for prefix,folder in [('pixel','PixelDirt'),('rgba','RGBADirt'),('boost_mask','PixelDirtBoost'),('boost_rgba','RGBADirtBoost')]:
    for i in [6,7,8,9]:
        source=(root/f'shader_source/{prefix}_ps_{i}.ll').read_text()
        sample=next(line for line in source.splitlines() if '%pixelSample = call' in line)
        assert '@dx.op.sampleLevel.f32(i32 62,' in sample
        assert sample.endswith('float 0.000000e+00)')
        assert '%verify' not in source and '%compareExposed' not in source and '%rawDisplay' not in source
        for c in 'rgb':
            assert re.search(rf'%dirtSceneLit{c} = fmul float %dirtGrey{c}, %\d+',source)
            assert re.search(rf'%dirtExposed{c} = fmul float %dirtSceneLit{c}, %\d+',source)
        assert ('%pixelBoostStrength = fmul float %dirtStrength, 8.000000e+00' in source)==prefix.startswith('boost_')
        if prefix in ['rgba','pixel']:assert '%pixelDirt = fmul float %dirtStrength, %pixelMask' in source
        revised=chunks(root/f'shaders/{folder}/ps_{i}.dxil');native=chunks(root/f'shaders/Universal/ps_{i}.dxil')
        assert all(revised[k]==native[k] for k in [b'ISG1',b'OSG1'])
        old=(root/f'shader_source/dirt_ps_{i}.ll').read_text()
        assert source[source.index('!llvm.ident'):]==old[old.index('!llvm.ident'):]
print('PASS: exact eight runtime-reference RGBA shaders; sixteen lit pixel paths, saved gain modes, mip-0 sampling, unchanged signatures/metadata, no diagnostic overlays')
