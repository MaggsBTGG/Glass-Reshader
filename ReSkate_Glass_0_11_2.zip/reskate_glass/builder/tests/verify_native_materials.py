"""Verify copy-on-write bindings in a compiled and locally repacked native fixture.
Usage: python verify_native_materials.py JOB HELPER [GAME_ROOT]
Analysis on Linux requires GLASS_ANALYSIS_DECODER; never package that decoder.
"""
import hashlib,json,struct,sys,subprocess,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from patch_native import Decoder
from material_depot import MaterialDepot
from pixel_dirt import material_texture_positions

def verify(job,helper,game_root=''):
 job=Path(job);recipe=json.loads((job/'normalized/glass-build-recipe.json').read_text());mapid=recipe['map_id'];decoder=Decoder(game_root)
 def load(root):
  c1=(root/'Win32/configurations/layout/initialinstallpackage/cas_01.cas').read_bytes();c2=(root/'Win32/configurations/layout/defaultinstallpackage/cas_01.cas').read_bytes()
  toc=root/f'Win32/levels/game/dingolevel_reskate_{mapid}/dingolevel_reskate_{mapid}.toc'
  rows=[s.split('\t') for s in subprocess.check_output([str(helper),'list',str(toc),str(root/'Win32/configurations/layout/initialinstallpackage/cas_01.cas'),str(root/'Win32/configurations/layout/defaultinstallpackage/cas_01.cas')],text=True).splitlines()]
  def read(r):
   source=c2 if r[6]=='2016875820' else c1
   return decoder.decode(source[int(r[7]):int(r[7])+int(r[8])])
  depotrow=next(r for r in rows if '/shaderblockdepot_' in r[3] and r[9]=='1')
  return rows,read,read(depotrow),bytes.fromhex(depotrow[11])
 before,read_before,original,oldmeta=load(job/'compiled/Patch');after,read_after,patched,newmeta=load(job/'playable/payload')
 old=MaterialDepot(original,oldmeta);new=MaterialDepot(patched,newmeta);groups={};target_keys=set()
 for obj in recipe['objects']:
  row=next(r for r in before if r[2]=='1' and '/meshes/'+obj['object']+'_' in r[3]);mesh=read_before(row)
  lod=struct.unpack_from('<Q',mesh,48)[0]+16;section=struct.unpack_from('<Q',mesh,lod+12)[0]+16;key=struct.unpack_from('<Q',mesh,section+312)[0]
  groups.setdefault(obj['material_id'],set()).add(key);target_keys.add(key)
 blocks={};hashes={}
 for mid,keys in groups.items():
  spec=recipe['pixel_materials'][mid];blocks[mid]={new.entries[k][1] for k in keys};hashes[mid]={new.entries[k][3] for k in keys}
  headerrow=next(r for r in after if r[2]=='1' and '/textures/'+spec['carrier_texture'] in r[3]);assetrow=next(r for r in after if r[2]=='0' and '/textures/'+spec['carrier_texture'] in r[3])
  header=read_after(headerrow);guid=str(uuid.UUID(bytes_le=header[40:56]));chunkrow=next(r for r in after if r[2]=='2' and r[4]==guid);pixels=read_after(chunkrow)
  assert hashlib.sha256(pixels).hexdigest()==spec['sha256']
  assert struct.unpack_from('<HH',header,22)==(spec['width'],spec['height'])
  fileguid=read_after(assetrow)[32:48]
  for key in keys:
   offset=material_texture_positions(patched,{key},table_end=16+new.count*16)[0]
   assert patched[offset:offset+16]==fileguid
 for a in groups:
  for b in groups:
   if a!=b:assert blocks[a].isdisjoint(blocks[b]) and hashes[a].isdisjoint(hashes[b])
 untouched=0
 for key,entry in old.entries.items():
  if key in target_keys:continue
  assert new.entries[key]==entry;start,identity,length=entry[2:]
  assert original[start:start+length]==patched[start:start+length];untouched+=1
 # Original storage is unchanged apart from table pointers for selected glass keys.
 allowed={byte for key in target_keys for byte in range(old.entries[key][0]+8,old.entries[key][0]+16)}
 assert all(original[i]==patched[i] for i in range(old.size) if i not in allowed)
 result={'map_id':mapid,'panes':len(recipe['objects']),'authored_materials':len(groups),'original_glass_blocks':len({old.entries[k][1] for k in target_keys}),'private_glass_blocks':len(set.union(*blocks.values())),'unchanged_other_keys':untouched,'texture_payload_hashes':'passed','relocations_and_metadata':'passed','original_parameter_storage':'unchanged','in_game_validated':False}
 print(json.dumps(result,indent=2));return result
if __name__=='__main__':verify(*sys.argv[1:])
