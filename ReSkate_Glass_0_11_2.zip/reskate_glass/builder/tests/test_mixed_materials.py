"""Glass-only replacement must retain opaque sections of the same source object."""
from pathlib import Path
import sys,json,zipfile,hashlib,struct,tempfile,copy
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from prepare_native import parse_glb,write_glb,prepare
from prepare_full_map import merge
base=Path(__file__).resolve().parents[1];profiles=json.loads((base/'profiles.json').read_text())
doc,binary=parse_glb(write_glb([(0,0,0),(2,0,0),(0,2,0)],[0,1,2]))
# glTF material indices intentionally differ from Blender material slot order.
primitive=doc['meshes'][0]['primitives'][0]
doc['materials']=[{'name':'GlassB'},{'name':'Frame'},{'name':'GlassA'}]
doc['meshes'][0]['primitives']=[dict(primitive,material=i) for i in [1,2,0]]
j=json.dumps(doc).encode();j+=b' '*(-len(j)%4)
glb=struct.pack('<4sII',b'glTF',2,28+len(j)+len(binary))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(binary),0x004e4942)+binary
manifest={'schema':1,'kind':'reskate-glass-authoring','objects':[{'name':'WindowFrame','mesh':'mixed.glb','material_slots':[None,'a','b',None,None,'a'],'material_slot_names':['Frame','GlassA','GlassB',None,'Unused','GlassA']}], 'materials':{'a':{'settings':profiles['Balanced']},'b':{'settings':profiles['Rough']}},'files':{'mixed.glb':hashlib.sha256(glb).hexdigest()}}
with tempfile.TemporaryDirectory() as td:
 p=Path(td);zpath=p/'author.zip'
 with zipfile.ZipFile(zpath,'w') as z:z.writestr('glass-authoring.json',json.dumps(manifest));z.writestr('mixed.glb',glb)
 prepare(zpath,p/'isolated');recipe=json.loads((p/'isolated/glass-build-recipe.json').read_text())
 assert len(recipe['objects'])==2
 assert recipe['objects'][0]['source_material_slots']==[1,5] and recipe['objects'][0]['settings']==profiles['Balanced']
 assert recipe['objects'][1]['source_material_slots']==[2] and recipe['objects'][1]['settings']==profiles['Rough']
 original=p/'base';original.mkdir();(original/'section.glb').write_bytes(glb)
 rows=[{'name':f'piece_{i}','source_object':'WindowFrame','source_material_slot':i,'mesh':'section.glb','material':m,'collision_mode':'triangle_mesh','collision_mesh':'section.glb','transform':[1,0,0,0,1,0,0,0,1,0,0,0]} for i,m in enumerate(['frame','a','b'])]
 base_doc={'format':1,'name':'mixed_test','units':'meters','up':'y','forward':'-z','objects':rows,'materials':{'frame':{'texture':'frame.png'}},'spawn':{'position':[0,2,0]}}
 (original/'map.json').write_text(json.dumps(base_doc));merge(original,zpath,p/'combined')
 result=json.loads((p/'combined/map.json').read_text())
 assert result['objects'][0]==rows[0], 'opaque frame was changed'
 assert len(result['objects'])==5
 assert sum(r.get('render') is False for r in result['objects'])==2
 assert [r['source_material_slot'] for r in result['objects'] if r.get('render') is False]==[1,2]
 assert result['materials']['frame']==base_doc['materials']['frame']
 # Never replace all of an object when stock material-slot metadata is missing.
 bad=copy.deepcopy(base_doc);bad['objects'][1].pop('source_material_slot');(original/'map.json').write_text(json.dumps(bad))
 try:merge(original,zpath,p/'refused')
 except ValueError as e:assert 'source material slot' in str(e)
 else:raise AssertionError('Missing source-slot metadata accepted')
 assert not (p/'refused').exists()
print('PASS: reordered glTF materials, mixed presets, unused/empty/duplicate slots, opaque frame retained, collision retained, ambiguous mapping refused')
