"""Pixel dirt must keep every original shader input/output signature."""
from pathlib import Path
import struct,re,sys,math
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from pixel_dirt import pack_uv,unpack_uv

def chunks(path):
 b=path.read_bytes();assert b[:4]==b'DXBC';result={}
 for i in range(struct.unpack_from('<I',b,28)[0]):
  off=struct.unpack_from('<I',b,32+4*i)[0];n=struct.unpack_from('<I',b,off+4)[0]
  result[b[off:off+4]]=b[off+8:off+8+n]
 return result

for name in ['vs']+[f'ps_{i}' for i in [6,7,8,9]]:
 original=root/'shaders'/('vs.dxil' if name=='vs' else 'Universal/'+name+'.dxil')
 revised=root/'shaders/RGBADirt'/(name+'.dxil')
 a,b=chunks(original),chunks(revised)
 for tag in [b'ISG1',b'OSG1']:
  assert a[tag]==b[tag],(name,tag)
 old=(root/'shader_source'/('dirt_'+name+'.ll')).read_text();new=(root/'shader_source'/(('pixel_' if name=='vs' else 'rgba_')+name+'.ll')).read_text()
 assert old[old.index('!llvm.ident'):]==new[new.index('!llvm.ident'):],name
 assert not re.search(r'loadInput[^\n]*i32 4, i32 '+('[36]' if name=='vs' else '6')+',',new),name
for uv in [(-16,-16),(-3.25,1.75),(0,0),(1,1),(16,16),(.1234,.9876)]:
 out=unpack_uv(pack_uv(uv));assert max(abs(x-y) for x,y in zip(uv,out))<=32/65535/2+1e-12
 # Model the actual UNORM8 vertex input and float32 shader arithmetic.
 bytes_=pack_uv(uv);f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
 decoded=[]
 for lo,hi in [bytes_[:2],bytes_[2:]]:
  packed=f32(f32(f32(lo/255)*255)+f32(f32(hi/255)*65280))
  decoded.append(f32(f32(packed*f32(32/65535))-16))
 assert max(abs(x-y) for x,y in zip(uv,decoded))<.00025
for uv in [(float('nan'),0),(17,0),(-17,0)]:
 try:pack_uv(uv)
 except ValueError:pass
 else:raise AssertionError('Invalid UV accepted')
print('PASS: exact input/output signature bytes and binding metadata for all five shaders; packed UV CPU/shader round trips')
