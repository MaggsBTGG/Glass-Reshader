from pathlib import Path
import importlib.util,json
spec=importlib.util.spec_from_file_location('build_status',Path(__file__).resolve().parents[2]/'build_status.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=Path(m.begin())
try:
 try:m.begin()
 except ValueError:pass
 else:raise AssertionError('Concurrent build accepted')
 assert m.refresh()
 p.write_text('{');assert m.refresh()
 p.write_text(json.dumps({'status':'running','stage':'Compiling','job':'test'}),encoding='utf-8-sig');assert m.refresh();assert m.STATE['stage']=='Compiling'
 p.write_text(json.dumps({'status':'ready','stage':'Ready','package':'test.zip'}));assert not m.refresh();assert m.STATE['package']=='test.zip'
 p.unlink();p=Path(m.begin())
 p.write_text(json.dumps({'status':'installed','stage':'Map and glass support installed'}));assert not m.refresh();assert m.STATE['status']=='installed'
 p.unlink();p=Path(m.begin())
 class Closed:
  def poll(self):return 1
 m.PROCESS=Closed();assert not m.refresh();assert m.STATE['status']=='failed'
finally:p.unlink(missing_ok=True)
print('PASS: build progress, BOM results, concurrent-build refusal, and closed-window detection')
