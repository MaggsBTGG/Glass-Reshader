from pathlib import Path
import sys, tempfile, zipfile, json, hashlib
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from package_checks import check_package, SUPPORTED_GAME
with tempfile.TemporaryDirectory() as td:
 p=Path(td)
 for folder in ['payload','shader-support']:
  (p/folder).mkdir();(p/folder/'layout.toc').write_bytes(b'fixture')
  (p/folder/'.reskate-studio-patch').write_text('ReSkate Studio native Patch v1\nskate_sha256='+SUPPORTED_GAME+'\n')
 (p/'payload/reskate-levels.json').write_text('{"levels":[]}')
 def tree(name):return {f.relative_to(p/name).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in (p/name).rglob('*') if f.is_file()}
 def stamp():
  spec={'package_id':'glass-auto-builder-v1','map_id':'glass_author_12345678','modes':{'Compare':tree('payload')},'support':{'map_id':'glass_shader_12345678','hashes':tree('shader-support')}}
  (p/'validation.json').write_text(json.dumps(spec))
 def refused():
  try:check_package(p)
  except (ValueError, FileNotFoundError):return
  raise AssertionError('Broken package was accepted')
 stamp();assert check_package(p)
 marker=p/'shader-support/.reskate-studio-patch';good=marker.read_bytes();marker.unlink();stamp();refused()
 marker.write_text('skate_sha256='+'0'*64+'\n');stamp();refused()
 marker.write_bytes(good);stamp();(p/'payload/layout.toc').write_bytes(b'bad');refused()
 (p/'payload/layout.toc').write_bytes(b'fixture');(p/'shader-support/reskate-levels.json').write_text('{}');stamp();refused()
print('PASS: final package refuses missing/wrong game stamp, corruption, and support level registration')
