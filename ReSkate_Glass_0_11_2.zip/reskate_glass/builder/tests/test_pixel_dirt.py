from pathlib import Path
import sys,tempfile,json,zipfile,struct,hashlib,math
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from prepare_native import write_glb,prepare,parse_glb,positions
from pixel_dirt import rgba_mips,texture_payload,bind_mask,texture_reference,FLOOR_TEXTURE_KEY,WATER_TEXTURE_KEY
base=Path(__file__).resolve().parents[1]
# Pixel masks retain the original triangle count and UVs, including tiled coordinates.
points=[(0,0,0),(2,0,0),(0,2,0)];uv=[(-1,.25),(2,.25),(-1,2.25)]
glb=write_glb(points,[0,1,2],uv);profiles=json.loads((base/'profiles.json').read_text());mask=bytes([0,64,128,255])
manifest={'schema':1,'kind':'reskate-glass-authoring','objects':[{'name':'pane','mesh':'pane.glb','material_slots':['a']}],'materials':{'a':{'settings':profiles['Balanced'],'dirt_mask':{'file':'mask','width':2,'height':2,'strength':1,'sha256':hashlib.sha256(mask).hexdigest()}}},'files':{'pane.glb':hashlib.sha256(glb).hexdigest()}}
with tempfile.TemporaryDirectory() as td:
 p=Path(td);zpath=p/'source.zip'
 with zipfile.ZipFile(zpath,'w') as z:z.writestr('glass-authoring.json',json.dumps(manifest));z.writestr('pane.glb',glb);z.writestr('mask',mask)
 prepare(zpath,p/'normalized',pixel_dirt=True);recipe=json.loads((p/'normalized/glass-build-recipe.json').read_text());o=recipe['objects'][0]
 assert o['dirt_samples'] is None and o['pixel_strength']==1
 d,b=parse_glb((p/'normalized/meshes/glass_000000.glb').read_bytes());pts,idx,exported_uvs=positions(d,b,with_uv=True)[0]
 assert len(pts)==3 and exported_uvs==[tuple(v) for v in uv]
 spec=next(iter(recipe['pixel_materials'].values()))
 assert spec['mode']=='MASK' and spec['coverage']==1
 assert (p/spec['file']).is_file()
# Rows flip to native top-down, and all mip bytes and dimensions agree.
raw,sizes=rgba_mips(mask,2,2);assert raw[:8]==bytes([128,128,128,255,255,255,255,255]);assert sizes==[16,4] and len(raw)==20
header=bytearray(180);new,data=texture_payload(header,mask,2,2)
assert struct.unpack_from('<I',new,12)[0]==18 and new[30]==2 and new[31]==0 and struct.unpack_from('<I',new,116)[0]==len(data)
assert sum(struct.unpack_from('<15I',new,56))==len(data)
# Retarget only the external reference value, preserving all key/type/layout bytes.
def entry(key,value):return struct.pack('<QIHHB',key,0x14c5fc30,1,0,1)+value
old=entry(WATER_TEXTURE_KEY,b'a'*32)+entry(FLOOR_TEXTURE_KEY,b'b'*32)
changed=bind_mask(old);a=texture_reference(changed,WATER_TEXTURE_KEY);assert changed[a:a+32]==b'b'*32 and changed[49:]==old[49:]
for profile in range(52,57):
 for q in range(32):
  v=struct.unpack('<e',struct.pack('<e',profile+q/32))[0]
  assert math.floor(v)==profile and v-profile==q/32
print('PASS: per-pixel UV preservation without subdivision, texture/mip layout, reference-only material edit and exact marker transport')
