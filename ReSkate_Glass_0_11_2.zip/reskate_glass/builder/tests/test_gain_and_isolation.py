from pathlib import Path
import sys,struct,json,tempfile,zipfile,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from dirt_bake import encode_marker,sample
from prepare_native import write_glb,parse_glb,prepare
root=Path(__file__).resolve().parents[1]
def chunks(path):
 b=path.read_bytes();out={}
 for i in range(struct.unpack_from('<I',b,28)[0]):
  off=struct.unpack_from('<I',b,32+4*i)[0];n=struct.unpack_from('<I',b,off+4)[0];out[b[off:off+4]]=b[off+8:off+8+n]
 return out
for mode,folder,original in [('mask','PixelDirtBoost','PixelDirt'),('rgba','RGBADirtBoost','RGBADirt')]:
 for i in [6,7,8,9]:
  a,b=chunks(root/f'shaders/{folder}/ps_{i}.dxil'),chunks(root/f'shaders/{original}/ps_{i}.dxil')
  assert all(a[k]==b[k] for k in [b'ISG1',b'OSG1'])
  src=(root/f'shader_source/boost_{mode}_ps_{i}.ll').read_text()
  old=(root/f'shader_source/{"pixel" if mode=="mask" else "rgba"}_ps_{i}.ll').read_text()
  assert src[src.index('!llvm.ident'):]==old[old.index('!llvm.ident'):]
for strength in [0,.6,1,3,5,7,8]:
 transported=(encode_marker(42,strength/8)-42)*32/31*8
 assert abs(transported-strength)<=8/31/2+1e-10
 for alpha in [0,.13,.44,1]:
  coverage=min(1,alpha*transported)
  rgb=.4*alpha
  out=rgb*coverage/max(alpha,1e-6)
  assert 0<=out<=.4+1e-10
  assert alpha!=0 or out==0
assert sample(bytes([255]),1,1,.5,.5,7)==1
# A contaminated per-object GLB must stop instead of duplicating unrelated panes.
glb=write_glb([(0,0,0),(1,0,0),(0,1,0)],[0,1,2],[(0,0),(1,0),(0,1)])
d,b=parse_glb(glb);d['nodes']=[{'mesh':0,'name':'Pane'},{'mesh':0,'name':'Other'}];d['scenes'][0]['nodes']=[0,1]
j=json.dumps(d).encode();j+=b' '*(-len(j)%4)
glb=struct.pack('<4sII',b'glTF',2,28+len(j)+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b
with tempfile.TemporaryDirectory() as td:
 p=Path(td);a=p/'bad.zip'
 m={'schema':1,'kind':'reskate-glass-authoring','objects':[{'name':'Pane','mesh':'pane.glb','material_slots':['a']}], 'materials':{'a':{'settings':json.loads((root/'profiles.json').read_text())['Balanced']}},'files':{'pane.glb':hashlib.sha256(glb).hexdigest()}}
 with zipfile.ZipFile(a,'w') as z:z.writestr('glass-authoring.json',json.dumps(m));z.writestr('pane.glb',glb)
 try:prepare(a,p/'output',True)
 except ValueError as e:assert 'contains other mesh objects' in str(e)
 else:raise AssertionError('Extra mesh silently imported')
print('PASS: gain shader signatures, bounded coverage/color, marker precision, vertex clamp and contaminated GLB refusal')
