import bpy,sys,importlib,math,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
import reskate_glass as addon
addon.register()
m=bpy.data.materials.new('Preview Test');m.use_nodes=True;old_names=set(n.name for n in m.node_tree.nodes);m.reskate_glass.enabled=True
mask=bpy.data.images.new('Test mask',width=2,height=2);mask.pixels=[0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,1]
colour_space=mask.colorspace_settings.name
m.reskate_glass.dirt_image=mask;m.reskate_glass.dirt_strength=.8;addon.preview(m)
g=next(n for n in m.node_tree.nodes if n.get('reskate_glass_preview')).node_tree
assert any(n.type=='TEX_IMAGE' and n.image==mask for n in g.nodes)
assert old_names.issubset(set(n.name for n in m.node_tree.nodes))
assert mask.colorspace_settings.name==colour_space
assert m.surface_render_method=='DITHERED'
copy=m.copy();old=g;copy.reskate_glass.roughness=.4
new=next(n for n in copy.node_tree.nodes if n.get('reskate_glass_preview')).node_tree
assert new!=old and new.nodes['Dirty roughness'].inputs[0].default_value>.39
assert old.nodes['Dirty roughness'].inputs[0].default_value<.1
print('PASS: live dirt nodes, dithered transparency, artist nodes retained, source image unchanged, independent copied materials')
