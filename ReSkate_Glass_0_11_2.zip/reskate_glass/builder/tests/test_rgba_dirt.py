from pathlib import Path
import sys,hashlib,json,tempfile,zipfile,struct
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from pixel_dirt import color_mips,texture_payload
from prepare_native import prepare,write_glb
# Top-down flip and premultiplication: transparent red cannot bleed into opaque blue.
rgba=bytes([255,0,0,0,0,0,255,255,0,255,0,128,255,255,255,255])
data,sizes=color_mips(rgba,2,2)
assert list(data[:8])==[0,128,0,128,255,255,255,255]
assert list(data[8:16])==[0,0,0,0,0,0,255,255]
assert list(data[16:])==[64,96,128,160]
odd,sizes=color_mips(bytes([255,255,255,255]*3),3,1);assert sizes==[12,4] and odd[-4:]==bytes([255]*4)
header=bytes(180);changed,pixels=texture_payload(header,rgba,2,2,'linear-rgba8');assert struct.unpack_from('<I',changed,12)[0]==18 and pixels==data
# An RGBA authoring package must select the new shaders without disturbing clean panes.
glb=write_glb([(0,0,0),(2,0,0),(0,2,0)],[0,1,2],[(0,0),(1,0),(0,1)])
settings=json.loads((Path(__file__).resolve().parents[1]/'profiles.json').read_text())['Balanced']
with tempfile.TemporaryDirectory() as td:
 p=Path(td);a=p/'a.zip'
 mask={'file':'color.rgba','width':2,'height':2,'strength':.6,'encoding':'linear-rgba8','sha256':hashlib.sha256(rgba).hexdigest()}
 manifest={'schema':1,'kind':'reskate-glass-authoring','objects':[{'name':'Pane','mesh':'pane.glb','material_slots':['a']}], 'materials':{'a':{'settings':settings,'dirt_texture':mask}},'files':{'pane.glb':hashlib.sha256(glb).hexdigest()}}
 with zipfile.ZipFile(a,'w') as z:
  z.writestr('glass-authoring.json',json.dumps(manifest));z.writestr('pane.glb',glb);z.writestr('color.rgba',rgba)
 prepare(a,p/'normalized',True)
 recipe=json.loads((p/'normalized/glass-build-recipe.json').read_text())
 spec=next(iter(recipe['pixel_materials'].values()))
 assert spec['mode']=='RGBA' and recipe['objects'][0]['pixel_strength']==.6
 assert (p/spec['file']).is_file()
 try:prepare(a,p/'vertex',False)
 except ValueError as e:assert 'Color + Alpha' in str(e)
 else:raise AssertionError('RGBA silently converted to vertex mask')
print('PASS: RGBA alpha/color data, premultiplied filtering/mips, orientation, odd sizes, recipe and vertex-route refusal')
