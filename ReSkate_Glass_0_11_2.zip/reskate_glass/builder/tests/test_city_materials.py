"""City clipping, independent images/settings, shader contracts and private bindings."""
from pathlib import Path
import hashlib,json,math,random,struct,sys,tempfile,uuid,zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from city_materials import payload,decode_parameters,texture_payload
from spatial_glass import pieces,area
from prepare_native import prepare,write_glb,positions,parse_glb
from prepare_full_map import merge
from pixel_dirt import apply_private_materials,WATER_TEXTURE_KEY,FLOOR_TEXTURE_KEY
root=Path(__file__).resolve().parents[1]
a={'reflection_strength':1.3719,'roughness':.2173,'face_opacity':.0371,'edge_opacity':.6731}
b=dict(a,reflection_strength=.117,roughness=.674,face_opacity=.1)
# Metadata is byte-exact float32, remains unpremultiplied; dirt is linear and premultiplied.
rgba=bytes([255,0,0,0,0,0,255,255,0,255,0,128,255,255,255,255])
raw,w,h=payload(a,3.14159,rgba,2,2);assert (w,h)==(6,3)
for k,v in dict(a,coverage=3.14159).items():assert decode_parameters(raw)[k]==struct.unpack('<f',struct.pack('<f',v))[0]
assert raw[w*4:w*4+8]==bytes([0,128,0,128,255,255,255,255])
assert raw[w*8:w*8+8]==bytes([0,0,0,0,0,0,255,255])
head,pixels=texture_payload(bytes(180),raw,w,h);assert pixels==raw and head[30]==1 and struct.unpack_from('<I',head,116)[0]==len(raw)
# Fixed integer texture loads recover every byte after UNORM float conversion.
for value in range(256):
 unorm=struct.unpack('<f',struct.pack('<f',value/255))[0];assert int(unorm*255+.5)==value
# Clipping preserves surface area and affine UVs across negative and positive cell boundaries.
rng=random.Random(113)
triangles=[[(-64,0,-64),(96,0,-64),(-64,0,96)],[(32,0,32),(32,32,32),(32,0,64)]]
triangles += [[tuple(rng.uniform(-120,120) for _ in range(3)) for _ in range(3)] for _ in range(20)]
for tri in triangles:
 uvs=[(p[0]/100+.3,p[2]/100-.2) for p in tri];output=list(pieces(tri,[0,1,2],uvs));total=0
 for pts,indices,uv,origin,cell in output:
  assert len(pts)<=60000 and len(pts)%3==0
  for p,u in zip(pts,uv):
   assert max(abs(p[i]-origin[i]) for i in range(3))<=16.000001
   assert abs(u[0]-(p[0]/100+.3))<1e-8 and abs(u[1]-(p[2]/100-.2))<1e-8
  total+=sum(area(pts[i:i+3]) for i in range(0,len(pts),3))
 assert math.isclose(total,area(tri),rel_tol=1e-9),(total,area(tri))
# Exact cell plane geometry must occur once; 16-bit section budget is enforced.
parts=list(pieces([(32,0,0),(32,10,0),(32,0,10)],[0,1,2]));assert len(parts)==1
parts=list(pieces([(1,1,1),(2,1,1),(1,2,1)],[0,1,2]*20001));assert [len(p[0]) for p in parts]==[60000,3]
# A two-image, mixed-mode city build preserves full world placement and the source map.
with tempfile.TemporaryDirectory() as td:
 p=Path(td);archive=p/'author.zip';files={};objects=[];materials={}
 for i,(settings,x) in enumerate([(a,-640),(b,640)]):
  pts=[(x,1,1),(x+80,1,1),(x,4,1)];glb=write_glb(pts,[0,1,2],[(0,0),(1,0),(0,1)])
  name='pane%d.glb'%i;files[name]=glb;objects.append({'name':'Pane%d'%i,'mesh':name,'material_slots':['m%d'%i]})
  data=rgba if i==0 else bytes([0,255,100,20]);image='dirt%d'%i;files[image]=data
  spec={'file':image,'width':2,'height':2,'strength':.68 if i==0 else .34,'boost':1,'sha256':hashlib.sha256(data).hexdigest()}
  if i==0:spec['encoding']='linear-rgba8'
  materials['m%d'%i]={'settings':settings,'dirt_texture' if i==0 else 'dirt_mask':spec}
 manifest={'schema':1,'kind':'reskate-glass-authoring','objects':objects,'materials':materials,'files':{name:hashlib.sha256(data).hexdigest() for name,data in files.items() if name.endswith('.glb')}}
 with zipfile.ZipFile(archive,'w') as z:
  z.writestr('glass-authoring.json',json.dumps(manifest))
  for name,data in files.items():z.writestr(name,data)
 prepare(archive,p/'isolated',True);r=json.loads((p/'isolated/glass-build-recipe.json').read_text());doc=json.loads((p/'isolated/map.json').read_text())
 assert len(r['pixel_materials'])==2 and len(r['objects'])>2
 sections=[x for x in doc['objects'] if x['name'].startswith('glass_')]
 assert len({tuple(x['native_render_origin']) for x in sections})==len(sections)
 assert len({x['material'] for x in sections})==len(sections)
 assert {s['mode'] for s in r['pixel_materials'].values()}=={'RGBA','MASK'}
 for obj in r['objects']:
  assert obj['pixel_strength']==r['pixel_materials'][obj['material_id']]['coverage']
  pts=positions(*parse_glb((p/'isolated/meshes'/(obj['object']+'.glb')).read_bytes()))[0][0]
  assert max(abs(v[k]-obj['native_render_origin'][k]) for v in pts for k in range(3))<=16
 base=p/'base';base.mkdir();(base/'unchanged.bin').write_bytes(b'opaque geometry')
 rows=[{'name':'Frame','mesh':'unchanged.bin','material':'frame','collision_mode':'triangle_mesh','collision_mesh':'unchanged.bin'}]
 rows += [{'name':'pane%d'%i,'source_object':'Pane%d'%i,'source_material_slot':0,'mesh':'unchanged.bin','collision_mode':'triangle_mesh','collision_mesh':'unchanged.bin'} for i in range(2)]
 src={'format':1,'name':'city','units':'meters','up':'y','forward':'-z','objects':rows,'materials':{'frame':{'domain':'surface'}},'spawn':{'position':[0,2,0]},'lights':[{'name':'KeptLight'}],'reflection_probes':[{'name':'KeptProbe'}]}
 original=json.dumps(src).encode();(base/'map.json').write_bytes(original)
 merge(base,archive,p/'normalized',True);merged=json.loads((p/'normalized/map.json').read_text());recipe=json.loads((p/'normalized/glass-build-recipe.json').read_text())
 assert (base/'map.json').read_bytes()==original and merged['objects'][0]==rows[0]
 assert merged['lights']==src['lights'] and merged['reflection_probes']==src['reflection_probes'] and merged['spawn']==src['spawn']
 assert sum(x.get('render') is False for x in merged['objects'])==2
 assert (p/'normalized/unchanged.bin').read_bytes()==b'opaque geometry'
 # Synthetic native depot with two glass materials, untouched ordinary water and two carriers.
 def tex(k,ref):return struct.pack('<QIHHB',k,0x14c5fc30,1,0,1)+ref
 refs=[b'a'*32,b'b'*32,b'w'*32,b'c'*32,b'd'*32];keys=[100,101,102,103,104]
 depot=bytearray(16+16*len(keys));params=[]
 for index,ref in enumerate(refs):
  params.append(len(depot));depot.extend(struct.pack('<I',1)+tex(WATER_TEXTURE_KEY if index<3 else FLOOR_TEXTURE_KEY,ref))
 depot.extend(bytes(-len(depot)%8));blocks=[]
 for offset in params:blocks.append(len(depot));depot.extend(struct.pack('<QQQ',offset,0,53))
 for i,key in enumerate(keys):struct.pack_into('<QQ',depot,16+16*i,key,blocks[0] if i<3 else blocks[i])
 struct.pack_into('<Q',depot,0,16)
 depot.extend(bytes(-len(depot)%16));data_size=len(depot)
 relocations=[0]+[16+i*16+8 for i in range(5)]+[blocks[0],blocks[3],blocks[4]]
 depot.extend(struct.pack('<%dI'%len(relocations),*relocations))
 metadata=struct.pack('<4I',data_size,len(relocations)*4,0x01190003,5)
 bundle='owned';native_rows=[];values={}
 def row(kind,name,guid='none'):
  r=[bundle,name,str(kind),name,guid,'180','2016875820','0','0','1','1'];native_rows.append(r);return r
 for i,(mid,spec) in enumerate(recipe['pixel_materials'].items()):
  name='x/textures/'+spec['carrier_texture']+'0';guid=uuid.UUID(int=i+1);head=bytearray(180);head[40:56]=guid.bytes_le
  ebx=bytearray(64);ebx[:4]=b'RIFF';ebx[32:48]=refs[3+i][:16]
  values[row(1,name)[1]]=bytes(head);values[row(0,name+'_ebx')[1]]=bytes(ebx);values[row(2,'chunk%d'%i,str(guid))[1]]=b'old'
 depotrow=row(1,'levels/game/dingolevel_reskate_test/x/shaderblockdepot_1');values[depotrow[1]]=bytes(depot);depotrow.append(metadata.hex())
 changes={};mapping={mid:{100+i} for i,mid in enumerate(recipe['pixel_materials'])}
 apply_private_materials(native_rows,bundle,lambda r:values[r[1]],lambda r,b,meta=None:changes.update({r[1]:b}),recipe,p,mapping)
 patched=changes[depotrow[1]]
 from pixel_dirt import material_texture_positions
 for i,expected in enumerate([refs[3],refs[4],refs[0]]):
  offset=material_texture_positions(patched,{100+i},table_end=96)[0];assert patched[offset:offset+32]==expected
 assert patched[params[0]:params[0]+53]==bytes(depot[params[0]:params[0]+53])
 assert len({struct.unpack_from('<Q',patched,16+i*16+8)[0] for i in range(3)})==3
 assert len(changes)==5
 # Refuse material deduplication that would make two configurations share one binding.
 mapping={mid:{100} for mid in recipe['pixel_materials']}
 try:apply_private_materials(native_rows,bundle,lambda r:values[r[1]],lambda *_:None,recipe,p,mapping)
 except ValueError as e:assert 'share a native shader key' in str(e)
 else:raise AssertionError('Cross-material binding accepted')
# Every new shader retains the native input/output signatures and binding metadata.
def chunks(path):
 data=path.read_bytes();result={}
 for i in range(struct.unpack_from('<I',data,28)[0]):
  at=struct.unpack_from('<I',data,32+4*i)[0];size=struct.unpack_from('<I',data,at+4)[0];result[data[at:at+4]]=data[at+8:at+8+size]
 return result
for i in (6,7,8,9):
 new=chunks(root/f'shaders/MaterialGlass/ps_{i}.dxil');old=chunks(root/f'shaders/Universal/ps_{i}.dxil')
 assert all(new[k]==old[k] for k in [b'ISG1',b'OSG1'])
 src=(root/f'shader_source/material_ps_{i}.ll').read_text();ref=(root/f'shader_source/boost_rgba_ps_{i}.ll').read_text()
 assert src[src.index('!llvm.ident'):]==ref[ref.index('!llvm.ident'):]
 assert src.count('%mat_coverage = bitcast')==1 and '%mat_sample_v' in src and '%dirtSceneLitr' in src
print('PASS: lossless material parameters; independent MASK/RGBA images; city clipping/UV/area/vertex budgets; world placement; source/collision/light/probe preservation; scoped native bindings; four shader contracts')
