[CmdletBinding()]
param(
 [ValidateSet('Install','Remove')][string]$Action='Install',
 [ValidateSet('Compare')][string]$Mode='Compare',
 [string]$ModsFolder,
 [string]$WorkFolder=(Join-Path $env:LOCALAPPDATA 'ReSkateGlass\InstallHistory')
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
if (Get-Process -Name 'Skate','ReSkateLauncher' -ErrorAction SilentlyContinue) { throw 'Close skate and ReSkateLauncher before installing/removing this preview.' }
$spec=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'validation.json') -Raw | ConvertFrom-Json
if ($spec.package_id -ne 'glass-auto-builder-v1' -or $spec.map_id -notmatch '^glass_author_[0-9a-f]{8}$') { throw 'Unexpected glass package identity.' }
if ($spec.support.map_id -ne ('glass_shader_'+$spec.map_id.Substring($spec.map_id.Length-8))) { throw 'Unexpected shader support identity.' }
if (-not $ModsFolder) {
 Add-Type -AssemblyName System.Windows.Forms
 $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
 try {
  $dialog.Description='Select the ReSkate Mods folder for this map'
  if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Mods folder selection cancelled.' }
  $ModsFolder=$dialog.SelectedPath
 } finally { $dialog.Dispose() }
}
$ModsFolder=[IO.Path]::GetFullPath($ModsFolder).TrimEnd('\')
$WorkFolder=[IO.Path]::GetFullPath($WorkFolder).TrimEnd('\')
if (-not (Test-Path -LiteralPath $ModsFolder -PathType Container)) { throw 'Mods folder not found.' }
if ($WorkFolder -eq $ModsFolder -or $WorkFolder.StartsWith($ModsFolder+'\',[StringComparison]::OrdinalIgnoreCase) -or $WorkFolder.StartsWith($ModsFolder+'/',[StringComparison]::OrdinalIgnoreCase)) { throw 'Install history must be outside Mods.' }
function Test-Tree([string]$Folder,$Expected) {
 if (-not (Test-Path -LiteralPath $Folder -PathType Container)) { return $false }
 $actual=@(Get-ChildItem -LiteralPath $Folder -Recurse -File -Force)
 $properties=@($Expected.PSObject.Properties)
 if ($actual.Count -ne $properties.Count) { return $false }
 foreach ($property in $properties) {
  $file=Join-Path $Folder $property.Name
  if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { return $false }
  if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $property.Value) { return $false }
 }
 return $true
}
function New-History([string]$Label) {
 New-Item -ItemType Directory -Path $WorkFolder -Force | Out-Null
 return (Join-Path $WorkFolder ($Label+'_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N').Substring(0,8)))
}
$mapKnown=@($spec.modes.PSObject.Properties | ForEach-Object {$_.Value})+@($spec.previous_modes.PSObject.Properties | ForEach-Object {$_.Value})
$supportKnown=@($spec.support.hashes)+@($spec.support.previous_hashes)
$targets=@(
 [pscustomobject]@{id=$spec.support.map_id;source=(Join-Path $PSScriptRoot 'shader-support');expected=$spec.support.hashes;known=$supportKnown;stage=$null;backup=$null;installed=$false},
 [pscustomobject]@{id=$spec.map_id;source=(Join-Path $PSScriptRoot 'payload');expected=$spec.modes.PSObject.Properties[$Mode].Value;known=$mapKnown;stage=$null;backup=$null;installed=$false}
)
foreach ($target in $targets) {
 $folder=Join-Path $ModsFolder $target.id
 if (Test-Path -LiteralPath $folder) {
  $known=$false
  foreach ($tree in $target.known) { if (Test-Tree $folder $tree) { $known=$true;break } }
  if (-not $known) { throw "Installed files were edited or belong to an unknown build; retained untouched: $folder" }
 }
}
if ($Action -eq 'Remove') {
 $moved=New-Object System.Collections.Generic.List[object]
 try {
  foreach ($target in $targets) {
   $folder=Join-Path $ModsFolder $target.id
   if (-not (Test-Path -LiteralPath $folder)) { continue }
   $backup=New-History ('Removed_'+$target.id)
   Move-Item -LiteralPath $folder -Destination $backup
   $moved.Add([pscustomobject]@{original=$folder;backup=$backup})
  }
 } catch {
  foreach ($entry in $moved) { if (-not (Test-Path -LiteralPath $entry.original)) { Move-Item -LiteralPath $entry.backup -Destination $entry.original } }
  throw
 }
 Write-Host 'REMOVED: map and shader support are outside Mods. Their files were retained.'
 return
}
foreach ($target in $targets) {
 if (-not (Test-Tree $target.source $target.expected)) { throw "Package payload failed hash checks: $($target.source)" }
}
if (Test-Path -LiteralPath (Join-Path $targets[0].source 'reskate-levels.json')) { throw 'Shader support must not register a level.' }
$legacy=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'legacy-tests.json') -Raw | ConvertFrom-Json
$toRetire=@{}
foreach ($entry in $legacy) {
 if ($entry.map_id -in $targets.id -or $entry.map_id -notmatch '^(glass_author_[0-9a-f]{8}|glass_shader_[0-9a-f]{8}|km_glass_pass_r4)$') { continue }
 $folder=Join-Path $ModsFolder $entry.map_id
 if (Test-Tree $folder $entry.hashes) { $toRetire[$entry.map_id]=$folder }
}
foreach ($folder in @(Get-ChildItem -LiteralPath $ModsFolder -Directory)) {
 if ($folder.Name -in $targets.id) { continue }
 if ($folder.Name -match '^(glass_author_[0-9a-f]{8}|glass_shader_[0-9a-f]{8}|km_glass_pass_r4)$' -and -not $toRetire.ContainsKey($folder.Name)) { throw "Another diagnostic has unknown/edited files. Move it outside Mods or use its original removal script: $($folder.FullName)" }
}
foreach ($target in $targets) {
 $target.stage=New-History ('Prepared_'+$target.id)
 New-Item -ItemType Directory -Path $target.stage | Out-Null
 foreach ($property in $target.expected.PSObject.Properties) {
  $file=Join-Path $target.stage $property.Name
  New-Item -ItemType Directory -Path (Split-Path -Parent $file) -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $target.source $property.Name) -Destination $file
 }
 if (-not (Test-Tree $target.stage $target.expected)) { throw 'Prepared payload failed verification; no installed files changed.' }
}
$retired=New-Object System.Collections.Generic.List[object]
try {
 foreach ($entry in $toRetire.GetEnumerator()) {
  $backup=New-History ('Previous_'+$entry.Key)
  Move-Item -LiteralPath $entry.Value -Destination $backup
  $retired.Add([pscustomobject]@{original=$entry.Value;backup=$backup})
 }
 foreach ($target in $targets) {
  $folder=Join-Path $ModsFolder $target.id
  if (Test-Path -LiteralPath $folder) {
   $target.backup=New-History ('Previous_'+$target.id)
   Move-Item -LiteralPath $folder -Destination $target.backup
  }
  Move-Item -LiteralPath $target.stage -Destination $folder
  $target.installed=$true
  if (-not (Test-Tree $folder $target.expected)) { throw 'Installed payload failed hash verification.' }
 }
} catch {
 $failure=$_
 foreach ($target in $targets) {
  $folder=Join-Path $ModsFolder $target.id
  if ($target.installed -and (Test-Tree $folder $target.expected)) { Move-Item -LiteralPath $folder -Destination (New-History ('Failed_'+$target.id)) }
  if ($target.backup -and -not (Test-Path -LiteralPath $folder)) { Move-Item -LiteralPath $target.backup -Destination $folder }
 }
 foreach ($entry in $retired) { if (-not (Test-Path -LiteralPath $entry.original)) { Move-Item -LiteralPath $entry.backup -Destination $entry.original } }
 throw $failure
}
$menu=(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'payload\reskate-levels.json') -Raw | ConvertFrom-Json).levels[0].displayName
Write-Host "INSTALLED: $menu"
Write-Host "SHADER SUPPORT: $($spec.support.map_id) (separate non-map mod)"
Write-Host 'Start ReSkate, confirm normal startup, then select the preview map.'
Write-Host 'To turn off the shader override alone, disable its glass_shader_... entry and restart.'
Write-Host 'To remove both components, close skate and its launcher and run Remove-Glass-Test.ps1 from this package.'
