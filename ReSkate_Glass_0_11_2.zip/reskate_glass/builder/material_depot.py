"""Copy-on-write edits to the pinned compiler's owned shader parameter depot."""
import hashlib,struct

class MaterialDepot:
    def __init__(self,data,metadata):
        if len(metadata)!=16:raise ValueError('Missing shader depot metadata; update the native helper')
        self.size,self.reloc_size,self.flags,self.count=struct.unpack('<4I',metadata)
        if self.flags!=0x01190003 or not 0<self.count<1000000 or self.size+self.reloc_size!=len(data) or self.reloc_size%4 or self.size%8:
            raise ValueError('Unsupported owned material depot layout')
        self.table=struct.unpack_from('<Q',data)[0]
        if self.table!=16 or self.table+self.count*16>self.size:raise ValueError('Invalid shader depot table')
        self.data=bytearray(data[:self.size]);self.relocations=list(struct.unpack('<%dI'%(self.reloc_size//4),data[self.size:]));self.entries={};self.identities=set();self.audit=[]
        if len(set(self.relocations))!=len(self.relocations):raise ValueError('Duplicate depot relocations')
        for i in range(self.count):
            at=self.table+i*16;key,block=struct.unpack_from('<QQ',data,at)
            if key in self.entries:raise ValueError('Duplicate native material key')
            if block+24>self.size or block%8:raise ValueError('Invalid material block pointer')
            start,identity,length=struct.unpack_from('<QQQ',data,block)
            if start+length>self.size or start<self.table+self.count*16 or length<4:raise ValueError('Invalid material parameter block')
            self.entries[key]=(at,block,start,identity,length);self.identities.add(identity)
        expected={0}|{e[0]+8 for e in self.entries.values()}|{e[1] for e in self.entries.values()}
        if set(self.relocations)!=expected:raise ValueError('Unknown depot pointer layout; refusing relocation edits')
        self.validate_relocations()

    def validate_relocations(self):
        for location in self.relocations:
            if location<0 or location+8>len(self.data):raise ValueError('Depot relocation exceeds data')
            if struct.unpack_from('<Q',self.data,location)[0]>=len(self.data):raise ValueError('Depot relocation target exceeds data')

    def bind(self,material_id,shader_keys,replacement):
        from pixel_dirt import material_texture_positions
        if len(replacement)!=32:raise ValueError('Expected external texture reference')
        originals={}
        for key in sorted(shader_keys):
            if key not in self.entries:raise ValueError('Glass key missing from private depot')
            entry=self.entries[key];originals.setdefault(entry[1],[]).append((key,entry))
        for parent,entries in originals.items():
            at,block,start,identity,length=entries[0][1]
            # Locate the slot while the source table is still the original one.
            positions=material_texture_positions(bytes(self.data),[entries[0][0]],table_end=self.table+self.count*16)
            if len(positions)!=1 or not start<=positions[0]<=start+length-32:raise ValueError('Texture slot outside parameter block')
            offset=positions[0]-start;params=bytearray(self.data[start:start+length]);params[offset:offset+32]=replacement
            new_start=len(self.data);self.data.extend(params);self.data.extend(bytes(-len(self.data)%8));new_block=len(self.data)
            # Block hashes are identities; change them as well as pointers to avoid runtime sharing.
            salt=0
            while True:
                new_identity=int.from_bytes(hashlib.sha256(b'reskate-glass-private-block-v1\0'+material_id.encode()+struct.pack('<QQ',identity,salt)+params).digest()[:8],'little')
                if new_identity and new_identity not in self.identities:break
                salt+=1
            self.identities.add(new_identity);self.data.extend(struct.pack('<QQQ',new_start,new_identity,length));self.relocations.append(new_block)
            for key,entry in entries:struct.pack_into('<Q',self.data,entry[0]+8,new_block)
            self.audit.append({'material_id':material_id,'shader_keys':[hex(k) for k,e in entries],'source_block':parent,'private_block':new_block,'parameter_bytes':length})

    def finish(self):
        self.data.extend(bytes(-len(self.data)%16))
        active_blocks={struct.unpack_from('<Q',self.data,e[0]+8)[0] for e in self.entries.values()}
        expected={0}|{e[0]+8 for e in self.entries.values()}|active_blocks
        self.relocations=[p for p in self.relocations if p in expected]
        if set(self.relocations)!=expected:raise ValueError('Missing private material relocations')
        self.validate_relocations()
        metadata=struct.pack('<4I',len(self.data),len(self.relocations)*4,self.flags,self.count)
        data=bytes(self.data)+struct.pack('<%dI'%len(self.relocations),*self.relocations)
        # Parse the complete output independently, including its rebuilt relocation table.
        MaterialDepot(data,metadata)
        return data,metadata
