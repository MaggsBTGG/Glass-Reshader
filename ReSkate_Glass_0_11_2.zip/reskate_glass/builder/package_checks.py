"""Final on-disk package contract, checked before making a distributable ZIP."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re

SUPPORTED_GAME = 'fbce74d5e28ef525dbba2cb4adbebc13405bdbd88f31bc940bca45e4ae88b8f9'


def check_package(folder):
    root = Path(folder)
    spec = json.loads((root / 'validation.json').read_text(encoding='utf-8-sig'))
    if spec.get('package_id') != 'glass-auto-builder-v1' or not re.fullmatch(r'glass_author_[0-9a-f]{8}', spec.get('map_id', '')):
        raise ValueError('Unexpected glass package identity')
    if spec['support']['map_id'] != 'glass_shader_' + spec['map_id'][-8:]:
        raise ValueError('Shader support identity does not match map')
    for name, expected in [('payload', spec['modes']['Compare']), ('shader-support', spec['support']['hashes'])]:
        tree = root / name
        actual = {f.relative_to(tree).as_posix() for f in tree.rglob('*') if f.is_file()}
        if actual != set(expected):
            raise ValueError(name + ': missing or unexpected package files')
        for relative, digest in expected.items():
            path = PurePosixPath(relative)
            if path.is_absolute() or '..' in path.parts or '\\' in relative or ':' in relative:
                raise ValueError('Unsafe payload path')
            f = tree / relative
            if f.is_symlink() or hashlib.sha256(f.read_bytes()).hexdigest() != digest:
                raise ValueError(name + ': payload hash check failed: ' + relative)
        marker = (tree / '.reskate-studio-patch').read_text(encoding='utf-8-sig')
        hashes = [line.split('=', 1)[1] for line in marker.splitlines() if line.startswith('skate_sha256=')]
        if hashes != [SUPPORTED_GAME]:
            raise ValueError(name + ': missing or unsupported game-version stamp')
    if (root / 'shader-support/reskate-levels.json').exists():
        raise ValueError('Shader support must not register map levels')
    if not (root / 'payload/reskate-levels.json').is_file():
        raise ValueError('Map level registration is missing')
    return True
