"""Combine a stock normalized scene export with authored glass, in a fresh folder."""
from pathlib import Path
import argparse, copy, hashlib, json, shutil, sys, tempfile, struct, zlib
sys.path.insert(0, str(Path(__file__).resolve().parent))
from prepare_native import prepare,parse_glb,positions,write_glb,IDENTITY


def merge(base_folder, authoring_zip, output,pixel_dirt=False):
    base_folder, output = Path(base_folder).resolve(), Path(output).resolve()
    if output.exists() or base_folder == output or base_folder in output.parents:
        raise ValueError('Choose a fresh output folder outside the base export')
    # Refuse links so the copy cannot silently depend on files outside this export.
    for p in base_folder.rglob('*'):
        if p.is_symlink(): raise ValueError('Linked export files are unsupported: '+str(p))
    original = json.loads((base_folder/'map.json').read_text(encoding='utf-8-sig'))
    if (original.get('format'), original.get('units'), original.get('up'), original.get('forward')) != (1,'meters','y','-z'):
        raise ValueError('Expected a stock normalized map in metres, Y up, -Z forward')
    if original.get('source',{}).get('scale',1) != 1:
        raise ValueError('Full-map glass preview requires Studio export scale 1')
    if not original.get('spawn'): raise ValueError('Add an Empty named spawn to the saved test scene')
    with tempfile.TemporaryDirectory(prefix='glass_full_') as td:
        glass = Path(td)/'glass'
        prepare(authoring_zip,glass,pixel_dirt=pixel_dirt)
        gd=json.loads((glass/'map.json').read_text());recipe=json.loads((glass/'glass-build-recipe.json').read_text())
        groups={(r['source_object'],tuple(r['source_material_slots'])) for r in recipe['objects']}
        names={name for name,_ in groups}
        found=set();kept=[];removed=[];collisions=[]
        for row in original['objects']:
            source=row.get('source_object')
            matches={g for g in groups if g[0]==source and row.get('source_material_slot') in g[1]}
            if source in names and row.get('render') is not False and 'source_material_slot' not in row:
                raise ValueError('Stock export lacks source material slot for '+source)
            if not matches or row.get('render') is False:
                kept.append(copy.deepcopy(row));continue
            if row.get('source_instance'):
                raise ValueError('Instanced glass is unsupported in this preview: '+source)
            if not row.get('mesh'):raise ValueError('Matched glass has no authored mesh: '+source)
            found.update(matches);removed.append(copy.deepcopy(row))
            if row.get('collision_mode','none')!='none':
                if not row.get('collision_mesh'):raise ValueError('Glass collision has no separate mesh: '+source)
                collision=copy.deepcopy(row);collision['render']=False
                collision.pop('mesh',None);collision.pop('material',None)
                kept.append(collision);collisions.append(collision)
        if found!=groups:raise ValueError('Glass material sections missing from stock scene export: '+str(sorted(groups-found)))
        doc=copy.deepcopy(original)
        # Keep the generated build separate from the source map's installed identity.
        signature=hashlib.sha256((base_folder/'map.json').read_bytes()+Path(authoring_zip).read_bytes()).hexdigest()[:8]
        mapid='glass_author_'+signature
        doc['name']=mapid;doc['display_name']=original.get('display_name',original['name'])+' - Glass Preview'
        existing_names={r['name'] for r in kept}
        material_pipeline=bool(recipe.get('material_pipeline'))
        if material_pipeline:
            glass_rows=[copy.deepcopy(r) for r in gd['objects'] if r['name']!='test_floor']
            for row in glass_rows:
                if row['name'] in existing_names:raise ValueError('Reserved glass object name exists: '+row['name'])
                name=row['material']
                if name in original['materials']:raise ValueError('Reserved glass material exists: '+name)
                doc['materials'][name]=gd['materials'][name]
            doc['objects']=kept+glass_rows
        else:
            material='rg_full_map_glass'
            if material in doc['materials']:raise ValueError('Reserved glass material already exists')
            doc['materials'][material]=gd['materials']['ocean_probe']
            glass_rows=[r for r in gd['objects'] if r['name']!='test_floor']
            for r in glass_rows:
                if r['name'] in existing_names:raise ValueError('Reserved glass object name already exists: '+r['name'])
                r['material']=material
            doc['objects']=kept+glass_rows
            if pixel_dirt:
                reserved='rg_dirt_carrier'
                if reserved in doc['materials'] or any(row['name']==reserved for row in doc['objects']):raise ValueError('Reserved dirt carrier name already exists')
                doc['materials'][reserved]=dict(gd['materials']['floor'],cast_shadows=False,texture='textures/rg_dirt_carrier.png',base_color_texture='textures/rg_dirt_carrier.png')
                # A tiny non-colliding, non-shadowing texture carrier stays below the authored geometry.
                coords=[]
                for row in glass_rows:
                    d,raw=parse_glb((glass/row['mesh']).read_bytes())
                    coords.extend(positions(d,raw)[0][0])
                x=sum(v[0] for v in coords)/len(coords);y=min(v[1] for v in coords)-30;z=sum(v[2] for v in coords)/len(coords)
                carrier_bytes=write_glb([(x,y,z),(x+1,y,z),(x,y,z+1)],[0,1,2])
                doc['objects'].append({'name':reserved,'mesh':'meshes/rg_dirt_carrier.glb','material':reserved,'placement_mode':'authored_mesh','transform':IDENTITY,'static':True,'collision_mode':'none'})
                recipe['mask_carrier_texture']='rg_dirt_carrier_basecolor_'
        probe_added=not bool(doc.get('reflection_probes'))
        if probe_added:doc['reflection_probes']=gd['reflection_probes']
        recipe.update(map_id=mapid,scope='full-map-preview',display_name=doc['display_name'],preserve_shared_lighting=True,
                      source_map_name=original['name'],probe_policy='existing probes retained' if not probe_added else 'generated local glass test probe')
        audit={'source_map':original['name'],'source_manifest_sha256':hashlib.sha256((base_folder/'map.json').read_bytes()).hexdigest(),
               'replaced_render_rows':removed,'preserved_glass_collision_rows':collisions,
               'untouched_object_count':len(original['objects'])-len(removed),'glass_object_count':len(glass_rows),
               'generated_probe_added':probe_added,'source_blend_modified':False,
               'material_count':len(recipe.get('pixel_materials',{})),'spatial_cell_metres':32 if material_pipeline else None,
               'limits':([] if material_pipeline else ['glass subset under 100 metres'])+['mixed material sections matched by exact source object and slot','no instanced glass','no LODs or streaming in preview','full native/GPU validation pending']}
        try:
            shutil.copytree(base_folder,output)
            # Canonical names are also used by the patcher's dirt alignment check.
            for r in glass_rows:
                target=output/'meshes'/(r['name']+'.glb')
                if target.exists():raise ValueError('Reserved normalized mesh path exists: '+str(target))
                target.parent.mkdir(exist_ok=True);shutil.copyfile(glass/'meshes'/Path(r['mesh']).name,target)
            if material_pipeline:
                for folder in ('textures','materials'):
                    for source in (glass/folder).glob('*'):
                        target=output/folder/source.name
                        if target.exists():raise ValueError('Reserved private material path exists: '+str(target))
                        target.parent.mkdir(exist_ok=True);shutil.copyfile(source,target)
            elif pixel_dirt:
                (output/'meshes/rg_dirt_carrier.glb').write_bytes(carrier_bytes)
                (output/'textures').mkdir(exist_ok=True)
                # A unique placeholder prevents texture deduplication with an authored surface.
                seed=hashlib.sha256(('private-dirt-carrier-'+mapid).encode()).digest()
                pixels=b''.join(b'\0'+seed[y*8:y*8+8] for y in range(2))
                def png_chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
                png=b'\x89PNG\r\n\x1a\n'+png_chunk(b'IHDR',struct.pack('>2I5B',2,2,8,6,0,0,0))+png_chunk(b'IDAT',zlib.compress(pixels))+png_chunk(b'IEND',b'')
                (output/'textures/rg_dirt_carrier.png').write_bytes(png)
                shutil.copyfile(glass/'pixel_mask.mask',output/'pixel_mask.mask')
            (output/'map.json').write_text(json.dumps(doc,indent=2))
            (output/'glass-build-recipe.json').write_text(json.dumps(recipe,indent=2))
            (output/'FULL_MAP_MERGE_AUDIT.json').write_text(json.dumps(audit,indent=2))
        except Exception:
            if output.exists():shutil.rmtree(output)
            raise
    return mapid

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('base_folder');p.add_argument('authoring_zip');p.add_argument('output');p.add_argument('--pixel-dirt',action='store_true')
    a=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else None)
    print('Prepared full-map glass preview:',merge(a.base_folder,a.authoring_zip,a.output,a.pixel_dirt))
