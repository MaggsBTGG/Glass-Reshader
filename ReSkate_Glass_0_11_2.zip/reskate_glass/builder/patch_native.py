"""Patch an owned native test build. Does not alter source .blend or game files."""
from pathlib import Path
import argparse,sys,json,struct,hashlib,shutil,subprocess,ctypes,uuid,zipfile,zlib,os

sys.path.insert(0, str(Path(__file__).resolve().parent))
from dirt_bake import encode_marker
from prepare_native import parse_glb, positions

class Decoder:
    def __init__(self,game_root):
        self.lib=None
        if os.name=='nt':
            matches=sorted(Path(game_root).glob('oo2core_*_win64.dll'))
            if not matches:raise ValueError('Game Oodle DLL not found')
            self.lib=ctypes.CDLL(str(matches[-1].resolve()),winmode=0x1100)
            self.assertion=ctypes.CFUNCTYPE(ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_char_p)(lambda *_:0)
            setter=self.lib.OodleCore_Plugins_SetAssertion;setter.argtypes=[ctypes.c_void_p];setter.restype=ctypes.c_void_p;setter(self.assertion)
            self.fn=self.lib.OodleLZ_Decompress
            self.fn.argtypes=[ctypes.c_void_p,ctypes.c_int64,ctypes.c_void_p,ctypes.c_int64,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_void_p,ctypes.c_int64,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int64,ctypes.c_int];self.fn.restype=ctypes.c_int64
            self.bound=self.lib.OodleLZ_GetDecodeBufferSize;self.bound.argtypes=[ctypes.c_int,ctypes.c_int64,ctypes.c_int];self.bound.restype=ctypes.c_int64
        elif os.environ.get('GLASS_ANALYSIS_DECODER'):
            self.lib=ctypes.CDLL(os.environ['GLASS_ANALYSIS_DECODER']);self.fn=self.lib.Kraken_Decompress;self.fn.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t];self.fn.restype=ctypes.c_int
    def decode(self,b):
        out=b''
        while b:
            if len(b)<8:raise ValueError('Truncated CAS header')
            n=int.from_bytes(b[:4],'big')&0xffffff;t=int.from_bytes(b[4:6],'little');size=int.from_bytes(b[6:8],'big')+(((t>>8)&15)<<16)
            if not 0<n<=0x40000 or size>len(b)-8:raise ValueError('Invalid CAS size')
            data=b[8:8+size];b=b[8+size:]
            if t&127==0:q=data
            elif t&127==2:q=zlib.decompress(data)
            elif t&127 in [17,21,25]:
                if self.lib is None:raise ValueError('Oodle decoder unavailable')
                src=ctypes.create_string_buffer(data);bound=max(n+0x40000,self.bound(-1,n,1)) if os.name=='nt' else n+64;dst=ctypes.create_string_buffer(bound)
                written=self.fn(src,len(data),dst,n,1,0,0,None,0,None,None,None,0,3) if os.name=='nt' else self.fn(src,len(data),dst,n)
                if written!=n:raise ValueError('Oodle decode failed')
                q=dst.raw[:n]
            else:raise ValueError('Unsupported CAS codec: '+str(t&127))
            if len(q)!=n:raise ValueError('CAS decode length mismatch')
            out+=q
        return out

def encode(b):
    return b''.join(((len(q)<<32)|(7<<20)|len(q)).to_bytes(8,'big')+q for q in [b[i:i+65536] for i in range(0,len(b),65536)])

def patch(job,game_root,helper):
    job=Path(job);base=Path(__file__).resolve().parent;recipe=json.loads((job/'normalized/glass-build-recipe.json').read_text());mapid=recipe['map_id']
    import re
    if not re.fullmatch('glass_author_[0-9a-f]{8}',mapid):raise ValueError('Unexpected test map ID')
    profiles=json.loads((base/'profiles.json').read_text());markers=json.loads((base/'profile-markers.json').read_text());selections={}
    material_pipeline=bool(recipe.get('material_pipeline'))
    for obj in recipe['objects']:
        if material_pipeline:
            from city_materials import validate
            validate(obj['settings']);selections[obj['object']]='Custom';continue
        match=next((k for k,v in profiles.items() if set(v)==set(obj['settings']) and all(abs(v[n]-obj['settings'][n])<1e-6 for n in v)),None)
        if match is None:raise ValueError('Custom material values are not supported yet. Choose an R9 preset in the add-on.')
        selections[obj['object']]=match
    if not selections:raise ValueError('No panes in recipe')
    dest=job/'playable'
    if dest.exists():raise ValueError('Playable output already exists; use a fresh build job')
    shutil.copytree(job/'compiled/Patch',dest/'payload');p=dest/'payload'
    root='Win32/levels/game/dingolevel_root/dingolevel_root.toc';mp=f'Win32/levels/game/dingolevel_reskate_{mapid}/dingolevel_reskate_{mapid}.toc';c1=p/'Win32/configurations/layout/initialinstallpackage/cas_01.cas';c2=p/'Win32/configurations/layout/defaultinstallpackage/cas_01.cas'
    def list_rows(toc):
        r=subprocess.run([str(helper),'list',str(p/toc),str(c1),str(c2)],capture_output=True,text=True,check=True)
        return [l.split('\t') for l in r.stdout.splitlines()]
    rr=list_rows(root);mr=list_rows(mp);cas=bytearray(c1.read_bytes());default=c2.read_bytes();decoder=Decoder(game_root);cfg=[];audit=[]
    def add(row,b,meta='-'):
        coded=encode(b);offset=len(cas);cas.extend(coded);cfg.append(f'{row[0]} {row[1]} {offset} {len(coded)} {len(b)} {hashlib.sha1(b).hexdigest()} {meta}');audit.append({'asset':row[3],'decoded_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    pixel_mode=bool(recipe.get('pixel_texture_mask') or material_pipeline)
    gain_scale=recipe.get('pixel_gain_scale',1)
    if gain_scale not in (1,8):raise ValueError('Unsupported pixel dirt gain scale')
    wrappers=json.loads((base/'shader-wrappers.json').read_text())
    pixel_folder='RGBADirt' if recipe.get('pixel_texture_mask',{}).get('encoding')=='linear-rgba8' else 'PixelDirt'
    if gain_scale==8:pixel_folder+='Boost'
    if material_pipeline:pixel_folder='MaterialGlass'
    for i in [5,6,7,8,9]:
        w=wrappers[str(i)];row=next(r for r in rr if r[3]==w['name']);dx=(base/'shaders'/(pixel_folder+'/'+('vs.dxil' if i==5 else f'ps_{i}.dxil') if pixel_mode else ('vs.dxil' if i==5 else 'Universal'+f'/ps_{i}.dxil'))).read_bytes();header=bytearray.fromhex(w['header']);start=len(header);end=start+len(dx);size=(end+15)&~15
        if dx[:4]!=b'DXBC':raise ValueError('Invalid shader payload')
        struct.pack_into('<I',header,start-4,len(dx));struct.pack_into('<I',header,12,end-32);struct.pack_into('<Q',header,16,size)
        b=bytes(header)+dx+bytes(size-end)+bytes.fromhex(w['tail']);add(row,b,struct.pack('<4I',size,8,0,0).hex())
    bundle=f'win32/levels/game/dingolevel_reskate_{mapid}/dingolevel_reskate_{mapid}';used={}
    def owned_bytes(row):
        if row[9]!='1' or row[10]!='1':raise ValueError('Target is not an owned patch asset')
        source=default if row[6]=='2016875820' else cas if row[6]=='3162564249' else None
        if source is None:raise ValueError('Unexpected install chunk')
        off,n=int(row[7]),int(row[8]);raw=source[off:off+n]
        if len(raw)!=n:raise ValueError('CAS location exceeds file')
        b=decoder.decode(raw)
        if len(b)!=int(row[5]):raise ValueError('Decoded asset length mismatch')
        return b
    mesh_index={}
    chunk_index={r[4]:r for r in mr if r[0]==bundle and r[2]=='2'}
    for row in mr:
        if row[0]==bundle and row[2]=='1' and '/meshes/' in row[3]:
            name=row[3].split('/meshes/',1)[1]
            # Our generated names contain the entire glass ordinal before the compiler suffix.
            match=re.match(r'(glass_\d+)_',name)
            if match:mesh_index.setdefault(match[1],[]).append(row)
    def meshes_for(obj):
        name=obj['object']
        if name in mesh_index:return mesh_index[name]
        return [r for r in mr if r[0]==bundle and r[2]=='1' and f'/meshes/{name}_' in r[3]]
    material_bindings=[]
    if pixel_mode:
        from pixel_dirt import apply_private_mask,apply_private_materials,pack_uv
        glass_keys=set();material_keys={}
        for obj in recipe['objects']:
            candidates=meshes_for(obj)
            if len(candidates)!=1:raise ValueError('Expected one private mesh per glass section')
            m=owned_bytes(candidates[0]);lod_at=struct.unpack_from('<Q',m,48)[0]+16;section_at=struct.unpack_from('<Q',m,lod_at+12)[0]+16
            key=struct.unpack_from('<Q',m,section_at+312)[0];glass_keys.add(key)
            if material_pipeline:material_keys.setdefault(obj['material_id'],set()).add(key)
        if material_pipeline:material_bindings=apply_private_materials(mr,bundle,owned_bytes,add,recipe,job,material_keys)
        else:apply_private_mask(mr,bundle,owned_bytes,add,recipe,job,glass_keys)
    for obj in recipe['objects']:
        matches=meshes_for(obj)
        if len(matches)!=1:raise ValueError('Expected one native mesh per authored pane; merged/instanced layouts are not supported yet')
        mesh=owned_bytes(matches[0]);lod=struct.unpack_from('<Q',mesh,48)[0]+16
        if struct.unpack_from('<H',mesh,180)[0]!=1 or struct.unpack_from('<I',mesh,lod+8)[0]!=1:raise ValueError('Only one LOD and one section are supported')
        section=struct.unpack_from('<Q',mesh,lod+12)[0]+16;vc=struct.unpack_from('<I',mesh,section+44)[0];start=struct.unpack_from('<I',mesh,section+40)[0]
        if mesh[section+112:section+124].hex()!='0108000021060001340d0002' or start!=0:raise ValueError('Water vertex declaration mismatch')
        guid=str(uuid.UUID(bytes_le=mesh[lod+116:lod+132]));row=chunk_index[guid]
        b=bytearray(owned_bytes(row));before=bytes(b)
        if vc*16>len(b):raise ValueError('Geometry is shorter than expected')
        samples=obj.get('dirt_samples')
        if samples is not None or pixel_mode:
            normalized=job/'normalized/meshes'/ (obj['object']+'.glb')
            doc,raw=parse_glb(normalized.read_bytes());source=positions(doc,raw,with_uv=True)
            if len(source)!=1:raise ValueError('Dirt bake requires one normalized primitive')
            expected_points=source[0][0]
            if (samples is not None and len(samples)!=vc) or len(expected_points)!=vc:raise ValueError('Native compiler changed vertex order/count; dirt patch was refused')
            for index,point in enumerate(expected_points):
                origin=obj.get('native_render_origin',[0,0,0])
                packed=struct.pack('<3e',*(point[k]-origin[k] for k in range(3)))
                if b[index*8:index*8+6]!=packed:raise ValueError('Native compiler reordered vertices; dirt patch was refused')
        pixel_uvs=source[0][2] if pixel_mode else None
        if pixel_mode and pixel_uvs is None and obj.get('pixel_strength',0)>0:raise ValueError('Pixel dirt pane lost its UV map')
        for index in range(vc):
            if struct.unpack_from('<e',b,index*8+6)[0]!=1:raise ValueError('Unexpected existing vertex marker')
            amount=samples[index] if samples is not None else 0
            marker=52 if material_pipeline else encode_marker(markers[selections[obj['object']]],obj.get('pixel_strength',0)/gain_scale if pixel_mode else amount)+(10 if pixel_mode else 0)
            struct.pack_into('<e',b,index*8+6,marker)
            if pixel_mode:
                uv=pixel_uvs[index] if pixel_uvs is not None else (0,0)
                b[vc*12+index*4:vc*12+index*4+4]=pack_uv(uv)
        if any(b[i]!=before[i] for i in range(len(b)) if not((i<vc*8 and i%8 in [6,7]) or (pixel_mode and vc*12<=i<vc*16))):raise ValueError('Unexpected geometry change')
        if guid in used:
            if used[guid]!=bytes(b):raise ValueError('Shared native geometry needs different glass UVs/markers; patch refused')
        else:
            used[guid]=bytes(b);add(row,bytes(b))
    c1.write_bytes(cas);cfgpath=job/'automatic-edits.tsv';cfgpath.write_text('\n'.join(cfg)+'\n')
    for toc in [root,mp]:subprocess.run([str(helper),'patch',str(p/toc),str(c1),str(c2),str(cfgpath),str(p/toc)],check=True)
    
    if not recipe.get('preserve_shared_lighting'):subprocess.run([str(helper),'trim',str(p/mp),str(p/mp)],check=True)
    expected={(l.split()[0],l.split()[1]):l.split() for l in cfg};verified=set();packed=c1.read_bytes()
    for toc in [root,mp]:
        for row in list_rows(toc):
            if not recipe.get('preserve_shared_lighting') and row[0]=='win32/levels/game/bam_levelroot/lighting_global':raise ValueError('Shared lighting override remains')
            key=tuple(row[:2])
            if key in expected:
                e=expected[key]
                if row[6]!='3162564249' or row[7:9]!=e[2:4]:raise ValueError('Repacked asset location mismatch')
                decoded=decoder.decode(packed[int(row[7]):int(row[7])+int(row[8])])
                if len(decoded)!=int(row[5]):raise ValueError('Repacked decoded asset size mismatch')
                if hashlib.sha1(decoded).hexdigest()!=e[5]:raise ValueError('Repacked payload hash mismatch')
                verified.add(key)
    expected_chunks={r[4]:expected[tuple(r[:2])] for r in list_rows(mp) if r[2]=='2' and tuple(r[:2]) in expected}
    for toc in [root,mp]:
        chunk_listing=subprocess.run([str(helper),'chunks',str(p/toc),'-'],capture_output=True,text=True,check=True)
        for line in chunk_listing.stdout.splitlines():
            guid,patch_flag,install,archive,offset,length=line.split('\t')
            if guid in expected_chunks:
                e=expected_chunks[guid]
                if [patch_flag,install,archive,offset,length]!=['1','3162564249','1',e[2],e[3]]:raise ValueError('Global chunk lookup does not match patched bundle')
    if len(verified)!=len(cfg):raise ValueError('Not all patched assets were verified')
    # Map mods preload their root even when disabled. Keep shader overrides in a non-map mod.
    support_id='glass_shader_'+mapid[-8:]
    support_root=dest/'shader-support'
    support_toc=support_root/root;support_cas=support_root/'Win32/configurations/layout/initialinstallpackage/cas_01.cas'
    support_toc.parent.mkdir(parents=True);support_cas.parent.mkdir(parents=True)
    subprocess.run([str(helper),'support',str(p/root),str(c1),str(c2),str(cfgpath),str(support_toc),str(support_cas)],check=True)
    source_layout=Path(game_root)/'Data/layout.toc'
    if not source_layout.is_file():raise ValueError('Supported game base layout is required for the shader support package')
    shutil.copyfile(source_layout,support_root/'layout.toc')
    # Every layout-bearing mod needs the validated game identity, including non-map support.
    marker=(p/'.reskate-studio-patch').read_bytes()
    if b'skate_sha256=' not in marker:raise ValueError('Missing validated map game-version stamp')
    (support_root/'.reskate-studio-patch').write_bytes(marker)
    # Verify the minimal support archive and restore original shader references in the map root.
    support_rows=[line.split('\t') for line in subprocess.check_output([str(helper),'list',str(support_toc),str(support_cas),str(c2)],text=True).splitlines()]
    if len(support_rows)!=5 or any(row[2]!='1' or not row[3].startswith('shaders/bytecode/') for row in support_rows):raise ValueError('Shader support contains unexpected assets')
    support_bytes=support_cas.read_bytes()
    expected_shader_hashes={entry['asset']:entry['sha256'] for entry in audit[:5]}
    for row in support_rows:
        decoded=decoder.decode(support_bytes[int(row[7]):int(row[7])+int(row[8])])
        if hashlib.sha256(decoded).hexdigest()!=expected_shader_hashes[row[3]]:raise ValueError('Shader support hash check failed')
    shutil.copyfile(job/'compiled/Patch'/root,p/root)
    if (support_root/'reskate-levels.json').exists():raise ValueError('Shader support must never register a level')
    support_hashes={f.relative_to(support_root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in support_root.rglob('*') if f.is_file()}
    levels=json.loads((p/'reskate-levels.json').read_text());levels['levels'][0]['displayName']=recipe.get('display_name','Glass Authoring - Dirt Bake');(p/'reskate-levels.json').write_text(json.dumps(levels,indent=2))
    modes=dest/'modes';modes.mkdir();shutil.copyfile(p/root,modes/'Compare-root.toc');shutil.copyfile(p/'reskate-levels.json',modes/'Compare-levels.json')
    hashes={f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}
    previous={'R10':json.loads((base/'r10-known.json').read_text())} if mapid=='glass_author_e6f285f6' else {}
    legacy_tests=[];support_previous=[]
    from diagnostic_compat import recognized_support_trees
    diagnostic_catalog=json.loads((base/'runtime-diagnostic-hashes.json').read_text())
    history_roots=[job.parent]
    old_history=Path('C:/KamurochoPort/GlassAutoBuilder/Builds')
    if old_history.is_dir() and old_history.resolve()!=job.parent.resolve():history_roots.append(old_history)
    candidates={candidate.resolve() for history in history_roots for candidate in history.rglob('validation.json')}
    for candidate in sorted(candidates):
        if dest in candidate.parents:continue
        try:
            old=json.loads(candidate.read_text(encoding='utf-8-sig'))
            if old.get('package_id')!='glass-auto-builder-v1':continue
            if not re.fullmatch('glass_author_[0-9a-f]{8}',old.get('map_id','')):continue
            if old.get('support'):
                if old['support']['map_id']==support_id:support_previous.append(old['support']['hashes'])
                else:legacy_tests.append({'map_id':old['support']['map_id'],'hashes':old['support']['hashes']})
                audit_path=candidate.parent/'BUILD_AUDIT.json'
                if audit_path.is_file():
                    old_audit=json.loads(audit_path.read_text(encoding='utf-8-sig'))
                    for tree in recognized_support_trees(old,old_audit,diagnostic_catalog):
                        if old['support']['map_id']==support_id:support_previous.append(tree)
                        else:legacy_tests.append({'map_id':old['support']['map_id'],'hashes':tree})
            for name,tree in old['modes'].items():
                if old['map_id']==mapid:previous[str(candidate)+name]=tree
                else:legacy_tests.append({'map_id':old['map_id'],'hashes':tree})
        except (OSError,ValueError,KeyError,TypeError):continue
    legacy_tests.extend({'map_id':'km_glass_pass_r4','hashes':v} for v in json.loads((base/'previous-test-hashes.json').read_text()).values())
    if mapid!='glass_author_e6f285f6':legacy_tests.append({'map_id':'glass_author_e6f285f6','hashes':json.loads((base/'r10-known.json').read_text())})
    (dest/'legacy-tests.json').write_text(json.dumps(legacy_tests,indent=2))
    spec={'package_id':'glass-auto-builder-v1','map_id':mapid,'modes':{'Compare':hashes},'previous_modes':previous,'support':{'map_id':support_id,'hashes':support_hashes,'previous_hashes':support_previous},'root_toc':root,'mode_files':{'Compare':{'root':'modes/Compare-root.toc','levels':'modes/Compare-levels.json'}}}
    (dest/'validation.json').write_text(json.dumps(spec,indent=2));shutil.copyfile(base/'Install-Glass-Test.template.ps1',dest/'Install-Glass-Test.ps1');shutil.copyfile(base/'previous-test-hashes.json',dest/'previous-test-hashes.json');shutil.copyfile(base/'r10-known.json',dest/'r10-known.json')
    (dest/'BUILD_AUDIT.json').write_text(json.dumps({'profiles_by_object':selections,'map_id':mapid,'patched_assets':audit,'payload_verification':'passed','game_verified':False,'scope':recipe.get('scope'),'addon_version':'0.11.2-experimental','material_settings':recipe.get('pixel_materials'),'private_material_blocks':material_bindings,'spatial_cell_metres':32 if material_pipeline else None,'dirt_lighting':'native diffuse accumulation' if pixel_mode else 'legacy vertex route','dirt_filtering':'mip 0' if pixel_mode else 'vertex','pixel_texture_test':pixel_mode,'shader_support_mod':support_id,'map_root_uses_original_shaders':True,'limits':(['full map preview; native integration requires validation'] if recipe.get('scope')=='full-map-preview' else ['isolated test map'])+(['independent private material images/settings; mip 0 sampling; city performance and GPU validation pending'] if material_pipeline else ['one shared private dirt image; full-resolution sampling; distance filtering and local-light response need broader validation'] if pixel_mode else ['5-bit vertex dirt bake; no per-pixel texture binding'])+['centimetre-scale half-position rounding possible','multi-map coexistence pending']},indent=2))
    (dest/'README.txt').write_text('Close skate. Run Install-Glass-Test.ps1. Load Glass Authoring - Dirt Bake. This is a glass-only isolated test map with a floor and probe, not the full city. Compiled panes are marked and shaders patched automatically. In-game result still requires validation.\n')
    if recipe.get('scope')=='full-map-preview':
        shutil.copyfile(job/'normalized/FULL_MAP_MERGE_AUDIT.json',dest/'FULL_MAP_MERGE_AUDIT.json')
        (dest/'README.txt').write_text('Close skate. Run Install-Glass-Test.ps1. Load '+recipe['display_name']+'. This is an experimental complete scene build. Original scene geometry, lights, spawn, probes and collision were carried through the normalized merge. Native compilation and in-game behavior need validation. Source files and Studio were not edited.\n')
    if pixel_mode and not material_pipeline and recipe.get('scope')!='full-map-preview':
        (dest/'README.txt').write_text('Close skate. Run Install-Glass-Test.ps1. Load Glass Authoring - Pixel Dirt Test. This is an isolated texture-slot experiment, not the full city. The floor also displays the mask as a reference. Glass UVs are passed to the pixel shader; no dirt subdivision was added. One shared mask image per test is supported. Binding and in-game results need validation.\n')
    if material_pipeline and recipe.get('scope')!='full-map-preview':
        (dest/'README.txt').write_text('Close skate. Run Install-Glass-Test.ps1. Load '+recipe['display_name']+'. Experimental independent material settings and city glass cells. Native/GPU validation is still required. Source scene unchanged.\n')
    with (dest/'README.txt').open('a') as f:f.write('\nThe installer manages a separate non-map glass_shader_... support mod. To remove the shader override alone, disable that support entry and restart. Remove-Glass-Test.ps1 moves both components outside Mods.\n')
    shutil.copyfile(base/'Remove-Glass-Test.template.ps1',dest/'Remove-Glass-Test.ps1')
    from package_checks import check_package
    check_package(dest)
    output=job/'Installable-Glass-Test.zip'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for f in dest.rglob('*'):
            if f.is_file():z.write(f,f.relative_to(dest).as_posix())
    print('INSTALLABLE TEST:',output)
    return output

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--job',required=True);parser.add_argument('--game-root',required=True);parser.add_argument('--helper',required=True)
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else None);patch(args.job,args.game_root,args.helper)
