#include "Engine/Resource/toc.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
using namespace dingosdk::frostbite;
std::vector<std::byte> rd(std::string p){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error(p);auto n=f.tellg();f.seekg(0);std::vector<std::byte>b(n);f.read((char*)b.data(),n);return b;}
void wr(std::string p,const std::vector<std::byte>&b){std::ofstream f(p,std::ios::binary);f.write((char*)b.data(),b.size());}

void support(char**v){
 auto t=read_toc(rd(v[2]));auto c1=rd(v[3]),c2=rd(v[4]);
 std::vector<std::byte> output;std::vector<TocBundle> bundles;size_t count=0;
 for(auto& bundle:t.bundles){
  auto region=read_bundle_region(bundle.region);if(region.files.empty())continue;
  auto first=region.files[0];auto& source=first.location.installChunk==3162564249u?c1:c2;
  auto original=read_binary_bundle(std::span(source).subspan(first.offset,first.size));
  std::vector<BundleAsset*> assets;for(auto&a:original.ebx)assets.push_back(&a);for(auto&a:original.resources)assets.push_back(&a);for(auto&a:original.chunks)assets.push_back(&a);
  BinaryBundle selected;std::vector<BundleFileInfo> files(1);
  std::ifstream cfg(v[5]);std::string line;
  while(std::getline(cfg,line)){
   std::istringstream row(line);std::string name,sha,meta;size_t index;unsigned offset,length,decoded;
   if(!(row>>name>>index>>offset>>length>>decoded>>sha>>meta))throw std::runtime_error("Malformed support config");
   if(name!=bundle.name)continue;
   auto& asset=*assets.at(index);auto f=region.files.at(index+1);
   if(asset.kind!=AssetKind::resource||!asset.name.starts_with("shaders/bytecode/")||!f.location.patch||f.location.installChunk!=3162564249u||f.location.archive!=1)throw std::runtime_error("Support package may contain only owned shader bytecode");
   if(size_t(f.offset)+f.size>c1.size())throw std::runtime_error("Support shader exceeds CAS");
   files.push_back({{true,3162564249u,1},static_cast<uint32_t>(output.size()),f.size});
   output.insert(output.end(),c1.begin()+f.offset,c1.begin()+f.offset+f.size);selected.resources.push_back(asset);++count;
  }
  if(selected.resources.empty())continue;
  auto manifest=write_binary_bundle(selected);files[0]={{true,3162564249u,1},static_cast<uint32_t>(output.size()),static_cast<uint32_t>(manifest.size())};
  output.insert(output.end(),manifest.begin(),manifest.end());
  auto changed=bundle;changed.region=write_bundle_region(files);bundles.push_back(std::move(changed));
 }
 if(count!=5)throw std::runtime_error("Expected five shader resources in support package");
 auto toc=write_patch_toc(bundles,{},t.flags);verify_toc(read_toc(toc));wr(v[6],toc);wr(v[7],output);
}
int main(int argc,char**v){try{if(argc<4)throw std::runtime_error("Missing command arguments");const std::string command=v[1];if(command=="support"){if(argc!=8)throw std::runtime_error("Wrong support arguments");support(v);return 0;}if((command=="list"&&argc!=5)||(command=="patch"&&argc!=7)||(command=="trim"&&argc!=4)||(command=="chunks"&&argc!=4))throw std::runtime_error("Wrong command arguments");if(command!="list"&&command!="patch"&&command!="trim"&&command!="chunks")throw std::runtime_error("Unknown command");auto t=read_toc(rd(v[2]));if(command=="chunks"){for(auto&c:t.chunks)std::cout<<c.guid.string()<<'\t'<<c.location.patch<<'\t'<<c.location.installChunk<<'\t'<<c.location.archive<<'\t'<<c.offset<<'\t'<<c.size<<'\n';return 0;}if(std::string(v[1])=="trim"){std::erase_if(t.bundles,[](auto&b){return b.name=="win32/levels/game/bam_levelroot/lighting_global";});auto out=write_patch_toc(t.bundles,t.chunks,t.flags);verify_toc(read_toc(out));wr(v[3],out);return 0;}auto c1=rd(v[3]),c2=rd(v[4]);for(auto&b:t.bundles){auto r=read_bundle_region(b.region);if(r.files.empty())continue;auto l=r.files[0];auto&cas=l.location.installChunk==3162564249u?c1:c2;auto m=read_binary_bundle(std::span(cas).subspan(l.offset,l.size));std::vector<BundleAsset*>assets;for(auto&a:m.ebx)assets.push_back(&a);for(auto&a:m.resources)assets.push_back(&a);for(auto&a:m.chunks)assets.push_back(&a);
if(std::string(v[1])=="list"){for(size_t i=0;i<assets.size();i++){auto&a=*assets[i];auto f=r.files.at(i+1);std::cout<<b.name<<'\t'<<i<<'\t'<<(int)a.kind<<'\t'<<a.name<<'\t'<<a.guid.string()<<'\t'<<a.originalSize<<'\t'<<f.location.installChunk<<'\t'<<f.offset<<'\t'<<f.size<<'\t'<<f.location.patch<<'\t'<<f.location.archive<<'\t';for(auto value:a.resourceMeta)std::cout<<std::hex<<std::setfill('0')<<std::setw(2)<<std::to_integer<unsigned>(value);std::cout<<std::dec<<'\n';}}else{bool changed=false;std::ifstream cfg(v[5]);std::string line;while(std::getline(cfg,line)){std::istringstream s(line);std::string bundle,path,sha,meta;size_t idx;unsigned off,len,decoded;s>>bundle>>idx>>off>>len>>decoded>>sha>>meta;if(bundle!=b.name)continue;auto&a=*assets.at(idx);for(size_t k=0;k<20;k++)a.sha1.bytes[k]=std::byte(std::stoul(sha.substr(2*k,2),nullptr,16));a.originalSize=decoded;if(a.kind==AssetKind::chunk){a.logicalOffset=0;a.logicalSize=decoded;for(auto&c:t.chunks)if(c.guid==a.guid){c.location={true,3162564249u,1};c.offset=off;c.size=len;}}if(meta!="-"){a.resourceMeta.clear();for(size_t k=0;k<meta.size();k+=2)a.resourceMeta.push_back(std::byte(std::stoul(meta.substr(k,2),nullptr,16)));}r.files.at(idx+1)={{true,3162564249u,1},off,len};changed=true;}if(changed){auto data=write_binary_bundle(m);r.files[0]={{true,3162564249u,1},(uint32_t)c1.size(),(uint32_t)data.size()};c1.insert(c1.end(),data.begin(),data.end());b.region=write_bundle_region(r.files);}}}if(std::string(v[1])!="list"){auto o=write_patch_toc(t.bundles,t.chunks,t.flags);verify_toc(read_toc(o));wr(v[6],o);wr(v[3],c1);}return 0;}catch(std::exception&e){std::cerr<<e.what();return 1;}}
