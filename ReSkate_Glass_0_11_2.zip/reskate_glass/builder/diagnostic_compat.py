"""Recognize exact temporary support trees only for a known historical build."""
import re

VS = 'shaders/bytecode/06b7cda9-3321-c174-30f1-ed2a5edd157c'
PS = 'shaders/bytecode/7c865dcb-3245-3305-fac4-4621dc65781c'


def recognized_support_trees(build, audit, catalog):
    map_id = build.get('map_id', '')
    if (build.get('package_id') != 'glass-auto-builder-v1'
            or not re.fullmatch(r'glass_author_[0-9a-f]{8}', map_id)
            or build.get('support', {}).get('map_id') != 'glass_shader_' + map_id[-8:]):
        return []
    assets = {item.get('asset'): item.get('sha256') for item in audit.get('patched_assets', [])}
    if (assets.get(VS) != catalog['vertex_shader_hash']
            or assets.get(PS) not in catalog['baseline_pixel_hashes']):
        return []
    # Actual installed bytes still have to match a whole tree in the paired
    # installer's Test-Tree. An audit never authorizes arbitrary changed files.
    return catalog['variants']
