"""Compile independent float settings and private images using the existing t33 binding."""
from pathlib import Path
import re,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];source=root/'shader_source';out=root/'shaders/MaterialGlass';out.mkdir(exist_ok=True)
shutil.copyfile(root/'shaders/RGBADirtBoost/vs.dxil',out/'vs.dxil')
fields=['reflection_strength','roughness','face_opacity','edge_opacity','coverage','image_width']
for i in (6,7,8,9):
    original=(source/f'boost_rgba_ps_{i}.ll').read_text();s=original
    if '%dx.types.Dimensions = type' not in s:
        s=s.replace('define void @ShaderDomain_Ps()', '%dx.types.Dimensions = type { i32, i32, i32, i32 }\n\ndeclare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2\n\ndefine void @ShaderDomain_Ps()',1)
    header=[]
    for x,name in enumerate(fields):
        header.append(f'  %mat_{name}_sample = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %4, i32 0, i32 {x}, i32 0, i32 undef, i32 0, i32 0, i32 undef)')
        for c in range(4):
            n=f'mat_{name}_{c}'
            header.extend([f'  %{n}_f = extractvalue %dx.types.ResRet.f32 %mat_{name}_sample, {c}',f'  %{n}_scaled = fmul float %{n}_f, 2.550000e+02',f'  %{n}_round = fadd float %{n}_scaled, 5.000000e-01',f'  %{n}_byte = fptoui float %{n}_round to i32'])
            if c:header.append(f'  %{n}_shift = shl i32 %{n}_byte, {8*c}')
        header.extend([f'  %mat_{name}_lo = or i32 %mat_{name}_0_byte, %mat_{name}_1_shift',f'  %mat_{name}_hi = or i32 %mat_{name}_2_shift, %mat_{name}_3_shift',f'  %mat_{name}_bits = or i32 %mat_{name}_lo, %mat_{name}_hi',f'  %mat_{name} = bitcast i32 %mat_{name}_bits to float'])
    s=s.replace('  %dirtPositive =', '\n'.join(header)+'\n  %dirtPositive =',1)
    s=s.replace('  %dirtStrength = call float @dx.op.unary.f32(i32 7, float %dirtRaw)','  %dirtStrength = select i1 %pixelMode, float %mat_coverage, float 0.000000e+00')
    dims='''  %mat_dims = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %4, i32 0)
  %mat_w_i = extractvalue %dx.types.Dimensions %mat_dims, 0
  %mat_h_i = extractvalue %dx.types.Dimensions %mat_dims, 1
  %mat_w = uitofp i32 %mat_w_i to float
  %mat_h = uitofp i32 %mat_h_i to float
  %mat_u_extent = fsub float %mat_image_width, 1.000000e+00
  %mat_v_extent = fsub float %mat_h, 2.000000e+00
  %mat_u_scaled = fmul float %pixelURepeat, %mat_u_extent
  %mat_v_scaled = fmul float %pixelVRepeat, %mat_v_extent
  %mat_u_center = fadd float %mat_u_scaled, 5.000000e-01
  %mat_v_center = fadd float %mat_v_scaled, 1.500000e+00
  %mat_sample_u = fdiv float %mat_u_center, %mat_w
  %mat_sample_v = fdiv float %mat_v_center, %mat_h
'''
    s=s.replace('  %pixelSample =', dims+'  %pixelSample =',1)
    s=s.replace('float %pixelURepeat, float %pixelVRepeat,','float %mat_sample_u, float %mat_sample_v,')
    s=s.replace('%pixelBoostStrength = fmul float %dirtStrength, 8.000000e+00','%pixelBoostStrength = fmul float %dirtStrength, 1.000000e+00')
    for name in fields[:4]:
        s=re.sub(rf'%setting_{name} = fadd float %setting_{name}_46, 0.000000e\+00',f'%setting_{name} = select i1 %pixelMode, float %mat_{name}, float %setting_{name}_46',s)
    assert s[s.index('!llvm.ident'):]==original[original.index('!llvm.ident'):]
    path=source/f'material_ps_{i}.ll';path.write_text(s)
    subprocess.run([sys.argv[1],str(path),str(out/f'ps_{i}.dxil')],check=True)
print('PASS: four material shaders assembled and DXIL validated; original signatures and metadata retained')
