;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; TEXCOORD                 0   xyzw        0     NONE   float   xyzw
; TEXCOORD                 1   xyz         1     NONE   float   xyz 
; TEXCOORD                 2   xyzw        2     NONE   float   xyzw
; TEXCOORD                 3   xyz         3     NONE   float   xyz 
; TEXCOORD                 4   xyz         4     NONE   float   xyz 
; SV_Position              0   xyzw        5      POS   float   xyzw
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: f7eb014fa03b065d4befdaf99ecc1bc5
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 6
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 6
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: ShaderDomain_Ps
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; TEXCOORD                 0                 linear       
; TEXCOORD                 1                 linear       
; TEXCOORD                 2                 linear       
; TEXCOORD                 3                 linear       
; TEXCOORD                 4                 linear       
; SV_Position              0          noperspective       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
; cbuffer 
; {
;
;   [212 x i8] (type annotation not present)
;
; }
;
; cbuffer 
; {
;
;   [76 x i8] (type annotation not present)
;
; }
;
; cbuffer 
; {
;
;   [7804 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [16 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [4 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [16 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [4 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [32 x i8] (type annotation not present)
; }
;
; Resource bind info for 
; {
;
;   [144 x i8] (type annotation not present)
; }
;
; Resource bind info for 
; {
;
;   [112 x i8] (type annotation not present)
; }
;
; Resource bind info for 
; {
;
;   [16 x i8] (type annotation not present)
; }
;
; Resource bind info for 
; {
;
;   [16 x i8] (type annotation not present)
; }
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
;                                   cbuffer      NA          NA     CB0            cb2     1
;                                   cbuffer      NA          NA     CB1            cb3     1
;                                   cbuffer      NA          NA     CB2            cb4     1
;                                   sampler      NA          NA      S0             s0     1
;                                   sampler      NA          NA      S1             s1     1
;                                   sampler      NA          NA      S2             s2     1
;                                   sampler      NA          NA      S3             s4     1
;                                   sampler      NA          NA      S4             s5     1
;                                   sampler      NA          NA      S5             s7     1
;                                   sampler      NA          NA      S6             s8     1
;                                   sampler      NA          NA      S7             s9     1
;                                   texture     f32          2d      T0            t65     1
;                                   texture    byte         r/o      T1            t66     1
;                                   texture     f32     2darray      T2            t67     1
;                                   texture  struct         r/o      T3            t69     1
;                                   texture     f32   cubearray      T4            t70     1
;                                   texture     f32          2d      T5            t71     1
;                                   texture  struct         r/o      T6            t73     1
;                                   texture  struct         r/o      T7            t74     1
;                                   texture     f32     2darray      T8            t76     1
;                                   texture     f32   cubearray      T9            t78     1
;                                   texture     f32   cubearray     T10            t80     1
;                                   texture     f32          2d     T11            t81     1
;                                   texture     f32          2d     T12            t82     1
;                                   texture     f32     2darray     T13            t84     1
;                                   texture  struct         r/o     T14            t85     1
;                                   texture     u32          3d     T15            t91     1
;                                   texture     f32          3d     T16            t95     1
;                                   texture     u32         buf     T17            t98     1
;                                   texture     u32         buf     T18           t100     1
;                                   texture     u32          3d     T19           t105     1
;                                   texture     f32          3d     T20           t106     1
;                                   texture     f32          2d     T21           t107     1
;                                   texture  struct         r/o     T22           t108     1
;                                   texture     f32          2d     T23           t109     1
;                                   texture     f32          2d     T24           t114     1
;                                   texture  struct         r/o     T25           t116     1
;                                   texture  struct         r/o     T26           t117     1
;                                   texture     f32          2d     T27           t121     1
;                                   texture  struct         r/o     T28           t123     1
;                                   texture  struct         r/o     T29           t128     1
;                                   texture     f32          2d     T30            t32     1
;                                   texture     f32          2d     T31            t33     1
;                                   texture     f32          2d     T32            t34     1
;                                   texture     f32          2d     T33            t35     1
;                                   texture     f32          2d     T34            t36     1
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.CBufRet.f32 = type { float, float, float, float }
%dx.types.CBufRet.i32 = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%dx.types.ResRet.i32 = type { i32, i32, i32, i32, i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }
%struct.ByteAddressBuffer = type { i32 }
%"class.Texture2DArray<float>" = type { float, %"class.Texture2DArray<float>::mips_type" }
%"class.Texture2DArray<float>::mips_type" = type { i32 }
%"class.StructuredBuffer<vector<float, 4> >" = type { <4 x float> }
%"class.TextureCubeArray<vector<float, 4> >" = type { <4 x float> }
%"class.StructuredBuffer<unsigned int>" = type { i32 }
%"class.TextureCubeArray<float>" = type { float }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2DArray<vector<float, 4> >" = type { <4 x float>, %"class.Texture2DArray<vector<float, 4> >::mips_type" }
%"class.Texture2DArray<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture3D<vector<unsigned int, 2> >" = type { <2 x i32>, %"class.Texture3D<vector<unsigned int, 2> >::mips_type" }
%"class.Texture3D<vector<unsigned int, 2> >::mips_type" = type { i32 }
%"class.Texture3D<vector<float, 4> >" = type { <4 x float>, %"class.Texture3D<vector<float, 4> >::mips_type" }
%"class.Texture3D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Buffer<unsigned int>" = type { i32 }
%"class.Texture3D<unsigned int>" = type { i32, %"class.Texture3D<unsigned int>::mips_type" }
%"class.Texture3D<unsigned int>::mips_type" = type { i32 }
%"class.StructuredBuffer<GiGridCellDesc>" = type { %struct.GiGridCellDesc }
%struct.GiGridCellDesc = type { <4 x float>, i32, i32, i32, i32 }
%"class.StructuredBuffer<ProbeContainer>" = type { %struct.ProbeContainer }
%struct.ProbeContainer = type { [9 x <4 x float>] }
%"hostlayout.class.StructuredBuffer<DenseProbeVolume>" = type { %hostlayout.struct.DenseProbeVolume }
%hostlayout.struct.DenseProbeVolume = type { [3 x <4 x float>], <3 x i32>, i32, <3 x i32>, i32, <3 x float>, float, <3 x float>, float }
%"class.StructuredBuffer<GiGridCellTreeOffsets>" = type { %struct.GiGridCellTreeOffsets }
%struct.GiGridCellTreeOffsets = type { i32, i32, i32, i32 }
%"class.StructuredBuffer<GiGridNode>" = type { %struct.GiGridNode }
%struct.GiGridNode = type { i32, i32, i32, i32 }
%common_shadercomponents_configuration_collections_worldglobal_collection = type { float, float, float, float, <3 x float>, <3 x float>, <3 x float>, float, float, float, float, float, float, i32, float, float, float, float, float, float, float, float, float, i32, float, float, float, float, float, float, <4 x float>, float, float, float, i32, float, float, i32, i32, float }
%common_shadercomponents_configuration_collections_worldseasonalevent_collection = type { <3 x float>, <3 x float>, <3 x float>, <3 x float>, <3 x float> }
%hostlayout.PerPassConstants = type { [3 x <4 x float>], <4 x float>, <4 x float>, [4 x [4 x <4 x float>]], <4 x float>, [3 x <4 x i32>], [4 x <4 x float>], [5 x <4 x i32>], <4 x float>, [120 x <4 x float>], [4 x <4 x i32>], <4 x float>, [8 x <4 x float>], [8 x <4 x float>], <4 x float>, %struct.TerrainHeightFieldParameters, [5 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], %struct.TerrainColorParameters, [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [4 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [120 x <4 x float>], [4 x <4 x float>], [8 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], %struct.TerrainVirtualTexureParameters, [7 x <4 x float>], [4 x <4 x float>], <4 x float>, [4 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], [8 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], [3 x <4 x float>], [5 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [4 x <4 x float>], <4 x float>, <4 x float>, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, float, <3 x float>, float, <3 x float>, float, <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, float, i32, i32, float, float, float, i32, float, i32, float, float, float, float, i32, float, i32, i32, i32, i32, i32, float, float, i32, i32, i32, float, i32, i32, i32, float, float, float, float, float, float, float, i32, float, float, i32, i32 }
%struct.TerrainHeightFieldParameters = type { <4 x float>, <4 x float>, <4 x float>, <2 x i32>, float, float }
%struct.TerrainColorParameters = type { <4 x float>, <3 x float>, float }
%struct.TerrainVirtualTexureParameters = type { <4 x float>, <2 x i32>, i32, i32, <4 x float>, i32, <3 x float> }
%struct.SamplerState = type { i32 }
%struct.SamplerComparisonState = type { i32 }

define void @ShaderDomain_Ps() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 34, i32 36, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 33, i32 35, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 32, i32 34, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %4 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 31, i32 33, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %5 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 30, i32 32, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %6 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 29, i32 128, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %7 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 28, i32 123, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %8 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 27, i32 121, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %9 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 26, i32 117, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %10 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 25, i32 116, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %11 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 24, i32 114, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %12 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 23, i32 109, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %13 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 22, i32 108, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %14 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 21, i32 107, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %15 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 20, i32 106, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %16 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 19, i32 105, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %17 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 18, i32 100, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %18 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 17, i32 98, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %19 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 16, i32 95, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %20 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 15, i32 91, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %21 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 14, i32 85, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %22 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 13, i32 84, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %23 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 12, i32 82, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %24 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 11, i32 81, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %25 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 10, i32 80, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %26 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 9, i32 78, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %27 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 8, i32 76, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %28 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 7, i32 74, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %29 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 6, i32 73, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %30 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 5, i32 71, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %31 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 4, i32 70, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %32 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 3, i32 69, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %33 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 2, i32 67, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %34 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 66, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %35 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 65, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %36 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 7, i32 9, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %37 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 6, i32 8, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %38 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 5, i32 7, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %39 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 4, i32 5, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %40 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 3, i32 4, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %41 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 2, i32 2, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %42 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %43 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %44 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 2, i32 4, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %45 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 1, i32 3, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %46 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 0, i32 2, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %47 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %48 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %49 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %50 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %51 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %52 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %53 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %54 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %55 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %56 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %57 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %58 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %59 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %60 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %dirtPositive = fsub float 0.000000e+00, %60
  %dirtPresetInteger = call float @dx.op.unary.f32(i32 27, float %dirtPositive)
  %pixelLow = fcmp oge float %dirtPresetInteger, 5.200000e+01
  %pixelHigh = fcmp ole float %dirtPresetInteger, 5.600000e+01
  %pixelMode = and i1 %pixelLow, %pixelHigh
  %pixelBase = fsub float %dirtPresetInteger, 1.000000e+01
  %normalizedProfile = select i1 %pixelMode, float %pixelBase, float %dirtPresetInteger
  %dirtPresetNegative = fsub float 0.000000e+00, %normalizedProfile
  %dirtFraction = fsub float %dirtPositive, %dirtPresetInteger
  %dirtRaw = fmul float %dirtFraction, 0x3FF0842100000000
  %dirtStrength = call float @dx.op.unary.f32(i32 7, float %dirtRaw)
  %pixelU = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)
  %pixelV = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)
  %pixelURepeat = call float @dx.op.unary.f32(i32 22, float %pixelU)
  %pixelVRepeat = call float @dx.op.unary.f32(i32 22, float %pixelV)
  %pixelSample = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %4, %dx.types.Handle %42, float %pixelURepeat, float %pixelVRepeat, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)
  %pixelMask = extractvalue %dx.types.ResRet.f32 %pixelSample, 0
  %pixelBoostStrength = fmul float %dirtStrength, 8.000000e+00
  %pixelBoostRaw = fmul float %pixelBoostStrength, %pixelMask
  %pixelDirt = call float @dx.op.unary.f32(i32 7, float %pixelBoostRaw)
  %dirtAmount = select i1 %pixelMode, float %pixelDirt, float %dirtStrength
  %profile42 = fcmp oeq float %dirtPresetNegative, 0xC045000000000000
  %profile43 = fcmp oeq float %dirtPresetNegative, 0xC045800000000000
  %profile44 = fcmp oeq float %dirtPresetNegative, 0xC046000000000000
  %profile45 = fcmp oeq float %dirtPresetNegative, 0xC046800000000000
  %profile46 = fcmp oeq float %dirtPresetNegative, 0xC047000000000000
  %profileAny43 = or i1 %profile42, %profile43
  %profileAny44 = or i1 %profileAny43, %profile44
  %profileAny45 = or i1 %profileAny44, %profile45
  %r8Marked = or i1 %profileAny45, %profile46
  %setting_reflection_strength_43 = select i1 %profile43, float 0x3FD0000000000000, float 0x3FF0000000000000
  %setting_reflection_strength_44 = select i1 %profile44, float 0x4000000000000000, float %setting_reflection_strength_43
  %setting_reflection_strength_45 = select i1 %profile45, float 0x3FF0000000000000, float %setting_reflection_strength_44
  %setting_reflection_strength_46 = select i1 %profile46, float 0x3FF0000000000000, float %setting_reflection_strength_45
  %setting_reflection_strength = fadd float %setting_reflection_strength_46, 0.000000e+00
  %setting_roughness_43 = select i1 %profile43, float 0x3FA99999A0000000, float 0x3FA99999A0000000
  %setting_roughness_44 = select i1 %profile44, float 0x3FA99999A0000000, float %setting_roughness_43
  %setting_roughness_45 = select i1 %profile45, float 0x3FA99999A0000000, float %setting_roughness_44
  %setting_roughness_46 = select i1 %profile46, float 0x3FD99999A0000000, float %setting_roughness_45
  %setting_roughness = fadd float %setting_roughness_46, 0.000000e+00
  %setting_face_opacity_43 = select i1 %profile43, float 0x3FB47AE140000000, float 0x3FB47AE140000000
  %setting_face_opacity_44 = select i1 %profile44, float 0x3FB47AE140000000, float %setting_face_opacity_43
  %setting_face_opacity_45 = select i1 %profile45, float 0x3F947AE140000000, float %setting_face_opacity_44
  %setting_face_opacity_46 = select i1 %profile46, float 0x3FB47AE140000000, float %setting_face_opacity_45
  %setting_face_opacity = fadd float %setting_face_opacity_46, 0.000000e+00
  %setting_edge_opacity_43 = select i1 %profile43, float 0x3FE99999A0000000, float 0x3FE99999A0000000
  %setting_edge_opacity_44 = select i1 %profile44, float 0x3FE99999A0000000, float %setting_edge_opacity_43
  %setting_edge_opacity_45 = select i1 %profile45, float 0x3FD6666660000000, float %setting_edge_opacity_44
  %setting_edge_opacity_46 = select i1 %profile46, float 0x3FE99999A0000000, float %setting_edge_opacity_45
  %setting_edge_opacity = fadd float %setting_edge_opacity_46, 0.000000e+00
  %setting_smoothness = fsub float 1.000000e+00, %setting_roughness
  %setting_opacity_range = fsub float %setting_edge_opacity, %setting_face_opacity
  %61 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %62 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %63 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %64 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %65 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %66 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %67 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %glass_r5_dxx = call float @dx.op.unary.f32(i32 83, float %61)  ; DerivCoarseX(value)
  %glass_r5_dyx = call float @dx.op.unary.f32(i32 84, float %61)  ; DerivCoarseY(value)
  %glass_r5_dxy = call float @dx.op.unary.f32(i32 83, float %62)  ; DerivCoarseX(value)
  %glass_r5_dyy = call float @dx.op.unary.f32(i32 84, float %62)  ; DerivCoarseY(value)
  %glass_r5_dxz = call float @dx.op.unary.f32(i32 83, float %63)  ; DerivCoarseX(value)
  %glass_r5_dyz = call float @dx.op.unary.f32(i32 84, float %63)  ; DerivCoarseY(value)
  %glass_r5_crossxa = fmul float %glass_r5_dxy, %glass_r5_dyz
  %glass_r5_crossxb = fmul float %glass_r5_dxz, %glass_r5_dyy
  %glass_r5_crossx = fsub float %glass_r5_crossxa, %glass_r5_crossxb
  %glass_r5_crossya = fmul float %glass_r5_dxz, %glass_r5_dyx
  %glass_r5_crossyb = fmul float %glass_r5_dxx, %glass_r5_dyz
  %glass_r5_crossy = fsub float %glass_r5_crossya, %glass_r5_crossyb
  %glass_r5_crossza = fmul float %glass_r5_dxx, %glass_r5_dyy
  %glass_r5_crosszb = fmul float %glass_r5_dxy, %glass_r5_dyx
  %glass_r5_crossz = fsub float %glass_r5_crossza, %glass_r5_crosszb
  %glass_r5_length2 = call float @dx.op.dot3.f32(i32 55, float %glass_r5_crossx, float %glass_r5_crossy, float %glass_r5_crossz, float %glass_r5_crossx, float %glass_r5_crossy, float %glass_r5_crossz)  ; Dot3(ax,ay,az,bx,by,bz)
  %glass_r5_safe_length2 = call float @dx.op.binary.f32(i32 35, float %glass_r5_length2, float 0x3BC79CA100000000)  ; FMax(a,b)
  %glass_r5_inv_length = call float @dx.op.unary.f32(i32 25, float %glass_r5_safe_length2)  ; Rsqrt(value)
  %glass_r5_raw_nx = fmul float %glass_r5_crossx, %glass_r5_inv_length
  %glass_r5_raw_ny = fmul float %glass_r5_crossy, %glass_r5_inv_length
  %glass_r5_raw_nz = fmul float %glass_r5_crossz, %glass_r5_inv_length
  %68 = alloca [12 x float], align 4
  %69 = alloca [12 x float], align 4
  %70 = alloca [6 x float], align 4
  %71 = alloca [6 x float], align 4
  %72 = alloca [6 x float], align 4
  %73 = alloca [6 x float], align 4
  %74 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 457)  ; CBufferLoadLegacy(handle,regIndex)
  %75 = extractvalue %dx.types.CBufRet.f32 %74, 3
  %76 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 455)  ; CBufferLoadLegacy(handle,regIndex)
  %77 = extractvalue %dx.types.CBufRet.f32 %76, 0
  %78 = extractvalue %dx.types.CBufRet.f32 %76, 1
  %79 = extractvalue %dx.types.CBufRet.f32 %76, 2
  %80 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 454)  ; CBufferLoadLegacy(handle,regIndex)
  %81 = extractvalue %dx.types.CBufRet.f32 %80, 0
  %82 = extractvalue %dx.types.CBufRet.f32 %80, 1
  %83 = extractvalue %dx.types.CBufRet.f32 %80, 2
  %84 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 208)  ; CBufferLoadLegacy(handle,regIndex)
  %85 = extractvalue %dx.types.CBufRet.f32 %84, 2
  %86 = extractvalue %dx.types.CBufRet.f32 %84, 3
  %87 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 459)  ; CBufferLoadLegacy(handle,regIndex)
  %88 = extractvalue %dx.types.CBufRet.f32 %87, 0
  %89 = extractvalue %dx.types.CBufRet.f32 %87, 1
  %90 = extractvalue %dx.types.CBufRet.f32 %87, 2
  %91 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 237)  ; CBufferLoadLegacy(handle,regIndex)
  %92 = extractvalue %dx.types.CBufRet.f32 %91, 0
  %93 = extractvalue %dx.types.CBufRet.f32 %91, 1
  %94 = extractvalue %dx.types.CBufRet.f32 %91, 2
  %95 = extractvalue %dx.types.CBufRet.f32 %91, 3
  %96 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 472)  ; CBufferLoadLegacy(handle,regIndex)
  %97 = extractvalue %dx.types.CBufRet.f32 %96, 2
  %98 = extractvalue %dx.types.CBufRet.f32 %96, 3
  %99 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 236)  ; CBufferLoadLegacy(handle,regIndex)
  %100 = extractvalue %dx.types.CBufRet.f32 %99, 0
  %101 = extractvalue %dx.types.CBufRet.f32 %99, 1
  %102 = extractvalue %dx.types.CBufRet.f32 %99, 2
  %103 = extractvalue %dx.types.CBufRet.f32 %99, 3
  %104 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 463)  ; CBufferLoadLegacy(handle,regIndex)
  %105 = extractvalue %dx.types.CBufRet.i32 %104, 3
  %106 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 400)  ; CBufferLoadLegacy(handle,regIndex)
  %107 = extractvalue %dx.types.CBufRet.f32 %106, 0
  %108 = extractvalue %dx.types.CBufRet.f32 %106, 1
  %109 = extractvalue %dx.types.CBufRet.f32 %106, 2
  %110 = extractvalue %dx.types.CBufRet.f32 %106, 3
  %111 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 217)  ; CBufferLoadLegacy(handle,regIndex)
  %112 = extractvalue %dx.types.CBufRet.f32 %111, 0
  %113 = extractvalue %dx.types.CBufRet.f32 %111, 1
  %114 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 209)  ; CBufferLoadLegacy(handle,regIndex)
  %115 = extractvalue %dx.types.CBufRet.f32 %114, 0
  %116 = extractvalue %dx.types.CBufRet.f32 %114, 1
  %117 = extractvalue %dx.types.CBufRet.f32 %114, 2
  %118 = extractvalue %dx.types.CBufRet.f32 %114, 3
  %119 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 395)  ; CBufferLoadLegacy(handle,regIndex)
  %120 = extractvalue %dx.types.CBufRet.f32 %119, 0
  %121 = extractvalue %dx.types.CBufRet.f32 %119, 1
  %122 = extractvalue %dx.types.CBufRet.f32 %119, 2
  %123 = extractvalue %dx.types.CBufRet.f32 %119, 3
  %124 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 234)  ; CBufferLoadLegacy(handle,regIndex)
  %125 = extractvalue %dx.types.CBufRet.f32 %124, 0
  %126 = extractvalue %dx.types.CBufRet.f32 %124, 1
  %127 = extractvalue %dx.types.CBufRet.f32 %87, 3
  %128 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 479)  ; CBufferLoadLegacy(handle,regIndex)
  %129 = extractvalue %dx.types.CBufRet.f32 %128, 3
  %130 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 3)  ; CBufferLoadLegacy(handle,regIndex)
  %131 = extractvalue %dx.types.CBufRet.f32 %130, 0
  %132 = extractvalue %dx.types.CBufRet.f32 %130, 2
  %133 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 159)  ; CBufferLoadLegacy(handle,regIndex)
  %134 = extractvalue %dx.types.CBufRet.f32 %133, 0
  %135 = extractvalue %dx.types.CBufRet.f32 %133, 2
  %136 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 21)  ; CBufferLoadLegacy(handle,regIndex)
  %137 = extractvalue %dx.types.CBufRet.f32 %136, 0
  %138 = extractvalue %dx.types.CBufRet.f32 %136, 2
  %139 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 25)  ; CBufferLoadLegacy(handle,regIndex)
  %140 = extractvalue %dx.types.CBufRet.f32 %139, 0
  %141 = extractvalue %dx.types.CBufRet.f32 %139, 1
  %142 = extractvalue %dx.types.CBufRet.f32 %139, 2
  %143 = extractvalue %dx.types.CBufRet.f32 %139, 3
  %144 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 26)  ; CBufferLoadLegacy(handle,regIndex)
  %145 = extractvalue %dx.types.CBufRet.f32 %144, 0
  %146 = extractvalue %dx.types.CBufRet.f32 %144, 1
  %147 = extractvalue %dx.types.CBufRet.f32 %144, 2
  %148 = extractvalue %dx.types.CBufRet.f32 %144, 3
  %149 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 27)  ; CBufferLoadLegacy(handle,regIndex)
  %150 = extractvalue %dx.types.CBufRet.f32 %149, 0
  %151 = extractvalue %dx.types.CBufRet.f32 %149, 1
  %152 = extractvalue %dx.types.CBufRet.f32 %149, 2
  %153 = extractvalue %dx.types.CBufRet.f32 %149, 3
  %154 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 4)  ; CBufferLoadLegacy(handle,regIndex)
  %155 = extractvalue %dx.types.CBufRet.f32 %154, 0
  %156 = extractvalue %dx.types.CBufRet.f32 %154, 1
  %157 = fmul fast float %61, 0x3FB99999A0000000
  %158 = fmul fast float %63, 0x3FB99999A0000000
  %159 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 452)  ; CBufferLoadLegacy(handle,regIndex)
  %160 = extractvalue %dx.types.CBufRet.f32 %159, 0
  %161 = extractvalue %dx.types.CBufRet.f32 %159, 2
  %162 = fmul fast float %161, 0x3F999999A0000000
  %163 = fadd fast float %162, %157
  %164 = fadd fast float %162, %158
  %165 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %1, %dx.types.Handle %42, float %163, float %164, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %166 = extractvalue %dx.types.ResRet.f32 %165, 0
  %167 = extractvalue %dx.types.ResRet.f32 %165, 1
  %168 = fmul fast float %166, 2.000000e+00
  %169 = fmul fast float %167, 2.000000e+00
  %170 = fadd fast float %168, -1.000000e+00
  %171 = fadd fast float %169, -1.000000e+00
  %172 = fmul fast float %170, %170
  %173 = fmul fast float %171, %171
  %174 = fsub fast float 1.000000e+00, %173
  %175 = fsub fast float %174, %172
  %176 = call float @dx.op.unary.f32(i32 7, float %175)  ; Saturate(value)
  %177 = call float @dx.op.unary.f32(i32 24, float %176)  ; Sqrt(value)
  %178 = fsub fast float %157, %162
  %179 = fsub fast float %158, %162
  %180 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %2, %dx.types.Handle %42, float %178, float %179, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %181 = extractvalue %dx.types.ResRet.f32 %180, 0
  %182 = extractvalue %dx.types.ResRet.f32 %180, 1
  %183 = fmul fast float %181, 2.000000e+00
  %184 = fmul fast float %182, 2.000000e+00
  %185 = fadd fast float %183, -1.000000e+00
  %186 = fadd fast float %184, -1.000000e+00
  %187 = fmul fast float %185, %185
  %188 = fmul fast float %186, %186
  %189 = fsub fast float 1.000000e+00, %188
  %190 = fsub fast float %189, %187
  %191 = call float @dx.op.unary.f32(i32 7, float %190)  ; Saturate(value)
  %192 = call float @dx.op.unary.f32(i32 24, float %191)  ; Sqrt(value)
  %193 = fadd fast float %185, %170
  %194 = fadd fast float %186, %171
  %195 = fadd fast float %192, %177
  %196 = fmul fast float %61, 0x3FA99999A0000000
  %197 = fmul fast float %63, 0x3FA99999A0000000
  %198 = fsub fast float %196, %162
  %199 = fadd fast float %162, %197
  %200 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %3, %dx.types.Handle %42, float %198, float %199, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %201 = extractvalue %dx.types.ResRet.f32 %200, 0
  %202 = extractvalue %dx.types.ResRet.f32 %200, 1
  %203 = fmul fast float %201, 2.000000e+00
  %204 = fmul fast float %202, 2.000000e+00
  %205 = fadd fast float %203, -1.000000e+00
  %206 = fadd fast float %204, -1.000000e+00
  %207 = fmul fast float %205, %205
  %208 = fmul fast float %206, %206
  %209 = fsub fast float 1.000000e+00, %208
  %210 = fsub fast float %209, %207
  %211 = call float @dx.op.unary.f32(i32 7, float %210)  ; Saturate(value)
  %212 = call float @dx.op.unary.f32(i32 24, float %211)  ; Sqrt(value)
  %213 = fadd fast float %193, %205
  %214 = fadd fast float %194, %206
  %215 = fadd fast float %195, %212
  %216 = fcmp fast oeq float %213, 0.000000e+00
  %217 = fcmp fast oeq float %214, 0.000000e+00
  %218 = fcmp fast oeq float %215, 0.000000e+00
  %219 = and i1 %216, %217
  %220 = and i1 %218, %219
  br i1 %220, label %227, label %221

; <label>:221                                     ; preds = %0
  %222 = call float @dx.op.dot3.f32(i32 55, float %213, float %214, float %215, float %213, float %214, float %215)  ; Dot3(ax,ay,az,bx,by,bz)
  %223 = call float @dx.op.unary.f32(i32 25, float %222)  ; Rsqrt(value)
  %224 = fmul fast float %223, %213
  %225 = fmul fast float %223, %214
  %226 = fmul fast float %223, %215
  br label %227

; <label>:227                                     ; preds = %221, %0
  %228 = phi float [ %224, %221 ], [ 0.000000e+00, %0 ]
  %229 = phi float [ %225, %221 ], [ 0.000000e+00, %0 ]
  %230 = phi float [ %226, %221 ], [ 0.000000e+00, %0 ]
  %231 = fadd fast float %230, -1.000000e+00
  %232 = fmul fast float %228, 2.500000e-01
  %233 = fmul fast float %229, 2.500000e-01
  %234 = fmul fast float %231, 2.500000e-01
  %235 = fadd fast float %234, 1.000000e+00
  %236 = fmul fast float %232, %54
  %237 = call float @dx.op.tertiary.f32(i32 46, float %233, float %51, float %236)  ; FMad(a,b,c)
  %238 = call float @dx.op.tertiary.f32(i32 46, float %235, float %57, float %237)  ; FMad(a,b,c)
  %239 = fmul fast float %232, %55
  %240 = call float @dx.op.tertiary.f32(i32 46, float %233, float %52, float %239)  ; FMad(a,b,c)
  %241 = call float @dx.op.tertiary.f32(i32 46, float %235, float %58, float %240)  ; FMad(a,b,c)
  %242 = fmul fast float %232, %56
  %243 = call float @dx.op.tertiary.f32(i32 46, float %233, float %53, float %242)  ; FMad(a,b,c)
  %244 = call float @dx.op.tertiary.f32(i32 46, float %235, float %59, float %243)  ; FMad(a,b,c)
  %245 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %45, i32 1)  ; CBufferLoadLegacy(handle,regIndex)
  %246 = extractvalue %dx.types.CBufRet.f32 %245, 0
  %247 = extractvalue %dx.types.CBufRet.f32 %245, 1
  %248 = extractvalue %dx.types.CBufRet.f32 %245, 2
  %249 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %45, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %250 = extractvalue %dx.types.CBufRet.f32 %249, 0
  %251 = extractvalue %dx.types.CBufRet.f32 %249, 1
  %252 = extractvalue %dx.types.CBufRet.f32 %249, 2
  %253 = fsub fast float %246, %250
  %254 = fsub fast float %247, %251
  %255 = fsub fast float %248, %252
  %256 = fmul fast float %253, %241
  %257 = fmul fast float %254, %241
  %258 = fmul fast float %255, %241
  %259 = fadd fast float %256, %250
  %260 = fadd fast float %257, %251
  %261 = fadd fast float %258, %252
  %262 = fmul fast float %241, 0x3FC3333300000000
  %263 = fadd fast float %262, 0x3FE99999A0000000
  %264 = fmul fast float %238, 8.750000e-01
  %265 = fmul fast float %241, 8.750000e-01
  %266 = fmul fast float %244, 8.750000e-01
  %267 = fsub fast float %77, %61
  %268 = fsub fast float %78, %62
  %269 = fsub fast float %79, %63
  %270 = call float @dx.op.dot3.f32(i32 55, float %267, float %268, float %269, float %267, float %268, float %269)  ; Dot3(ax,ay,az,bx,by,bz)
  %271 = call float @dx.op.unary.f32(i32 25, float %270)  ; Rsqrt(value)
  %272 = fmul fast float %271, %267
  %273 = fmul fast float %271, %268
  %274 = fmul fast float %271, %269
  %glass_r5_dot = call float @dx.op.dot3.f32(i32 55, float %glass_r5_raw_nx, float %glass_r5_raw_ny, float %glass_r5_raw_nz, float %272, float %273, float %274)  ; Dot3(ax,ay,az,bx,by,bz)
  %glass_r5_back = fcmp olt float %glass_r5_dot, 0.000000e+00
  %glass_r5_face = select i1 %glass_r5_back, float -1.000000e+00, float 1.000000e+00
  %glass_r5_nx = fmul float %glass_r5_raw_nx, %glass_r5_face
  %glass_r5_ny = fmul float %glass_r5_raw_ny, %glass_r5_face
  %glass_r5_nz = fmul float %glass_r5_raw_nz, %glass_r5_face
  %glass_r5_abs_dot = call float @dx.op.unary.f32(i32 6, float %glass_r5_dot)  ; FAbs(value)
  %glass_r5_cos = call float @dx.op.unary.f32(i32 7, float %glass_r5_abs_dot)  ; Saturate(value)
  %glass_r5_grazing = fsub float 1.000000e+00, %glass_r5_cos
  %glass_r5_grazing2 = fmul float %glass_r5_grazing, %glass_r5_grazing
  %glass_r5_grazing4 = fmul float %glass_r5_grazing2, %glass_r5_grazing2
  %glass_r5_grazing5 = fmul float %glass_r5_grazing4, %glass_r5_grazing
  %glass_r5_native_grazing = fmul float %glass_r5_grazing5, 0x3FEEB851E0000000
  %glass_r5_native_fresnel = fadd float %glass_r5_native_grazing, 0x3FA47AE140000000
  %glass_r5_target_grazing = fmul float %glass_r5_grazing5, %setting_opacity_range
  %glass_r5_glass_alpha = fadd float %glass_r5_target_grazing, %setting_face_opacity
  %glass_r5_mirror_half = fcmp olt float %61, 0.000000e+00
  %dirtOpacityGap = fsub float 0x3FEE666660000000, %glass_r5_glass_alpha
  %dirtOpacityDelta = fmul float %dirtAmount, %dirtOpacityGap
  %glass_r5_alpha = fadd float %glass_r5_glass_alpha, %dirtOpacityDelta
  %glass_r5_reflection_scale = fdiv float %glass_r5_alpha, %glass_r5_native_fresnel
  %275 = fmul fast float %160, 0x3F847AE140000000
  %276 = fmul fast float %61, 0x3F947AE140000000
  %277 = fmul fast float %63, 0x3F947AE140000000
  %278 = fadd fast float %275, %276
  %279 = fadd fast float %275, %277
  %280 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %4, %dx.types.Handle %42, float %278, float %279, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %281 = extractvalue %dx.types.ResRet.f32 %280, 0
  %282 = extractvalue %dx.types.ResRet.f32 %280, 1
  %283 = extractvalue %dx.types.ResRet.f32 %280, 2
  %284 = fsub fast float %196, %275
  %285 = fsub fast float %197, %275
  %286 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %4, %dx.types.Handle %42, float %284, float %285, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %287 = extractvalue %dx.types.ResRet.f32 %286, 0
  %288 = extractvalue %dx.types.ResRet.f32 %286, 1
  %289 = extractvalue %dx.types.ResRet.f32 %286, 2
  %290 = fmul fast float %238, 4.000000e+00
  %291 = fmul fast float %241, 4.000000e+00
  %292 = fmul fast float %244, 4.000000e+00
  %293 = fadd fast float %290, %61
  %294 = fadd fast float %291, %62
  %295 = fadd fast float %292, %63
  %296 = fmul fast float %293, 0x3F847AE140000000
  %297 = fmul fast float %294, 0x3F847AE140000000
  %298 = fmul fast float %295, 0x3F847AE140000000
  %299 = call float @dx.op.unary.f32(i32 22, float %296)  ; Frc(value)
  %300 = call float @dx.op.unary.f32(i32 22, float %297)  ; Frc(value)
  %301 = call float @dx.op.unary.f32(i32 22, float %298)  ; Frc(value)
  %302 = fmul fast float %299, 1.024000e+03
  %303 = fmul fast float %300, 1.024000e+03
  %304 = fmul fast float %301, 1.024000e+03
  %305 = call float @dx.op.unary.f32(i32 27, float %302)  ; Round_ni(value)
  %306 = call float @dx.op.unary.f32(i32 27, float %303)  ; Round_ni(value)
  %307 = call float @dx.op.unary.f32(i32 27, float %304)  ; Round_ni(value)
  %308 = fmul fast float %305, 0x3F59E377A0000000
  %309 = fmul fast float %306, 0x3F59E377A0000000
  %310 = fmul fast float %307, 0x3F59E377A0000000
  %311 = fadd fast float %308, 0xC00921FB60000000
  %312 = fadd fast float %309, 0xBFF9E377A0000000
  %313 = fadd fast float %310, 0xC005BF0A80000000
  %314 = fmul fast float %311, %311
  %315 = fmul fast float %312, %312
  %316 = fadd fast float %315, %314
  %317 = fmul fast float %313, %313
  %318 = fadd fast float %316, %317
  %319 = call float @dx.op.unary.f32(i32 24, float %318)  ; Sqrt(value)
  %320 = call float @dx.op.unary.f32(i32 13, float %319)  ; Sin(value)
  %321 = fmul fast float %320, 0x4123B6DA60000000
  %322 = call float @dx.op.unary.f32(i32 22, float %321)  ; Frc(value)
  %323 = fmul fast float %305, 0x3F5B7D1140000000
  %324 = fmul fast float %306, 0x3F5B7D1140000000
  %325 = fmul fast float %307, 0x3F5B7D1140000000
  %326 = fadd fast float %323, 0xC00921FB60000000
  %327 = fadd fast float %324, 0xBFF9E377A0000000
  %328 = fadd fast float %325, 0xC005BF0A80000000
  %329 = fmul fast float %326, %326
  %330 = fmul fast float %327, %327
  %331 = fadd fast float %330, %329
  %332 = fmul fast float %328, %328
  %333 = fadd fast float %331, %332
  %334 = call float @dx.op.unary.f32(i32 24, float %333)  ; Sqrt(value)
  %335 = call float @dx.op.unary.f32(i32 13, float %334)  ; Sin(value)
  %336 = fmul fast float %335, 0x4123B6DA60000000
  %337 = call float @dx.op.unary.f32(i32 22, float %336)  ; Frc(value)
  %338 = fmul fast float %305, 0x3F5D16AAE0000000
  %339 = fmul fast float %306, 0x3F5D16AAE0000000
  %340 = fmul fast float %307, 0x3F5D16AAE0000000
  %341 = fadd fast float %338, 0xC00921FB60000000
  %342 = fadd fast float %339, 0xBFF9E377A0000000
  %343 = fadd fast float %340, 0xC005BF0A80000000
  %344 = fmul fast float %341, %341
  %345 = fmul fast float %342, %342
  %346 = fadd fast float %345, %344
  %347 = fmul fast float %343, %343
  %348 = fadd fast float %346, %347
  %349 = call float @dx.op.unary.f32(i32 24, float %348)  ; Sqrt(value)
  %350 = call float @dx.op.unary.f32(i32 13, float %349)  ; Sin(value)
  %351 = fmul fast float %350, 0x4123B6DA60000000
  %352 = call float @dx.op.unary.f32(i32 22, float %351)  ; Frc(value)
  %353 = fmul fast float %293, 0x3F747AE140000000
  %354 = fmul fast float %294, 0x3F747AE140000000
  %355 = fmul fast float %295, 0x3F747AE140000000
  %356 = call float @dx.op.unary.f32(i32 22, float %353)  ; Frc(value)
  %357 = call float @dx.op.unary.f32(i32 22, float %354)  ; Frc(value)
  %358 = call float @dx.op.unary.f32(i32 22, float %355)  ; Frc(value)
  %359 = fmul fast float %356, 1.024000e+03
  %360 = fmul fast float %357, 1.024000e+03
  %361 = fmul fast float %358, 1.024000e+03
  %362 = call float @dx.op.unary.f32(i32 27, float %359)  ; Round_ni(value)
  %363 = call float @dx.op.unary.f32(i32 27, float %360)  ; Round_ni(value)
  %364 = call float @dx.op.unary.f32(i32 27, float %361)  ; Round_ni(value)
  %365 = fmul fast float %362, 0x3F59E377A0000000
  %366 = fmul fast float %363, 0x3F59E377A0000000
  %367 = fmul fast float %364, 0x3F59E377A0000000
  %368 = fadd fast float %365, 0xC00921FB60000000
  %369 = fadd fast float %366, 0xBFF9E377A0000000
  %370 = fadd fast float %367, 0xC005BF0A80000000
  %371 = fmul fast float %368, %368
  %372 = fmul fast float %369, %369
  %373 = fadd fast float %372, %371
  %374 = fmul fast float %370, %370
  %375 = fadd fast float %373, %374
  %376 = call float @dx.op.unary.f32(i32 24, float %375)  ; Sqrt(value)
  %377 = call float @dx.op.unary.f32(i32 13, float %376)  ; Sin(value)
  %378 = fmul fast float %377, 0x4123B6DA60000000
  %379 = call float @dx.op.unary.f32(i32 22, float %378)  ; Frc(value)
  %380 = fmul fast float %362, 0x3F5B7D1140000000
  %381 = fmul fast float %363, 0x3F5B7D1140000000
  %382 = fmul fast float %364, 0x3F5B7D1140000000
  %383 = fadd fast float %380, 0xC00921FB60000000
  %384 = fadd fast float %381, 0xBFF9E377A0000000
  %385 = fadd fast float %382, 0xC005BF0A80000000
  %386 = fmul fast float %383, %383
  %387 = fmul fast float %384, %384
  %388 = fadd fast float %387, %386
  %389 = fmul fast float %385, %385
  %390 = fadd fast float %388, %389
  %391 = call float @dx.op.unary.f32(i32 24, float %390)  ; Sqrt(value)
  %392 = call float @dx.op.unary.f32(i32 13, float %391)  ; Sin(value)
  %393 = fmul fast float %392, 0x4123B6DA60000000
  %394 = call float @dx.op.unary.f32(i32 22, float %393)  ; Frc(value)
  %395 = fmul fast float %362, 0x3F5D16AAE0000000
  %396 = fmul fast float %363, 0x3F5D16AAE0000000
  %397 = fmul fast float %364, 0x3F5D16AAE0000000
  %398 = fadd fast float %395, 0xC00921FB60000000
  %399 = fadd fast float %396, 0xBFF9E377A0000000
  %400 = fadd fast float %397, 0xC005BF0A80000000
  %401 = fmul fast float %398, %398
  %402 = fmul fast float %399, %399
  %403 = fadd fast float %402, %401
  %404 = fmul fast float %400, %400
  %405 = fadd fast float %403, %404
  %406 = call float @dx.op.unary.f32(i32 24, float %405)  ; Sqrt(value)
  %407 = call float @dx.op.unary.f32(i32 13, float %406)  ; Sin(value)
  %408 = fmul fast float %407, 0x4123B6DA60000000
  %409 = call float @dx.op.unary.f32(i32 22, float %408)  ; Frc(value)
  %410 = fsub fast float %379, %322
  %411 = fsub fast float %394, %337
  %412 = fsub fast float %409, %352
  %413 = fmul fast float %410, 5.000000e-01
  %414 = fmul fast float %411, 5.000000e-01
  %415 = fmul fast float %412, 5.000000e-01
  %416 = fadd fast float %413, %322
  %417 = fadd fast float %414, %337
  %418 = fadd fast float %415, %352
  %419 = fmul fast float %416, 0x3FD3333320000000
  %420 = fadd fast float %419, 0x3FD99999A0000000
  %421 = fsub fast float %287, %281
  %422 = fsub fast float %288, %282
  %423 = fsub fast float %289, %283
  %424 = fmul fast float %420, %421
  %425 = fmul fast float %420, %422
  %426 = fmul fast float %420, %423
  %427 = fadd fast float %424, %281
  %428 = fadd fast float %425, %282
  %429 = fadd fast float %426, %283
  %430 = fsub fast float 1.000000e+00, %427
  %431 = fsub fast float 1.000000e+00, %428
  %432 = fsub fast float 1.000000e+00, %429
  %433 = fmul fast float %432, 2.000000e+00
  %434 = fsub fast float 1.000000e+00, %416
  %435 = fsub fast float 1.000000e+00, %417
  %436 = fsub fast float 1.000000e+00, %418
  %437 = fmul fast float %434, 2.000000e+00
  %438 = fmul fast float %437, %430
  %439 = fmul fast float %435, 2.000000e+00
  %440 = fmul fast float %439, %431
  %441 = fmul fast float %433, %436
  %442 = fsub fast float 1.000000e+00, %438
  %443 = fsub fast float 1.000000e+00, %440
  %444 = fsub fast float 1.000000e+00, %441
  %445 = fmul fast float %429, 2.000000e+00
  %446 = fmul fast float %416, 2.000000e+00
  %447 = fmul fast float %446, %427
  %448 = fmul fast float %417, 2.000000e+00
  %449 = fmul fast float %448, %428
  %450 = fmul fast float %445, %418
  %451 = fcmp fast olt float %427, 5.000000e-01
  %452 = fcmp fast olt float %428, 5.000000e-01
  %453 = fcmp fast olt float %429, 5.000000e-01
  %454 = select i1 %451, float %447, float %442
  %455 = select i1 %452, float %449, float %443
  %456 = select i1 %453, float %450, float %444
  %457 = fsub fast float %454, %427
  %458 = fsub fast float %455, %428
  %459 = fsub fast float %456, %429
  %460 = fmul fast float %457, 2.500000e-01
  %461 = fmul fast float %458, 2.500000e-01
  %462 = fmul fast float %459, 2.500000e-01
  %463 = fadd fast float %460, %427
  %464 = fadd fast float %461, %428
  %465 = fadd fast float %462, %429
  %466 = call float @dx.op.unary.f32(i32 22, float %293)  ; Frc(value)
  %467 = call float @dx.op.unary.f32(i32 22, float %294)  ; Frc(value)
  %468 = call float @dx.op.unary.f32(i32 22, float %295)  ; Frc(value)
  %469 = fmul fast float %466, 1.024000e+03
  %470 = fmul fast float %467, 1.024000e+03
  %471 = fmul fast float %468, 1.024000e+03
  %472 = call float @dx.op.unary.f32(i32 27, float %469)  ; Round_ni(value)
  %473 = call float @dx.op.unary.f32(i32 27, float %470)  ; Round_ni(value)
  %474 = call float @dx.op.unary.f32(i32 27, float %471)  ; Round_ni(value)
  %475 = fmul fast float %472, 0x3F59E377A0000000
  %476 = fmul fast float %473, 0x3F59E377A0000000
  %477 = fmul fast float %474, 0x3F59E377A0000000
  %478 = fadd fast float %475, 0xC00921FB60000000
  %479 = fadd fast float %476, 0xBFF9E377A0000000
  %480 = fadd fast float %477, 0xC005BF0A80000000
  %481 = fmul fast float %478, %478
  %482 = fmul fast float %479, %479
  %483 = fadd fast float %482, %481
  %484 = fmul fast float %480, %480
  %485 = fadd fast float %483, %484
  %486 = call float @dx.op.unary.f32(i32 24, float %485)  ; Sqrt(value)
  %487 = call float @dx.op.unary.f32(i32 13, float %486)  ; Sin(value)
  %488 = fmul fast float %487, 0x4123B6DA60000000
  %489 = call float @dx.op.unary.f32(i32 22, float %488)  ; Frc(value)
  %490 = fmul fast float %472, 0x3F5B7D1140000000
  %491 = fmul fast float %473, 0x3F5B7D1140000000
  %492 = fmul fast float %474, 0x3F5B7D1140000000
  %493 = fadd fast float %490, 0xC00921FB60000000
  %494 = fadd fast float %491, 0xBFF9E377A0000000
  %495 = fadd fast float %492, 0xC005BF0A80000000
  %496 = fmul fast float %493, %493
  %497 = fmul fast float %494, %494
  %498 = fadd fast float %497, %496
  %499 = fmul fast float %495, %495
  %500 = fadd fast float %498, %499
  %501 = call float @dx.op.unary.f32(i32 24, float %500)  ; Sqrt(value)
  %502 = call float @dx.op.unary.f32(i32 13, float %501)  ; Sin(value)
  %503 = fmul fast float %502, 0x4123B6DA60000000
  %504 = call float @dx.op.unary.f32(i32 22, float %503)  ; Frc(value)
  %505 = fmul fast float %472, 0x3F5D16AAE0000000
  %506 = fmul fast float %473, 0x3F5D16AAE0000000
  %507 = fmul fast float %474, 0x3F5D16AAE0000000
  %508 = fadd fast float %505, 0xC00921FB60000000
  %509 = fadd fast float %506, 0xBFF9E377A0000000
  %510 = fadd fast float %507, 0xC005BF0A80000000
  %511 = fmul fast float %508, %508
  %512 = fmul fast float %509, %509
  %513 = fadd fast float %512, %511
  %514 = fmul fast float %510, %510
  %515 = fadd fast float %513, %514
  %516 = call float @dx.op.unary.f32(i32 24, float %515)  ; Sqrt(value)
  %517 = call float @dx.op.unary.f32(i32 13, float %516)  ; Sin(value)
  %518 = fmul fast float %517, 0x4123B6DA60000000
  %519 = call float @dx.op.unary.f32(i32 22, float %518)  ; Frc(value)
  %520 = fsub fast float 1.000000e+00, %463
  %521 = fsub fast float 1.000000e+00, %464
  %522 = fsub fast float 1.000000e+00, %465
  %523 = fmul fast float %520, 2.000000e+00
  %524 = fmul fast float %521, 2.000000e+00
  %525 = fmul fast float %522, 2.000000e+00
  %526 = fsub fast float 1.000000e+00, %489
  %527 = fsub fast float 1.000000e+00, %504
  %528 = fsub fast float 1.000000e+00, %519
  %529 = fmul fast float %523, %526
  %530 = fmul fast float %524, %527
  %531 = fmul fast float %525, %528
  %532 = fsub fast float 1.000000e+00, %529
  %533 = fsub fast float 1.000000e+00, %530
  %534 = fsub fast float 1.000000e+00, %531
  %535 = fmul fast float %463, 2.000000e+00
  %536 = fmul fast float %464, 2.000000e+00
  %537 = fmul fast float %465, 2.000000e+00
  %538 = fmul fast float %535, %489
  %539 = fmul fast float %536, %504
  %540 = fmul fast float %537, %519
  %541 = fcmp fast olt float %463, 5.000000e-01
  %542 = fcmp fast olt float %464, 5.000000e-01
  %543 = fcmp fast olt float %465, 5.000000e-01
  %544 = select i1 %541, float %538, float %532
  %545 = select i1 %542, float %539, float %533
  %546 = select i1 %543, float %540, float %534
  %547 = fsub fast float %544, %463
  %548 = fsub fast float %545, %464
  %549 = fsub fast float %546, %465
  %550 = fmul fast float %547, 0x3FB99999A0000000
  %551 = fmul fast float %548, 0x3FB99999A0000000
  %552 = fmul fast float %549, 0x3FB99999A0000000
  %553 = fadd fast float %550, %463
  %554 = fadd fast float %551, %464
  %555 = fadd fast float %552, %465
  %556 = fmul fast float %272, 2.500000e-01
  %557 = fmul fast float %556, %553
  %558 = fmul fast float %273, 2.500000e-01
  %559 = fmul fast float %558, %554
  %560 = fmul fast float %274, 2.500000e-01
  %561 = fmul fast float %560, %555
  %562 = fadd fast float %557, %264
  %563 = fadd fast float %559, %265
  %564 = fadd fast float %561, %266
  %565 = fsub fast float %61, %77
  %566 = fsub fast float %62, %78
  %567 = fsub fast float %63, %79
  %568 = call float @dx.op.dot3.f32(i32 55, float %565, float %566, float %567, float %272, float %273, float %274)  ; Dot3(ax,ay,az,bx,by,bz)
  %569 = call float @dx.op.unary.f32(i32 6, float %568)  ; FAbs(value)
  %570 = fadd fast float %569, -5.000000e+00
  %571 = fmul fast float %570, 0x3F96C16C20000000
  %572 = call float @dx.op.unary.f32(i32 7, float %571)  ; Saturate(value)
  %573 = fmul fast float %572, %572
  %574 = fmul fast float %573, %572
  %575 = fmul fast float %572, 6.000000e+00
  %576 = fadd fast float %575, -1.500000e+01
  %577 = fmul fast float %576, %572
  %578 = fadd fast float %577, 1.000000e+01
  %579 = fmul fast float %574, %578
  %580 = fmul fast float %579, %579
  %581 = fmul fast float %580, 7.500000e-01
  %582 = fsub fast float 1.000000e+00, %563
  %583 = fmul fast float %581, %562
  %584 = fmul fast float %581, %582
  %585 = fmul fast float %581, %564
  %586 = fsub fast float %562, %583
  %587 = fadd fast float %584, %563
  %588 = fsub fast float %564, %585
  %589 = fcmp fast oeq float %586, 0.000000e+00
  %590 = fcmp fast oeq float %587, 0.000000e+00
  %591 = fcmp fast oeq float %588, 0.000000e+00
  %592 = and i1 %589, %590
  %593 = and i1 %591, %592
  br i1 %593, label %600, label %594

; <label>:594                                     ; preds = %227
  %595 = call float @dx.op.dot3.f32(i32 55, float %586, float %587, float %588, float %586, float %587, float %588)  ; Dot3(ax,ay,az,bx,by,bz)
  %596 = call float @dx.op.unary.f32(i32 25, float %595)  ; Rsqrt(value)
  %597 = fmul fast float %596, %586
  %598 = fmul fast float %596, %587
  %599 = fmul fast float %596, %588
  br label %600

; <label>:600                                     ; preds = %594, %227
  %601 = phi float [ %597, %594 ], [ 0.000000e+00, %227 ]
  %602 = phi float [ %598, %594 ], [ 0.000000e+00, %227 ]
  %603 = phi float [ %599, %594 ], [ 0.000000e+00, %227 ]
  %604 = fmul fast float %241, 0x3FD3333300000000
  %605 = fsub fast float 0x3FD9999980000000, %604
  %606 = fsub fast float 1.000000e+00, %553
  %607 = fmul fast float %606, %605
  %608 = fsub fast float 1.000000e+00, %607
  %609 = fadd fast float %604, 0x3FF99999A0000000
  %610 = fmul fast float %553, %609
  %611 = fcmp fast olt float %263, 5.000000e-01
  %612 = select i1 %611, float %610, float %608
  %613 = fsub fast float %612, %263
  %614 = fmul fast float %613, 2.500000e-01
  %615 = fadd fast float %614, %263
  %616 = fsub fast float -0.000000e+00, %81
  %617 = fsub fast float -0.000000e+00, %82
  %618 = fsub fast float -0.000000e+00, %83
  %619 = call float @dx.op.dot3.f32(i32 55, float %616, float %617, float %618, float %267, float %268, float %269)  ; Dot3(ax,ay,az,bx,by,bz)
  %620 = call float @dx.op.unary.f32(i32 6, float %619)  ; FAbs(value)
  %621 = fadd fast float %620, -2.000000e+02
  %622 = fmul fast float %621, 0x3F42345680000000
  %623 = call float @dx.op.unary.f32(i32 7, float %622)  ; Saturate(value)
  %624 = fmul fast float %623, %623
  %625 = fmul fast float %624, %623
  %626 = fmul fast float %623, 6.000000e+00
  %627 = fadd fast float %626, -1.500000e+01
  %628 = fmul fast float %627, %623
  %629 = fadd fast float %628, 1.000000e+01
  %630 = fmul fast float %625, %629
  %631 = fsub fast float 5.000000e-01, %259
  %632 = fsub fast float 5.000000e-01, %260
  %633 = fsub fast float 5.000000e-01, %261
  %634 = fmul fast float %630, %631
  %635 = fmul fast float %630, %632
  %636 = fmul fast float %630, %633
  %637 = fadd fast float %634, %259
  %638 = fadd fast float %635, %260
  %639 = fadd fast float %636, %261
  %640 = fsub fast float 1.000000e+00, %602
  %641 = fmul fast float %630, %601
  %642 = fmul fast float %630, %640
  %643 = fmul fast float %630, %603
  %644 = fsub fast float %601, %641
  %645 = fadd fast float %642, %602
  %646 = fsub fast float %603, %643
  %647 = fmul fast float %630, %615
  %648 = fsub fast float %615, %647
  %649 = call float @dx.op.dot3.f32(i32 55, float %565, float %566, float %567, float %616, float %617, float %618)  ; Dot3(ax,ay,az,bx,by,bz)
  %650 = call float @dx.op.unary.f32(i32 6, float %649)  ; FAbs(value)
  %651 = fsub fast float %489, %416
  %652 = fsub fast float %504, %417
  %653 = fmul fast float %651, 0x3FC99999A0000000
  %654 = fmul fast float %652, 0x3FC99999A0000000
  %655 = fadd fast float %653, %416
  %656 = fadd fast float %654, %417
  %657 = fmul fast float %655, 2.000000e+00
  %658 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 473)  ; CBufferLoadLegacy(handle,regIndex)
  %659 = extractvalue %dx.types.CBufRet.f32 %658, 0
  %660 = extractvalue %dx.types.CBufRet.f32 %658, 1
  %661 = fmul fast float %85, %47
  %662 = fmul fast float %86, %48
  %663 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %11, %dx.types.Handle %38, float %661, float %662, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %664 = extractvalue %dx.types.ResRet.f32 %663, 0
  %665 = fsub fast float %664, %660
  %666 = fdiv fast float 1.000000e+00, %665
  %667 = fmul fast float %666, %659
  %668 = fadd fast float %657, -1.000000e+00
  %669 = fadd fast float %668, %650
  %670 = fsub fast float %669, %667
  %671 = call float @dx.op.unary.f32(i32 6, float %670)  ; FAbs(value)
  %672 = fadd fast float %671, -5.000000e+00
  %673 = fmul fast float %672, 0xBFC5555560000000
  %674 = call float @dx.op.unary.f32(i32 7, float %673)  ; Saturate(value)
  %675 = call float @dx.op.dot3.f32(i32 55, float %644, float %645, float %646, float %272, float %273, float %274)  ; Dot3(ax,ay,az,bx,by,bz)
  %676 = fmul fast float %379, 0x3FA47AE140000000
  %677 = fadd fast float %676, 0x3FEF5C2900000000
  %678 = fsub fast float %677, %675
  %679 = call float @dx.op.unary.f32(i32 23, float %678)  ; Log(value)
  %680 = fmul fast float %679, 4.000000e+00
  %681 = call float @dx.op.unary.f32(i32 21, float %680)  ; Exp(value)
  %682 = fadd fast float %681, 0xBFE3333340000000
  %683 = fmul fast float %682, 0x4014000020000000
  %684 = call float @dx.op.unary.f32(i32 7, float %683)  ; Saturate(value)
  %685 = fmul fast float %684, 0x3FC99999A0000000
  %686 = fadd fast float %685, %674
  %687 = fmul fast float %656, 0x3FB99999A0000000
  %688 = fsub fast float %662, %687
  %689 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %11, %dx.types.Handle %38, float %661, float %688, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %690 = extractvalue %dx.types.ResRet.f32 %689, 0
  %691 = fsub fast float %690, %660
  %692 = fdiv fast float 1.000000e+00, %691
  %693 = fsub fast float %666, %692
  %694 = fmul fast float %693, %659
  %695 = call float @dx.op.unary.f32(i32 6, float %694)  ; FAbs(value)
  %696 = fmul fast float %671, 5.000000e-01
  %697 = fadd fast float %696, 0xBF847AE140000000
  %698 = fadd fast float %697, %695
  %699 = fmul fast float %698, 1.000000e+02
  %700 = call float @dx.op.unary.f32(i32 7, float %699)  ; Saturate(value)
  %701 = fmul fast float %700, %686
  %702 = fadd fast float %701, %684
  %703 = fsub fast float 0x3F9482FB20000000, %637
  %704 = fsub fast float 0x3FB738DA40000000, %638
  %705 = fsub fast float 0x3FC51BC080000000, %639
  %706 = fmul fast float %702, %703
  %707 = fmul fast float %702, %704
  %708 = fmul fast float %702, %705
  %709 = fadd fast float %706, %637
  %710 = fadd fast float %707, %638
  %711 = fadd fast float %708, %639
  %712 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %45, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %713 = extractvalue %dx.types.CBufRet.f32 %712, 0
  %714 = extractvalue %dx.types.CBufRet.f32 %712, 1
  %715 = extractvalue %dx.types.CBufRet.f32 %712, 2
  %716 = fsub fast float 1.000000e+00, %713
  %717 = fsub fast float 1.000000e+00, %714
  %718 = fsub fast float 1.000000e+00, %715
  %719 = fmul fast float %716, 5.000000e-01
  %720 = fmul fast float %717, 5.000000e-01
  %721 = fmul fast float %718, 5.000000e-01
  %722 = fadd fast float %719, %713
  %723 = fadd fast float %720, %714
  %724 = fadd fast float %721, %715
  %725 = fadd fast float %671, 0xBFD99999A0000000
  %726 = fmul fast float %725, 0xC00AAAAAA0000000
  %727 = call float @dx.op.unary.f32(i32 7, float %726)  ; Saturate(value)
  %728 = fsub fast float %722, %709
  %729 = fsub fast float %723, %710
  %730 = fsub fast float %724, %711
  %731 = fmul fast float %728, %727
  %732 = fmul fast float %729, %727
  %733 = fmul fast float %730, %727
  %734 = fadd fast float %731, %709
  %735 = fadd fast float %732, %710
  %736 = fadd fast float %733, %711
  %737 = fmul fast float %655, 2.500000e-01
  %738 = fadd fast float %650, %737
  %739 = fsub fast float %738, %667
  %740 = call float @dx.op.unary.f32(i32 6, float %739)  ; FAbs(value)
  %741 = fadd fast float %740, 0xBFC99999A0000000
  %742 = fmul fast float %741, -1.000000e+01
  %743 = call float @dx.op.unary.f32(i32 7, float %742)  ; Saturate(value)
  %744 = fsub fast float 1.000000e+00, %734
  %745 = fsub fast float 1.000000e+00, %735
  %746 = fsub fast float 1.000000e+00, %736
  %747 = fmul fast float %744, %743
  %748 = fmul fast float %745, %743
  %749 = fmul fast float %746, %743
  %750 = fadd fast float %747, %734
  %751 = fadd fast float %748, %735
  %752 = fadd fast float %749, %736
  %753 = fmul fast float %702, 2.500000e-01
  %754 = fsub fast float 1.000000e+00, %645
  %755 = fmul fast float %753, %644
  %756 = fmul fast float %753, %754
  %757 = fmul fast float %753, %646
  %758 = fsub fast float %644, %755
  %759 = fadd fast float %756, %645
  %760 = fsub fast float %646, %757
  %761 = fsub fast float 0x3FE99999A0000000, %648
  %762 = fmul fast float %702, %761
  %763 = fadd fast float %762, %648
  %764 = call float @dx.op.unary.f32(i32 6, float %268)  ; FAbs(value)
  %765 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %46, i32 4)  ; CBufferLoadLegacy(handle,regIndex)
  %766 = extractvalue %dx.types.CBufRet.f32 %765, 1
  %767 = fdiv fast float %764, %766
  %768 = call float @dx.op.unary.f32(i32 7, float %767)  ; Saturate(value)
  %769 = fmul fast float %768, %768
  %770 = fmul fast float %768, 2.000000e+00
  %771 = fsub fast float 3.000000e+00, %770
  %772 = fmul fast float %769, %771
  %773 = fmul fast float %772, 4.000000e+01
  %774 = extractvalue %dx.types.CBufRet.f32 %765, 0
  %775 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %46, i32 3)  ; CBufferLoadLegacy(handle,regIndex)
  %776 = extractvalue %dx.types.CBufRet.f32 %775, 3
  %777 = fadd fast float %620, -1.000000e+00
  %778 = fsub fast float %777, %776
  %779 = fadd fast float %778, %773
  %780 = fsub fast float %774, %776
  %781 = fdiv fast float %779, %780
  %782 = call float @dx.op.unary.f32(i32 7, float %781)  ; Saturate(value)
  %783 = fmul fast float %782, %772
  %784 = fsub fast float %783, %782
  %785 = fmul fast float %784, 5.000000e-01
  %786 = fadd fast float %785, %782
  %787 = call float @dx.op.unary.f32(i32 7, float %786)  ; Saturate(value)
  %788 = extractvalue %dx.types.CBufRet.f32 %765, 2
  %789 = fmul fast float %787, %788
  %790 = fmul fast float %789, 2.500000e-01
  %791 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %46, i32 1)  ; CBufferLoadLegacy(handle,regIndex)
  %792 = extractvalue %dx.types.CBufRet.f32 %791, 0
  %793 = extractvalue %dx.types.CBufRet.f32 %791, 1
  %794 = extractvalue %dx.types.CBufRet.f32 %791, 2
  %795 = fmul fast float %790, %792
  %796 = fmul fast float %790, %793
  %797 = fmul fast float %790, %794
  %798 = fadd fast float %750, %795
  %799 = fadd fast float %751, %796
  %800 = fadd fast float %752, %797
  %801 = fmul fast float %789, 7.500000e-01
  %802 = fsub fast float %792, %798
  %803 = fsub fast float %793, %799
  %804 = fsub fast float %794, %800
  %805 = fmul fast float %802, %801
  %806 = fmul fast float %803, %801
  %807 = fmul fast float %804, %801
  %808 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 453)  ; CBufferLoadLegacy(handle,regIndex)
  %809 = extractvalue %dx.types.CBufRet.i32 %808, 3
  %810 = fptoui float %47 to i32
  %811 = fptoui float %48 to i32
  %812 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 181)  ; CBufferLoadLegacy(handle,regIndex)
  %813 = extractvalue %dx.types.CBufRet.f32 %812, 0
  %814 = extractvalue %dx.types.CBufRet.f32 %812, 1
  %815 = extractvalue %dx.types.CBufRet.f32 %812, 2
  %816 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 182)  ; CBufferLoadLegacy(handle,regIndex)
  %817 = extractvalue %dx.types.CBufRet.f32 %816, 0
  %818 = extractvalue %dx.types.CBufRet.f32 %816, 1
  %819 = extractvalue %dx.types.CBufRet.f32 %816, 2
  %820 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 183)  ; CBufferLoadLegacy(handle,regIndex)
  %821 = extractvalue %dx.types.CBufRet.f32 %820, 0
  %822 = extractvalue %dx.types.CBufRet.f32 %820, 1
  %823 = extractvalue %dx.types.CBufRet.f32 %820, 2
  %824 = bitcast float %821 to i32
  %825 = bitcast float %822 to i32
  %826 = bitcast float %823 to i32
  %827 = extractvalue %dx.types.CBufRet.f32 %820, 3
  %828 = bitcast float %827 to i32
  %829 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 185)  ; CBufferLoadLegacy(handle,regIndex)
  %830 = extractvalue %dx.types.CBufRet.f32 %829, 0
  %831 = extractvalue %dx.types.CBufRet.f32 %829, 1
  %832 = extractvalue %dx.types.CBufRet.f32 %829, 2
  %833 = and i32 %809, 65535
  %834 = icmp eq i32 %833, 0
  %835 = icmp eq i32 %828, 0
  %836 = or i1 %834, %835
  br i1 %836, label %1118, label %837

; <label>:837                                     ; preds = %600
  %838 = fcmp fast olt float %61, %817
  %839 = fcmp fast olt float %62, %818
  %840 = fcmp fast olt float %63, %819
  %841 = fcmp fast ole float %813, %61
  %842 = fcmp fast ole float %814, %62
  %843 = fcmp fast ole float %815, %63
  %844 = and i1 %841, %838
  %845 = and i1 %842, %839
  %846 = and i1 %843, %840
  %847 = and i1 %844, %845
  %848 = and i1 %846, %847
  br i1 %848, label %849, label %871

; <label>:849                                     ; preds = %837
  %850 = uitofp i32 %824 to float
  %851 = uitofp i32 %825 to float
  %852 = uitofp i32 %826 to float
  %853 = fsub fast float %61, %813
  %854 = fsub fast float %62, %814
  %855 = fsub fast float %63, %815
  %856 = fmul fast float %850, %853
  %857 = fmul fast float %851, %854
  %858 = fmul fast float %852, %855
  %859 = fsub fast float %817, %813
  %860 = fsub fast float %818, %814
  %861 = fsub fast float %819, %815
  %862 = fdiv fast float %856, %859
  %863 = fdiv fast float %857, %860
  %864 = fdiv fast float %858, %861
  %865 = fptoui float %862 to i32
  %866 = fptoui float %863 to i32
  %867 = fptoui float %864 to i32
  %868 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %20, i32 0, i32 %865, i32 %866, i32 %867, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %869 = extractvalue %dx.types.ResRet.i32 %868, 0
  %870 = extractvalue %dx.types.ResRet.i32 %868, 1
  br label %871

; <label>:871                                     ; preds = %849, %837
  %872 = phi i32 [ %870, %849 ], [ 0, %837 ]
  %873 = phi i32 [ %869, %849 ], [ 0, %837 ]
  %874 = add i32 %873, %872
  %875 = icmp ult i32 %873, %874
  br i1 %875, label %876, label %1089

; <label>:876                                     ; preds = %871
  br label %877

; <label>:877                                     ; preds = %1057, %876
  %878 = phi float [ %1058, %1057 ], [ 0.000000e+00, %876 ]
  %879 = phi float [ %1059, %1057 ], [ 0.000000e+00, %876 ]
  %880 = phi float [ %1060, %1057 ], [ 0.000000e+00, %876 ]
  %881 = phi float [ %1061, %1057 ], [ 0.000000e+00, %876 ]
  %882 = phi float [ %1062, %1057 ], [ 0.000000e+00, %876 ]
  %883 = phi float [ %1063, %1057 ], [ 0.000000e+00, %876 ]
  %884 = phi float [ %1064, %1057 ], [ 0.000000e+00, %876 ]
  %885 = phi float [ %1065, %1057 ], [ 0.000000e+00, %876 ]
  %886 = phi float [ %1066, %1057 ], [ 0.000000e+00, %876 ]
  %887 = phi float [ %1067, %1057 ], [ 0.000000e+00, %876 ]
  %888 = phi float [ %1068, %1057 ], [ 0.000000e+00, %876 ]
  %889 = phi float [ %1069, %1057 ], [ 0.000000e+00, %876 ]
  %890 = phi i32 [ %1070, %1057 ], [ -1, %876 ]
  %891 = phi float [ %1071, %1057 ], [ 1.000000e+00, %876 ]
  %892 = phi i32 [ %1073, %1057 ], [ %873, %876 ]
  %893 = phi float [ %1072, %1057 ], [ 0.000000e+00, %876 ]
  %894 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %18, i32 %892, i32 undef)  ; BufferLoad(srv,index,wot)
  %895 = extractvalue %dx.types.ResRet.i32 %894, 0
  %896 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %895, i32 0)  ; BufferLoad(srv,index,wot)
  %897 = extractvalue %dx.types.ResRet.f32 %896, 0
  %898 = extractvalue %dx.types.ResRet.f32 %896, 1
  %899 = extractvalue %dx.types.ResRet.f32 %896, 2
  %900 = extractvalue %dx.types.ResRet.f32 %896, 3
  %901 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %895, i32 16)  ; BufferLoad(srv,index,wot)
  %902 = extractvalue %dx.types.ResRet.f32 %901, 0
  %903 = extractvalue %dx.types.ResRet.f32 %901, 1
  %904 = extractvalue %dx.types.ResRet.f32 %901, 2
  %905 = extractvalue %dx.types.ResRet.f32 %901, 3
  %906 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %895, i32 32)  ; BufferLoad(srv,index,wot)
  %907 = extractvalue %dx.types.ResRet.f32 %906, 0
  %908 = extractvalue %dx.types.ResRet.f32 %906, 1
  %909 = extractvalue %dx.types.ResRet.f32 %906, 2
  %910 = extractvalue %dx.types.ResRet.f32 %906, 3
  %911 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %9, i32 %895, i32 48)  ; BufferLoad(srv,index,wot)
  %912 = extractvalue %dx.types.ResRet.i32 %911, 0
  %913 = extractvalue %dx.types.ResRet.i32 %911, 1
  %914 = extractvalue %dx.types.ResRet.i32 %911, 2
  %915 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %9, i32 %895, i32 60)  ; BufferLoad(srv,index,wot)
  %916 = extractvalue %dx.types.ResRet.i32 %915, 0
  %917 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %9, i32 %895, i32 64)  ; BufferLoad(srv,index,wot)
  %918 = extractvalue %dx.types.ResRet.i32 %917, 0
  %919 = extractvalue %dx.types.ResRet.i32 %917, 1
  %920 = extractvalue %dx.types.ResRet.i32 %917, 2
  %921 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %9, i32 %895, i32 76)  ; BufferLoad(srv,index,wot)
  %922 = extractvalue %dx.types.ResRet.i32 %921, 0
  %923 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %895, i32 80)  ; BufferLoad(srv,index,wot)
  %924 = extractvalue %dx.types.ResRet.f32 %923, 0
  %925 = extractvalue %dx.types.ResRet.f32 %923, 1
  %926 = extractvalue %dx.types.ResRet.f32 %923, 2
  %927 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %895, i32 96)  ; BufferLoad(srv,index,wot)
  %928 = extractvalue %dx.types.ResRet.f32 %927, 0
  %929 = extractvalue %dx.types.ResRet.f32 %927, 1
  %930 = extractvalue %dx.types.ResRet.f32 %927, 2
  %931 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %895, i32 108)  ; BufferLoad(srv,index,wot)
  %932 = extractvalue %dx.types.ResRet.f32 %931, 0
  %933 = and i32 %916, %833
  %934 = icmp eq i32 %933, 0
  br i1 %934, label %1057, label %935

; <label>:935                                     ; preds = %877
  %936 = icmp ult i32 %922, %890
  %937 = fsub fast float 1.000000e+00, %893
  %938 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %937)  ; FMax(a,b)
  %939 = fcmp fast oeq float %938, 0.000000e+00
  %940 = and i1 %936, %939
  br i1 %940, label %1075, label %941

; <label>:941                                     ; preds = %935
  %942 = fmul fast float %897, %61
  %943 = call float @dx.op.tertiary.f32(i32 46, float %62, float %898, float %942)  ; FMad(a,b,c)
  %944 = call float @dx.op.tertiary.f32(i32 46, float %63, float %899, float %943)  ; FMad(a,b,c)
  %945 = fadd fast float %944, %900
  %946 = fmul fast float %902, %61
  %947 = call float @dx.op.tertiary.f32(i32 46, float %62, float %903, float %946)  ; FMad(a,b,c)
  %948 = call float @dx.op.tertiary.f32(i32 46, float %63, float %904, float %947)  ; FMad(a,b,c)
  %949 = fadd fast float %948, %905
  %950 = fmul fast float %907, %61
  %951 = call float @dx.op.tertiary.f32(i32 46, float %62, float %908, float %950)  ; FMad(a,b,c)
  %952 = call float @dx.op.tertiary.f32(i32 46, float %63, float %909, float %951)  ; FMad(a,b,c)
  %953 = fadd fast float %952, %910
  %954 = call float @dx.op.binary.f32(i32 35, float %945, float -5.000000e-01)  ; FMax(a,b)
  %955 = call float @dx.op.binary.f32(i32 35, float %949, float -5.000000e-01)  ; FMax(a,b)
  %956 = call float @dx.op.binary.f32(i32 35, float %953, float -5.000000e-01)  ; FMax(a,b)
  %957 = call float @dx.op.binary.f32(i32 36, float %954, float 5.000000e-01)  ; FMin(a,b)
  %958 = call float @dx.op.binary.f32(i32 36, float %955, float 5.000000e-01)  ; FMin(a,b)
  %959 = call float @dx.op.binary.f32(i32 36, float %956, float 5.000000e-01)  ; FMin(a,b)
  %960 = fcmp fast olt float %945, 0.000000e+00
  %961 = fcmp fast olt float %949, 0.000000e+00
  %962 = fcmp fast olt float %953, 0.000000e+00
  %963 = select i1 %960, float %924, float %928
  %964 = select i1 %961, float %925, float %929
  %965 = select i1 %962, float %926, float %930
  %966 = fsub fast float %945, %957
  %967 = fsub fast float %949, %958
  %968 = fsub fast float %953, %959
  %969 = call float @dx.op.binary.f32(i32 35, float %963, float 0x3F50624DE0000000)  ; FMax(a,b)
  %970 = call float @dx.op.binary.f32(i32 35, float %964, float 0x3F50624DE0000000)  ; FMax(a,b)
  %971 = call float @dx.op.binary.f32(i32 35, float %965, float 0x3F50624DE0000000)  ; FMax(a,b)
  %972 = fdiv fast float %966, %969
  %973 = fdiv fast float %967, %970
  %974 = fdiv fast float %968, %971
  %975 = call float @dx.op.dot3.f32(i32 55, float %972, float %973, float %974, float %972, float %973, float %974)  ; Dot3(ax,ay,az,bx,by,bz)
  %976 = fcmp fast olt float %975, 1.000000e+00
  br i1 %976, label %977, label %1057, !dx.controlflow.hints !80

; <label>:977                                     ; preds = %941
  %978 = select i1 %936, float %938, float %891
  %979 = fmul fast float %978, %932
  %980 = call float @dx.op.unary.f32(i32 24, float %975)  ; Sqrt(value)
  %981 = fsub fast float 1.000000e+00, %980
  %982 = fmul fast float %979, %981
  %983 = fadd fast float %957, 5.000000e-01
  %984 = fadd fast float %958, 5.000000e-01
  %985 = fadd fast float %959, 5.000000e-01
  %986 = uitofp i32 %918 to float
  %987 = uitofp i32 %919 to float
  %988 = uitofp i32 %920 to float
  %989 = fadd fast float %986, 1.000000e+00
  %990 = fadd fast float %987, 1.000000e+00
  %991 = fadd fast float %988, 1.000000e+00
  %992 = fmul fast float %983, %989
  %993 = fmul fast float %984, %990
  %994 = fmul fast float %985, %991
  %995 = call float @dx.op.binary.f32(i32 35, float %992, float 1.000000e+00)  ; FMax(a,b)
  %996 = call float @dx.op.binary.f32(i32 35, float %993, float 1.000000e+00)  ; FMax(a,b)
  %997 = call float @dx.op.binary.f32(i32 35, float %994, float 1.000000e+00)  ; FMax(a,b)
  %998 = call float @dx.op.binary.f32(i32 36, float %995, float %986)  ; FMin(a,b)
  %999 = call float @dx.op.binary.f32(i32 36, float %996, float %987)  ; FMin(a,b)
  %1000 = call float @dx.op.binary.f32(i32 36, float %997, float %988)  ; FMin(a,b)
  %1001 = uitofp i32 %912 to float
  %1002 = uitofp i32 %913 to float
  %1003 = uitofp i32 %914 to float
  %1004 = fadd fast float %1001, -5.000000e-01
  %1005 = fadd fast float %1004, %998
  %1006 = fadd fast float %1002, -5.000000e-01
  %1007 = fadd fast float %1006, %999
  %1008 = fadd fast float %1003, -5.000000e-01
  %1009 = fadd fast float %1008, %1000
  %1010 = fmul fast float %1009, %832
  %1011 = fmul fast float %830, 5.000000e-01
  %1012 = fmul fast float %1011, %1005
  %1013 = fmul fast float %831, 5.000000e-01
  %1014 = fmul fast float %1013, %1007
  %1015 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %19, %dx.types.Handle %37, float %1012, float %1014, float %1010, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1016 = extractvalue %dx.types.ResRet.f32 %1015, 0
  %1017 = extractvalue %dx.types.ResRet.f32 %1015, 1
  %1018 = extractvalue %dx.types.ResRet.f32 %1015, 2
  %1019 = extractvalue %dx.types.ResRet.f32 %1015, 3
  %1020 = fadd fast float %1012, 5.000000e-01
  %1021 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %19, %dx.types.Handle %37, float %1020, float %1014, float %1010, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1022 = extractvalue %dx.types.ResRet.f32 %1021, 0
  %1023 = extractvalue %dx.types.ResRet.f32 %1021, 1
  %1024 = extractvalue %dx.types.ResRet.f32 %1021, 2
  %1025 = extractvalue %dx.types.ResRet.f32 %1021, 3
  %1026 = fadd fast float %1014, 5.000000e-01
  %1027 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %19, %dx.types.Handle %37, float %1012, float %1026, float %1010, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1028 = extractvalue %dx.types.ResRet.f32 %1027, 0
  %1029 = extractvalue %dx.types.ResRet.f32 %1027, 1
  %1030 = extractvalue %dx.types.ResRet.f32 %1027, 2
  %1031 = extractvalue %dx.types.ResRet.f32 %1027, 3
  %1032 = fmul fast float %1016, %982
  %1033 = fmul fast float %1022, %982
  %1034 = fmul fast float %1028, %982
  %1035 = fadd fast float %1032, %881
  %1036 = fadd fast float %1033, %885
  %1037 = fadd fast float %1034, %889
  %1038 = fmul fast float %1017, %982
  %1039 = fmul fast float %1023, %982
  %1040 = fmul fast float %1029, %982
  %1041 = fadd fast float %1038, %880
  %1042 = fadd fast float %1039, %884
  %1043 = fadd fast float %1040, %888
  %1044 = fmul fast float %1018, %982
  %1045 = fmul fast float %1024, %982
  %1046 = fmul fast float %1030, %982
  %1047 = fadd fast float %1044, %879
  %1048 = fadd fast float %1045, %883
  %1049 = fadd fast float %1046, %887
  %1050 = fmul fast float %1019, %982
  %1051 = fmul fast float %1025, %982
  %1052 = fmul fast float %1031, %982
  %1053 = fadd fast float %1050, %878
  %1054 = fadd fast float %1051, %882
  %1055 = fadd fast float %1052, %886
  %1056 = fadd fast float %982, %893
  br label %1057

; <label>:1057                                    ; preds = %977, %941, %877
  %1058 = phi float [ %878, %877 ], [ %1053, %977 ], [ %878, %941 ]
  %1059 = phi float [ %879, %877 ], [ %1047, %977 ], [ %879, %941 ]
  %1060 = phi float [ %880, %877 ], [ %1041, %977 ], [ %880, %941 ]
  %1061 = phi float [ %881, %877 ], [ %1035, %977 ], [ %881, %941 ]
  %1062 = phi float [ %882, %877 ], [ %1054, %977 ], [ %882, %941 ]
  %1063 = phi float [ %883, %877 ], [ %1048, %977 ], [ %883, %941 ]
  %1064 = phi float [ %884, %877 ], [ %1042, %977 ], [ %884, %941 ]
  %1065 = phi float [ %885, %877 ], [ %1036, %977 ], [ %885, %941 ]
  %1066 = phi float [ %886, %877 ], [ %1055, %977 ], [ %886, %941 ]
  %1067 = phi float [ %887, %877 ], [ %1049, %977 ], [ %887, %941 ]
  %1068 = phi float [ %888, %877 ], [ %1043, %977 ], [ %888, %941 ]
  %1069 = phi float [ %889, %877 ], [ %1037, %977 ], [ %889, %941 ]
  %1070 = phi i32 [ %890, %877 ], [ %922, %977 ], [ %890, %941 ]
  %1071 = phi float [ %891, %877 ], [ %978, %977 ], [ %891, %941 ]
  %1072 = phi float [ %893, %877 ], [ %1056, %977 ], [ %893, %941 ]
  %1073 = add nuw i32 %892, 1
  %1074 = icmp ult i32 %1073, %874
  br i1 %1074, label %877, label %1075

; <label>:1075                                    ; preds = %1057, %935
  %1076 = phi float [ %1058, %1057 ], [ %878, %935 ]
  %1077 = phi float [ %1059, %1057 ], [ %879, %935 ]
  %1078 = phi float [ %1060, %1057 ], [ %880, %935 ]
  %1079 = phi float [ %1061, %1057 ], [ %881, %935 ]
  %1080 = phi float [ %1062, %1057 ], [ %882, %935 ]
  %1081 = phi float [ %1063, %1057 ], [ %883, %935 ]
  %1082 = phi float [ %1064, %1057 ], [ %884, %935 ]
  %1083 = phi float [ %1065, %1057 ], [ %885, %935 ]
  %1084 = phi float [ %1066, %1057 ], [ %886, %935 ]
  %1085 = phi float [ %1067, %1057 ], [ %887, %935 ]
  %1086 = phi float [ %1068, %1057 ], [ %888, %935 ]
  %1087 = phi float [ %1069, %1057 ], [ %889, %935 ]
  %1088 = phi float [ %1072, %1057 ], [ %893, %935 ]
  br label %1089

; <label>:1089                                    ; preds = %1075, %871
  %1090 = phi float [ 0.000000e+00, %871 ], [ %1076, %1075 ]
  %1091 = phi float [ 0.000000e+00, %871 ], [ %1077, %1075 ]
  %1092 = phi float [ 0.000000e+00, %871 ], [ %1078, %1075 ]
  %1093 = phi float [ 0.000000e+00, %871 ], [ %1079, %1075 ]
  %1094 = phi float [ 0.000000e+00, %871 ], [ %1080, %1075 ]
  %1095 = phi float [ 0.000000e+00, %871 ], [ %1081, %1075 ]
  %1096 = phi float [ 0.000000e+00, %871 ], [ %1082, %1075 ]
  %1097 = phi float [ 0.000000e+00, %871 ], [ %1083, %1075 ]
  %1098 = phi float [ 0.000000e+00, %871 ], [ %1084, %1075 ]
  %1099 = phi float [ 0.000000e+00, %871 ], [ %1085, %1075 ]
  %1100 = phi float [ 0.000000e+00, %871 ], [ %1086, %1075 ]
  %1101 = phi float [ 0.000000e+00, %871 ], [ %1087, %1075 ]
  %1102 = phi float [ 0.000000e+00, %871 ], [ %1088, %1075 ]
  %1103 = call float @dx.op.binary.f32(i32 36, float %1102, float 1.000000e+00)  ; FMin(a,b)
  %1104 = call float @dx.op.binary.f32(i32 35, float %1102, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %1105 = fdiv fast float %1103, %1104
  %1106 = fmul fast float %1105, %1093
  %1107 = fmul fast float %1105, %1097
  %1108 = fmul fast float %1105, %1101
  %1109 = fmul fast float %1105, %1092
  %1110 = fmul fast float %1105, %1096
  %1111 = fmul fast float %1105, %1100
  %1112 = fmul fast float %1105, %1091
  %1113 = fmul fast float %1105, %1095
  %1114 = fmul fast float %1105, %1099
  %1115 = fmul fast float %1105, %1090
  %1116 = fmul fast float %1105, %1094
  %1117 = fmul fast float %1105, %1098
  br label %1118

; <label>:1118                                    ; preds = %1089, %600
  %1119 = phi float [ 0.000000e+00, %600 ], [ %1115, %1089 ]
  %1120 = phi float [ 0.000000e+00, %600 ], [ %1112, %1089 ]
  %1121 = phi float [ 0.000000e+00, %600 ], [ %1109, %1089 ]
  %1122 = phi float [ 0.000000e+00, %600 ], [ %1106, %1089 ]
  %1123 = phi float [ 0.000000e+00, %600 ], [ %1116, %1089 ]
  %1124 = phi float [ 0.000000e+00, %600 ], [ %1113, %1089 ]
  %1125 = phi float [ 0.000000e+00, %600 ], [ %1110, %1089 ]
  %1126 = phi float [ 0.000000e+00, %600 ], [ %1107, %1089 ]
  %1127 = phi float [ 0.000000e+00, %600 ], [ %1117, %1089 ]
  %1128 = phi float [ 0.000000e+00, %600 ], [ %1114, %1089 ]
  %1129 = phi float [ 0.000000e+00, %600 ], [ %1111, %1089 ]
  %1130 = phi float [ 0.000000e+00, %600 ], [ %1108, %1089 ]
  %1131 = phi float [ 0.000000e+00, %600 ], [ %1103, %1089 ]
  %1132 = fsub fast float 1.000000e+00, %1131
  %1133 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1132)  ; FMax(a,b)
  %1134 = fcmp fast ogt float %1133, 0.000000e+00
  br i1 %1134, label %1135, label %2627, !dx.controlflow.hints !81

; <label>:1135                                    ; preds = %1118
  %1136 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 409)  ; CBufferLoadLegacy(handle,regIndex)
  %1137 = extractvalue %dx.types.CBufRet.f32 %1136, 0
  %1138 = extractvalue %dx.types.CBufRet.f32 %1136, 1
  %1139 = extractvalue %dx.types.CBufRet.f32 %1136, 2
  %1140 = extractvalue %dx.types.CBufRet.f32 %1136, 3
  %1141 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 410)  ; CBufferLoadLegacy(handle,regIndex)
  %1142 = extractvalue %dx.types.CBufRet.f32 %1141, 0
  %1143 = extractvalue %dx.types.CBufRet.f32 %1141, 1
  %1144 = extractvalue %dx.types.CBufRet.f32 %1141, 2
  %1145 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 411)  ; CBufferLoadLegacy(handle,regIndex)
  %1146 = extractvalue %dx.types.CBufRet.f32 %1145, 3
  %1147 = bitcast float %1146 to i32
  %1148 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 413)  ; CBufferLoadLegacy(handle,regIndex)
  %1149 = extractvalue %dx.types.CBufRet.f32 %1148, 0
  %1150 = extractvalue %dx.types.CBufRet.f32 %1148, 1
  %1151 = extractvalue %dx.types.CBufRet.f32 %1148, 2
  %1152 = extractvalue %dx.types.CBufRet.f32 %1148, 3
  %1153 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 414)  ; CBufferLoadLegacy(handle,regIndex)
  %1154 = extractvalue %dx.types.CBufRet.f32 %1153, 0
  %1155 = extractvalue %dx.types.CBufRet.f32 %1153, 1
  %1156 = extractvalue %dx.types.CBufRet.f32 %1153, 2
  %1157 = extractvalue %dx.types.CBufRet.f32 %1153, 3
  %1158 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 415)  ; CBufferLoadLegacy(handle,regIndex)
  %1159 = extractvalue %dx.types.CBufRet.f32 %1158, 0
  %1160 = extractvalue %dx.types.CBufRet.f32 %1158, 1
  %1161 = extractvalue %dx.types.CBufRet.f32 %1158, 2
  %1162 = extractvalue %dx.types.CBufRet.f32 %1158, 3
  %1163 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 416)  ; CBufferLoadLegacy(handle,regIndex)
  %1164 = extractvalue %dx.types.CBufRet.f32 %1163, 0
  %1165 = extractvalue %dx.types.CBufRet.f32 %1163, 1
  %1166 = bitcast float %1165 to i32
  %1167 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 412)  ; CBufferLoadLegacy(handle,regIndex)
  %1168 = extractvalue %dx.types.CBufRet.f32 %1167, 0
  %1169 = extractvalue %dx.types.CBufRet.f32 %1167, 1
  %1170 = extractvalue %dx.types.CBufRet.f32 %1167, 2
  %1171 = extractvalue %dx.types.CBufRet.f32 %1167, 3
  %1172 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 0
  store float %1149, float* %1172, align 4
  %1173 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 1
  store float %1150, float* %1173, align 4
  %1174 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 2
  store float %1151, float* %1174, align 4
  %1175 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 3
  store float %1152, float* %1175, align 4
  %1176 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 4
  store float %1154, float* %1176, align 4
  %1177 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 5
  store float %1155, float* %1177, align 4
  %1178 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 6
  store float %1156, float* %1178, align 4
  %1179 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 7
  store float %1157, float* %1179, align 4
  %1180 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 8
  store float %1159, float* %1180, align 4
  %1181 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 9
  store float %1160, float* %1181, align 4
  %1182 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 10
  store float %1161, float* %1182, align 4
  %1183 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 11
  store float %1162, float* %1183, align 4
  %1184 = and i32 %1147, %833
  %1185 = icmp eq i32 %1184, 0
  br i1 %1185, label %1465, label %1186

; <label>:1186                                    ; preds = %1135
  %1187 = fsub fast float %61, %1137
  %1188 = fsub fast float %62, %1138
  %1189 = fsub fast float %63, %1139
  %1190 = fdiv fast float %1187, %1140
  %1191 = fdiv fast float %1188, %1140
  %1192 = fdiv fast float %1189, %1140
  %1193 = fcmp fast olt float %1190, %1142
  %1194 = fcmp fast olt float %1191, %1143
  %1195 = fcmp fast olt float %1192, %1144
  %1196 = fcmp fast oge float %1190, 0.000000e+00
  %1197 = fcmp fast oge float %1191, 0.000000e+00
  %1198 = fcmp fast oge float %1192, 0.000000e+00
  %1199 = and i1 %1196, %1193
  %1200 = and i1 %1197, %1194
  %1201 = and i1 %1198, %1195
  %1202 = and i1 %1199, %1200
  %1203 = and i1 %1202, %1201
  br i1 %1203, label %1204, label %1210

; <label>:1204                                    ; preds = %1186
  %1205 = fptoui float %1190 to i32
  %1206 = fptoui float %1191 to i32
  %1207 = fptoui float %1192 to i32
  %1208 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %16, i32 0, i32 %1205, i32 %1206, i32 %1207, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1209 = extractvalue %dx.types.ResRet.i32 %1208, 0
  br label %1210

; <label>:1210                                    ; preds = %1204, %1186
  %1211 = phi i32 [ %1209, %1204 ], [ 65535, %1186 ]
  %1212 = icmp eq i32 %1211, 65535
  br i1 %1212, label %1465, label %1213, !dx.controlflow.hints !82

; <label>:1213                                    ; preds = %1210
  %1214 = fmul fast float %267, %267
  %1215 = fmul fast float %268, %268
  %1216 = fadd fast float %1214, %1215
  %1217 = fmul fast float %269, %269
  %1218 = fadd fast float %1216, %1217
  %1219 = call float @dx.op.unary.f32(i32 24, float %1218)  ; Sqrt(value)
  %1220 = and i32 %1166, 1
  %1221 = icmp eq i32 %1220, 0
  br i1 %1221, label %1292, label %1222

; <label>:1222                                    ; preds = %1213
  %1223 = fcmp fast ogt float %1219, %1149
  %1224 = fcmp fast ogt float %1219, %1150
  %1225 = fcmp fast ogt float %1219, %1151
  %1226 = fcmp fast ogt float %1219, %1152
  %1227 = uitofp i1 %1223 to float
  %1228 = uitofp i1 %1224 to float
  %1229 = uitofp i1 %1225 to float
  %1230 = uitofp i1 %1226 to float
  %1231 = call float @dx.op.dot4.f32(i32 56, float %1227, float %1228, float %1229, float %1230, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1232 = fptosi float %1231 to i32
  %1233 = fcmp fast ogt float %1219, %1154
  %1234 = fcmp fast ogt float %1219, %1155
  %1235 = fcmp fast ogt float %1219, %1156
  %1236 = fcmp fast ogt float %1219, %1157
  %1237 = uitofp i1 %1233 to float
  %1238 = uitofp i1 %1234 to float
  %1239 = uitofp i1 %1235 to float
  %1240 = uitofp i1 %1236 to float
  %1241 = call float @dx.op.dot4.f32(i32 56, float %1237, float %1238, float %1239, float %1240, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1242 = fptosi float %1241 to i32
  %1243 = add nsw i32 %1242, %1232
  %1244 = fcmp fast ogt float %1219, %1159
  %1245 = fcmp fast ogt float %1219, %1160
  %1246 = fcmp fast ogt float %1219, %1161
  %1247 = fcmp fast ogt float %1219, %1162
  %1248 = uitofp i1 %1244 to float
  %1249 = uitofp i1 %1245 to float
  %1250 = uitofp i1 %1246 to float
  %1251 = uitofp i1 %1247 to float
  %1252 = call float @dx.op.dot4.f32(i32 56, float %1248, float %1249, float %1250, float %1251, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1253 = fptosi float %1252 to i32
  %1254 = add nsw i32 %1243, %1253
  %1255 = call i32 @dx.op.binary.i32(i32 38, i32 %1254, i32 9)  ; IMin(a,b)
  %1256 = add nsw i32 %1255, -1
  %1257 = ashr i32 %1255, 2
  %1258 = call i32 @dx.op.binary.i32(i32 38, i32 %1257, i32 2)  ; IMin(a,b)
  %1259 = and i32 %1255, 3
  %1260 = mul i32 %1258, 4
  %1261 = add i32 %1259, %1260
  %1262 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 %1261
  %1263 = load float, float* %1262, align 4, !tbaa !83, !noalias !87
  %1264 = icmp slt i32 %1255, 1
  br i1 %1264, label %1273, label %1265

; <label>:1265                                    ; preds = %1222
  %1266 = ashr i32 %1256, 2
  %1267 = call i32 @dx.op.binary.i32(i32 38, i32 %1266, i32 2)  ; IMin(a,b)
  %1268 = and i32 %1256, 3
  %1269 = mul i32 %1267, 4
  %1270 = add i32 %1268, %1269
  %1271 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 %1270
  %1272 = load float, float* %1271, align 4, !tbaa !83, !noalias !87
  br label %1273

; <label>:1273                                    ; preds = %1265, %1222
  %1274 = phi float [ %1272, %1265 ], [ 0.000000e+00, %1222 ]
  %1275 = fsub fast float %1219, %1274
  %1276 = fsub fast float %1263, %1274
  %1277 = call float @dx.op.binary.f32(i32 35, float %1276, float 0x3F1A36E2E0000000)  ; FMax(a,b)
  %1278 = fdiv fast float %1275, %1277
  %1279 = call i32 @dx.op.binary.i32(i32 37, i32 %1256, i32 0)  ; IMax(a,b)
  %1280 = and i32 %810, 127
  %1281 = and i32 %811, 127
  %1282 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %8, i32 0, i32 %1280, i32 %1281, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1283 = extractvalue %dx.types.ResRet.f32 %1282, 0
  %1284 = fmul fast float %1278, %1164
  %1285 = call float @dx.op.unary.f32(i32 7, float %1284)  ; Saturate(value)
  %1286 = fmul fast float %1285, 2.000000e+00
  %1287 = fsub fast float 3.000000e+00, %1286
  %1288 = fmul fast float %1285, %1285
  %1289 = fmul fast float %1288, %1287
  %1290 = fcmp fast ogt float %1289, %1283
  %1291 = select i1 %1290, i32 %1255, i32 %1279
  br label %1292

; <label>:1292                                    ; preds = %1273, %1213
  %1293 = phi i32 [ %1291, %1273 ], [ 0, %1213 ]
  %1294 = sub nsw i32 9, %1293
  %1295 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1211, i32 0)  ; BufferLoad(srv,index,wot)
  %1296 = extractvalue %dx.types.ResRet.i32 %1295, 0
  %1297 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1211, i32 4)  ; BufferLoad(srv,index,wot)
  %1298 = extractvalue %dx.types.ResRet.i32 %1297, 0
  %1299 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1211, i32 8)  ; BufferLoad(srv,index,wot)
  %1300 = extractvalue %dx.types.ResRet.i32 %1299, 0
  %1301 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1211, i32 12)  ; BufferLoad(srv,index,wot)
  %1302 = extractvalue %dx.types.ResRet.i32 %1301, 0
  %1303 = call i32 @dx.op.binary.i32(i32 40, i32 %1296, i32 -1)  ; UMin(a,b)
  %1304 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %13, i32 %1298, i32 0)  ; BufferLoad(srv,index,wot)
  %1305 = extractvalue %dx.types.ResRet.f32 %1304, 3
  %1306 = call i32 @dx.op.binary.i32(i32 40, i32 %1294, i32 %1303)  ; UMin(a,b)
  %1307 = extractvalue %dx.types.ResRet.f32 %1304, 2
  %1308 = extractvalue %dx.types.ResRet.f32 %1304, 1
  %1309 = extractvalue %dx.types.ResRet.f32 %1304, 0
  %1310 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1300, i32 4)  ; BufferLoad(srv,index,wot)
  %1311 = extractvalue %dx.types.ResRet.i32 %1310, 0
  %1312 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1300, i32 12)  ; BufferLoad(srv,index,wot)
  %1313 = extractvalue %dx.types.ResRet.i32 %1312, 0
  %1314 = fsub fast float %61, %1309
  %1315 = fsub fast float %62, %1308
  %1316 = fsub fast float %63, %1307
  %1317 = fdiv fast float %1314, %1305
  %1318 = fdiv fast float %1315, %1305
  %1319 = fdiv fast float %1316, %1305
  %1320 = call float @dx.op.unary.f32(i32 7, float %1317)  ; Saturate(value)
  %1321 = call float @dx.op.unary.f32(i32 7, float %1318)  ; Saturate(value)
  %1322 = call float @dx.op.unary.f32(i32 7, float %1319)  ; Saturate(value)
  %1323 = icmp eq i32 %1306, 0
  br i1 %1323, label %1398, label %1324

; <label>:1324                                    ; preds = %1292
  %1325 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1300, i32 8)  ; BufferLoad(srv,index,wot)
  %1326 = extractvalue %dx.types.ResRet.i32 %1325, 0
  %1327 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1300, i32 0)  ; BufferLoad(srv,index,wot)
  %1328 = extractvalue %dx.types.ResRet.i32 %1327, 0
  br label %1329

; <label>:1329                                    ; preds = %1385, %1324
  %1330 = phi i32 [ %1390, %1385 ], [ 0, %1324 ]
  %1331 = phi float [ %1365, %1385 ], [ %1320, %1324 ]
  %1332 = phi float [ %1366, %1385 ], [ %1321, %1324 ]
  %1333 = phi float [ %1367, %1385 ], [ %1322, %1324 ]
  %1334 = phi i32 [ %1364, %1385 ], [ %1313, %1324 ]
  %1335 = phi i32 [ %1387, %1385 ], [ %1326, %1324 ]
  %1336 = phi i32 [ %1362, %1385 ], [ %1311, %1324 ]
  %1337 = phi i32 [ %1389, %1385 ], [ %1328, %1324 ]
  %1338 = fmul fast float %1331, 3.000000e+00
  %1339 = fmul fast float %1332, 3.000000e+00
  %1340 = fmul fast float %1333, 3.000000e+00
  %1341 = call float @dx.op.unary.f32(i32 27, float %1338)  ; Round_ni(value)
  %1342 = call float @dx.op.unary.f32(i32 27, float %1339)  ; Round_ni(value)
  %1343 = call float @dx.op.unary.f32(i32 27, float %1340)  ; Round_ni(value)
  %1344 = fptoui float %1341 to i32
  %1345 = fptoui float %1342 to i32
  %1346 = fptoui float %1343 to i32
  %1347 = mul i32 %1345, 3
  %1348 = add i32 %1347, %1344
  %1349 = mul i32 %1346, 9
  %1350 = add i32 %1348, %1349
  %1351 = and i32 %1350, 31
  %1352 = shl i32 1, %1351
  %1353 = and i32 %1352, %1335
  %1354 = icmp eq i32 %1353, 0
  br i1 %1354, label %1392, label %1355

; <label>:1355                                    ; preds = %1329
  %1356 = add i32 %1352, -1
  %1357 = and i32 %1356, %1335
  %1358 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %1357)  ; Countbits(value)
  %1359 = add i32 %1337, %1300
  %1360 = add i32 %1359, %1358
  %1361 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1360, i32 4)  ; BufferLoad(srv,index,wot)
  %1362 = extractvalue %dx.types.ResRet.i32 %1361, 0
  %1363 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1360, i32 12)  ; BufferLoad(srv,index,wot)
  %1364 = extractvalue %dx.types.ResRet.i32 %1363, 0
  %1365 = call float @dx.op.unary.f32(i32 22, float %1338)  ; Frc(value)
  %1366 = call float @dx.op.unary.f32(i32 22, float %1339)  ; Frc(value)
  %1367 = call float @dx.op.unary.f32(i32 22, float %1340)  ; Frc(value)
  %1368 = fmul fast float %1365, 3.000000e+00
  %1369 = fmul fast float %1366, 3.000000e+00
  %1370 = fmul fast float %1367, 3.000000e+00
  %1371 = call float @dx.op.unary.f32(i32 27, float %1368)  ; Round_ni(value)
  %1372 = call float @dx.op.unary.f32(i32 27, float %1369)  ; Round_ni(value)
  %1373 = call float @dx.op.unary.f32(i32 27, float %1370)  ; Round_ni(value)
  %1374 = fptoui float %1371 to i32
  %1375 = fptoui float %1372 to i32
  %1376 = fptoui float %1373 to i32
  %1377 = mul i32 %1375, 3
  %1378 = add i32 %1377, %1374
  %1379 = mul i32 %1376, 9
  %1380 = add i32 %1378, %1379
  %1381 = and i32 %1380, 31
  %1382 = shl i32 1, %1381
  %1383 = and i32 %1382, %1364
  %1384 = icmp eq i32 %1383, 0
  br i1 %1384, label %1392, label %1385

; <label>:1385                                    ; preds = %1355
  %1386 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1360, i32 8)  ; BufferLoad(srv,index,wot)
  %1387 = extractvalue %dx.types.ResRet.i32 %1386, 0
  %1388 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1360, i32 0)  ; BufferLoad(srv,index,wot)
  %1389 = extractvalue %dx.types.ResRet.i32 %1388, 0
  %1390 = add nuw i32 %1330, 1
  %1391 = icmp ult i32 %1390, %1306
  br i1 %1391, label %1329, label %1392, !llvm.loop !104

; <label>:1392                                    ; preds = %1385, %1355, %1329
  %1393 = phi float [ %1365, %1385 ], [ %1331, %1329 ], [ %1331, %1355 ]
  %1394 = phi float [ %1366, %1385 ], [ %1332, %1329 ], [ %1332, %1355 ]
  %1395 = phi float [ %1367, %1385 ], [ %1333, %1329 ], [ %1333, %1355 ]
  %1396 = phi i32 [ %1364, %1385 ], [ %1334, %1329 ], [ %1334, %1355 ]
  %1397 = phi i32 [ %1362, %1385 ], [ %1336, %1329 ], [ %1336, %1355 ]
  br label %1398

; <label>:1398                                    ; preds = %1392, %1292
  %1399 = phi float [ %1320, %1292 ], [ %1393, %1392 ]
  %1400 = phi float [ %1321, %1292 ], [ %1394, %1392 ]
  %1401 = phi float [ %1322, %1292 ], [ %1395, %1392 ]
  %1402 = phi i32 [ %1313, %1292 ], [ %1396, %1392 ]
  %1403 = phi i32 [ %1311, %1292 ], [ %1397, %1392 ]
  %1404 = fmul fast float %1399, 3.000000e+00
  %1405 = fmul fast float %1400, 3.000000e+00
  %1406 = fmul fast float %1401, 3.000000e+00
  %1407 = call float @dx.op.unary.f32(i32 27, float %1404)  ; Round_ni(value)
  %1408 = call float @dx.op.unary.f32(i32 27, float %1405)  ; Round_ni(value)
  %1409 = call float @dx.op.unary.f32(i32 27, float %1406)  ; Round_ni(value)
  %1410 = fptoui float %1407 to i32
  %1411 = fptoui float %1408 to i32
  %1412 = fptoui float %1409 to i32
  %1413 = mul i32 %1411, 3
  %1414 = add i32 %1413, %1410
  %1415 = mul i32 %1412, 9
  %1416 = add i32 %1414, %1415
  %1417 = and i32 %1416, 31
  %1418 = shl i32 1, %1417
  %1419 = add i32 %1418, -1
  %1420 = and i32 %1419, %1402
  %1421 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %1420)  ; Countbits(value)
  %1422 = add i32 %1403, %1302
  %1423 = add i32 %1422, %1421
  %1424 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %17, i32 %1423, i32 undef)  ; BufferLoad(srv,index,wot)
  %1425 = extractvalue %dx.types.ResRet.i32 %1424, 0
  %1426 = and i32 %1425, 1023
  %1427 = lshr i32 %1425, 10
  %1428 = and i32 %1427, 1023
  %1429 = lshr i32 %1425, 20
  %1430 = and i32 %1429, 1023
  %1431 = uitofp i32 %1426 to float
  %1432 = uitofp i32 %1428 to float
  %1433 = uitofp i32 %1430 to float
  %1434 = call float @dx.op.unary.f32(i32 22, float %1404)  ; Frc(value)
  %1435 = call float @dx.op.unary.f32(i32 22, float %1405)  ; Frc(value)
  %1436 = call float @dx.op.unary.f32(i32 22, float %1406)  ; Frc(value)
  %1437 = fadd fast float %1434, 5.000000e-01
  %1438 = fadd fast float %1437, %1431
  %1439 = fadd fast float %1435, 5.000000e-01
  %1440 = fadd fast float %1439, %1432
  %1441 = fadd fast float %1436, 5.000000e-01
  %1442 = fadd fast float %1441, %1433
  %1443 = fmul fast float %1442, %1170
  %1444 = fmul fast float %1168, 5.000000e-01
  %1445 = fmul fast float %1444, %1438
  %1446 = fmul fast float %1169, 5.000000e-01
  %1447 = fmul fast float %1446, %1440
  %1448 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1445, float %1447, float %1443, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1449 = extractvalue %dx.types.ResRet.f32 %1448, 0
  %1450 = extractvalue %dx.types.ResRet.f32 %1448, 1
  %1451 = extractvalue %dx.types.ResRet.f32 %1448, 2
  %1452 = extractvalue %dx.types.ResRet.f32 %1448, 3
  %1453 = fadd fast float %1445, 5.000000e-01
  %1454 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1453, float %1447, float %1443, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1455 = extractvalue %dx.types.ResRet.f32 %1454, 0
  %1456 = extractvalue %dx.types.ResRet.f32 %1454, 1
  %1457 = extractvalue %dx.types.ResRet.f32 %1454, 2
  %1458 = extractvalue %dx.types.ResRet.f32 %1454, 3
  %1459 = fadd fast float %1447, 5.000000e-01
  %1460 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1445, float %1459, float %1443, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1461 = extractvalue %dx.types.ResRet.f32 %1460, 0
  %1462 = extractvalue %dx.types.ResRet.f32 %1460, 1
  %1463 = extractvalue %dx.types.ResRet.f32 %1460, 2
  %1464 = extractvalue %dx.types.ResRet.f32 %1460, 3
  br label %1465

; <label>:1465                                    ; preds = %1398, %1210, %1135
  %1466 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1452, %1398 ]
  %1467 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1451, %1398 ]
  %1468 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1450, %1398 ]
  %1469 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1449, %1398 ]
  %1470 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1458, %1398 ]
  %1471 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1457, %1398 ]
  %1472 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1456, %1398 ]
  %1473 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1455, %1398 ]
  %1474 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1464, %1398 ]
  %1475 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1463, %1398 ]
  %1476 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1462, %1398 ]
  %1477 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ %1461, %1398 ]
  %1478 = phi float [ 0.000000e+00, %1210 ], [ 0.000000e+00, %1135 ], [ 1.000000e+00, %1398 ]
  %1479 = fsub fast float 1.000000e+00, %1478
  %1480 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1479)  ; FMax(a,b)
  %1481 = fcmp fast ogt float %1480, 0.000000e+00
  %1482 = fcmp fast ogt float %1171, 0.000000e+00
  %1483 = and i1 %1482, %1481
  br i1 %1483, label %1484, label %2544

; <label>:1484                                    ; preds = %1465
  %1485 = fsub fast float %61, %1137
  %1486 = fsub fast float %62, %1138
  %1487 = fsub fast float %63, %1139
  %1488 = fdiv fast float %1485, %1140
  %1489 = fdiv fast float %1486, %1140
  %1490 = fdiv fast float %1487, %1140
  %1491 = call float @dx.op.unary.f32(i32 27, float %1488)  ; Round_ni(value)
  %1492 = call float @dx.op.unary.f32(i32 27, float %1489)  ; Round_ni(value)
  %1493 = call float @dx.op.unary.f32(i32 27, float %1490)  ; Round_ni(value)
  %1494 = fadd fast float %1491, 1.000000e+00
  %1495 = fadd fast float %1492, 1.000000e+00
  %1496 = fadd fast float %1493, 1.000000e+00
  %1497 = fmul fast float %1494, %1140
  %1498 = fmul fast float %1495, %1140
  %1499 = fmul fast float %1496, %1140
  %1500 = fadd fast float %1497, %1137
  %1501 = fadd fast float %1498, %1138
  %1502 = fadd fast float %1499, %1139
  %1503 = fmul fast float %1171, %1140
  %1504 = fadd fast float %1503, %61
  %1505 = fsub fast float %1504, %1500
  %1506 = fadd fast float %1503, %62
  %1507 = fsub fast float %1506, %1501
  %1508 = fadd fast float %1503, %63
  %1509 = fsub fast float %1508, %1502
  %1510 = fdiv fast float %1505, %1503
  %1511 = fdiv fast float %1507, %1503
  %1512 = fdiv fast float %1509, %1503
  %1513 = call float @dx.op.unary.f32(i32 7, float %1510)  ; Saturate(value)
  %1514 = call float @dx.op.unary.f32(i32 7, float %1511)  ; Saturate(value)
  %1515 = call float @dx.op.unary.f32(i32 7, float %1512)  ; Saturate(value)
  %1516 = fcmp fast ogt float %1513, 0.000000e+00
  br i1 %1516, label %1517, label %1848

; <label>:1517                                    ; preds = %1484
  %1518 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 0
  store float %1149, float* %1518, align 4
  %1519 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 1
  store float %1150, float* %1519, align 4
  %1520 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 2
  store float %1151, float* %1520, align 4
  %1521 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 3
  store float %1152, float* %1521, align 4
  %1522 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 4
  store float %1154, float* %1522, align 4
  %1523 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 5
  store float %1155, float* %1523, align 4
  %1524 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 6
  store float %1156, float* %1524, align 4
  %1525 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 7
  store float %1157, float* %1525, align 4
  %1526 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 8
  store float %1159, float* %1526, align 4
  %1527 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 9
  store float %1160, float* %1527, align 4
  %1528 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 10
  store float %1161, float* %1528, align 4
  %1529 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 11
  store float %1162, float* %1529, align 4
  br i1 %1185, label %1805, label %1530

; <label>:1530                                    ; preds = %1517
  %1531 = fdiv fast float %1497, %1140
  %1532 = fcmp fast olt float %1531, %1142
  %1533 = fcmp fast olt float %1489, %1143
  %1534 = fcmp fast olt float %1490, %1144
  %1535 = fcmp fast oge float %1531, 0.000000e+00
  %1536 = fcmp fast oge float %1489, 0.000000e+00
  %1537 = fcmp fast oge float %1490, 0.000000e+00
  %1538 = and i1 %1535, %1532
  %1539 = and i1 %1536, %1533
  %1540 = and i1 %1537, %1534
  %1541 = and i1 %1539, %1538
  %1542 = and i1 %1540, %1541
  br i1 %1542, label %1543, label %1549

; <label>:1543                                    ; preds = %1530
  %1544 = fptoui float %1531 to i32
  %1545 = fptoui float %1489 to i32
  %1546 = fptoui float %1490 to i32
  %1547 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %16, i32 0, i32 %1544, i32 %1545, i32 %1546, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1548 = extractvalue %dx.types.ResRet.i32 %1547, 0
  br label %1549

; <label>:1549                                    ; preds = %1543, %1530
  %1550 = phi i32 [ %1548, %1543 ], [ 65535, %1530 ]
  %1551 = icmp eq i32 %1550, 65535
  br i1 %1551, label %1805, label %1552, !dx.controlflow.hints !82

; <label>:1552                                    ; preds = %1549
  %1553 = fsub fast float %77, %1500
  %1554 = fmul fast float %1553, %1553
  %1555 = fmul fast float %268, %268
  %1556 = fmul fast float %269, %269
  %1557 = fadd fast float %1556, %1555
  %1558 = fadd fast float %1557, %1554
  %1559 = call float @dx.op.unary.f32(i32 24, float %1558)  ; Sqrt(value)
  %1560 = and i32 %1166, 1
  %1561 = icmp eq i32 %1560, 0
  br i1 %1561, label %1632, label %1562

; <label>:1562                                    ; preds = %1552
  %1563 = fcmp fast ogt float %1559, %1149
  %1564 = fcmp fast ogt float %1559, %1150
  %1565 = fcmp fast ogt float %1559, %1151
  %1566 = fcmp fast ogt float %1559, %1152
  %1567 = uitofp i1 %1563 to float
  %1568 = uitofp i1 %1564 to float
  %1569 = uitofp i1 %1565 to float
  %1570 = uitofp i1 %1566 to float
  %1571 = call float @dx.op.dot4.f32(i32 56, float %1567, float %1568, float %1569, float %1570, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1572 = fptosi float %1571 to i32
  %1573 = fcmp fast ogt float %1559, %1154
  %1574 = fcmp fast ogt float %1559, %1155
  %1575 = fcmp fast ogt float %1559, %1156
  %1576 = fcmp fast ogt float %1559, %1157
  %1577 = uitofp i1 %1573 to float
  %1578 = uitofp i1 %1574 to float
  %1579 = uitofp i1 %1575 to float
  %1580 = uitofp i1 %1576 to float
  %1581 = call float @dx.op.dot4.f32(i32 56, float %1577, float %1578, float %1579, float %1580, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1582 = fptosi float %1581 to i32
  %1583 = add nsw i32 %1582, %1572
  %1584 = fcmp fast ogt float %1559, %1159
  %1585 = fcmp fast ogt float %1559, %1160
  %1586 = fcmp fast ogt float %1559, %1161
  %1587 = fcmp fast ogt float %1559, %1162
  %1588 = uitofp i1 %1584 to float
  %1589 = uitofp i1 %1585 to float
  %1590 = uitofp i1 %1586 to float
  %1591 = uitofp i1 %1587 to float
  %1592 = call float @dx.op.dot4.f32(i32 56, float %1588, float %1589, float %1590, float %1591, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1593 = fptosi float %1592 to i32
  %1594 = add nsw i32 %1583, %1593
  %1595 = call i32 @dx.op.binary.i32(i32 38, i32 %1594, i32 9)  ; IMin(a,b)
  %1596 = add nsw i32 %1595, -1
  %1597 = ashr i32 %1595, 2
  %1598 = call i32 @dx.op.binary.i32(i32 38, i32 %1597, i32 2)  ; IMin(a,b)
  %1599 = and i32 %1595, 3
  %1600 = mul i32 %1598, 4
  %1601 = add i32 %1599, %1600
  %1602 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %1601
  %1603 = load float, float* %1602, align 4, !tbaa !83, !noalias !106
  %1604 = icmp slt i32 %1595, 1
  br i1 %1604, label %1613, label %1605

; <label>:1605                                    ; preds = %1562
  %1606 = ashr i32 %1596, 2
  %1607 = call i32 @dx.op.binary.i32(i32 38, i32 %1606, i32 2)  ; IMin(a,b)
  %1608 = and i32 %1596, 3
  %1609 = mul i32 %1607, 4
  %1610 = add i32 %1608, %1609
  %1611 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %1610
  %1612 = load float, float* %1611, align 4, !tbaa !83, !noalias !106
  br label %1613

; <label>:1613                                    ; preds = %1605, %1562
  %1614 = phi float [ %1612, %1605 ], [ 0.000000e+00, %1562 ]
  %1615 = fsub fast float %1559, %1614
  %1616 = fsub fast float %1603, %1614
  %1617 = call float @dx.op.binary.f32(i32 35, float %1616, float 0x3F1A36E2E0000000)  ; FMax(a,b)
  %1618 = fdiv fast float %1615, %1617
  %1619 = call i32 @dx.op.binary.i32(i32 37, i32 %1596, i32 0)  ; IMax(a,b)
  %1620 = and i32 %810, 127
  %1621 = and i32 %811, 127
  %1622 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %8, i32 0, i32 %1620, i32 %1621, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1623 = extractvalue %dx.types.ResRet.f32 %1622, 0
  %1624 = fmul fast float %1618, %1164
  %1625 = call float @dx.op.unary.f32(i32 7, float %1624)  ; Saturate(value)
  %1626 = fmul fast float %1625, 2.000000e+00
  %1627 = fsub fast float 3.000000e+00, %1626
  %1628 = fmul fast float %1625, %1625
  %1629 = fmul fast float %1628, %1627
  %1630 = fcmp fast ogt float %1629, %1623
  %1631 = select i1 %1630, i32 %1595, i32 %1619
  br label %1632

; <label>:1632                                    ; preds = %1613, %1552
  %1633 = phi i32 [ %1631, %1613 ], [ 0, %1552 ]
  %1634 = sub nsw i32 9, %1633
  %1635 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1550, i32 0)  ; BufferLoad(srv,index,wot)
  %1636 = extractvalue %dx.types.ResRet.i32 %1635, 0
  %1637 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1550, i32 4)  ; BufferLoad(srv,index,wot)
  %1638 = extractvalue %dx.types.ResRet.i32 %1637, 0
  %1639 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1550, i32 8)  ; BufferLoad(srv,index,wot)
  %1640 = extractvalue %dx.types.ResRet.i32 %1639, 0
  %1641 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1550, i32 12)  ; BufferLoad(srv,index,wot)
  %1642 = extractvalue %dx.types.ResRet.i32 %1641, 0
  %1643 = call i32 @dx.op.binary.i32(i32 40, i32 %1636, i32 -1)  ; UMin(a,b)
  %1644 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %13, i32 %1638, i32 0)  ; BufferLoad(srv,index,wot)
  %1645 = extractvalue %dx.types.ResRet.f32 %1644, 3
  %1646 = call i32 @dx.op.binary.i32(i32 40, i32 %1634, i32 %1643)  ; UMin(a,b)
  %1647 = extractvalue %dx.types.ResRet.f32 %1644, 2
  %1648 = extractvalue %dx.types.ResRet.f32 %1644, 1
  %1649 = extractvalue %dx.types.ResRet.f32 %1644, 0
  %1650 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1640, i32 4)  ; BufferLoad(srv,index,wot)
  %1651 = extractvalue %dx.types.ResRet.i32 %1650, 0
  %1652 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1640, i32 12)  ; BufferLoad(srv,index,wot)
  %1653 = extractvalue %dx.types.ResRet.i32 %1652, 0
  %1654 = fsub fast float %1500, %1649
  %1655 = fsub fast float %62, %1648
  %1656 = fsub fast float %63, %1647
  %1657 = fdiv fast float %1654, %1645
  %1658 = fdiv fast float %1655, %1645
  %1659 = fdiv fast float %1656, %1645
  %1660 = call float @dx.op.unary.f32(i32 7, float %1657)  ; Saturate(value)
  %1661 = call float @dx.op.unary.f32(i32 7, float %1658)  ; Saturate(value)
  %1662 = call float @dx.op.unary.f32(i32 7, float %1659)  ; Saturate(value)
  %1663 = icmp eq i32 %1646, 0
  br i1 %1663, label %1738, label %1664

; <label>:1664                                    ; preds = %1632
  %1665 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1640, i32 8)  ; BufferLoad(srv,index,wot)
  %1666 = extractvalue %dx.types.ResRet.i32 %1665, 0
  %1667 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1640, i32 0)  ; BufferLoad(srv,index,wot)
  %1668 = extractvalue %dx.types.ResRet.i32 %1667, 0
  br label %1669

; <label>:1669                                    ; preds = %1725, %1664
  %1670 = phi i32 [ %1730, %1725 ], [ 0, %1664 ]
  %1671 = phi float [ %1705, %1725 ], [ %1660, %1664 ]
  %1672 = phi float [ %1706, %1725 ], [ %1661, %1664 ]
  %1673 = phi float [ %1707, %1725 ], [ %1662, %1664 ]
  %1674 = phi i32 [ %1704, %1725 ], [ %1653, %1664 ]
  %1675 = phi i32 [ %1727, %1725 ], [ %1666, %1664 ]
  %1676 = phi i32 [ %1702, %1725 ], [ %1651, %1664 ]
  %1677 = phi i32 [ %1729, %1725 ], [ %1668, %1664 ]
  %1678 = fmul fast float %1671, 3.000000e+00
  %1679 = fmul fast float %1672, 3.000000e+00
  %1680 = fmul fast float %1673, 3.000000e+00
  %1681 = call float @dx.op.unary.f32(i32 27, float %1678)  ; Round_ni(value)
  %1682 = call float @dx.op.unary.f32(i32 27, float %1679)  ; Round_ni(value)
  %1683 = call float @dx.op.unary.f32(i32 27, float %1680)  ; Round_ni(value)
  %1684 = fptoui float %1681 to i32
  %1685 = fptoui float %1682 to i32
  %1686 = fptoui float %1683 to i32
  %1687 = mul i32 %1685, 3
  %1688 = add i32 %1687, %1684
  %1689 = mul i32 %1686, 9
  %1690 = add i32 %1688, %1689
  %1691 = and i32 %1690, 31
  %1692 = shl i32 1, %1691
  %1693 = and i32 %1692, %1675
  %1694 = icmp eq i32 %1693, 0
  br i1 %1694, label %1732, label %1695

; <label>:1695                                    ; preds = %1669
  %1696 = add i32 %1692, -1
  %1697 = and i32 %1696, %1675
  %1698 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %1697)  ; Countbits(value)
  %1699 = add i32 %1677, %1640
  %1700 = add i32 %1699, %1698
  %1701 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1700, i32 4)  ; BufferLoad(srv,index,wot)
  %1702 = extractvalue %dx.types.ResRet.i32 %1701, 0
  %1703 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1700, i32 12)  ; BufferLoad(srv,index,wot)
  %1704 = extractvalue %dx.types.ResRet.i32 %1703, 0
  %1705 = call float @dx.op.unary.f32(i32 22, float %1678)  ; Frc(value)
  %1706 = call float @dx.op.unary.f32(i32 22, float %1679)  ; Frc(value)
  %1707 = call float @dx.op.unary.f32(i32 22, float %1680)  ; Frc(value)
  %1708 = fmul fast float %1705, 3.000000e+00
  %1709 = fmul fast float %1706, 3.000000e+00
  %1710 = fmul fast float %1707, 3.000000e+00
  %1711 = call float @dx.op.unary.f32(i32 27, float %1708)  ; Round_ni(value)
  %1712 = call float @dx.op.unary.f32(i32 27, float %1709)  ; Round_ni(value)
  %1713 = call float @dx.op.unary.f32(i32 27, float %1710)  ; Round_ni(value)
  %1714 = fptoui float %1711 to i32
  %1715 = fptoui float %1712 to i32
  %1716 = fptoui float %1713 to i32
  %1717 = mul i32 %1715, 3
  %1718 = add i32 %1717, %1714
  %1719 = mul i32 %1716, 9
  %1720 = add i32 %1718, %1719
  %1721 = and i32 %1720, 31
  %1722 = shl i32 1, %1721
  %1723 = and i32 %1722, %1704
  %1724 = icmp eq i32 %1723, 0
  br i1 %1724, label %1732, label %1725

; <label>:1725                                    ; preds = %1695
  %1726 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1700, i32 8)  ; BufferLoad(srv,index,wot)
  %1727 = extractvalue %dx.types.ResRet.i32 %1726, 0
  %1728 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1700, i32 0)  ; BufferLoad(srv,index,wot)
  %1729 = extractvalue %dx.types.ResRet.i32 %1728, 0
  %1730 = add nuw i32 %1670, 1
  %1731 = icmp ult i32 %1730, %1646
  br i1 %1731, label %1669, label %1732, !llvm.loop !104

; <label>:1732                                    ; preds = %1725, %1695, %1669
  %1733 = phi float [ %1705, %1725 ], [ %1671, %1669 ], [ %1671, %1695 ]
  %1734 = phi float [ %1706, %1725 ], [ %1672, %1669 ], [ %1672, %1695 ]
  %1735 = phi float [ %1707, %1725 ], [ %1673, %1669 ], [ %1673, %1695 ]
  %1736 = phi i32 [ %1704, %1725 ], [ %1674, %1669 ], [ %1674, %1695 ]
  %1737 = phi i32 [ %1702, %1725 ], [ %1676, %1669 ], [ %1676, %1695 ]
  br label %1738

; <label>:1738                                    ; preds = %1732, %1632
  %1739 = phi float [ %1660, %1632 ], [ %1733, %1732 ]
  %1740 = phi float [ %1661, %1632 ], [ %1734, %1732 ]
  %1741 = phi float [ %1662, %1632 ], [ %1735, %1732 ]
  %1742 = phi i32 [ %1653, %1632 ], [ %1736, %1732 ]
  %1743 = phi i32 [ %1651, %1632 ], [ %1737, %1732 ]
  %1744 = fmul fast float %1739, 3.000000e+00
  %1745 = fmul fast float %1740, 3.000000e+00
  %1746 = fmul fast float %1741, 3.000000e+00
  %1747 = call float @dx.op.unary.f32(i32 27, float %1744)  ; Round_ni(value)
  %1748 = call float @dx.op.unary.f32(i32 27, float %1745)  ; Round_ni(value)
  %1749 = call float @dx.op.unary.f32(i32 27, float %1746)  ; Round_ni(value)
  %1750 = fptoui float %1747 to i32
  %1751 = fptoui float %1748 to i32
  %1752 = fptoui float %1749 to i32
  %1753 = mul i32 %1751, 3
  %1754 = add i32 %1753, %1750
  %1755 = mul i32 %1752, 9
  %1756 = add i32 %1754, %1755
  %1757 = and i32 %1756, 31
  %1758 = shl i32 1, %1757
  %1759 = add i32 %1758, -1
  %1760 = and i32 %1759, %1742
  %1761 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %1760)  ; Countbits(value)
  %1762 = add i32 %1743, %1642
  %1763 = add i32 %1762, %1761
  %1764 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %17, i32 %1763, i32 undef)  ; BufferLoad(srv,index,wot)
  %1765 = extractvalue %dx.types.ResRet.i32 %1764, 0
  %1766 = and i32 %1765, 1023
  %1767 = lshr i32 %1765, 10
  %1768 = and i32 %1767, 1023
  %1769 = lshr i32 %1765, 20
  %1770 = and i32 %1769, 1023
  %1771 = uitofp i32 %1766 to float
  %1772 = uitofp i32 %1768 to float
  %1773 = uitofp i32 %1770 to float
  %1774 = call float @dx.op.unary.f32(i32 22, float %1744)  ; Frc(value)
  %1775 = call float @dx.op.unary.f32(i32 22, float %1745)  ; Frc(value)
  %1776 = call float @dx.op.unary.f32(i32 22, float %1746)  ; Frc(value)
  %1777 = fadd fast float %1774, 5.000000e-01
  %1778 = fadd fast float %1777, %1771
  %1779 = fadd fast float %1775, 5.000000e-01
  %1780 = fadd fast float %1779, %1772
  %1781 = fadd fast float %1776, 5.000000e-01
  %1782 = fadd fast float %1781, %1773
  %1783 = fmul fast float %1782, %1170
  %1784 = fmul fast float %1168, 5.000000e-01
  %1785 = fmul fast float %1784, %1778
  %1786 = fmul fast float %1169, 5.000000e-01
  %1787 = fmul fast float %1786, %1780
  %1788 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1785, float %1787, float %1783, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1789 = extractvalue %dx.types.ResRet.f32 %1788, 0
  %1790 = extractvalue %dx.types.ResRet.f32 %1788, 1
  %1791 = extractvalue %dx.types.ResRet.f32 %1788, 2
  %1792 = extractvalue %dx.types.ResRet.f32 %1788, 3
  %1793 = fadd fast float %1785, 5.000000e-01
  %1794 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1793, float %1787, float %1783, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1795 = extractvalue %dx.types.ResRet.f32 %1794, 0
  %1796 = extractvalue %dx.types.ResRet.f32 %1794, 1
  %1797 = extractvalue %dx.types.ResRet.f32 %1794, 2
  %1798 = extractvalue %dx.types.ResRet.f32 %1794, 3
  %1799 = fadd fast float %1787, 5.000000e-01
  %1800 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1785, float %1799, float %1783, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1801 = extractvalue %dx.types.ResRet.f32 %1800, 0
  %1802 = extractvalue %dx.types.ResRet.f32 %1800, 1
  %1803 = extractvalue %dx.types.ResRet.f32 %1800, 2
  %1804 = extractvalue %dx.types.ResRet.f32 %1800, 3
  br label %1805

; <label>:1805                                    ; preds = %1738, %1549, %1517
  %1806 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1792, %1738 ]
  %1807 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1791, %1738 ]
  %1808 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1790, %1738 ]
  %1809 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1789, %1738 ]
  %1810 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1798, %1738 ]
  %1811 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1797, %1738 ]
  %1812 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1796, %1738 ]
  %1813 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1795, %1738 ]
  %1814 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1804, %1738 ]
  %1815 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1803, %1738 ]
  %1816 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1802, %1738 ]
  %1817 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ %1801, %1738 ]
  %1818 = phi float [ 0.000000e+00, %1549 ], [ 0.000000e+00, %1517 ], [ 1.000000e+00, %1738 ]
  %1819 = call float @dx.op.binary.f32(i32 36, float %1513, float %1480)  ; FMin(a,b)
  %1820 = fmul fast float %1819, %1809
  %1821 = fmul fast float %1819, %1813
  %1822 = fmul fast float %1819, %1817
  %1823 = fadd fast float %1820, %1469
  %1824 = fadd fast float %1821, %1473
  %1825 = fadd fast float %1822, %1477
  %1826 = fmul fast float %1819, %1808
  %1827 = fmul fast float %1819, %1812
  %1828 = fmul fast float %1819, %1816
  %1829 = fadd fast float %1826, %1468
  %1830 = fadd fast float %1827, %1472
  %1831 = fadd fast float %1828, %1476
  %1832 = fmul fast float %1819, %1807
  %1833 = fmul fast float %1819, %1811
  %1834 = fmul fast float %1819, %1815
  %1835 = fadd fast float %1832, %1467
  %1836 = fadd fast float %1833, %1471
  %1837 = fadd fast float %1834, %1475
  %1838 = fmul fast float %1819, %1806
  %1839 = fmul fast float %1819, %1810
  %1840 = fmul fast float %1819, %1814
  %1841 = fadd fast float %1838, %1466
  %1842 = fadd fast float %1839, %1470
  %1843 = fadd fast float %1840, %1474
  %1844 = fmul fast float %1819, %1818
  %1845 = fadd fast float %1844, %1478
  %1846 = fsub fast float 1.000000e+00, %1845
  %1847 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1846)  ; FMax(a,b)
  br label %1848

; <label>:1848                                    ; preds = %1805, %1484
  %1849 = phi float [ %1841, %1805 ], [ %1466, %1484 ]
  %1850 = phi float [ %1835, %1805 ], [ %1467, %1484 ]
  %1851 = phi float [ %1829, %1805 ], [ %1468, %1484 ]
  %1852 = phi float [ %1823, %1805 ], [ %1469, %1484 ]
  %1853 = phi float [ %1842, %1805 ], [ %1470, %1484 ]
  %1854 = phi float [ %1836, %1805 ], [ %1471, %1484 ]
  %1855 = phi float [ %1830, %1805 ], [ %1472, %1484 ]
  %1856 = phi float [ %1824, %1805 ], [ %1473, %1484 ]
  %1857 = phi float [ %1843, %1805 ], [ %1474, %1484 ]
  %1858 = phi float [ %1837, %1805 ], [ %1475, %1484 ]
  %1859 = phi float [ %1831, %1805 ], [ %1476, %1484 ]
  %1860 = phi float [ %1825, %1805 ], [ %1477, %1484 ]
  %1861 = phi float [ %1847, %1805 ], [ %1480, %1484 ]
  %1862 = phi float [ %1845, %1805 ], [ %1478, %1484 ]
  %1863 = fcmp fast ogt float %1861, 0.000000e+00
  %1864 = fcmp fast ogt float %1514, 0.000000e+00
  %1865 = and i1 %1864, %1863
  br i1 %1865, label %1866, label %2197

; <label>:1866                                    ; preds = %1848
  %1867 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 0
  store float %1149, float* %1867, align 4
  %1868 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 1
  store float %1150, float* %1868, align 4
  %1869 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 2
  store float %1151, float* %1869, align 4
  %1870 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 3
  store float %1152, float* %1870, align 4
  %1871 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 4
  store float %1154, float* %1871, align 4
  %1872 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 5
  store float %1155, float* %1872, align 4
  %1873 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 6
  store float %1156, float* %1873, align 4
  %1874 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 7
  store float %1157, float* %1874, align 4
  %1875 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 8
  store float %1159, float* %1875, align 4
  %1876 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 9
  store float %1160, float* %1876, align 4
  %1877 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 10
  store float %1161, float* %1877, align 4
  %1878 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 11
  store float %1162, float* %1878, align 4
  br i1 %1185, label %2154, label %1879

; <label>:1879                                    ; preds = %1866
  %1880 = fdiv fast float %1498, %1140
  %1881 = fcmp fast olt float %1488, %1142
  %1882 = fcmp fast olt float %1880, %1143
  %1883 = fcmp fast olt float %1490, %1144
  %1884 = fcmp fast oge float %1488, 0.000000e+00
  %1885 = fcmp fast oge float %1880, 0.000000e+00
  %1886 = fcmp fast oge float %1490, 0.000000e+00
  %1887 = and i1 %1884, %1881
  %1888 = and i1 %1885, %1882
  %1889 = and i1 %1886, %1883
  %1890 = and i1 %1887, %1888
  %1891 = and i1 %1889, %1890
  br i1 %1891, label %1892, label %1898

; <label>:1892                                    ; preds = %1879
  %1893 = fptoui float %1488 to i32
  %1894 = fptoui float %1880 to i32
  %1895 = fptoui float %1490 to i32
  %1896 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %16, i32 0, i32 %1893, i32 %1894, i32 %1895, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1897 = extractvalue %dx.types.ResRet.i32 %1896, 0
  br label %1898

; <label>:1898                                    ; preds = %1892, %1879
  %1899 = phi i32 [ %1897, %1892 ], [ 65535, %1879 ]
  %1900 = icmp eq i32 %1899, 65535
  br i1 %1900, label %2154, label %1901, !dx.controlflow.hints !82

; <label>:1901                                    ; preds = %1898
  %1902 = fsub fast float %78, %1501
  %1903 = fmul fast float %267, %267
  %1904 = fmul fast float %1902, %1902
  %1905 = fmul fast float %269, %269
  %1906 = fadd fast float %1905, %1903
  %1907 = fadd fast float %1906, %1904
  %1908 = call float @dx.op.unary.f32(i32 24, float %1907)  ; Sqrt(value)
  %1909 = and i32 %1166, 1
  %1910 = icmp eq i32 %1909, 0
  br i1 %1910, label %1981, label %1911

; <label>:1911                                    ; preds = %1901
  %1912 = fcmp fast ogt float %1908, %1149
  %1913 = fcmp fast ogt float %1908, %1150
  %1914 = fcmp fast ogt float %1908, %1151
  %1915 = fcmp fast ogt float %1908, %1152
  %1916 = uitofp i1 %1912 to float
  %1917 = uitofp i1 %1913 to float
  %1918 = uitofp i1 %1914 to float
  %1919 = uitofp i1 %1915 to float
  %1920 = call float @dx.op.dot4.f32(i32 56, float %1916, float %1917, float %1918, float %1919, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1921 = fptosi float %1920 to i32
  %1922 = fcmp fast ogt float %1908, %1154
  %1923 = fcmp fast ogt float %1908, %1155
  %1924 = fcmp fast ogt float %1908, %1156
  %1925 = fcmp fast ogt float %1908, %1157
  %1926 = uitofp i1 %1922 to float
  %1927 = uitofp i1 %1923 to float
  %1928 = uitofp i1 %1924 to float
  %1929 = uitofp i1 %1925 to float
  %1930 = call float @dx.op.dot4.f32(i32 56, float %1926, float %1927, float %1928, float %1929, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1931 = fptosi float %1930 to i32
  %1932 = add nsw i32 %1931, %1921
  %1933 = fcmp fast ogt float %1908, %1159
  %1934 = fcmp fast ogt float %1908, %1160
  %1935 = fcmp fast ogt float %1908, %1161
  %1936 = fcmp fast ogt float %1908, %1162
  %1937 = uitofp i1 %1933 to float
  %1938 = uitofp i1 %1934 to float
  %1939 = uitofp i1 %1935 to float
  %1940 = uitofp i1 %1936 to float
  %1941 = call float @dx.op.dot4.f32(i32 56, float %1937, float %1938, float %1939, float %1940, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1942 = fptosi float %1941 to i32
  %1943 = add nsw i32 %1932, %1942
  %1944 = call i32 @dx.op.binary.i32(i32 38, i32 %1943, i32 9)  ; IMin(a,b)
  %1945 = add nsw i32 %1944, -1
  %1946 = ashr i32 %1944, 2
  %1947 = call i32 @dx.op.binary.i32(i32 38, i32 %1946, i32 2)  ; IMin(a,b)
  %1948 = and i32 %1944, 3
  %1949 = mul i32 %1947, 4
  %1950 = add i32 %1948, %1949
  %1951 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %1950
  %1952 = load float, float* %1951, align 4, !tbaa !83, !noalias !106
  %1953 = icmp slt i32 %1944, 1
  br i1 %1953, label %1962, label %1954

; <label>:1954                                    ; preds = %1911
  %1955 = ashr i32 %1945, 2
  %1956 = call i32 @dx.op.binary.i32(i32 38, i32 %1955, i32 2)  ; IMin(a,b)
  %1957 = and i32 %1945, 3
  %1958 = mul i32 %1956, 4
  %1959 = add i32 %1957, %1958
  %1960 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %1959
  %1961 = load float, float* %1960, align 4, !tbaa !83, !noalias !106
  br label %1962

; <label>:1962                                    ; preds = %1954, %1911
  %1963 = phi float [ %1961, %1954 ], [ 0.000000e+00, %1911 ]
  %1964 = fsub fast float %1908, %1963
  %1965 = fsub fast float %1952, %1963
  %1966 = call float @dx.op.binary.f32(i32 35, float %1965, float 0x3F1A36E2E0000000)  ; FMax(a,b)
  %1967 = fdiv fast float %1964, %1966
  %1968 = call i32 @dx.op.binary.i32(i32 37, i32 %1945, i32 0)  ; IMax(a,b)
  %1969 = and i32 %810, 127
  %1970 = and i32 %811, 127
  %1971 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %8, i32 0, i32 %1969, i32 %1970, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1972 = extractvalue %dx.types.ResRet.f32 %1971, 0
  %1973 = fmul fast float %1967, %1164
  %1974 = call float @dx.op.unary.f32(i32 7, float %1973)  ; Saturate(value)
  %1975 = fmul fast float %1974, 2.000000e+00
  %1976 = fsub fast float 3.000000e+00, %1975
  %1977 = fmul fast float %1974, %1974
  %1978 = fmul fast float %1977, %1976
  %1979 = fcmp fast ogt float %1978, %1972
  %1980 = select i1 %1979, i32 %1944, i32 %1968
  br label %1981

; <label>:1981                                    ; preds = %1962, %1901
  %1982 = phi i32 [ %1980, %1962 ], [ 0, %1901 ]
  %1983 = sub nsw i32 9, %1982
  %1984 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1899, i32 0)  ; BufferLoad(srv,index,wot)
  %1985 = extractvalue %dx.types.ResRet.i32 %1984, 0
  %1986 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1899, i32 4)  ; BufferLoad(srv,index,wot)
  %1987 = extractvalue %dx.types.ResRet.i32 %1986, 0
  %1988 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1899, i32 8)  ; BufferLoad(srv,index,wot)
  %1989 = extractvalue %dx.types.ResRet.i32 %1988, 0
  %1990 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1899, i32 12)  ; BufferLoad(srv,index,wot)
  %1991 = extractvalue %dx.types.ResRet.i32 %1990, 0
  %1992 = call i32 @dx.op.binary.i32(i32 40, i32 %1985, i32 -1)  ; UMin(a,b)
  %1993 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %13, i32 %1987, i32 0)  ; BufferLoad(srv,index,wot)
  %1994 = extractvalue %dx.types.ResRet.f32 %1993, 3
  %1995 = call i32 @dx.op.binary.i32(i32 40, i32 %1983, i32 %1992)  ; UMin(a,b)
  %1996 = extractvalue %dx.types.ResRet.f32 %1993, 2
  %1997 = extractvalue %dx.types.ResRet.f32 %1993, 1
  %1998 = extractvalue %dx.types.ResRet.f32 %1993, 0
  %1999 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1989, i32 4)  ; BufferLoad(srv,index,wot)
  %2000 = extractvalue %dx.types.ResRet.i32 %1999, 0
  %2001 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1989, i32 12)  ; BufferLoad(srv,index,wot)
  %2002 = extractvalue %dx.types.ResRet.i32 %2001, 0
  %2003 = fsub fast float %61, %1998
  %2004 = fsub fast float %1501, %1997
  %2005 = fsub fast float %63, %1996
  %2006 = fdiv fast float %2003, %1994
  %2007 = fdiv fast float %2004, %1994
  %2008 = fdiv fast float %2005, %1994
  %2009 = call float @dx.op.unary.f32(i32 7, float %2006)  ; Saturate(value)
  %2010 = call float @dx.op.unary.f32(i32 7, float %2007)  ; Saturate(value)
  %2011 = call float @dx.op.unary.f32(i32 7, float %2008)  ; Saturate(value)
  %2012 = icmp eq i32 %1995, 0
  br i1 %2012, label %2087, label %2013

; <label>:2013                                    ; preds = %1981
  %2014 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1989, i32 8)  ; BufferLoad(srv,index,wot)
  %2015 = extractvalue %dx.types.ResRet.i32 %2014, 0
  %2016 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1989, i32 0)  ; BufferLoad(srv,index,wot)
  %2017 = extractvalue %dx.types.ResRet.i32 %2016, 0
  br label %2018

; <label>:2018                                    ; preds = %2074, %2013
  %2019 = phi i32 [ %2079, %2074 ], [ 0, %2013 ]
  %2020 = phi float [ %2054, %2074 ], [ %2009, %2013 ]
  %2021 = phi float [ %2055, %2074 ], [ %2010, %2013 ]
  %2022 = phi float [ %2056, %2074 ], [ %2011, %2013 ]
  %2023 = phi i32 [ %2053, %2074 ], [ %2002, %2013 ]
  %2024 = phi i32 [ %2076, %2074 ], [ %2015, %2013 ]
  %2025 = phi i32 [ %2051, %2074 ], [ %2000, %2013 ]
  %2026 = phi i32 [ %2078, %2074 ], [ %2017, %2013 ]
  %2027 = fmul fast float %2020, 3.000000e+00
  %2028 = fmul fast float %2021, 3.000000e+00
  %2029 = fmul fast float %2022, 3.000000e+00
  %2030 = call float @dx.op.unary.f32(i32 27, float %2027)  ; Round_ni(value)
  %2031 = call float @dx.op.unary.f32(i32 27, float %2028)  ; Round_ni(value)
  %2032 = call float @dx.op.unary.f32(i32 27, float %2029)  ; Round_ni(value)
  %2033 = fptoui float %2030 to i32
  %2034 = fptoui float %2031 to i32
  %2035 = fptoui float %2032 to i32
  %2036 = mul i32 %2034, 3
  %2037 = add i32 %2036, %2033
  %2038 = mul i32 %2035, 9
  %2039 = add i32 %2037, %2038
  %2040 = and i32 %2039, 31
  %2041 = shl i32 1, %2040
  %2042 = and i32 %2041, %2024
  %2043 = icmp eq i32 %2042, 0
  br i1 %2043, label %2081, label %2044

; <label>:2044                                    ; preds = %2018
  %2045 = add i32 %2041, -1
  %2046 = and i32 %2045, %2024
  %2047 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %2046)  ; Countbits(value)
  %2048 = add i32 %2026, %1989
  %2049 = add i32 %2048, %2047
  %2050 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2049, i32 4)  ; BufferLoad(srv,index,wot)
  %2051 = extractvalue %dx.types.ResRet.i32 %2050, 0
  %2052 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2049, i32 12)  ; BufferLoad(srv,index,wot)
  %2053 = extractvalue %dx.types.ResRet.i32 %2052, 0
  %2054 = call float @dx.op.unary.f32(i32 22, float %2027)  ; Frc(value)
  %2055 = call float @dx.op.unary.f32(i32 22, float %2028)  ; Frc(value)
  %2056 = call float @dx.op.unary.f32(i32 22, float %2029)  ; Frc(value)
  %2057 = fmul fast float %2054, 3.000000e+00
  %2058 = fmul fast float %2055, 3.000000e+00
  %2059 = fmul fast float %2056, 3.000000e+00
  %2060 = call float @dx.op.unary.f32(i32 27, float %2057)  ; Round_ni(value)
  %2061 = call float @dx.op.unary.f32(i32 27, float %2058)  ; Round_ni(value)
  %2062 = call float @dx.op.unary.f32(i32 27, float %2059)  ; Round_ni(value)
  %2063 = fptoui float %2060 to i32
  %2064 = fptoui float %2061 to i32
  %2065 = fptoui float %2062 to i32
  %2066 = mul i32 %2064, 3
  %2067 = add i32 %2066, %2063
  %2068 = mul i32 %2065, 9
  %2069 = add i32 %2067, %2068
  %2070 = and i32 %2069, 31
  %2071 = shl i32 1, %2070
  %2072 = and i32 %2071, %2053
  %2073 = icmp eq i32 %2072, 0
  br i1 %2073, label %2081, label %2074

; <label>:2074                                    ; preds = %2044
  %2075 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2049, i32 8)  ; BufferLoad(srv,index,wot)
  %2076 = extractvalue %dx.types.ResRet.i32 %2075, 0
  %2077 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2049, i32 0)  ; BufferLoad(srv,index,wot)
  %2078 = extractvalue %dx.types.ResRet.i32 %2077, 0
  %2079 = add nuw i32 %2019, 1
  %2080 = icmp ult i32 %2079, %1995
  br i1 %2080, label %2018, label %2081, !llvm.loop !104

; <label>:2081                                    ; preds = %2074, %2044, %2018
  %2082 = phi float [ %2054, %2074 ], [ %2020, %2018 ], [ %2020, %2044 ]
  %2083 = phi float [ %2055, %2074 ], [ %2021, %2018 ], [ %2021, %2044 ]
  %2084 = phi float [ %2056, %2074 ], [ %2022, %2018 ], [ %2022, %2044 ]
  %2085 = phi i32 [ %2053, %2074 ], [ %2023, %2018 ], [ %2023, %2044 ]
  %2086 = phi i32 [ %2051, %2074 ], [ %2025, %2018 ], [ %2025, %2044 ]
  br label %2087

; <label>:2087                                    ; preds = %2081, %1981
  %2088 = phi float [ %2009, %1981 ], [ %2082, %2081 ]
  %2089 = phi float [ %2010, %1981 ], [ %2083, %2081 ]
  %2090 = phi float [ %2011, %1981 ], [ %2084, %2081 ]
  %2091 = phi i32 [ %2002, %1981 ], [ %2085, %2081 ]
  %2092 = phi i32 [ %2000, %1981 ], [ %2086, %2081 ]
  %2093 = fmul fast float %2088, 3.000000e+00
  %2094 = fmul fast float %2089, 3.000000e+00
  %2095 = fmul fast float %2090, 3.000000e+00
  %2096 = call float @dx.op.unary.f32(i32 27, float %2093)  ; Round_ni(value)
  %2097 = call float @dx.op.unary.f32(i32 27, float %2094)  ; Round_ni(value)
  %2098 = call float @dx.op.unary.f32(i32 27, float %2095)  ; Round_ni(value)
  %2099 = fptoui float %2096 to i32
  %2100 = fptoui float %2097 to i32
  %2101 = fptoui float %2098 to i32
  %2102 = mul i32 %2100, 3
  %2103 = add i32 %2102, %2099
  %2104 = mul i32 %2101, 9
  %2105 = add i32 %2103, %2104
  %2106 = and i32 %2105, 31
  %2107 = shl i32 1, %2106
  %2108 = add i32 %2107, -1
  %2109 = and i32 %2108, %2091
  %2110 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %2109)  ; Countbits(value)
  %2111 = add i32 %2092, %1991
  %2112 = add i32 %2111, %2110
  %2113 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %17, i32 %2112, i32 undef)  ; BufferLoad(srv,index,wot)
  %2114 = extractvalue %dx.types.ResRet.i32 %2113, 0
  %2115 = and i32 %2114, 1023
  %2116 = lshr i32 %2114, 10
  %2117 = and i32 %2116, 1023
  %2118 = lshr i32 %2114, 20
  %2119 = and i32 %2118, 1023
  %2120 = uitofp i32 %2115 to float
  %2121 = uitofp i32 %2117 to float
  %2122 = uitofp i32 %2119 to float
  %2123 = call float @dx.op.unary.f32(i32 22, float %2093)  ; Frc(value)
  %2124 = call float @dx.op.unary.f32(i32 22, float %2094)  ; Frc(value)
  %2125 = call float @dx.op.unary.f32(i32 22, float %2095)  ; Frc(value)
  %2126 = fadd fast float %2123, 5.000000e-01
  %2127 = fadd fast float %2126, %2120
  %2128 = fadd fast float %2124, 5.000000e-01
  %2129 = fadd fast float %2128, %2121
  %2130 = fadd fast float %2125, 5.000000e-01
  %2131 = fadd fast float %2130, %2122
  %2132 = fmul fast float %2131, %1170
  %2133 = fmul fast float %1168, 5.000000e-01
  %2134 = fmul fast float %2133, %2127
  %2135 = fmul fast float %1169, 5.000000e-01
  %2136 = fmul fast float %2135, %2129
  %2137 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2134, float %2136, float %2132, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2138 = extractvalue %dx.types.ResRet.f32 %2137, 0
  %2139 = extractvalue %dx.types.ResRet.f32 %2137, 1
  %2140 = extractvalue %dx.types.ResRet.f32 %2137, 2
  %2141 = extractvalue %dx.types.ResRet.f32 %2137, 3
  %2142 = fadd fast float %2134, 5.000000e-01
  %2143 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2142, float %2136, float %2132, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2144 = extractvalue %dx.types.ResRet.f32 %2143, 0
  %2145 = extractvalue %dx.types.ResRet.f32 %2143, 1
  %2146 = extractvalue %dx.types.ResRet.f32 %2143, 2
  %2147 = extractvalue %dx.types.ResRet.f32 %2143, 3
  %2148 = fadd fast float %2136, 5.000000e-01
  %2149 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2134, float %2148, float %2132, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2150 = extractvalue %dx.types.ResRet.f32 %2149, 0
  %2151 = extractvalue %dx.types.ResRet.f32 %2149, 1
  %2152 = extractvalue %dx.types.ResRet.f32 %2149, 2
  %2153 = extractvalue %dx.types.ResRet.f32 %2149, 3
  br label %2154

; <label>:2154                                    ; preds = %2087, %1898, %1866
  %2155 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2141, %2087 ]
  %2156 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2140, %2087 ]
  %2157 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2139, %2087 ]
  %2158 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2138, %2087 ]
  %2159 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2147, %2087 ]
  %2160 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2146, %2087 ]
  %2161 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2145, %2087 ]
  %2162 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2144, %2087 ]
  %2163 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2153, %2087 ]
  %2164 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2152, %2087 ]
  %2165 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2151, %2087 ]
  %2166 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ %2150, %2087 ]
  %2167 = phi float [ 0.000000e+00, %1898 ], [ 0.000000e+00, %1866 ], [ 1.000000e+00, %2087 ]
  %2168 = call float @dx.op.binary.f32(i32 36, float %1514, float %1861)  ; FMin(a,b)
  %2169 = fmul fast float %2168, %2158
  %2170 = fmul fast float %2168, %2162
  %2171 = fmul fast float %2168, %2166
  %2172 = fadd fast float %2169, %1852
  %2173 = fadd fast float %2170, %1856
  %2174 = fadd fast float %2171, %1860
  %2175 = fmul fast float %2168, %2157
  %2176 = fmul fast float %2168, %2161
  %2177 = fmul fast float %2168, %2165
  %2178 = fadd fast float %2175, %1851
  %2179 = fadd fast float %2176, %1855
  %2180 = fadd fast float %2177, %1859
  %2181 = fmul fast float %2168, %2156
  %2182 = fmul fast float %2168, %2160
  %2183 = fmul fast float %2168, %2164
  %2184 = fadd fast float %2181, %1850
  %2185 = fadd fast float %2182, %1854
  %2186 = fadd fast float %2183, %1858
  %2187 = fmul fast float %2168, %2155
  %2188 = fmul fast float %2168, %2159
  %2189 = fmul fast float %2168, %2163
  %2190 = fadd fast float %2187, %1849
  %2191 = fadd fast float %2188, %1853
  %2192 = fadd fast float %2189, %1857
  %2193 = fmul fast float %2168, %2167
  %2194 = fadd fast float %2193, %1862
  %2195 = fsub fast float 1.000000e+00, %2194
  %2196 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2195)  ; FMax(a,b)
  br label %2197

; <label>:2197                                    ; preds = %2154, %1848
  %2198 = phi float [ %2190, %2154 ], [ %1849, %1848 ]
  %2199 = phi float [ %2184, %2154 ], [ %1850, %1848 ]
  %2200 = phi float [ %2178, %2154 ], [ %1851, %1848 ]
  %2201 = phi float [ %2172, %2154 ], [ %1852, %1848 ]
  %2202 = phi float [ %2191, %2154 ], [ %1853, %1848 ]
  %2203 = phi float [ %2185, %2154 ], [ %1854, %1848 ]
  %2204 = phi float [ %2179, %2154 ], [ %1855, %1848 ]
  %2205 = phi float [ %2173, %2154 ], [ %1856, %1848 ]
  %2206 = phi float [ %2192, %2154 ], [ %1857, %1848 ]
  %2207 = phi float [ %2186, %2154 ], [ %1858, %1848 ]
  %2208 = phi float [ %2180, %2154 ], [ %1859, %1848 ]
  %2209 = phi float [ %2174, %2154 ], [ %1860, %1848 ]
  %2210 = phi float [ %2196, %2154 ], [ %1861, %1848 ]
  %2211 = phi float [ %2194, %2154 ], [ %1862, %1848 ]
  %2212 = fcmp fast ogt float %2210, 0.000000e+00
  %2213 = fcmp fast ogt float %1515, 0.000000e+00
  %2214 = and i1 %2213, %2212
  br i1 %2214, label %2215, label %2544

; <label>:2215                                    ; preds = %2197
  %2216 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 0
  store float %1149, float* %2216, align 4
  %2217 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 1
  store float %1150, float* %2217, align 4
  %2218 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 2
  store float %1151, float* %2218, align 4
  %2219 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 3
  store float %1152, float* %2219, align 4
  %2220 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 4
  store float %1154, float* %2220, align 4
  %2221 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 5
  store float %1155, float* %2221, align 4
  %2222 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 6
  store float %1156, float* %2222, align 4
  %2223 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 7
  store float %1157, float* %2223, align 4
  %2224 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 8
  store float %1159, float* %2224, align 4
  %2225 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 9
  store float %1160, float* %2225, align 4
  %2226 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 10
  store float %1161, float* %2226, align 4
  %2227 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 11
  store float %1162, float* %2227, align 4
  br i1 %1185, label %2503, label %2228

; <label>:2228                                    ; preds = %2215
  %2229 = fdiv fast float %1499, %1140
  %2230 = fcmp fast olt float %1488, %1142
  %2231 = fcmp fast olt float %1489, %1143
  %2232 = fcmp fast olt float %2229, %1144
  %2233 = fcmp fast oge float %1488, 0.000000e+00
  %2234 = fcmp fast oge float %1489, 0.000000e+00
  %2235 = fcmp fast oge float %2229, 0.000000e+00
  %2236 = and i1 %2233, %2230
  %2237 = and i1 %2234, %2231
  %2238 = and i1 %2235, %2232
  %2239 = and i1 %2236, %2237
  %2240 = and i1 %2239, %2238
  br i1 %2240, label %2241, label %2247

; <label>:2241                                    ; preds = %2228
  %2242 = fptoui float %1488 to i32
  %2243 = fptoui float %1489 to i32
  %2244 = fptoui float %2229 to i32
  %2245 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %16, i32 0, i32 %2242, i32 %2243, i32 %2244, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2246 = extractvalue %dx.types.ResRet.i32 %2245, 0
  br label %2247

; <label>:2247                                    ; preds = %2241, %2228
  %2248 = phi i32 [ %2246, %2241 ], [ 65535, %2228 ]
  %2249 = icmp eq i32 %2248, 65535
  br i1 %2249, label %2503, label %2250, !dx.controlflow.hints !82

; <label>:2250                                    ; preds = %2247
  %2251 = fsub fast float %79, %1502
  %2252 = fmul fast float %267, %267
  %2253 = fmul fast float %268, %268
  %2254 = fadd fast float %2252, %2253
  %2255 = fmul fast float %2251, %2251
  %2256 = fadd fast float %2254, %2255
  %2257 = call float @dx.op.unary.f32(i32 24, float %2256)  ; Sqrt(value)
  %2258 = and i32 %1166, 1
  %2259 = icmp eq i32 %2258, 0
  br i1 %2259, label %2330, label %2260

; <label>:2260                                    ; preds = %2250
  %2261 = fcmp fast ogt float %2257, %1149
  %2262 = fcmp fast ogt float %2257, %1150
  %2263 = fcmp fast ogt float %2257, %1151
  %2264 = fcmp fast ogt float %2257, %1152
  %2265 = uitofp i1 %2261 to float
  %2266 = uitofp i1 %2262 to float
  %2267 = uitofp i1 %2263 to float
  %2268 = uitofp i1 %2264 to float
  %2269 = call float @dx.op.dot4.f32(i32 56, float %2265, float %2266, float %2267, float %2268, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2270 = fptosi float %2269 to i32
  %2271 = fcmp fast ogt float %2257, %1154
  %2272 = fcmp fast ogt float %2257, %1155
  %2273 = fcmp fast ogt float %2257, %1156
  %2274 = fcmp fast ogt float %2257, %1157
  %2275 = uitofp i1 %2271 to float
  %2276 = uitofp i1 %2272 to float
  %2277 = uitofp i1 %2273 to float
  %2278 = uitofp i1 %2274 to float
  %2279 = call float @dx.op.dot4.f32(i32 56, float %2275, float %2276, float %2277, float %2278, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2280 = fptosi float %2279 to i32
  %2281 = add nsw i32 %2280, %2270
  %2282 = fcmp fast ogt float %2257, %1159
  %2283 = fcmp fast ogt float %2257, %1160
  %2284 = fcmp fast ogt float %2257, %1161
  %2285 = fcmp fast ogt float %2257, %1162
  %2286 = uitofp i1 %2282 to float
  %2287 = uitofp i1 %2283 to float
  %2288 = uitofp i1 %2284 to float
  %2289 = uitofp i1 %2285 to float
  %2290 = call float @dx.op.dot4.f32(i32 56, float %2286, float %2287, float %2288, float %2289, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2291 = fptosi float %2290 to i32
  %2292 = add nsw i32 %2281, %2291
  %2293 = call i32 @dx.op.binary.i32(i32 38, i32 %2292, i32 9)  ; IMin(a,b)
  %2294 = add nsw i32 %2293, -1
  %2295 = ashr i32 %2293, 2
  %2296 = call i32 @dx.op.binary.i32(i32 38, i32 %2295, i32 2)  ; IMin(a,b)
  %2297 = and i32 %2293, 3
  %2298 = mul i32 %2296, 4
  %2299 = add i32 %2297, %2298
  %2300 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %2299
  %2301 = load float, float* %2300, align 4, !tbaa !83, !noalias !106
  %2302 = icmp slt i32 %2293, 1
  br i1 %2302, label %2311, label %2303

; <label>:2303                                    ; preds = %2260
  %2304 = ashr i32 %2294, 2
  %2305 = call i32 @dx.op.binary.i32(i32 38, i32 %2304, i32 2)  ; IMin(a,b)
  %2306 = and i32 %2294, 3
  %2307 = mul i32 %2305, 4
  %2308 = add i32 %2306, %2307
  %2309 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %2308
  %2310 = load float, float* %2309, align 4, !tbaa !83, !noalias !106
  br label %2311

; <label>:2311                                    ; preds = %2303, %2260
  %2312 = phi float [ %2310, %2303 ], [ 0.000000e+00, %2260 ]
  %2313 = fsub fast float %2257, %2312
  %2314 = fsub fast float %2301, %2312
  %2315 = call float @dx.op.binary.f32(i32 35, float %2314, float 0x3F1A36E2E0000000)  ; FMax(a,b)
  %2316 = fdiv fast float %2313, %2315
  %2317 = call i32 @dx.op.binary.i32(i32 37, i32 %2294, i32 0)  ; IMax(a,b)
  %2318 = and i32 %810, 127
  %2319 = and i32 %811, 127
  %2320 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %8, i32 0, i32 %2318, i32 %2319, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2321 = extractvalue %dx.types.ResRet.f32 %2320, 0
  %2322 = fmul fast float %2316, %1164
  %2323 = call float @dx.op.unary.f32(i32 7, float %2322)  ; Saturate(value)
  %2324 = fmul fast float %2323, 2.000000e+00
  %2325 = fsub fast float 3.000000e+00, %2324
  %2326 = fmul fast float %2323, %2323
  %2327 = fmul fast float %2326, %2325
  %2328 = fcmp fast ogt float %2327, %2321
  %2329 = select i1 %2328, i32 %2293, i32 %2317
  br label %2330

; <label>:2330                                    ; preds = %2311, %2250
  %2331 = phi i32 [ %2329, %2311 ], [ 0, %2250 ]
  %2332 = sub nsw i32 9, %2331
  %2333 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %2248, i32 0)  ; BufferLoad(srv,index,wot)
  %2334 = extractvalue %dx.types.ResRet.i32 %2333, 0
  %2335 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %2248, i32 4)  ; BufferLoad(srv,index,wot)
  %2336 = extractvalue %dx.types.ResRet.i32 %2335, 0
  %2337 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %2248, i32 8)  ; BufferLoad(srv,index,wot)
  %2338 = extractvalue %dx.types.ResRet.i32 %2337, 0
  %2339 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %2248, i32 12)  ; BufferLoad(srv,index,wot)
  %2340 = extractvalue %dx.types.ResRet.i32 %2339, 0
  %2341 = call i32 @dx.op.binary.i32(i32 40, i32 %2334, i32 -1)  ; UMin(a,b)
  %2342 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %13, i32 %2336, i32 0)  ; BufferLoad(srv,index,wot)
  %2343 = extractvalue %dx.types.ResRet.f32 %2342, 3
  %2344 = call i32 @dx.op.binary.i32(i32 40, i32 %2332, i32 %2341)  ; UMin(a,b)
  %2345 = extractvalue %dx.types.ResRet.f32 %2342, 2
  %2346 = extractvalue %dx.types.ResRet.f32 %2342, 1
  %2347 = extractvalue %dx.types.ResRet.f32 %2342, 0
  %2348 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2338, i32 4)  ; BufferLoad(srv,index,wot)
  %2349 = extractvalue %dx.types.ResRet.i32 %2348, 0
  %2350 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2338, i32 12)  ; BufferLoad(srv,index,wot)
  %2351 = extractvalue %dx.types.ResRet.i32 %2350, 0
  %2352 = fsub fast float %61, %2347
  %2353 = fsub fast float %62, %2346
  %2354 = fsub fast float %1502, %2345
  %2355 = fdiv fast float %2352, %2343
  %2356 = fdiv fast float %2353, %2343
  %2357 = fdiv fast float %2354, %2343
  %2358 = call float @dx.op.unary.f32(i32 7, float %2355)  ; Saturate(value)
  %2359 = call float @dx.op.unary.f32(i32 7, float %2356)  ; Saturate(value)
  %2360 = call float @dx.op.unary.f32(i32 7, float %2357)  ; Saturate(value)
  %2361 = icmp eq i32 %2344, 0
  br i1 %2361, label %2436, label %2362

; <label>:2362                                    ; preds = %2330
  %2363 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2338, i32 8)  ; BufferLoad(srv,index,wot)
  %2364 = extractvalue %dx.types.ResRet.i32 %2363, 0
  %2365 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2338, i32 0)  ; BufferLoad(srv,index,wot)
  %2366 = extractvalue %dx.types.ResRet.i32 %2365, 0
  br label %2367

; <label>:2367                                    ; preds = %2423, %2362
  %2368 = phi i32 [ %2428, %2423 ], [ 0, %2362 ]
  %2369 = phi float [ %2403, %2423 ], [ %2358, %2362 ]
  %2370 = phi float [ %2404, %2423 ], [ %2359, %2362 ]
  %2371 = phi float [ %2405, %2423 ], [ %2360, %2362 ]
  %2372 = phi i32 [ %2402, %2423 ], [ %2351, %2362 ]
  %2373 = phi i32 [ %2425, %2423 ], [ %2364, %2362 ]
  %2374 = phi i32 [ %2400, %2423 ], [ %2349, %2362 ]
  %2375 = phi i32 [ %2427, %2423 ], [ %2366, %2362 ]
  %2376 = fmul fast float %2369, 3.000000e+00
  %2377 = fmul fast float %2370, 3.000000e+00
  %2378 = fmul fast float %2371, 3.000000e+00
  %2379 = call float @dx.op.unary.f32(i32 27, float %2376)  ; Round_ni(value)
  %2380 = call float @dx.op.unary.f32(i32 27, float %2377)  ; Round_ni(value)
  %2381 = call float @dx.op.unary.f32(i32 27, float %2378)  ; Round_ni(value)
  %2382 = fptoui float %2379 to i32
  %2383 = fptoui float %2380 to i32
  %2384 = fptoui float %2381 to i32
  %2385 = mul i32 %2383, 3
  %2386 = add i32 %2385, %2382
  %2387 = mul i32 %2384, 9
  %2388 = add i32 %2386, %2387
  %2389 = and i32 %2388, 31
  %2390 = shl i32 1, %2389
  %2391 = and i32 %2390, %2373
  %2392 = icmp eq i32 %2391, 0
  br i1 %2392, label %2430, label %2393

; <label>:2393                                    ; preds = %2367
  %2394 = add i32 %2390, -1
  %2395 = and i32 %2394, %2373
  %2396 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %2395)  ; Countbits(value)
  %2397 = add i32 %2375, %2338
  %2398 = add i32 %2397, %2396
  %2399 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2398, i32 4)  ; BufferLoad(srv,index,wot)
  %2400 = extractvalue %dx.types.ResRet.i32 %2399, 0
  %2401 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2398, i32 12)  ; BufferLoad(srv,index,wot)
  %2402 = extractvalue %dx.types.ResRet.i32 %2401, 0
  %2403 = call float @dx.op.unary.f32(i32 22, float %2376)  ; Frc(value)
  %2404 = call float @dx.op.unary.f32(i32 22, float %2377)  ; Frc(value)
  %2405 = call float @dx.op.unary.f32(i32 22, float %2378)  ; Frc(value)
  %2406 = fmul fast float %2403, 3.000000e+00
  %2407 = fmul fast float %2404, 3.000000e+00
  %2408 = fmul fast float %2405, 3.000000e+00
  %2409 = call float @dx.op.unary.f32(i32 27, float %2406)  ; Round_ni(value)
  %2410 = call float @dx.op.unary.f32(i32 27, float %2407)  ; Round_ni(value)
  %2411 = call float @dx.op.unary.f32(i32 27, float %2408)  ; Round_ni(value)
  %2412 = fptoui float %2409 to i32
  %2413 = fptoui float %2410 to i32
  %2414 = fptoui float %2411 to i32
  %2415 = mul i32 %2413, 3
  %2416 = add i32 %2415, %2412
  %2417 = mul i32 %2414, 9
  %2418 = add i32 %2416, %2417
  %2419 = and i32 %2418, 31
  %2420 = shl i32 1, %2419
  %2421 = and i32 %2420, %2402
  %2422 = icmp eq i32 %2421, 0
  br i1 %2422, label %2430, label %2423

; <label>:2423                                    ; preds = %2393
  %2424 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2398, i32 8)  ; BufferLoad(srv,index,wot)
  %2425 = extractvalue %dx.types.ResRet.i32 %2424, 0
  %2426 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2398, i32 0)  ; BufferLoad(srv,index,wot)
  %2427 = extractvalue %dx.types.ResRet.i32 %2426, 0
  %2428 = add nuw i32 %2368, 1
  %2429 = icmp ult i32 %2428, %2344
  br i1 %2429, label %2367, label %2430, !llvm.loop !104

; <label>:2430                                    ; preds = %2423, %2393, %2367
  %2431 = phi float [ %2403, %2423 ], [ %2369, %2367 ], [ %2369, %2393 ]
  %2432 = phi float [ %2404, %2423 ], [ %2370, %2367 ], [ %2370, %2393 ]
  %2433 = phi float [ %2405, %2423 ], [ %2371, %2367 ], [ %2371, %2393 ]
  %2434 = phi i32 [ %2402, %2423 ], [ %2372, %2367 ], [ %2372, %2393 ]
  %2435 = phi i32 [ %2400, %2423 ], [ %2374, %2367 ], [ %2374, %2393 ]
  br label %2436

; <label>:2436                                    ; preds = %2430, %2330
  %2437 = phi float [ %2358, %2330 ], [ %2431, %2430 ]
  %2438 = phi float [ %2359, %2330 ], [ %2432, %2430 ]
  %2439 = phi float [ %2360, %2330 ], [ %2433, %2430 ]
  %2440 = phi i32 [ %2351, %2330 ], [ %2434, %2430 ]
  %2441 = phi i32 [ %2349, %2330 ], [ %2435, %2430 ]
  %2442 = fmul fast float %2437, 3.000000e+00
  %2443 = fmul fast float %2438, 3.000000e+00
  %2444 = fmul fast float %2439, 3.000000e+00
  %2445 = call float @dx.op.unary.f32(i32 27, float %2442)  ; Round_ni(value)
  %2446 = call float @dx.op.unary.f32(i32 27, float %2443)  ; Round_ni(value)
  %2447 = call float @dx.op.unary.f32(i32 27, float %2444)  ; Round_ni(value)
  %2448 = fptoui float %2445 to i32
  %2449 = fptoui float %2446 to i32
  %2450 = fptoui float %2447 to i32
  %2451 = mul i32 %2449, 3
  %2452 = add i32 %2451, %2448
  %2453 = mul i32 %2450, 9
  %2454 = add i32 %2452, %2453
  %2455 = and i32 %2454, 31
  %2456 = shl i32 1, %2455
  %2457 = add i32 %2456, -1
  %2458 = and i32 %2457, %2440
  %2459 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %2458)  ; Countbits(value)
  %2460 = add i32 %2441, %2340
  %2461 = add i32 %2460, %2459
  %2462 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %17, i32 %2461, i32 undef)  ; BufferLoad(srv,index,wot)
  %2463 = extractvalue %dx.types.ResRet.i32 %2462, 0
  %2464 = and i32 %2463, 1023
  %2465 = lshr i32 %2463, 10
  %2466 = and i32 %2465, 1023
  %2467 = lshr i32 %2463, 20
  %2468 = and i32 %2467, 1023
  %2469 = uitofp i32 %2464 to float
  %2470 = uitofp i32 %2466 to float
  %2471 = uitofp i32 %2468 to float
  %2472 = call float @dx.op.unary.f32(i32 22, float %2442)  ; Frc(value)
  %2473 = call float @dx.op.unary.f32(i32 22, float %2443)  ; Frc(value)
  %2474 = call float @dx.op.unary.f32(i32 22, float %2444)  ; Frc(value)
  %2475 = fadd fast float %2472, 5.000000e-01
  %2476 = fadd fast float %2475, %2469
  %2477 = fadd fast float %2473, 5.000000e-01
  %2478 = fadd fast float %2477, %2470
  %2479 = fadd fast float %2474, 5.000000e-01
  %2480 = fadd fast float %2479, %2471
  %2481 = fmul fast float %2480, %1170
  %2482 = fmul fast float %1168, 5.000000e-01
  %2483 = fmul fast float %2482, %2476
  %2484 = fmul fast float %1169, 5.000000e-01
  %2485 = fmul fast float %2484, %2478
  %2486 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2483, float %2485, float %2481, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2487 = extractvalue %dx.types.ResRet.f32 %2486, 0
  %2488 = extractvalue %dx.types.ResRet.f32 %2486, 1
  %2489 = extractvalue %dx.types.ResRet.f32 %2486, 2
  %2490 = extractvalue %dx.types.ResRet.f32 %2486, 3
  %2491 = fadd fast float %2483, 5.000000e-01
  %2492 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2491, float %2485, float %2481, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2493 = extractvalue %dx.types.ResRet.f32 %2492, 0
  %2494 = extractvalue %dx.types.ResRet.f32 %2492, 1
  %2495 = extractvalue %dx.types.ResRet.f32 %2492, 2
  %2496 = extractvalue %dx.types.ResRet.f32 %2492, 3
  %2497 = fadd fast float %2485, 5.000000e-01
  %2498 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2483, float %2497, float %2481, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2499 = extractvalue %dx.types.ResRet.f32 %2498, 0
  %2500 = extractvalue %dx.types.ResRet.f32 %2498, 1
  %2501 = extractvalue %dx.types.ResRet.f32 %2498, 2
  %2502 = extractvalue %dx.types.ResRet.f32 %2498, 3
  br label %2503

; <label>:2503                                    ; preds = %2436, %2247, %2215
  %2504 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2490, %2436 ]
  %2505 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2489, %2436 ]
  %2506 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2488, %2436 ]
  %2507 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2487, %2436 ]
  %2508 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2496, %2436 ]
  %2509 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2495, %2436 ]
  %2510 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2494, %2436 ]
  %2511 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2493, %2436 ]
  %2512 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2502, %2436 ]
  %2513 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2501, %2436 ]
  %2514 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2500, %2436 ]
  %2515 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ %2499, %2436 ]
  %2516 = phi float [ 0.000000e+00, %2247 ], [ 0.000000e+00, %2215 ], [ 1.000000e+00, %2436 ]
  %2517 = call float @dx.op.binary.f32(i32 36, float %1515, float %2210)  ; FMin(a,b)
  %2518 = fmul fast float %2517, %2507
  %2519 = fmul fast float %2517, %2511
  %2520 = fmul fast float %2517, %2515
  %2521 = fadd fast float %2518, %2201
  %2522 = fadd fast float %2519, %2205
  %2523 = fadd fast float %2520, %2209
  %2524 = fmul fast float %2517, %2506
  %2525 = fmul fast float %2517, %2510
  %2526 = fmul fast float %2517, %2514
  %2527 = fadd fast float %2524, %2200
  %2528 = fadd fast float %2525, %2204
  %2529 = fadd fast float %2526, %2208
  %2530 = fmul fast float %2517, %2505
  %2531 = fmul fast float %2517, %2509
  %2532 = fmul fast float %2517, %2513
  %2533 = fadd fast float %2530, %2199
  %2534 = fadd fast float %2531, %2203
  %2535 = fadd fast float %2532, %2207
  %2536 = fmul fast float %2517, %2504
  %2537 = fmul fast float %2517, %2508
  %2538 = fmul fast float %2517, %2512
  %2539 = fadd fast float %2536, %2198
  %2540 = fadd fast float %2537, %2202
  %2541 = fadd fast float %2538, %2206
  %2542 = fmul fast float %2517, %2516
  %2543 = fadd fast float %2542, %2211
  br label %2544

; <label>:2544                                    ; preds = %2503, %2197, %1465
  %2545 = phi float [ %1466, %1465 ], [ %2539, %2503 ], [ %2198, %2197 ]
  %2546 = phi float [ %1467, %1465 ], [ %2533, %2503 ], [ %2199, %2197 ]
  %2547 = phi float [ %1468, %1465 ], [ %2527, %2503 ], [ %2200, %2197 ]
  %2548 = phi float [ %1469, %1465 ], [ %2521, %2503 ], [ %2201, %2197 ]
  %2549 = phi float [ %1470, %1465 ], [ %2540, %2503 ], [ %2202, %2197 ]
  %2550 = phi float [ %1471, %1465 ], [ %2534, %2503 ], [ %2203, %2197 ]
  %2551 = phi float [ %1472, %1465 ], [ %2528, %2503 ], [ %2204, %2197 ]
  %2552 = phi float [ %1473, %1465 ], [ %2522, %2503 ], [ %2205, %2197 ]
  %2553 = phi float [ %1474, %1465 ], [ %2541, %2503 ], [ %2206, %2197 ]
  %2554 = phi float [ %1475, %1465 ], [ %2535, %2503 ], [ %2207, %2197 ]
  %2555 = phi float [ %1476, %1465 ], [ %2529, %2503 ], [ %2208, %2197 ]
  %2556 = phi float [ %1477, %1465 ], [ %2523, %2503 ], [ %2209, %2197 ]
  %2557 = phi float [ %1478, %1465 ], [ %2543, %2503 ], [ %2211, %2197 ]
  %2558 = fmul fast float %2548, %1133
  %2559 = fmul fast float %2552, %1133
  %2560 = fmul fast float %2556, %1133
  %2561 = fadd fast float %2558, %1122
  %2562 = fadd fast float %2559, %1126
  %2563 = fadd fast float %2560, %1130
  %2564 = fmul fast float %2547, %1133
  %2565 = fmul fast float %2551, %1133
  %2566 = fmul fast float %2555, %1133
  %2567 = fadd fast float %2564, %1121
  %2568 = fadd fast float %2565, %1125
  %2569 = fadd fast float %2566, %1129
  %2570 = fmul fast float %2546, %1133
  %2571 = fmul fast float %2550, %1133
  %2572 = fmul fast float %2554, %1133
  %2573 = fadd fast float %2570, %1120
  %2574 = fadd fast float %2571, %1124
  %2575 = fadd fast float %2572, %1128
  %2576 = fmul fast float %2545, %1133
  %2577 = fmul fast float %2549, %1133
  %2578 = fmul fast float %2553, %1133
  %2579 = fadd fast float %2576, %1119
  %2580 = fadd fast float %2577, %1123
  %2581 = fadd fast float %2578, %1127
  %2582 = fmul fast float %2557, %1133
  %2583 = fsub fast float %1132, %2582
  %2584 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2583)  ; FMax(a,b)
  %2585 = fcmp fast ogt float %2584, 0.000000e+00
  br i1 %2585, label %2586, label %2627, !dx.controlflow.hints !117

; <label>:2586                                    ; preds = %2544
  %2587 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %10, i32 0, i32 0)  ; BufferLoad(srv,index,wot)
  %2588 = extractvalue %dx.types.ResRet.f32 %2587, 0
  %2589 = extractvalue %dx.types.ResRet.f32 %2587, 1
  %2590 = extractvalue %dx.types.ResRet.f32 %2587, 2
  %2591 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %10, i32 0, i32 16)  ; BufferLoad(srv,index,wot)
  %2592 = extractvalue %dx.types.ResRet.f32 %2591, 0
  %2593 = extractvalue %dx.types.ResRet.f32 %2591, 1
  %2594 = extractvalue %dx.types.ResRet.f32 %2591, 2
  %2595 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %10, i32 0, i32 32)  ; BufferLoad(srv,index,wot)
  %2596 = extractvalue %dx.types.ResRet.f32 %2595, 0
  %2597 = extractvalue %dx.types.ResRet.f32 %2595, 1
  %2598 = extractvalue %dx.types.ResRet.f32 %2595, 2
  %2599 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %10, i32 0, i32 48)  ; BufferLoad(srv,index,wot)
  %2600 = extractvalue %dx.types.ResRet.f32 %2599, 0
  %2601 = extractvalue %dx.types.ResRet.f32 %2599, 1
  %2602 = extractvalue %dx.types.ResRet.f32 %2599, 2
  %2603 = fmul fast float %2588, %2584
  %2604 = fmul fast float %2589, %2584
  %2605 = fmul fast float %2590, %2584
  %2606 = fadd fast float %2603, %2561
  %2607 = fadd fast float %2604, %2562
  %2608 = fadd fast float %2605, %2563
  %2609 = fmul fast float %2592, %2584
  %2610 = fmul fast float %2593, %2584
  %2611 = fmul fast float %2594, %2584
  %2612 = fadd fast float %2609, %2567
  %2613 = fadd fast float %2610, %2568
  %2614 = fadd fast float %2611, %2569
  %2615 = fmul fast float %2596, %2584
  %2616 = fmul fast float %2597, %2584
  %2617 = fmul fast float %2598, %2584
  %2618 = fadd fast float %2615, %2573
  %2619 = fadd fast float %2616, %2574
  %2620 = fadd fast float %2617, %2575
  %2621 = fmul fast float %2600, %2584
  %2622 = fmul fast float %2601, %2584
  %2623 = fmul fast float %2602, %2584
  %2624 = fadd fast float %2621, %2579
  %2625 = fadd fast float %2622, %2580
  %2626 = fadd fast float %2623, %2581
  br label %2627

; <label>:2627                                    ; preds = %2586, %2544, %1118
  %2628 = phi float [ %2624, %2586 ], [ %1119, %1118 ], [ %2579, %2544 ]
  %2629 = phi float [ %2618, %2586 ], [ %1120, %1118 ], [ %2573, %2544 ]
  %2630 = phi float [ %2612, %2586 ], [ %1121, %1118 ], [ %2567, %2544 ]
  %2631 = phi float [ %2606, %2586 ], [ %1122, %1118 ], [ %2561, %2544 ]
  %2632 = phi float [ %2625, %2586 ], [ %1123, %1118 ], [ %2580, %2544 ]
  %2633 = phi float [ %2619, %2586 ], [ %1124, %1118 ], [ %2574, %2544 ]
  %2634 = phi float [ %2613, %2586 ], [ %1125, %1118 ], [ %2568, %2544 ]
  %2635 = phi float [ %2607, %2586 ], [ %1126, %1118 ], [ %2562, %2544 ]
  %2636 = phi float [ %2626, %2586 ], [ %1127, %1118 ], [ %2581, %2544 ]
  %2637 = phi float [ %2620, %2586 ], [ %1128, %1118 ], [ %2575, %2544 ]
  %2638 = phi float [ %2614, %2586 ], [ %1129, %1118 ], [ %2569, %2544 ]
  %2639 = phi float [ %2608, %2586 ], [ %1130, %1118 ], [ %2563, %2544 ]
  %2640 = call float @dx.op.dot3.f32(i32 55, float %758, float %759, float %760, float %758, float %759, float %760)  ; Dot3(ax,ay,az,bx,by,bz)
  %2641 = call float @dx.op.unary.f32(i32 25, float %2640)  ; Rsqrt(value)
  %2642 = fmul fast float %2641, %758
  %2643 = fmul fast float %2641, %759
  %2644 = fmul fast float %2641, %760
  %2645 = call float @dx.op.dot3.f32(i32 55, float %272, float %273, float %274, float %758, float %759, float %760)  ; Dot3(ax,ay,az,bx,by,bz)
  %2646 = fmul fast float %2645, 2.000000e+00
  %2647 = fmul fast float %2646, %758
  %2648 = fmul fast float %2646, %759
  %2649 = fmul fast float %2646, %760
  %2650 = fsub fast float %272, %2647
  %2651 = fsub fast float %274, %2649
  %2652 = fmul fast float %78, 0x3F847AE140000000
  %2653 = call float @dx.op.unary.f32(i32 7, float %2652)  ; Saturate(value)
  %2654 = fmul fast float %2653, 6.000000e+00
  %2655 = fadd fast float %2654, -1.500000e+01
  %2656 = fmul fast float %2655, %2653
  %2657 = fadd fast float %2656, 1.000000e+01
  %2658 = fmul fast float %2653, %2653
  %2659 = fmul fast float %2658, 0x3FC99999A0000000
  %2660 = fmul fast float %2659, %2653
  %2661 = fmul fast float %2660, %2657
  %2662 = fadd fast float %273, 0xBFB99999A0000000
  %2663 = fsub fast float %2662, %2648
  %2664 = fadd fast float %2663, %2661
  %2665 = fadd fast float %77, -3.000000e+02
  %2666 = fadd fast float %78, -1.950000e+02
  %2667 = fadd fast float %79, -1.440000e+03
  %2668 = fmul fast float %2665, 0x3F40624DE0000000
  %2669 = fmul fast float %2667, 0x3F40624DE0000000
  %2670 = fsub fast float %2668, %2650
  %2671 = fsub fast float %2669, %2651
  %2672 = fmul fast float %2670, 0x3FE8799660000000
  %2673 = call float @dx.op.tertiary.f32(i32 46, float %2671, float 0x3FE49D6E60000000, float %2672)  ; FMad(a,b,c)
  %2674 = fmul fast float %2670, 0xBFE49D6E60000000
  %2675 = call float @dx.op.tertiary.f32(i32 46, float %2671, float 0x3FE8799660000000, float %2674)  ; FMad(a,b,c)
  %2676 = fdiv fast float %2675, %2673
  %2677 = call float @dx.op.unary.f32(i32 17, float %2676)  ; Atan(value)
  %2678 = fadd fast float %2677, 0x400921FB60000000
  %2679 = fadd fast float %2677, 0xC00921FB60000000
  %2680 = fcmp fast olt float %2673, 0.000000e+00
  %2681 = fcmp fast oeq float %2673, 0.000000e+00
  %2682 = fcmp fast oge float %2675, 0.000000e+00
  %2683 = fcmp fast olt float %2675, 0.000000e+00
  %2684 = and i1 %2680, %2682
  %2685 = select i1 %2684, float %2678, float %2677
  %2686 = and i1 %2680, %2683
  %2687 = select i1 %2686, float %2679, float %2685
  %2688 = and i1 %2681, %2683
  %2689 = and i1 %2681, %2682
  %2690 = fadd fast float %2687, 0x3FF921FB60000000
  %2691 = fmul fast float %2690, 0x3FC45F3060000000
  %2692 = select i1 %2688, float 0.000000e+00, float %2691
  %2693 = select i1 %2689, float 5.000000e-01, float %2692
  %2694 = call float @dx.op.unary.f32(i32 15, float %2664)  ; Acos(value)
  %2695 = fmul fast float %2694, 0x3FD45F3060000000
  %2696 = call float @dx.op.unary.f32(i32 83, float %2693)  ; DerivCoarseX(value)
  %2697 = call float @dx.op.unary.f32(i32 6, float %2696)  ; FAbs(value)
  %2698 = call float @dx.op.unary.f32(i32 84, float %2693)  ; DerivCoarseY(value)
  %2699 = call float @dx.op.unary.f32(i32 6, float %2698)  ; FAbs(value)
  %2700 = fadd fast float %2699, %2697
  %2701 = fcmp fast ogt float %2700, 0x3FB99999A0000000
  br i1 %2701, label %2702, label %2704

; <label>:2702                                    ; preds = %2627
  %2703 = call float @dx.op.unary.f32(i32 22, float %2693)  ; Frc(value)
  br label %2704

; <label>:2704                                    ; preds = %2702, %2627
  %2705 = phi float [ %2703, %2702 ], [ %2693, %2627 ]
  %2706 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %5, %dx.types.Handle %42, float %2705, float %2695, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %2707 = extractvalue %dx.types.ResRet.f32 %2706, 0
  %2708 = extractvalue %dx.types.ResRet.f32 %2706, 1
  %2709 = extractvalue %dx.types.ResRet.f32 %2706, 2
  %2710 = fmul fast float %565, %565
  %2711 = fmul fast float %566, %566
  %2712 = fadd fast float %2710, %2711
  %2713 = fmul fast float %567, %567
  %2714 = fadd fast float %2712, %2713
  %2715 = call float @dx.op.unary.f32(i32 24, float %2714)  ; Sqrt(value)
  %2716 = fadd fast float %2715, -2.200000e+03
  %2717 = fmul fast float %2716, 0xBF647AE140000000
  %2718 = call float @dx.op.unary.f32(i32 7, float %2717)  ; Saturate(value)
  %2719 = fmul fast float %2665, %2665
  %2720 = fmul fast float %2666, %2666
  %2721 = fadd fast float %2719, %2720
  %2722 = fmul fast float %2667, %2667
  %2723 = fadd fast float %2721, %2722
  %2724 = call float @dx.op.unary.f32(i32 24, float %2723)  ; Sqrt(value)
  %2725 = fadd fast float %2724, -8.000000e+02
  %2726 = fmul fast float %2725, 0xBF6B4E81C0000000
  %2727 = call float @dx.op.unary.f32(i32 7, float %2726)  ; Saturate(value)
  %2728 = fmul fast float %759, 2.500000e-01
  %2729 = fmul fast float %2728, %2718
  %2730 = fmul fast float %2729, %2727
  %2731 = fadd fast float %2707, 0xBFD99999A0000000
  %2732 = fmul fast float %2731, 0x3FFAAAAAA0000000
  %2733 = call float @dx.op.unary.f32(i32 7, float %2732)  ; Saturate(value)
  %2734 = fmul fast float %2733, %2733
  %2735 = fmul fast float %2734, %2733
  %2736 = fmul fast float %2733, 6.000000e+00
  %2737 = fadd fast float %2736, -1.500000e+01
  %2738 = fmul fast float %2737, %2733
  %2739 = fadd fast float %2738, 1.000000e+01
  %2740 = fmul fast float %2735, %2739
  %2741 = fmul fast float %2740, 0x3FC331E1E0000000
  %2742 = fmul fast float %2740, 0x3FC0A84FE0000000
  %2743 = fmul fast float %2740, 0x3FB2806880000000
  %2744 = fadd fast float %2741, %2707
  %2745 = fmul fast float %2744, %2730
  %2746 = fadd fast float %805, %798
  %2747 = fadd fast float %2746, %2745
  %2748 = fadd fast float %2742, %2708
  %2749 = fmul fast float %2748, %2730
  %2750 = fadd fast float %806, %799
  %2751 = fadd fast float %2750, %2749
  %2752 = fadd fast float %2743, %2709
  %2753 = fmul fast float %2752, %2730
  %2754 = fadd fast float %807, %800
  %2755 = fadd fast float %2754, %2753
  %2756 = call float @dx.op.unary.f32(i32 7, float %2747)  ; Saturate(value)
  %2757 = call float @dx.op.unary.f32(i32 7, float %2751)  ; Saturate(value)
  %2758 = call float @dx.op.unary.f32(i32 7, float %2755)  ; Saturate(value)
  %2759 = fmul fast float %2630, 5.000000e-01
  %2760 = fmul fast float %2629, 5.000000e-01
  %2761 = fmul fast float %2628, 5.000000e-01
  %2762 = fmul fast float %2759, %2759
  %2763 = fmul fast float %2760, %2760
  %2764 = fmul fast float %2761, %2761
  %2765 = fadd fast float %2763, %2764
  %2766 = fadd fast float %2765, %2762
  %2767 = call float @dx.op.unary.f32(i32 24, float %2766)  ; Sqrt(value)
  %2768 = fcmp fast olt float %2631, 0x3E7AD7F2A0000000
  %2769 = fcmp fast olt float %2767, 0x3E7AD7F2A0000000
  %2770 = or i1 %2768, %2769
  br i1 %2770, label %2771, label %2773

; <label>:2771                                    ; preds = %2704
  %2772 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2631)  ; FMax(a,b)
  br label %2796

; <label>:2773                                    ; preds = %2704
  %2774 = fdiv fast float %2767, %2631
  %2775 = fdiv fast float %2759, %2767
  %2776 = fdiv fast float %2760, %2767
  %2777 = fdiv fast float %2761, %2767
  %2778 = call float @dx.op.dot3.f32(i32 55, float %2775, float %2776, float %2777, float %2642, float %2643, float %2644)  ; Dot3(ax,ay,az,bx,by,bz)
  %2779 = fadd fast float %2778, 1.000000e+00
  %2780 = fmul fast float %2779, 5.000000e-01
  %2781 = fmul fast float %2774, 2.000000e+00
  %2782 = fadd fast float %2781, 1.000000e+00
  %2783 = fsub fast float 1.000000e+00, %2774
  %2784 = fadd fast float %2774, 1.000000e+00
  %2785 = fdiv fast float %2783, %2784
  %2786 = fsub fast float 1.000000e+00, %2785
  %2787 = fadd fast float %2781, 2.000000e+00
  %2788 = fmul fast float %2786, %2787
  %2789 = call float @dx.op.unary.f32(i32 6, float %2780)  ; FAbs(value)
  %2790 = call float @dx.op.unary.f32(i32 23, float %2789)  ; Log(value)
  %2791 = fmul fast float %2790, %2782
  %2792 = call float @dx.op.unary.f32(i32 21, float %2791)  ; Exp(value)
  %2793 = fmul fast float %2788, %2792
  %2794 = fadd fast float %2793, %2785
  %2795 = fmul fast float %2794, %2631
  br label %2796

; <label>:2796                                    ; preds = %2773, %2771
  %2797 = phi float [ %2772, %2771 ], [ %2795, %2773 ]
  %2798 = fmul fast float %2634, 5.000000e-01
  %2799 = fmul fast float %2633, 5.000000e-01
  %2800 = fmul fast float %2632, 5.000000e-01
  %2801 = fmul fast float %2798, %2798
  %2802 = fmul fast float %2799, %2799
  %2803 = fmul fast float %2800, %2800
  %2804 = fadd fast float %2802, %2803
  %2805 = fadd fast float %2804, %2801
  %2806 = call float @dx.op.unary.f32(i32 24, float %2805)  ; Sqrt(value)
  %2807 = fcmp fast olt float %2635, 0x3E7AD7F2A0000000
  %2808 = fcmp fast olt float %2806, 0x3E7AD7F2A0000000
  %2809 = or i1 %2807, %2808
  br i1 %2809, label %2810, label %2812

; <label>:2810                                    ; preds = %2796
  %2811 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2635)  ; FMax(a,b)
  br label %2835

; <label>:2812                                    ; preds = %2796
  %2813 = fdiv fast float %2806, %2635
  %2814 = fdiv fast float %2798, %2806
  %2815 = fdiv fast float %2799, %2806
  %2816 = fdiv fast float %2800, %2806
  %2817 = call float @dx.op.dot3.f32(i32 55, float %2814, float %2815, float %2816, float %2642, float %2643, float %2644)  ; Dot3(ax,ay,az,bx,by,bz)
  %2818 = fadd fast float %2817, 1.000000e+00
  %2819 = fmul fast float %2818, 5.000000e-01
  %2820 = fmul fast float %2813, 2.000000e+00
  %2821 = fadd fast float %2820, 1.000000e+00
  %2822 = fsub fast float 1.000000e+00, %2813
  %2823 = fadd fast float %2813, 1.000000e+00
  %2824 = fdiv fast float %2822, %2823
  %2825 = fsub fast float 1.000000e+00, %2824
  %2826 = fadd fast float %2820, 2.000000e+00
  %2827 = fmul fast float %2825, %2826
  %2828 = call float @dx.op.unary.f32(i32 6, float %2819)  ; FAbs(value)
  %2829 = call float @dx.op.unary.f32(i32 23, float %2828)  ; Log(value)
  %2830 = fmul fast float %2829, %2821
  %2831 = call float @dx.op.unary.f32(i32 21, float %2830)  ; Exp(value)
  %2832 = fmul fast float %2827, %2831
  %2833 = fadd fast float %2832, %2824
  %2834 = fmul fast float %2833, %2635
  br label %2835

; <label>:2835                                    ; preds = %2812, %2810
  %2836 = phi float [ %2811, %2810 ], [ %2834, %2812 ]
  %2837 = fmul fast float %2638, 5.000000e-01
  %2838 = fmul fast float %2637, 5.000000e-01
  %2839 = fmul fast float %2636, 5.000000e-01
  %2840 = fmul fast float %2837, %2837
  %2841 = fmul fast float %2838, %2838
  %2842 = fmul fast float %2839, %2839
  %2843 = fadd fast float %2841, %2842
  %2844 = fadd fast float %2843, %2840
  %2845 = call float @dx.op.unary.f32(i32 24, float %2844)  ; Sqrt(value)
  %2846 = fcmp fast olt float %2639, 0x3E7AD7F2A0000000
  %2847 = fcmp fast olt float %2845, 0x3E7AD7F2A0000000
  %2848 = or i1 %2846, %2847
  br i1 %2848, label %2849, label %2851

; <label>:2849                                    ; preds = %2835
  %2850 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2639)  ; FMax(a,b)
  br label %2874

; <label>:2851                                    ; preds = %2835
  %2852 = fdiv fast float %2845, %2639
  %2853 = fdiv fast float %2837, %2845
  %2854 = fdiv fast float %2838, %2845
  %2855 = fdiv fast float %2839, %2845
  %2856 = call float @dx.op.dot3.f32(i32 55, float %2853, float %2854, float %2855, float %2642, float %2643, float %2644)  ; Dot3(ax,ay,az,bx,by,bz)
  %2857 = fadd fast float %2856, 1.000000e+00
  %2858 = fmul fast float %2857, 5.000000e-01
  %2859 = fmul fast float %2852, 2.000000e+00
  %2860 = fadd fast float %2859, 1.000000e+00
  %2861 = fsub fast float 1.000000e+00, %2852
  %2862 = fadd fast float %2852, 1.000000e+00
  %2863 = fdiv fast float %2861, %2862
  %2864 = fsub fast float 1.000000e+00, %2863
  %2865 = fadd fast float %2859, 2.000000e+00
  %2866 = fmul fast float %2864, %2865
  %2867 = call float @dx.op.unary.f32(i32 6, float %2858)  ; FAbs(value)
  %2868 = call float @dx.op.unary.f32(i32 23, float %2867)  ; Log(value)
  %2869 = fmul fast float %2868, %2860
  %2870 = call float @dx.op.unary.f32(i32 21, float %2869)  ; Exp(value)
  %2871 = fmul fast float %2866, %2870
  %2872 = fadd fast float %2871, %2863
  %2873 = fmul fast float %2872, %2639
  br label %2874

; <label>:2874                                    ; preds = %2851, %2849
  %2875 = phi float [ %2850, %2849 ], [ %2873, %2851 ]
  %r8Native2876 = call float @dx.op.unary.f32(i32 7, float %763)  ; Saturate(value)
  %dirtRoughGap = fsub float 0x3FE6666660000000, %setting_roughness
  %dirtRoughDelta = fmul float %dirtAmount, %dirtRoughGap
  %dirtRoughness = fadd float %setting_roughness, %dirtRoughDelta
  %dirtSmoothness = fsub float 1.000000e+00, %dirtRoughness
  %r8Glass2876 = fadd float %dirtSmoothness, 0.000000e+00
  %2876 = select i1 %r8Marked, float %r8Glass2876, float %r8Native2876
  %2877 = call float @dx.op.dot3.f32(i32 55, float %2642, float %2643, float %2644, float %2642, float %2643, float %2644)  ; Dot3(ax,ay,az,bx,by,bz)
  %2878 = call float @dx.op.unary.f32(i32 25, float %2877)  ; Rsqrt(value)
  %r8Native2879 = fmul fast float %2878, %2642
  %r8Glass2879 = fadd float %glass_r5_nx, 0.000000e+00
  %2879 = select i1 %r8Marked, float %r8Glass2879, float %r8Native2879
  %r8Native2880 = fmul fast float %2878, %2643
  %r8Glass2880 = fadd float %glass_r5_ny, 0.000000e+00
  %2880 = select i1 %r8Marked, float %r8Glass2880, float %r8Native2880
  %r8Native2881 = fmul fast float %2878, %2644
  %r8Glass2881 = fadd float %glass_r5_nz, 0.000000e+00
  %2881 = select i1 %r8Marked, float %r8Glass2881, float %r8Native2881
  %2882 = fsub fast float 1.000000e+00, %2876
  %2883 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 30)  ; CBufferLoadLegacy(handle,regIndex)
  %2884 = extractvalue %dx.types.CBufRet.i32 %2883, 3
  %2885 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 22)  ; CBufferLoadLegacy(handle,regIndex)
  %2886 = extractvalue %dx.types.CBufRet.i32 %2885, 0
  %2887 = icmp eq i32 %2886, 0
  br i1 %2887, label %2937, label %2888

; <label>:2888                                    ; preds = %2874
  %2889 = extractvalue %dx.types.CBufRet.i32 %2885, 1
  %2890 = icmp ult i32 %2889, %2886
  br i1 %2890, label %2891, label %2937

; <label>:2891                                    ; preds = %2888
  br label %2892

; <label>:2892                                    ; preds = %2931, %2891
  %2893 = phi i32 [ %2932, %2931 ], [ %2889, %2891 ]
  %2894 = shl i32 %2893, 2
  %2895 = add i32 %2894, 5
  %2896 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %2895)  ; CBufferLoadLegacy(handle,regIndex)
  %2897 = extractvalue %dx.types.CBufRet.f32 %2896, 0
  %2898 = extractvalue %dx.types.CBufRet.f32 %2896, 1
  %2899 = extractvalue %dx.types.CBufRet.f32 %2896, 2
  %2900 = extractvalue %dx.types.CBufRet.f32 %2896, 3
  %2901 = add i32 %2894, 6
  %2902 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %2901)  ; CBufferLoadLegacy(handle,regIndex)
  %2903 = extractvalue %dx.types.CBufRet.f32 %2902, 0
  %2904 = extractvalue %dx.types.CBufRet.f32 %2902, 1
  %2905 = extractvalue %dx.types.CBufRet.f32 %2902, 2
  %2906 = extractvalue %dx.types.CBufRet.f32 %2902, 3
  %2907 = add i32 %2894, 7
  %2908 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %2907)  ; CBufferLoadLegacy(handle,regIndex)
  %2909 = extractvalue %dx.types.CBufRet.f32 %2908, 0
  %2910 = extractvalue %dx.types.CBufRet.f32 %2908, 1
  %2911 = extractvalue %dx.types.CBufRet.f32 %2908, 2
  %2912 = extractvalue %dx.types.CBufRet.f32 %2908, 3
  %2913 = fmul fast float %2897, %565
  %2914 = call float @dx.op.tertiary.f32(i32 46, float %566, float %2898, float %2913)  ; FMad(a,b,c)
  %2915 = call float @dx.op.tertiary.f32(i32 46, float %567, float %2899, float %2914)  ; FMad(a,b,c)
  %2916 = fadd fast float %2915, %2900
  %2917 = fmul fast float %2903, %565
  %2918 = call float @dx.op.tertiary.f32(i32 46, float %566, float %2904, float %2917)  ; FMad(a,b,c)
  %2919 = call float @dx.op.tertiary.f32(i32 46, float %567, float %2905, float %2918)  ; FMad(a,b,c)
  %2920 = fadd fast float %2919, %2906
  %2921 = fmul fast float %2909, %565
  %2922 = call float @dx.op.tertiary.f32(i32 46, float %566, float %2910, float %2921)  ; FMad(a,b,c)
  %2923 = call float @dx.op.tertiary.f32(i32 46, float %567, float %2911, float %2922)  ; FMad(a,b,c)
  %2924 = fadd fast float %2923, %2912
  %2925 = call float @dx.op.binary.f32(i32 36, float %2916, float %2920)  ; FMin(a,b)
  %2926 = call float @dx.op.binary.f32(i32 36, float %2925, float %2924)  ; FMin(a,b)
  %2927 = call float @dx.op.binary.f32(i32 35, float %2916, float %2920)  ; FMax(a,b)
  %2928 = fsub fast float 1.000000e+00, %2927
  %2929 = call float @dx.op.binary.f32(i32 36, float %2926, float %2928)  ; FMin(a,b)
  %2930 = fcmp fast ogt float %2929, 0x3EF0001000000000
  br i1 %2930, label %2934, label %2931

; <label>:2931                                    ; preds = %2892
  %2932 = add nuw i32 %2893, 1
  %2933 = icmp ult i32 %2932, %2886
  br i1 %2933, label %2892, label %2934

; <label>:2934                                    ; preds = %2931, %2892
  %2935 = phi i1 [ false, %2931 ], [ true, %2892 ]
  %2936 = phi i32 [ %2932, %2931 ], [ %2893, %2892 ]
  br label %2937

; <label>:2937                                    ; preds = %2934, %2888, %2874
  %2938 = phi i1 [ false, %2874 ], [ false, %2888 ], [ %2935, %2934 ]
  %2939 = phi i32 [ 0, %2874 ], [ %2889, %2888 ], [ %2936, %2934 ]
  %2940 = phi float [ 0.000000e+00, %2874 ], [ 0.000000e+00, %2888 ], [ %2916, %2934 ]
  %2941 = phi float [ 0.000000e+00, %2874 ], [ 0.000000e+00, %2888 ], [ %2920, %2934 ]
  %2942 = phi float [ 0.000000e+00, %2874 ], [ 0.000000e+00, %2888 ], [ %2924, %2934 ]
  br i1 %2938, label %2943, label %3064

; <label>:2943                                    ; preds = %2937
  %2944 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 23)  ; CBufferLoadLegacy(handle,regIndex)
  %2945 = extractvalue %dx.types.CBufRet.i32 %2944, 1
  %2946 = extractvalue %dx.types.CBufRet.i32 %2944, 3
  %2947 = uitofp i32 %2939 to float
  %2948 = add i32 %2945, -1
  %2949 = lshr i32 %2948, 1
  %2950 = fmul fast float %2940, %131
  %2951 = fmul fast float %2941, %131
  %2952 = fadd fast float %2950, -5.000000e-01
  %2953 = fadd fast float %2951, -5.000000e-01
  %2954 = call float @dx.op.unary.f32(i32 22, float %2952)  ; Frc(value)
  %2955 = call float @dx.op.unary.f32(i32 22, float %2953)  ; Frc(value)
  %2956 = fsub fast float 1.000000e+00, %2954
  %2957 = fsub fast float 1.000000e+00, %2955
  %2958 = fmul fast float %2957, %2956
  %2959 = fmul fast float %2957, %2954
  %2960 = fmul fast float %2956, %2955
  %2961 = fmul fast float %2955, %2954
  %2962 = call float @dx.op.unary.f32(i32 27, float %2952)  ; Round_ni(value)
  %2963 = fptosi float %2962 to i32
  %2964 = sub i32 %2963, %2949
  %2965 = sitofp i32 %2964 to float
  %2966 = fmul fast float %2965, %132
  %2967 = fadd fast float %2966, %132
  %2968 = fmul fast float %132, 2.000000e+00
  %2969 = icmp eq i32 %2945, 0
  br i1 %2969, label %3058, label %2970

; <label>:2970                                    ; preds = %2943
  %2971 = call float @dx.op.unary.f32(i32 27, float %2953)  ; Round_ni(value)
  %2972 = fptosi float %2971 to i32
  %2973 = sub i32 %2972, %2949
  %2974 = sitofp i32 %2973 to float
  %2975 = fmul fast float %2974, %132
  %2976 = fadd fast float %2975, %132
  %2977 = extractvalue %dx.types.CBufRet.i32 %2944, 2
  br label %2978

; <label>:2978                                    ; preds = %3051, %2970
  %2979 = phi float [ %3052, %3051 ], [ %2976, %2970 ]
  %2980 = phi float [ %3047, %3051 ], [ 0.000000e+00, %2970 ]
  %2981 = phi i32 [ %3054, %3051 ], [ %2977, %2970 ]
  %2982 = phi i32 [ %3055, %3051 ], [ 0, %2970 ]
  br label %2983

; <label>:2983                                    ; preds = %2983, %2978
  %2984 = phi float [ %3047, %2983 ], [ %2980, %2978 ]
  %2985 = phi float [ %3048, %2983 ], [ %2967, %2978 ]
  %2986 = phi i32 [ %3049, %2983 ], [ 0, %2978 ]
  %2987 = add i32 %2986, %2981
  %2988 = add i32 %2987, %2946
  %2989 = add i32 %2987, 35
  %2990 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %2989)  ; CBufferLoadLegacy(handle,regIndex)
  %2991 = extractvalue %dx.types.CBufRet.f32 %2990, 0
  %2992 = fmul fast float %2991, %2961
  %2993 = extractvalue %dx.types.CBufRet.f32 %2990, 1
  %2994 = fmul fast float %2993, %2960
  %2995 = fadd fast float %2994, %2992
  %2996 = extractvalue %dx.types.CBufRet.f32 %2990, 2
  %2997 = fmul fast float %2996, %2959
  %2998 = fadd fast float %2995, %2997
  %2999 = extractvalue %dx.types.CBufRet.f32 %2990, 3
  %3000 = fmul fast float %2999, %2958
  %3001 = fadd fast float %2998, %3000
  %3002 = add i32 %2987, 36
  %3003 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3002)  ; CBufferLoadLegacy(handle,regIndex)
  %3004 = extractvalue %dx.types.CBufRet.f32 %3003, 0
  %3005 = fmul fast float %3004, %2961
  %3006 = extractvalue %dx.types.CBufRet.f32 %3003, 1
  %3007 = fmul fast float %3006, %2960
  %3008 = fadd fast float %3007, %3005
  %3009 = extractvalue %dx.types.CBufRet.f32 %3003, 2
  %3010 = fmul fast float %3009, %2959
  %3011 = fadd fast float %3008, %3010
  %3012 = extractvalue %dx.types.CBufRet.f32 %3003, 3
  %3013 = fmul fast float %3012, %2958
  %3014 = fadd fast float %3011, %3013
  %3015 = add i32 %2988, 35
  %3016 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3015)  ; CBufferLoadLegacy(handle,regIndex)
  %3017 = extractvalue %dx.types.CBufRet.f32 %3016, 0
  %3018 = fmul fast float %3017, %2961
  %3019 = extractvalue %dx.types.CBufRet.f32 %3016, 1
  %3020 = fmul fast float %3019, %2960
  %3021 = fadd fast float %3020, %3018
  %3022 = extractvalue %dx.types.CBufRet.f32 %3016, 2
  %3023 = fmul fast float %3022, %2959
  %3024 = fadd fast float %3021, %3023
  %3025 = extractvalue %dx.types.CBufRet.f32 %3016, 3
  %3026 = fmul fast float %3025, %2958
  %3027 = fadd fast float %3024, %3026
  %3028 = add i32 %2988, 36
  %3029 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3028)  ; CBufferLoadLegacy(handle,regIndex)
  %3030 = extractvalue %dx.types.CBufRet.f32 %3029, 0
  %3031 = fmul fast float %3030, %2961
  %3032 = extractvalue %dx.types.CBufRet.f32 %3029, 1
  %3033 = fmul fast float %3032, %2960
  %3034 = fadd fast float %3033, %3031
  %3035 = extractvalue %dx.types.CBufRet.f32 %3029, 2
  %3036 = fmul fast float %3035, %2959
  %3037 = fadd fast float %3034, %3036
  %3038 = extractvalue %dx.types.CBufRet.f32 %3029, 3
  %3039 = fmul fast float %3038, %2958
  %3040 = fadd fast float %3037, %3039
  %3041 = call %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32 74, %dx.types.Handle %27, %dx.types.Handle %36, float %2985, float %2979, float %2947, float undef, i32 0, i32 0, i32 0, float %2942)  ; TextureGatherCmp(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,channel,compareValue)
  %3042 = extractvalue %dx.types.ResRet.f32 %3041, 0
  %3043 = extractvalue %dx.types.ResRet.f32 %3041, 1
  %3044 = extractvalue %dx.types.ResRet.f32 %3041, 2
  %3045 = extractvalue %dx.types.ResRet.f32 %3041, 3
  %3046 = call float @dx.op.dot4.f32(i32 56, float %3045, float %3044, float %3042, float %3043, float %3001, float %3014, float %3027, float %3040)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %3047 = fadd fast float %3046, %2984
  %3048 = fadd fast float %2985, %2968
  %3049 = add i32 %2986, 2
  %3050 = icmp ult i32 %3049, %2945
  br i1 %3050, label %2983, label %3051

; <label>:3051                                    ; preds = %2983
  %3052 = fadd fast float %2979, %2968
  %3053 = shl i32 %2946, 1
  %3054 = add i32 %2981, %3053
  %3055 = add i32 %2982, 2
  %3056 = icmp ult i32 %3055, %2945
  br i1 %3056, label %2978, label %3057

; <label>:3057                                    ; preds = %3051
  br label %3058

; <label>:3058                                    ; preds = %3057, %2943
  %3059 = phi float [ 0.000000e+00, %2943 ], [ %3047, %3057 ]
  %3060 = call float @dx.op.unary.f32(i32 7, float %3059)  ; Saturate(value)
  %3061 = extractvalue %dx.types.CBufRet.i32 %2944, 0
  %3062 = icmp uge i32 %2939, %3061
  %3063 = zext i1 %3062 to i32
  br label %3064

; <label>:3064                                    ; preds = %3058, %2937
  %3065 = phi float [ %3060, %3058 ], [ 1.000000e+00, %2937 ]
  %3066 = phi i32 [ %3063, %3058 ], [ 1, %2937 ]
  %3067 = icmp eq i32 %3066, 0
  br i1 %3067, label %3208, label %3068

; <label>:3068                                    ; preds = %3064
  %3069 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 24)  ; CBufferLoadLegacy(handle,regIndex)
  %3070 = extractvalue %dx.types.CBufRet.i32 %3069, 0
  %3071 = icmp eq i32 %3070, 0
  br i1 %3071, label %3208, label %3072

; <label>:3072                                    ; preds = %3068
  %3073 = extractvalue %dx.types.CBufRet.i32 %3069, 1
  %3074 = extractvalue %dx.types.CBufRet.i32 %3069, 3
  %3075 = fmul fast float %140, %565
  %3076 = call float @dx.op.tertiary.f32(i32 46, float %566, float %141, float %3075)  ; FMad(a,b,c)
  %3077 = call float @dx.op.tertiary.f32(i32 46, float %567, float %142, float %3076)  ; FMad(a,b,c)
  %3078 = fadd fast float %3077, %143
  %3079 = fmul fast float %145, %565
  %3080 = call float @dx.op.tertiary.f32(i32 46, float %566, float %146, float %3079)  ; FMad(a,b,c)
  %3081 = call float @dx.op.tertiary.f32(i32 46, float %567, float %147, float %3080)  ; FMad(a,b,c)
  %3082 = fadd fast float %3081, %148
  %3083 = fmul fast float %150, %565
  %3084 = call float @dx.op.tertiary.f32(i32 46, float %566, float %151, float %3083)  ; FMad(a,b,c)
  %3085 = call float @dx.op.tertiary.f32(i32 46, float %567, float %152, float %3084)  ; FMad(a,b,c)
  %3086 = fadd fast float %3085, %153
  %3087 = call float @dx.op.binary.f32(i32 36, float %3078, float %3082)  ; FMin(a,b)
  %3088 = call float @dx.op.binary.f32(i32 36, float %3087, float %3086)  ; FMin(a,b)
  %3089 = call float @dx.op.binary.f32(i32 35, float %3078, float %3082)  ; FMax(a,b)
  %3090 = fsub fast float 1.000000e+00, %3089
  %3091 = call float @dx.op.binary.f32(i32 36, float %3088, float %3090)  ; FMin(a,b)
  %3092 = fcmp fast ogt float %3091, 0.000000e+00
  br i1 %3092, label %3093, label %3208

; <label>:3093                                    ; preds = %3072
  %3094 = add i32 %3073, -1
  %3095 = lshr i32 %3094, 1
  %3096 = fmul fast float %3078, %137
  %3097 = fmul fast float %3082, %137
  %3098 = fadd fast float %3096, -5.000000e-01
  %3099 = fadd fast float %3097, -5.000000e-01
  %3100 = call float @dx.op.unary.f32(i32 22, float %3098)  ; Frc(value)
  %3101 = call float @dx.op.unary.f32(i32 22, float %3099)  ; Frc(value)
  %3102 = fsub fast float 1.000000e+00, %3100
  %3103 = fsub fast float 1.000000e+00, %3101
  %3104 = fmul fast float %3103, %3102
  %3105 = fmul fast float %3103, %3100
  %3106 = fmul fast float %3102, %3101
  %3107 = fmul fast float %3101, %3100
  %3108 = call float @dx.op.unary.f32(i32 27, float %3098)  ; Round_ni(value)
  %3109 = fptosi float %3108 to i32
  %3110 = sub i32 %3109, %3095
  %3111 = sitofp i32 %3110 to float
  %3112 = fmul fast float %3111, %138
  %3113 = fadd fast float %3112, %138
  %3114 = fmul fast float %138, 2.000000e+00
  %3115 = icmp eq i32 %3073, 0
  br i1 %3115, label %3204, label %3116

; <label>:3116                                    ; preds = %3093
  %3117 = call float @dx.op.unary.f32(i32 27, float %3099)  ; Round_ni(value)
  %3118 = fptosi float %3117 to i32
  %3119 = sub i32 %3118, %3095
  %3120 = sitofp i32 %3119 to float
  %3121 = fmul fast float %3120, %138
  %3122 = fadd fast float %3121, %138
  %3123 = extractvalue %dx.types.CBufRet.i32 %3069, 2
  br label %3124

; <label>:3124                                    ; preds = %3197, %3116
  %3125 = phi float [ %3198, %3197 ], [ %3122, %3116 ]
  %3126 = phi float [ %3193, %3197 ], [ 0.000000e+00, %3116 ]
  %3127 = phi i32 [ %3200, %3197 ], [ %3123, %3116 ]
  %3128 = phi i32 [ %3201, %3197 ], [ 0, %3116 ]
  br label %3129

; <label>:3129                                    ; preds = %3129, %3124
  %3130 = phi float [ %3193, %3129 ], [ %3126, %3124 ]
  %3131 = phi float [ %3194, %3129 ], [ %3113, %3124 ]
  %3132 = phi i32 [ %3195, %3129 ], [ 0, %3124 ]
  %3133 = add i32 %3132, %3127
  %3134 = add i32 %3133, %3074
  %3135 = add i32 %3133, 35
  %3136 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3135)  ; CBufferLoadLegacy(handle,regIndex)
  %3137 = extractvalue %dx.types.CBufRet.f32 %3136, 0
  %3138 = fmul fast float %3137, %3107
  %3139 = extractvalue %dx.types.CBufRet.f32 %3136, 1
  %3140 = fmul fast float %3139, %3106
  %3141 = fadd fast float %3140, %3138
  %3142 = extractvalue %dx.types.CBufRet.f32 %3136, 2
  %3143 = fmul fast float %3142, %3105
  %3144 = fadd fast float %3141, %3143
  %3145 = extractvalue %dx.types.CBufRet.f32 %3136, 3
  %3146 = fmul fast float %3145, %3104
  %3147 = fadd fast float %3144, %3146
  %3148 = add i32 %3133, 36
  %3149 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3148)  ; CBufferLoadLegacy(handle,regIndex)
  %3150 = extractvalue %dx.types.CBufRet.f32 %3149, 0
  %3151 = fmul fast float %3150, %3107
  %3152 = extractvalue %dx.types.CBufRet.f32 %3149, 1
  %3153 = fmul fast float %3152, %3106
  %3154 = fadd fast float %3153, %3151
  %3155 = extractvalue %dx.types.CBufRet.f32 %3149, 2
  %3156 = fmul fast float %3155, %3105
  %3157 = fadd fast float %3154, %3156
  %3158 = extractvalue %dx.types.CBufRet.f32 %3149, 3
  %3159 = fmul fast float %3158, %3104
  %3160 = fadd fast float %3157, %3159
  %3161 = add i32 %3134, 35
  %3162 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3161)  ; CBufferLoadLegacy(handle,regIndex)
  %3163 = extractvalue %dx.types.CBufRet.f32 %3162, 0
  %3164 = fmul fast float %3163, %3107
  %3165 = extractvalue %dx.types.CBufRet.f32 %3162, 1
  %3166 = fmul fast float %3165, %3106
  %3167 = fadd fast float %3166, %3164
  %3168 = extractvalue %dx.types.CBufRet.f32 %3162, 2
  %3169 = fmul fast float %3168, %3105
  %3170 = fadd fast float %3167, %3169
  %3171 = extractvalue %dx.types.CBufRet.f32 %3162, 3
  %3172 = fmul fast float %3171, %3104
  %3173 = fadd fast float %3170, %3172
  %3174 = add i32 %3134, 36
  %3175 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3174)  ; CBufferLoadLegacy(handle,regIndex)
  %3176 = extractvalue %dx.types.CBufRet.f32 %3175, 0
  %3177 = fmul fast float %3176, %3107
  %3178 = extractvalue %dx.types.CBufRet.f32 %3175, 1
  %3179 = fmul fast float %3178, %3106
  %3180 = fadd fast float %3179, %3177
  %3181 = extractvalue %dx.types.CBufRet.f32 %3175, 2
  %3182 = fmul fast float %3181, %3105
  %3183 = fadd fast float %3180, %3182
  %3184 = extractvalue %dx.types.CBufRet.f32 %3175, 3
  %3185 = fmul fast float %3184, %3104
  %3186 = fadd fast float %3183, %3185
  %3187 = call %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32 74, %dx.types.Handle %35, %dx.types.Handle %36, float %3131, float %3125, float undef, float undef, i32 0, i32 0, i32 0, float %3086)  ; TextureGatherCmp(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,channel,compareValue)
  %3188 = extractvalue %dx.types.ResRet.f32 %3187, 0
  %3189 = extractvalue %dx.types.ResRet.f32 %3187, 1
  %3190 = extractvalue %dx.types.ResRet.f32 %3187, 2
  %3191 = extractvalue %dx.types.ResRet.f32 %3187, 3
  %3192 = call float @dx.op.dot4.f32(i32 56, float %3191, float %3190, float %3188, float %3189, float %3147, float %3160, float %3173, float %3186)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %3193 = fadd fast float %3192, %3130
  %3194 = fadd fast float %3131, %3114
  %3195 = add i32 %3132, 2
  %3196 = icmp ult i32 %3195, %3073
  br i1 %3196, label %3129, label %3197

; <label>:3197                                    ; preds = %3129
  %3198 = fadd fast float %3125, %3114
  %3199 = shl i32 %3074, 1
  %3200 = add i32 %3127, %3199
  %3201 = add i32 %3128, 2
  %3202 = icmp ult i32 %3201, %3073
  br i1 %3202, label %3124, label %3203

; <label>:3203                                    ; preds = %3197
  br label %3204

; <label>:3204                                    ; preds = %3203, %3093
  %3205 = phi float [ 0.000000e+00, %3093 ], [ %3193, %3203 ]
  %3206 = call float @dx.op.unary.f32(i32 7, float %3205)  ; Saturate(value)
  %3207 = call float @dx.op.binary.f32(i32 36, float %3065, float %3206)  ; FMin(a,b)
  br label %3208

; <label>:3208                                    ; preds = %3204, %3072, %3068, %3064
  %3209 = phi float [ %3207, %3204 ], [ %3065, %3072 ], [ %3065, %3068 ], [ %3065, %3064 ]
  %3210 = icmp eq i32 %105, 1
  br i1 %3210, label %3211, label %3260

; <label>:3211                                    ; preds = %3208
  %3212 = fmul fast float %88, %62
  %3213 = fmul fast float %90, %62
  %3214 = fmul fast float %110, %3212
  %3215 = fmul fast float %110, %3213
  %3216 = fsub fast float %565, %3214
  %3217 = fsub fast float %567, %3215
  %3218 = fmul fast float %3216, %109
  %3219 = fmul fast float %3217, %109
  %3220 = fadd fast float %3218, %107
  %3221 = fadd fast float %3219, %108
  %3222 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %14, %dx.types.Handle %43, float %3220, float %3221, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3223 = extractvalue %dx.types.ResRet.f32 %3222, 0
  %3224 = fadd fast float %3223, %112
  %3225 = call float @dx.op.unary.f32(i32 7, float %3224)  ; Saturate(value)
  %3226 = call float @dx.op.unary.f32(i32 23, float %3225)  ; Log(value)
  %3227 = fmul fast float %3226, %113
  %3228 = call float @dx.op.unary.f32(i32 21, float %3227)  ; Exp(value)
  %3229 = fcmp fast olt float %112, 1.000000e+00
  br i1 %3229, label %3230, label %3247

; <label>:3230                                    ; preds = %3211
  %3231 = fmul fast float %123, %3212
  %3232 = fmul fast float %123, %3213
  %3233 = fsub fast float %565, %3231
  %3234 = fsub fast float %567, %3232
  %3235 = fmul fast float %3233, %122
  %3236 = fmul fast float %3234, %122
  %3237 = fadd fast float %3235, %120
  %3238 = fadd fast float %3236, %121
  %3239 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %12, %dx.types.Handle %43, float %3237, float %3238, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3240 = extractvalue %dx.types.ResRet.f32 %3239, 0
  %3241 = fadd fast float %3240, %125
  %3242 = call float @dx.op.unary.f32(i32 7, float %3241)  ; Saturate(value)
  %3243 = call float @dx.op.unary.f32(i32 23, float %3242)  ; Log(value)
  %3244 = fmul fast float %3243, %126
  %3245 = call float @dx.op.unary.f32(i32 21, float %3244)  ; Exp(value)
  %3246 = fmul fast float %3245, %3228
  br label %3247

; <label>:3247                                    ; preds = %3230, %3211
  %3248 = phi float [ %3246, %3230 ], [ %3228, %3211 ]
  %3249 = fmul fast float %2715, %116
  %3250 = fadd fast float %3249, %115
  %3251 = call float @dx.op.unary.f32(i32 7, float %3250)  ; Saturate(value)
  %3252 = fmul fast float %118, %62
  %3253 = fadd fast float %3252, %117
  %3254 = call float @dx.op.unary.f32(i32 7, float %3253)  ; Saturate(value)
  %3255 = call float @dx.op.binary.f32(i32 35, float %3251, float %3254)  ; FMax(a,b)
  %3256 = fsub fast float 1.000000e+00, %3248
  %3257 = fmul fast float %3255, %3255
  %3258 = fmul fast float %3257, %3256
  %3259 = fadd fast float %3258, %3248
  br label %3278

; <label>:3260                                    ; preds = %3208
  %3261 = icmp eq i32 %105, 2
  br i1 %3261, label %3262, label %3278

; <label>:3262                                    ; preds = %3260
  %3263 = call float @dx.op.unary.f32(i32 6, float %89)  ; FAbs(value)
  %3264 = fcmp fast olt float %3263, 0x3EB0C6F7A0000000
  %3265 = select i1 %3264, float 0x3EB0C6F7A0000000, float %89
  %3266 = fsub fast float %113, %62
  %3267 = fdiv fast float %3266, %3265
  %3268 = fmul fast float %3267, %88
  %3269 = fmul fast float %3267, %90
  %3270 = fadd fast float %107, %61
  %3271 = fadd fast float %3270, %3268
  %3272 = fadd fast float %108, %63
  %3273 = fadd fast float %3272, %3269
  %3274 = fmul fast float %3271, %109
  %3275 = fmul fast float %3273, %109
  %3276 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %14, %dx.types.Handle %43, float %3274, float %3275, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3277 = extractvalue %dx.types.ResRet.f32 %3276, 0
  br label %3278

; <label>:3278                                    ; preds = %3262, %3260, %3247
  %3279 = phi float [ %3259, %3247 ], [ %3277, %3262 ], [ 1.000000e+00, %3260 ]
  %3280 = fmul fast float %3279, %3209
  %3281 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %272, float %273, float %274)  ; Dot3(ax,ay,az,bx,by,bz)
  %3282 = call float @dx.op.unary.f32(i32 7, float %3281)  ; Saturate(value)
  %3283 = fmul fast float %2882, %2882
  %3284 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %24, %dx.types.Handle %40, float %3282, float %3283, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3285 = extractvalue %dx.types.ResRet.f32 %3284, 0
  %3286 = extractvalue %dx.types.ResRet.f32 %3284, 1
  %3287 = extractvalue %dx.types.ResRet.f32 %3284, 2
  %3288 = fsub fast float %3285, %3286
  %3289 = fmul fast float %3288, 0x3FA47AE140000000
  %3290 = fadd fast float %3289, %3286
  %3291 = fmul fast float %3282, %2879
  %3292 = fmul fast float %3282, %2880
  %3293 = fmul fast float %3282, %2881
  %3294 = fsub fast float %272, %3291
  %3295 = fsub fast float %273, %3292
  %3296 = fsub fast float %274, %3293
  %3297 = call float @dx.op.dot3.f32(i32 55, float %3294, float %3295, float %3296, float %3294, float %3295, float %3296)  ; Dot3(ax,ay,az,bx,by,bz)
  %3298 = call float @dx.op.unary.f32(i32 25, float %3297)  ; Rsqrt(value)
  %3299 = fmul fast float %3298, %3294
  %3300 = fmul fast float %3298, %3295
  %3301 = fmul fast float %3298, %3296
  %3302 = fmul fast float %3301, %2880
  %3303 = fmul fast float %3300, %2881
  %3304 = fsub fast float %3302, %3303
  %3305 = fmul fast float %3299, %2881
  %3306 = fmul fast float %3301, %2879
  %3307 = fsub fast float %3305, %3306
  %3308 = fmul fast float %3300, %2879
  %3309 = fmul fast float %3299, %2880
  %3310 = fsub fast float %3308, %3309
  %3311 = call float @dx.op.binary.f32(i32 35, float %2882, float 0x3FA6E5B7E0000000)  ; FMax(a,b)
  %3312 = call float @dx.op.unary.f32(i32 7, float %3282)  ; Saturate(value)
  %3313 = fsub fast float 1.000000e+00, %3312
  %3314 = call float @dx.op.unary.f32(i32 24, float %3313)  ; Sqrt(value)
  %3315 = fmul fast float %3311, 9.843750e-01
  %3316 = fmul fast float %3314, 9.843750e-01
  %3317 = fadd fast float %3315, 7.812500e-03
  %3318 = fadd fast float %3316, 7.812500e-03
  %3319 = call float @dx.op.unary.f32(i32 7, float %3317)  ; Saturate(value)
  %3320 = call float @dx.op.unary.f32(i32 7, float %3318)  ; Saturate(value)
  %3321 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %22, %dx.types.Handle %40, float %3319, float %3320, float 1.000000e+00, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3322 = extractvalue %dx.types.ResRet.f32 %3321, 0
  %3323 = extractvalue %dx.types.ResRet.f32 %3321, 1
  %3324 = extractvalue %dx.types.ResRet.f32 %3321, 2
  %3325 = extractvalue %dx.types.ResRet.f32 %3321, 3
  %3326 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %22, %dx.types.Handle %40, float %3319, float %3320, float 0.000000e+00, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3327 = extractvalue %dx.types.ResRet.f32 %3326, 0
  %3328 = extractvalue %dx.types.ResRet.f32 %3326, 1
  %3329 = extractvalue %dx.types.ResRet.f32 %3326, 2
  %3330 = extractvalue %dx.types.ResRet.f32 %3326, 3
  %3331 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 155)  ; CBufferLoadLegacy(handle,regIndex)
  %3332 = extractvalue %dx.types.CBufRet.i32 %3331, 0
  %3333 = extractvalue %dx.types.CBufRet.i32 %3331, 1
  %3334 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 156)  ; CBufferLoadLegacy(handle,regIndex)
  %3335 = extractvalue %dx.types.CBufRet.i32 %3334, 0
  %3336 = extractvalue %dx.types.CBufRet.i32 %3334, 2
  %3337 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 157)  ; CBufferLoadLegacy(handle,regIndex)
  %3338 = extractvalue %dx.types.CBufRet.i32 %3337, 0
  %3339 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 31)  ; CBufferLoadLegacy(handle,regIndex)
  %3340 = extractvalue %dx.types.CBufRet.i32 %3339, 0
  %3341 = extractvalue %dx.types.CBufRet.i32 %3339, 1
  %3342 = sub i32 0, %3341
  %3343 = icmp eq i32 %3340, %3342
  br i1 %3343, label %3387, label %3344

; <label>:3344                                    ; preds = %3278
  %3345 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 29)  ; CBufferLoadLegacy(handle,regIndex)
  %3346 = extractvalue %dx.types.CBufRet.i32 %3345, 0
  %3347 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 32)  ; CBufferLoadLegacy(handle,regIndex)
  %3348 = extractvalue %dx.types.CBufRet.i32 %3347, 0
  %3349 = extractvalue %dx.types.CBufRet.i32 %3347, 1
  %3350 = extractvalue %dx.types.CBufRet.i32 %3347, 2
  %3351 = extractvalue %dx.types.CBufRet.i32 %3347, 3
  %3352 = bitcast i32 %3348 to float
  %3353 = bitcast i32 %3349 to float
  %3354 = bitcast i32 %3350 to float
  %3355 = bitcast i32 %3351 to float
  %3356 = fmul fast float %3352, %47
  %3357 = fmul fast float %3353, %48
  %3358 = fadd fast float %3356, %3354
  %3359 = fadd fast float %3357, %3355
  %3360 = fptoui float %3358 to i32
  %3361 = fptoui float %3359 to i32
  %3362 = extractvalue %dx.types.CBufRet.i32 %3339, 2
  %3363 = extractvalue %dx.types.CBufRet.i32 %3339, 3
  %3364 = extractvalue %dx.types.CBufRet.i32 %3345, 2
  %3365 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 33)  ; CBufferLoadLegacy(handle,regIndex)
  %3366 = extractvalue %dx.types.CBufRet.i32 %3365, 0
  %3367 = extractvalue %dx.types.CBufRet.i32 %3365, 1
  %3368 = extractvalue %dx.types.CBufRet.i32 %3365, 2
  %3369 = extractvalue %dx.types.CBufRet.i32 %3365, 3
  %3370 = mul i32 %3361, %3346
  %3371 = add i32 %3370, %3360
  %3372 = mul i32 %3371, %3362
  %3373 = fsub fast float %49, %156
  %3374 = fdiv fast float 1.000000e+00, %3373
  %3375 = bitcast i32 %3366 to float
  %3376 = fmul fast float %3374, %155
  %3377 = fmul fast float %3376, %3375
  %3378 = bitcast i32 %3367 to float
  %3379 = fadd fast float %3377, %3378
  %3380 = call i32 @dx.op.legacyF32ToF16(i32 130, float %3379)  ; LegacyF32ToF16(value)
  %3381 = and i32 %3369, 31
  %3382 = lshr i32 %3380, %3381
  %3383 = and i32 %3368, 31
  %3384 = shl i32 1, %3383
  %3385 = add i32 %3384, -1
  %3386 = and i32 %3385, %3382
  br label %3387

; <label>:3387                                    ; preds = %3344, %3278
  %3388 = phi i32 [ %3363, %3344 ], [ 0, %3278 ]
  %3389 = phi i32 [ %3364, %3344 ], [ 0, %3278 ]
  %3390 = phi i32 [ %3372, %3344 ], [ 0, %3278 ]
  %3391 = phi i32 [ %3386, %3344 ], [ 0, %3278 ]
  %3392 = icmp eq i32 %3340, 0
  br i1 %3392, label %6576, label %3393

; <label>:3393                                    ; preds = %3387
  %3394 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %21, i32 %3391, i32 0)  ; BufferLoad(srv,index,wot)
  %3395 = extractvalue %dx.types.ResRet.i32 %3394, 0
  %3396 = and i32 %3395, 65535
  %3397 = lshr i32 %3395, 16
  %3398 = lshr i32 %3396, 5
  %3399 = lshr i32 %3395, 21
  %3400 = icmp ugt i32 %3398, %3399
  br i1 %3400, label %6576, label %3401

; <label>:3401                                    ; preds = %3393
  br label %3402

; <label>:3402                                    ; preds = %6543, %3401
  %3403 = phi float [ %6544, %6543 ], [ 0.000000e+00, %3401 ]
  %3404 = phi float [ %6545, %6543 ], [ 0.000000e+00, %3401 ]
  %3405 = phi float [ %6546, %6543 ], [ 0.000000e+00, %3401 ]
  %3406 = phi float [ %6570, %6543 ], [ 0.000000e+00, %3401 ]
  %3407 = phi float [ %6571, %6543 ], [ 0.000000e+00, %3401 ]
  %3408 = phi float [ %6572, %6543 ], [ 0.000000e+00, %3401 ]
  %3409 = phi i32 [ %6573, %6543 ], [ %3398, %3401 ]
  %3410 = add i32 %3409, %3390
  %3411 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %29, i32 %3410, i32 0)  ; BufferLoad(srv,index,wot)
  %3412 = extractvalue %dx.types.ResRet.i32 %3411, 0
  %3413 = shl i32 %3409, 5
  %3414 = sub nsw i32 %3396, %3413
  %3415 = call i32 @dx.op.binary.i32(i32 37, i32 %3414, i32 0)  ; IMax(a,b)
  %3416 = call i32 @dx.op.binary.i32(i32 38, i32 %3415, i32 31)  ; IMin(a,b)
  %3417 = add nuw nsw i32 %3413, 32
  %3418 = icmp uge i32 %3396, %3417
  %3419 = icmp ult i32 %3397, %3413
  %3420 = or i1 %3419, %3418
  br i1 %3420, label %3429, label %3421

; <label>:3421                                    ; preds = %3402
  %3422 = sub nsw i32 %3397, %3413
  %3423 = call i32 @dx.op.binary.i32(i32 37, i32 %3422, i32 0)  ; IMax(a,b)
  %3424 = call i32 @dx.op.binary.i32(i32 38, i32 %3423, i32 31)  ; IMin(a,b)
  %3425 = sub i32 1, %3416
  %3426 = add i32 %3425, %3424
  %3427 = call i32 @dx.op.binary.i32(i32 37, i32 %3426, i32 0)  ; IMax(a,b)
  %3428 = call i32 @dx.op.binary.i32(i32 38, i32 %3427, i32 32)  ; IMin(a,b)
  br label %3429

; <label>:3429                                    ; preds = %3421, %3402
  %3430 = phi i32 [ %3428, %3421 ], [ 0, %3402 ]
  %3431 = icmp eq i32 %3430, 32
  br i1 %3431, label %3438, label %3432

; <label>:3432                                    ; preds = %3429
  %3433 = and i32 %3430, 31
  %3434 = shl i32 1, %3433
  %3435 = add i32 %3434, -1
  %3436 = and i32 %3416, 31
  %3437 = shl i32 %3435, %3436
  br label %3438

; <label>:3438                                    ; preds = %3432, %3429
  %3439 = phi i32 [ %3437, %3432 ], [ -1, %3429 ]
  %3440 = and i32 %3439, %3412
  %3441 = icmp eq i32 %3440, 0
  br i1 %3441, label %6543, label %3442

; <label>:3442                                    ; preds = %3438
  br label %3443

; <label>:3443                                    ; preds = %3515, %3442
  %3444 = phi float [ %3516, %3515 ], [ %3403, %3442 ]
  %3445 = phi float [ %3517, %3515 ], [ %3404, %3442 ]
  %3446 = phi float [ %3518, %3515 ], [ %3405, %3442 ]
  %3447 = phi float [ %3519, %3515 ], [ %3406, %3442 ]
  %3448 = phi float [ %3520, %3515 ], [ %3407, %3442 ]
  %3449 = phi float [ %3521, %3515 ], [ %3408, %3442 ]
  %3450 = phi i32 [ %3454, %3515 ], [ %3440, %3442 ]
  %3451 = call i32 @dx.op.unaryBits.i32(i32 32, i32 %3450)  ; FirstbitLo(value)
  %3452 = and i32 %3451, 31
  %3453 = shl i32 1, %3452
  %3454 = xor i32 %3453, %3450
  %3455 = add i32 %3451, %3413
  %3456 = add i32 %3455, %3332
  %3457 = shl i32 %3456, 2
  %3458 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %3457, i32 undef)  ; BufferLoad(srv,index,wot)
  %3459 = extractvalue %dx.types.ResRet.i32 %3458, 0
  %3460 = lshr i32 %3459, 19
  %3461 = and i32 %3460, 7
  %3462 = mul i32 %3455, 28
  %3463 = add i32 %3462, %3335
  %3464 = shl i32 %3463, 2
  %3465 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3464, i32 undef)  ; BufferLoad(srv,index,wot)
  %3466 = extractvalue %dx.types.ResRet.f32 %3465, 0
  %3467 = extractvalue %dx.types.ResRet.f32 %3465, 1
  %3468 = extractvalue %dx.types.ResRet.f32 %3465, 2
  %3469 = add i32 %3464, 12
  %3470 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3469, i32 undef)  ; BufferLoad(srv,index,wot)
  %3471 = extractvalue %dx.types.ResRet.f32 %3470, 0
  %3472 = add i32 %3464, 16
  %3473 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3472, i32 undef)  ; BufferLoad(srv,index,wot)
  %3474 = extractvalue %dx.types.ResRet.f32 %3473, 0
  %3475 = extractvalue %dx.types.ResRet.f32 %3473, 1
  %3476 = extractvalue %dx.types.ResRet.f32 %3473, 2
  %3477 = add i32 %3464, 28
  %3478 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3477, i32 undef)  ; BufferLoad(srv,index,wot)
  %3479 = extractvalue %dx.types.ResRet.f32 %3478, 0
  %3480 = add i32 %3464, 36
  %3481 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3480, i32 undef)  ; BufferLoad(srv,index,wot)
  %3482 = extractvalue %dx.types.ResRet.f32 %3481, 0
  %3483 = add i32 %3464, 40
  %3484 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3483, i32 undef)  ; BufferLoad(srv,index,wot)
  %3485 = extractvalue %dx.types.ResRet.f32 %3484, 0
  %3486 = add i32 %3464, 44
  %3487 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %3486, i32 undef)  ; BufferLoad(srv,index,wot)
  %3488 = extractvalue %dx.types.ResRet.i32 %3487, 0
  %3489 = add i32 %3464, 48
  %3490 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3489, i32 undef)  ; BufferLoad(srv,index,wot)
  %3491 = extractvalue %dx.types.ResRet.f32 %3490, 0
  %3492 = extractvalue %dx.types.ResRet.f32 %3490, 1
  %3493 = extractvalue %dx.types.ResRet.f32 %3490, 2
  %3494 = add i32 %3464, 60
  %3495 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3494, i32 undef)  ; BufferLoad(srv,index,wot)
  %3496 = extractvalue %dx.types.ResRet.f32 %3495, 0
  %3497 = add i32 %3464, 64
  %3498 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3497, i32 undef)  ; BufferLoad(srv,index,wot)
  %3499 = extractvalue %dx.types.ResRet.f32 %3498, 0
  %3500 = extractvalue %dx.types.ResRet.f32 %3498, 1
  %3501 = extractvalue %dx.types.ResRet.f32 %3498, 2
  %3502 = add i32 %3464, 76
  %3503 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3502, i32 undef)  ; BufferLoad(srv,index,wot)
  %3504 = extractvalue %dx.types.ResRet.f32 %3503, 0
  %3505 = add i32 %3464, 80
  %3506 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3505, i32 undef)  ; BufferLoad(srv,index,wot)
  %3507 = extractvalue %dx.types.ResRet.f32 %3506, 0
  %3508 = extractvalue %dx.types.ResRet.f32 %3506, 1
  %3509 = extractvalue %dx.types.ResRet.f32 %3506, 2
  %3510 = add i32 %3464, 96
  %3511 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3510, i32 undef)  ; BufferLoad(srv,index,wot)
  %3512 = extractvalue %dx.types.ResRet.f32 %3511, 0
  %3513 = extractvalue %dx.types.ResRet.f32 %3511, 1
  %3514 = extractvalue %dx.types.ResRet.f32 %3511, 2
  switch i32 %3461, label %3515 [
    i32 0, label %3523
    i32 1, label %4087
  ]

; <label>:3515                                    ; preds = %6528, %4080, %4059, %3443
  %3516 = phi float [ %3444, %3443 ], [ %6539, %6528 ], [ %4077, %4059 ], [ %4084, %4080 ]
  %3517 = phi float [ %3445, %3443 ], [ %6540, %6528 ], [ %4078, %4059 ], [ %4085, %4080 ]
  %3518 = phi float [ %3446, %3443 ], [ %6541, %6528 ], [ %4079, %4059 ], [ %4086, %4080 ]
  %3519 = phi float [ %3447, %3443 ], [ %6533, %6528 ], [ %4071, %4059 ], [ %4081, %4080 ]
  %3520 = phi float [ %3448, %3443 ], [ %6534, %6528 ], [ %4072, %4059 ], [ %4082, %4080 ]
  %3521 = phi float [ %3449, %3443 ], [ %6535, %6528 ], [ %4073, %4059 ], [ %4083, %4080 ]
  %3522 = icmp eq i32 %3450, %3453
  br i1 %3522, label %6542, label %3443

; <label>:3523                                    ; preds = %3443
  %3524 = fsub fast float %3466, %565
  %3525 = fsub fast float %3467, %566
  %3526 = fsub fast float %3468, %567
  %3527 = call float @dx.op.dot3.f32(i32 55, float %3524, float %3525, float %3526, float %3524, float %3525, float %3526)  ; Dot3(ax,ay,az,bx,by,bz)
  %3528 = call float @dx.op.unary.f32(i32 25, float %3527)  ; Rsqrt(value)
  %3529 = fmul fast float %3528, %3524
  %3530 = fmul fast float %3528, %3525
  %3531 = fmul fast float %3528, %3526
  %3532 = fadd fast float %3527, %3479
  %3533 = call float @dx.op.binary.f32(i32 35, float 0x3F1A36E2E0000000, float %3532)  ; FMax(a,b)
  %3534 = fdiv fast float 1.000000e+00, %3533
  %3535 = fmul fast float %3527, %3471
  %3536 = fmul fast float %3535, %3535
  %3537 = fsub fast float 1.000000e+00, %3536
  %3538 = call float @dx.op.unary.f32(i32 7, float %3537)  ; Saturate(value)
  %3539 = call float @dx.op.dot3.f32(i32 55, float %3491, float %3492, float %3493, float %3529, float %3530, float %3531)  ; Dot3(ax,ay,az,bx,by,bz)
  %3540 = fmul fast float %3539, %3482
  %3541 = fadd fast float %3540, %3485
  %3542 = call float @dx.op.unary.f32(i32 7, float %3541)  ; Saturate(value)
  %3543 = fmul float %3538, %3542
  %3544 = fmul float %3543, %3543
  %3545 = fmul fast float %3544, %3534
  %3546 = fcmp fast ogt float %3545, 0.000000e+00
  %3547 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %3529, float %3530, float %3531)  ; Dot3(ax,ay,az,bx,by,bz)
  %3548 = call float @dx.op.unary.f32(i32 7, float %3547)  ; Saturate(value)
  %3549 = fmul fast float %3545, %3548
  %3550 = fcmp fast ogt float %3549, 0.000000e+00
  br i1 %3550, label %3551, label %3656

; <label>:3551                                    ; preds = %3523
  %3552 = fadd fast float %3529, %272
  %3553 = fadd fast float %3530, %273
  %3554 = fadd fast float %3531, %274
  %3555 = call float @dx.op.dot3.f32(i32 55, float %3552, float %3553, float %3554, float %3552, float %3553, float %3554)  ; Dot3(ax,ay,az,bx,by,bz)
  %3556 = call float @dx.op.unary.f32(i32 25, float %3555)  ; Rsqrt(value)
  %3557 = fmul fast float %3556, %3552
  %3558 = fmul fast float %3556, %3553
  %3559 = fmul fast float %3556, %3554
  %3560 = call float @dx.op.unary.f32(i32 6, float %3281)  ; FAbs(value)
  %3561 = call float @dx.op.binary.f32(i32 35, float %3560, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %3562 = call float @dx.op.unary.f32(i32 7, float %3561)  ; Saturate(value)
  %3563 = call float @dx.op.dot3.f32(i32 55, float %3529, float %3530, float %3531, float %3557, float %3558, float %3559)  ; Dot3(ax,ay,az,bx,by,bz)
  %3564 = call float @dx.op.unary.f32(i32 7, float %3563)  ; Saturate(value)
  %3565 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %3557, float %3558, float %3559)  ; Dot3(ax,ay,az,bx,by,bz)
  %3566 = call float @dx.op.unary.f32(i32 7, float %3565)  ; Saturate(value)
  %3567 = call float @dx.op.unary.f32(i32 6, float %3565)  ; FAbs(value)
  %3568 = call float @dx.op.binary.f32(i32 35, float %3567, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %3569 = call float @dx.op.unary.f32(i32 7, float %3568)  ; Saturate(value)
  %3570 = fsub fast float 1.000000e+00, %3564
  %3571 = fmul fast float %3570, %3570
  %3572 = fmul fast float %3571, %3571
  %3573 = fmul fast float %3572, %3570
  %3574 = fmul fast float %3573, 0x3FEEB851E0000000
  %3575 = fadd fast float %3574, 0x3FA47AE140000000
  %3576 = call float @dx.op.binary.f32(i32 35, float %3283, float 0x3F60624DE0000000)  ; FMax(a,b)
  %3577 = fmul fast float %3576, %3576
  %3578 = fmul fast float %3577, %3562
  %3579 = fsub fast float %3562, %3578
  %3580 = fmul fast float %3579, %3562
  %3581 = fadd fast float %3580, %3577
  %3582 = call float @dx.op.unary.f32(i32 24, float %3581)  ; Sqrt(value)
  %3583 = fmul fast float %3582, %3548
  %3584 = fmul fast float %3577, %3548
  %3585 = fsub fast float %3548, %3584
  %3586 = fmul fast float %3585, %3548
  %3587 = fadd fast float %3586, %3577
  %3588 = call float @dx.op.unary.f32(i32 24, float %3587)  ; Sqrt(value)
  %3589 = fmul fast float %3588, %3562
  %3590 = fadd fast float %3589, %3583
  %3591 = fdiv fast float 5.000000e-01, %3590
  %3592 = fmul fast float %3577, %3566
  %3593 = fsub fast float %3592, %3566
  %3594 = fmul fast float %3593, %3566
  %3595 = fadd fast float %3594, 1.000000e+00
  %3596 = fmul fast float %3595, %3595
  %3597 = fdiv fast float 1.000000e+00, %3596
  %3598 = fdiv fast float 2.000000e+00, %3577
  %3599 = fadd fast float %3598, -1.000000e+00
  %3600 = call float @dx.op.unary.f32(i32 23, float %3599)  ; Log(value)
  %3601 = fmul fast float %3600, 0x3FAC71C720000000
  %3602 = call float @dx.op.unary.f32(i32 7, float %3601)  ; Saturate(value)
  %3603 = fadd fast float %3573, %3564
  %3604 = fsub fast float 1.000000e+00, %3548
  %3605 = fmul fast float %3604, %3604
  %3606 = fmul fast float %3605, %3605
  %3607 = fmul fast float %3606, %3604
  %3608 = fsub fast float 1.000000e+00, %3607
  %3609 = fsub fast float 1.000000e+00, %3562
  %3610 = fmul fast float %3609, %3609
  %3611 = fmul fast float %3610, %3610
  %3612 = fmul fast float %3611, %3609
  %3613 = fsub fast float 1.000000e+00, %3612
  %3614 = fmul fast float %3613, %3608
  %3615 = fmul fast float %3602, 0x40019999A0000000
  %3616 = fadd fast float %3615, -5.000000e-01
  %3617 = call float @dx.op.unary.f32(i32 7, float %3616)  ; Saturate(value)
  %3618 = fsub fast float %3614, %3603
  %3619 = fmul fast float %3617, %3618
  %3620 = fadd fast float %3619, %3603
  %3621 = fmul fast float %3602, %3602
  %3622 = fmul fast float %3621, 3.450000e+01
  %3623 = fmul fast float %3602, 5.900000e+01
  %3624 = fsub fast float 2.450000e+01, %3623
  %3625 = fadd fast float %3624, %3622
  %3626 = fmul fast float %3625, %3564
  %3627 = fmul fast float %3602, 0x40524CCCC0000000
  %3628 = fadd fast float %3627, 0xC035333340000000
  %3629 = call float @dx.op.binary.f32(i32 35, float %3628, float 0x4021CCCCC0000000)  ; FMax(a,b)
  %3630 = call float @dx.op.unary.f32(i32 24, float %3569)  ; Sqrt(value)
  %3631 = fmul fast float %3629, %3630
  %3632 = fsub fast float -0.000000e+00, %3631
  %3633 = call float @dx.op.unary.f32(i32 21, float %3632)  ; Exp(value)
  %3634 = fmul fast float %3626, %3633
  %3635 = fadd fast float %3620, %3634
  %3636 = call float @dx.op.binary.f32(i32 35, float %3635, float 0.000000e+00)  ; FMax(a,b)
  %3637 = and i32 %3459, 32
  %3638 = icmp ne i32 %3637, 0
  %3639 = select i1 %3638, float 1.000000e+00, float 0.000000e+00
  %3640 = fmul fast float %3549, %3639
  %3641 = and i32 %3459, 64
  %3642 = icmp ne i32 %3641, 0
  %3643 = select i1 %3642, float 1.000000e+00, float 0.000000e+00
  %3644 = fmul fast float %3640, %3636
  %3645 = fmul fast float %3644, %3474
  %3646 = fmul fast float %3644, %3475
  %3647 = fmul fast float %3644, %3476
  %3648 = fmul fast float %3549, %3643
  %3649 = fmul fast float %3648, %3577
  %3650 = fmul fast float %3649, %3591
  %3651 = fmul fast float %3650, %3597
  %3652 = fmul fast float %3651, %3575
  %3653 = fmul fast float %3652, %3474
  %3654 = fmul fast float %3652, %3475
  %3655 = fmul fast float %3652, %3476
  br label %3656

; <label>:3656                                    ; preds = %3551, %3523
  %3657 = phi float [ %3645, %3551 ], [ 0.000000e+00, %3523 ]
  %3658 = phi float [ %3646, %3551 ], [ 0.000000e+00, %3523 ]
  %3659 = phi float [ %3647, %3551 ], [ 0.000000e+00, %3523 ]
  %3660 = phi float [ %3653, %3551 ], [ 0.000000e+00, %3523 ]
  %3661 = phi float [ %3654, %3551 ], [ 0.000000e+00, %3523 ]
  %3662 = phi float [ %3655, %3551 ], [ 0.000000e+00, %3523 ]
  %3663 = and i32 %3459, 256
  %3664 = icmp ne i32 %3663, 0
  %3665 = and i1 %3664, %3546
  br i1 %3665, label %3666, label %4080

; <label>:3666                                    ; preds = %3656
  %3667 = mul i32 %3488, 52
  %3668 = add i32 %3667, %3336
  %3669 = shl i32 %3668, 2
  %3670 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3669, i32 undef)  ; BufferLoad(srv,index,wot)
  %3671 = extractvalue %dx.types.ResRet.f32 %3670, 0
  %3672 = extractvalue %dx.types.ResRet.f32 %3670, 1
  %3673 = extractvalue %dx.types.ResRet.f32 %3670, 2
  %3674 = extractvalue %dx.types.ResRet.f32 %3670, 3
  %3675 = add i32 %3669, 16
  %3676 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3675, i32 undef)  ; BufferLoad(srv,index,wot)
  %3677 = extractvalue %dx.types.ResRet.f32 %3676, 0
  %3678 = extractvalue %dx.types.ResRet.f32 %3676, 1
  %3679 = extractvalue %dx.types.ResRet.f32 %3676, 2
  %3680 = extractvalue %dx.types.ResRet.f32 %3676, 3
  %3681 = add i32 %3669, 32
  %3682 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3681, i32 undef)  ; BufferLoad(srv,index,wot)
  %3683 = extractvalue %dx.types.ResRet.f32 %3682, 0
  %3684 = extractvalue %dx.types.ResRet.f32 %3682, 1
  %3685 = extractvalue %dx.types.ResRet.f32 %3682, 2
  %3686 = extractvalue %dx.types.ResRet.f32 %3682, 3
  %3687 = add i32 %3669, 48
  %3688 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3687, i32 undef)  ; BufferLoad(srv,index,wot)
  %3689 = extractvalue %dx.types.ResRet.f32 %3688, 0
  %3690 = extractvalue %dx.types.ResRet.f32 %3688, 1
  %3691 = extractvalue %dx.types.ResRet.f32 %3688, 2
  %3692 = extractvalue %dx.types.ResRet.f32 %3688, 3
  %3693 = add i32 %3669, 76
  %3694 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3693, i32 undef)  ; BufferLoad(srv,index,wot)
  %3695 = extractvalue %dx.types.ResRet.f32 %3694, 0
  %3696 = add i32 %3669, 80
  %3697 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3696, i32 undef)  ; BufferLoad(srv,index,wot)
  %3698 = extractvalue %dx.types.ResRet.f32 %3697, 0
  %3699 = add i32 %3669, 84
  %3700 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3699, i32 undef)  ; BufferLoad(srv,index,wot)
  %3701 = extractvalue %dx.types.ResRet.f32 %3700, 0
  %3702 = add i32 %3669, 96
  %3703 = add i32 %3669, 192
  %3704 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3703, i32 undef)  ; BufferLoad(srv,index,wot)
  %3705 = extractvalue %dx.types.ResRet.f32 %3704, 2
  %3706 = extractvalue %dx.types.ResRet.f32 %3704, 3
  %3707 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3702, i32 undef)  ; BufferLoad(srv,index,wot)
  %3708 = extractvalue %dx.types.ResRet.f32 %3707, 0
  %3709 = extractvalue %dx.types.ResRet.f32 %3707, 1
  %3710 = add i32 %3669, 112
  %3711 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3710, i32 undef)  ; BufferLoad(srv,index,wot)
  %3712 = extractvalue %dx.types.ResRet.f32 %3711, 0
  %3713 = extractvalue %dx.types.ResRet.f32 %3711, 1
  %3714 = extractvalue %dx.types.ResRet.f32 %3711, 2
  %3715 = extractvalue %dx.types.ResRet.f32 %3711, 3
  %3716 = add i32 %3669, 128
  %3717 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3716, i32 undef)  ; BufferLoad(srv,index,wot)
  %3718 = extractvalue %dx.types.ResRet.f32 %3717, 0
  %3719 = extractvalue %dx.types.ResRet.f32 %3717, 1
  %3720 = add i32 %3669, 144
  %3721 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3720, i32 undef)  ; BufferLoad(srv,index,wot)
  %3722 = extractvalue %dx.types.ResRet.f32 %3721, 0
  %3723 = extractvalue %dx.types.ResRet.f32 %3721, 1
  %3724 = add i32 %3669, 160
  %3725 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3724, i32 undef)  ; BufferLoad(srv,index,wot)
  %3726 = extractvalue %dx.types.ResRet.f32 %3725, 0
  %3727 = extractvalue %dx.types.ResRet.f32 %3725, 1
  %3728 = add i32 %3669, 176
  %3729 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3728, i32 undef)  ; BufferLoad(srv,index,wot)
  %3730 = extractvalue %dx.types.ResRet.f32 %3729, 0
  %3731 = extractvalue %dx.types.ResRet.f32 %3729, 1
  %3732 = and i32 %3459, 16
  %3733 = icmp ne i32 %3732, 0
  %3734 = and i1 %3733, %3550
  br i1 %3734, label %3735, label %3774

; <label>:3735                                    ; preds = %3666
  %3736 = add i32 %3669, 68
  %3737 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %3736, i32 undef)  ; BufferLoad(srv,index,wot)
  %3738 = extractvalue %dx.types.ResRet.i32 %3737, 0
  %3739 = and i32 %3738, 65535
  %3740 = uitofp i32 %3739 to float
  %3741 = fsub fast float -0.000000e+00, %3529
  %3742 = fsub fast float -0.000000e+00, %3530
  %3743 = fsub fast float -0.000000e+00, %3531
  %3744 = fmul fast float %3507, %3741
  %3745 = call float @dx.op.tertiary.f32(i32 46, float %3508, float %3742, float %3744)  ; FMad(a,b,c)
  %3746 = call float @dx.op.tertiary.f32(i32 46, float %3509, float %3743, float %3745)  ; FMad(a,b,c)
  %3747 = fmul fast float %3499, %3741
  %3748 = call float @dx.op.tertiary.f32(i32 46, float %3500, float %3742, float %3747)  ; FMad(a,b,c)
  %3749 = call float @dx.op.tertiary.f32(i32 46, float %3501, float %3743, float %3748)  ; FMad(a,b,c)
  %3750 = fmul fast float %3491, %3741
  %3751 = call float @dx.op.tertiary.f32(i32 46, float %3492, float %3742, float %3750)  ; FMad(a,b,c)
  %3752 = call float @dx.op.tertiary.f32(i32 46, float %3493, float %3743, float %3751)  ; FMad(a,b,c)
  %3753 = fmul fast float %3752, 5.000000e-01
  %3754 = fadd fast float %3753, 5.000000e-01
  %3755 = fdiv fast float %3749, %3746
  %3756 = call float @dx.op.unary.f32(i32 17, float %3755)  ; Atan(value)
  %3757 = fadd fast float %3756, 0x400921FB60000000
  %3758 = fadd fast float %3756, 0xC00921FB60000000
  %3759 = fcmp fast olt float %3746, 0.000000e+00
  %3760 = fcmp fast oeq float %3746, 0.000000e+00
  %3761 = fcmp fast oge float %3749, 0.000000e+00
  %3762 = fcmp fast olt float %3749, 0.000000e+00
  %3763 = and i1 %3759, %3761
  %3764 = select i1 %3763, float %3757, float %3756
  %3765 = and i1 %3759, %3762
  %3766 = select i1 %3765, float %3758, float %3764
  %3767 = and i1 %3760, %3762
  %3768 = and i1 %3760, %3761
  %3769 = fmul fast float %3766, 0x3FC45F3060000000
  %3770 = select i1 %3767, float -2.500000e-01, float %3769
  %3771 = select i1 %3768, float 2.500000e-01, float %3770
  %3772 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %33, %dx.types.Handle %41, float %3771, float %3754, float %3740, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3773 = extractvalue %dx.types.ResRet.f32 %3772, 0
  br label %3774

; <label>:3774                                    ; preds = %3735, %3666
  %3775 = phi float [ %3773, %3735 ], [ 1.000000e+00, %3666 ]
  %3776 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 30)  ; CBufferLoadLegacy(handle,regIndex)
  %3777 = extractvalue %dx.types.CBufRet.i32 %3776, 0
  %3778 = extractvalue %dx.types.CBufRet.i32 %3776, 1
  %3779 = extractvalue %dx.types.CBufRet.i32 %3776, 2
  %3780 = and i32 %3459, 6144
  %3781 = icmp ne i32 %3780, 0
  %3782 = and i1 %3781, %3550
  br i1 %3782, label %3783, label %4006

; <label>:3783                                    ; preds = %3774
  %3784 = fmul fast float %3698, %3539
  %3785 = fadd fast float %3784, %3701
  %3786 = call float @dx.op.unary.f32(i32 7, float %3785)  ; Saturate(value)
  %3787 = fmul fast float %3786, %3786
  %3788 = fcmp fast ogt float %3787, 0.000000e+00
  br i1 %3788, label %3789, label %4006

; <label>:3789                                    ; preds = %3783
  %3790 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 0
  %3791 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 0
  store float %3708, float* %3790, align 4
  store float %3709, float* %3791, align 4
  %3792 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 1
  %3793 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 1
  store float %3712, float* %3792, align 4
  store float %3713, float* %3793, align 4
  %3794 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 2
  %3795 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 2
  store float %3718, float* %3794, align 4
  store float %3719, float* %3795, align 4
  %3796 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 3
  %3797 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 3
  store float %3722, float* %3796, align 4
  store float %3723, float* %3797, align 4
  %3798 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 4
  %3799 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 4
  store float %3726, float* %3798, align 4
  store float %3727, float* %3799, align 4
  %3800 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 5
  %3801 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 5
  store float %3730, float* %3800, align 4
  store float %3731, float* %3801, align 4
  %3802 = icmp eq i32 %3780, 4096
  br i1 %3802, label %3803, label %3847

; <label>:3803                                    ; preds = %3789
  %3804 = call float @dx.op.unary.f32(i32 6, float %3524)  ; FAbs(value)
  %3805 = call float @dx.op.unary.f32(i32 6, float %3525)  ; FAbs(value)
  %3806 = call float @dx.op.unary.f32(i32 6, float %3526)  ; FAbs(value)
  %3807 = call float @dx.op.binary.f32(i32 35, float %3804, float %3805)  ; FMax(a,b)
  %3808 = call float @dx.op.binary.f32(i32 35, float %3807, float %3806)  ; FMax(a,b)
  %3809 = fcmp fast oge float %3806, %3805
  %3810 = fcmp fast oge float %3806, %3804
  %3811 = and i1 %3810, %3809
  br i1 %3811, label %3812, label %3818

; <label>:3812                                    ; preds = %3803
  %3813 = fsub fast float -0.000000e+00, %3524
  %3814 = fcmp fast olt float %3526, 0.000000e+00
  %3815 = select i1 %3814, float %3813, float %3524
  %3816 = fsub fast float -0.000000e+00, %3525
  %3817 = select i1 %3814, float 5.000000e+00, float 4.000000e+00
  br label %3830

; <label>:3818                                    ; preds = %3803
  %3819 = fcmp fast ult float %3805, %3804
  %3820 = fsub fast float -0.000000e+00, %3526
  br i1 %3819, label %3825, label %3821

; <label>:3821                                    ; preds = %3818
  %3822 = fcmp fast olt float %3525, 0.000000e+00
  %3823 = select i1 %3822, float %3820, float %3526
  %3824 = select i1 %3822, float 3.000000e+00, float 2.000000e+00
  br label %3830

; <label>:3825                                    ; preds = %3818
  %3826 = fcmp fast olt float %3524, 0.000000e+00
  %3827 = select i1 %3826, float %3526, float %3820
  %3828 = fsub fast float -0.000000e+00, %3525
  %3829 = select i1 %3826, float 1.000000e+00, float 0.000000e+00
  br label %3830

; <label>:3830                                    ; preds = %3825, %3821, %3812
  %3831 = phi float [ %3815, %3812 ], [ %3524, %3821 ], [ %3827, %3825 ]
  %3832 = phi float [ %3816, %3812 ], [ %3823, %3821 ], [ %3828, %3825 ]
  %3833 = phi float [ %3817, %3812 ], [ %3824, %3821 ], [ %3829, %3825 ]
  %3834 = fsub fast float -0.000000e+00, %3831
  %3835 = fdiv fast float %3834, %3808
  %3836 = fsub fast float -0.000000e+00, %3832
  %3837 = fdiv fast float %3836, %3808
  %3838 = fmul fast float %3808, %3685
  %3839 = fsub fast float %3686, %3838
  %3840 = fdiv fast float %3839, %3808
  %3841 = fsub fast float 1.000000e+00, %3840
  %3842 = fptoui float %3833 to i32
  %3843 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 %3842
  %3844 = load float, float* %3843, align 4
  %3845 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 %3842
  %3846 = load float, float* %3845, align 4
  br label %3874

; <label>:3847                                    ; preds = %3789
  %3848 = fmul fast float %3671, %565
  %3849 = call float @dx.op.tertiary.f32(i32 46, float %566, float %3672, float %3848)  ; FMad(a,b,c)
  %3850 = call float @dx.op.tertiary.f32(i32 46, float %567, float %3673, float %3849)  ; FMad(a,b,c)
  %3851 = fadd fast float %3850, %3674
  %3852 = fmul fast float %3677, %565
  %3853 = call float @dx.op.tertiary.f32(i32 46, float %566, float %3678, float %3852)  ; FMad(a,b,c)
  %3854 = call float @dx.op.tertiary.f32(i32 46, float %567, float %3679, float %3853)  ; FMad(a,b,c)
  %3855 = fadd fast float %3854, %3680
  %3856 = fmul fast float %3683, %565
  %3857 = call float @dx.op.tertiary.f32(i32 46, float %566, float %3684, float %3856)  ; FMad(a,b,c)
  %3858 = call float @dx.op.tertiary.f32(i32 46, float %567, float %3685, float %3857)  ; FMad(a,b,c)
  %3859 = fadd fast float %3858, %3686
  %3860 = fmul fast float %3689, %565
  %3861 = call float @dx.op.tertiary.f32(i32 46, float %566, float %3690, float %3860)  ; FMad(a,b,c)
  %3862 = call float @dx.op.tertiary.f32(i32 46, float %567, float %3691, float %3861)  ; FMad(a,b,c)
  %3863 = fadd fast float %3862, %3692
  %3864 = fdiv fast float 1.000000e+00, %3863
  %3865 = fmul fast float %3864, %3851
  %3866 = fmul fast float %3855, %3864
  %3867 = fsub fast float -0.000000e+00, %3866
  %3868 = fmul fast float %3864, %3859
  %3869 = fsub fast float 1.000000e+00, %3868
  %3870 = call float @dx.op.unary.f32(i32 6, float %3867)  ; FAbs(value)
  %3871 = call float @dx.op.unary.f32(i32 6, float %3865)  ; FAbs(value)
  %3872 = call float @dx.op.binary.f32(i32 35, float %3871, float %3870)  ; FMax(a,b)
  %3873 = call float @dx.op.binary.f32(i32 35, float %3872, float %3869)  ; FMax(a,b)
  br label %3874

; <label>:3874                                    ; preds = %3847, %3830
  %3875 = phi float [ %3846, %3830 ], [ %3709, %3847 ]
  %3876 = phi float [ %3844, %3830 ], [ %3708, %3847 ]
  %3877 = phi float [ %3841, %3830 ], [ %3873, %3847 ]
  %3878 = phi float [ %3835, %3830 ], [ %3865, %3847 ]
  %3879 = phi float [ %3837, %3830 ], [ %3867, %3847 ]
  %3880 = phi float [ %3840, %3830 ], [ %3868, %3847 ]
  %3881 = fcmp fast ole float %3877, 1.000000e+00
  %3882 = fmul fast float %3878, %3705
  %3883 = fmul fast float %3879, %3706
  %3884 = fadd fast float %3882, %3876
  %3885 = fadd fast float %3883, %3875
  %3886 = fcmp fast oge float %3876, 0.000000e+00
  %3887 = and i1 %3886, %3881
  %3888 = add i32 %3777, -1
  %3889 = lshr i32 %3888, 1
  %3890 = fmul fast float %3884, %134
  %3891 = fmul fast float %3885, %134
  %3892 = fadd fast float %3890, -5.000000e-01
  %3893 = fadd fast float %3891, -5.000000e-01
  %3894 = call float @dx.op.unary.f32(i32 22, float %3892)  ; Frc(value)
  %3895 = call float @dx.op.unary.f32(i32 22, float %3893)  ; Frc(value)
  %3896 = fsub fast float 1.000000e+00, %3894
  %3897 = fsub fast float 1.000000e+00, %3895
  %3898 = fmul fast float %3897, %3896
  %3899 = fmul fast float %3897, %3894
  %3900 = fmul fast float %3896, %3895
  %3901 = fmul fast float %3895, %3894
  %3902 = call float @dx.op.unary.f32(i32 27, float %3892)  ; Round_ni(value)
  %3903 = fptosi float %3902 to i32
  %3904 = sub i32 %3903, %3889
  %3905 = sitofp i32 %3904 to float
  %3906 = fmul fast float %3905, %135
  %3907 = fadd fast float %3906, %135
  %3908 = fmul fast float %135, 2.000000e+00
  %3909 = icmp eq i32 %3777, 0
  br i1 %3909, label %3997, label %3910

; <label>:3910                                    ; preds = %3874
  %3911 = call float @dx.op.unary.f32(i32 27, float %3893)  ; Round_ni(value)
  %3912 = fptosi float %3911 to i32
  %3913 = sub i32 %3912, %3889
  %3914 = sitofp i32 %3913 to float
  %3915 = fmul fast float %3914, %135
  %3916 = fadd fast float %3915, %135
  br label %3917

; <label>:3917                                    ; preds = %3990, %3910
  %3918 = phi float [ %3991, %3990 ], [ %3916, %3910 ]
  %3919 = phi float [ %3986, %3990 ], [ 0.000000e+00, %3910 ]
  %3920 = phi i32 [ %3993, %3990 ], [ %3778, %3910 ]
  %3921 = phi i32 [ %3994, %3990 ], [ 0, %3910 ]
  br label %3922

; <label>:3922                                    ; preds = %3922, %3917
  %3923 = phi float [ %3986, %3922 ], [ %3919, %3917 ]
  %3924 = phi float [ %3987, %3922 ], [ %3907, %3917 ]
  %3925 = phi i32 [ %3988, %3922 ], [ 0, %3917 ]
  %3926 = add i32 %3925, %3920
  %3927 = add i32 %3926, %3779
  %3928 = add i32 %3926, 35
  %3929 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3928)  ; CBufferLoadLegacy(handle,regIndex)
  %3930 = extractvalue %dx.types.CBufRet.f32 %3929, 0
  %3931 = fmul fast float %3930, %3901
  %3932 = extractvalue %dx.types.CBufRet.f32 %3929, 1
  %3933 = fmul fast float %3932, %3900
  %3934 = fadd fast float %3933, %3931
  %3935 = extractvalue %dx.types.CBufRet.f32 %3929, 2
  %3936 = fmul fast float %3935, %3899
  %3937 = fadd fast float %3934, %3936
  %3938 = extractvalue %dx.types.CBufRet.f32 %3929, 3
  %3939 = fmul fast float %3938, %3898
  %3940 = fadd fast float %3937, %3939
  %3941 = add i32 %3926, 36
  %3942 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3941)  ; CBufferLoadLegacy(handle,regIndex)
  %3943 = extractvalue %dx.types.CBufRet.f32 %3942, 0
  %3944 = fmul fast float %3943, %3901
  %3945 = extractvalue %dx.types.CBufRet.f32 %3942, 1
  %3946 = fmul fast float %3945, %3900
  %3947 = fadd fast float %3946, %3944
  %3948 = extractvalue %dx.types.CBufRet.f32 %3942, 2
  %3949 = fmul fast float %3948, %3899
  %3950 = fadd fast float %3947, %3949
  %3951 = extractvalue %dx.types.CBufRet.f32 %3942, 3
  %3952 = fmul fast float %3951, %3898
  %3953 = fadd fast float %3950, %3952
  %3954 = add i32 %3927, 35
  %3955 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3954)  ; CBufferLoadLegacy(handle,regIndex)
  %3956 = extractvalue %dx.types.CBufRet.f32 %3955, 0
  %3957 = fmul fast float %3956, %3901
  %3958 = extractvalue %dx.types.CBufRet.f32 %3955, 1
  %3959 = fmul fast float %3958, %3900
  %3960 = fadd fast float %3959, %3957
  %3961 = extractvalue %dx.types.CBufRet.f32 %3955, 2
  %3962 = fmul fast float %3961, %3899
  %3963 = fadd fast float %3960, %3962
  %3964 = extractvalue %dx.types.CBufRet.f32 %3955, 3
  %3965 = fmul fast float %3964, %3898
  %3966 = fadd fast float %3963, %3965
  %3967 = add i32 %3927, 36
  %3968 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3967)  ; CBufferLoadLegacy(handle,regIndex)
  %3969 = extractvalue %dx.types.CBufRet.f32 %3968, 0
  %3970 = fmul fast float %3969, %3901
  %3971 = extractvalue %dx.types.CBufRet.f32 %3968, 1
  %3972 = fmul fast float %3971, %3900
  %3973 = fadd fast float %3972, %3970
  %3974 = extractvalue %dx.types.CBufRet.f32 %3968, 2
  %3975 = fmul fast float %3974, %3899
  %3976 = fadd fast float %3973, %3975
  %3977 = extractvalue %dx.types.CBufRet.f32 %3968, 3
  %3978 = fmul fast float %3977, %3898
  %3979 = fadd fast float %3976, %3978
  %3980 = call %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32 74, %dx.types.Handle %30, %dx.types.Handle %36, float %3924, float %3918, float undef, float undef, i32 0, i32 0, i32 0, float %3880)  ; TextureGatherCmp(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,channel,compareValue)
  %3981 = extractvalue %dx.types.ResRet.f32 %3980, 0
  %3982 = extractvalue %dx.types.ResRet.f32 %3980, 1
  %3983 = extractvalue %dx.types.ResRet.f32 %3980, 2
  %3984 = extractvalue %dx.types.ResRet.f32 %3980, 3
  %3985 = call float @dx.op.dot4.f32(i32 56, float %3984, float %3983, float %3981, float %3982, float %3940, float %3953, float %3966, float %3979)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %3986 = fadd fast float %3985, %3923
  %3987 = fadd fast float %3924, %3908
  %3988 = add i32 %3925, 2
  %3989 = icmp ult i32 %3988, %3777
  br i1 %3989, label %3922, label %3990

; <label>:3990                                    ; preds = %3922
  %3991 = fadd fast float %3918, %3908
  %3992 = shl i32 %3779, 1
  %3993 = add i32 %3920, %3992
  %3994 = add i32 %3921, 2
  %3995 = icmp ult i32 %3994, %3777
  br i1 %3995, label %3917, label %3996

; <label>:3996                                    ; preds = %3990
  br label %3997

; <label>:3997                                    ; preds = %3996, %3874
  %3998 = phi float [ 0.000000e+00, %3874 ], [ %3986, %3996 ]
  %3999 = call float @dx.op.unary.f32(i32 7, float %3998)  ; Saturate(value)
  %4000 = fadd fast float %3999, -1.000000e+00
  %4001 = select i1 %3887, float %4000, float 0.000000e+00
  %4002 = fmul fast float %3787, %3695
  %4003 = fmul fast float %4002, %4001
  %4004 = fadd fast float %4003, 1.000000e+00
  %4005 = fmul fast float %4004, %3775
  br label %4006

; <label>:4006                                    ; preds = %3997, %3783, %3774
  %4007 = phi float [ %4005, %3997 ], [ %3775, %3783 ], [ %3775, %3774 ]
  %4008 = and i32 %3459, 1536
  %4009 = icmp eq i32 %4008, 0
  br i1 %4009, label %4059, label %4010

; <label>:4010                                    ; preds = %4006
  %4011 = fmul fast float %3671, %565
  %4012 = call float @dx.op.tertiary.f32(i32 46, float %3672, float %566, float %4011)  ; FMad(a,b,c)
  %4013 = call float @dx.op.tertiary.f32(i32 46, float %3673, float %567, float %4012)  ; FMad(a,b,c)
  %4014 = fadd fast float %4013, %3674
  %4015 = fmul fast float %3677, %565
  %4016 = call float @dx.op.tertiary.f32(i32 46, float %3678, float %566, float %4015)  ; FMad(a,b,c)
  %4017 = call float @dx.op.tertiary.f32(i32 46, float %3679, float %567, float %4016)  ; FMad(a,b,c)
  %4018 = fadd fast float %4017, %3680
  %4019 = fmul fast float %3683, %565
  %4020 = call float @dx.op.tertiary.f32(i32 46, float %3684, float %566, float %4019)  ; FMad(a,b,c)
  %4021 = call float @dx.op.tertiary.f32(i32 46, float %3685, float %567, float %4020)  ; FMad(a,b,c)
  %4022 = fadd fast float %4021, %3686
  %4023 = fmul fast float %3689, %565
  %4024 = call float @dx.op.tertiary.f32(i32 46, float %3690, float %566, float %4023)  ; FMad(a,b,c)
  %4025 = call float @dx.op.tertiary.f32(i32 46, float %3691, float %567, float %4024)  ; FMad(a,b,c)
  %4026 = fadd fast float %4025, %3692
  %4027 = call float @dx.op.unary.f32(i32 6, float %4014)  ; FAbs(value)
  %4028 = call float @dx.op.unary.f32(i32 6, float %4018)  ; FAbs(value)
  %4029 = call float @dx.op.unary.f32(i32 6, float %4022)  ; FAbs(value)
  %4030 = fcmp fast ogt float %4027, %4026
  %4031 = fcmp fast ogt float %4028, %4026
  %4032 = fcmp fast ogt float %4029, %4026
  %4033 = or i1 %4030, %4031
  %4034 = or i1 %4033, %4032
  %4035 = select i1 %4034, float 0.000000e+00, float 1.000000e+00
  %4036 = and i32 %3459, 128
  %4037 = icmp eq i32 %4036, 0
  br i1 %4037, label %4059, label %4038

; <label>:4038                                    ; preds = %4010
  %4039 = fdiv fast float %4014, %4026
  %4040 = fdiv fast float %4018, %4026
  %4041 = fmul fast float %4039, 5.000000e-01
  %4042 = fmul fast float %4040, 5.000000e-01
  %4043 = fadd fast float %4041, 5.000000e-01
  %4044 = fsub fast float 5.000000e-01, %4042
  %4045 = fmul fast float %4043, %3714
  %4046 = fmul fast float %4044, %3715
  %4047 = fadd fast float %4045, %3712
  %4048 = fadd fast float %4046, %3713
  %4049 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %23, %dx.types.Handle %40, float %4047, float %4048, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %4050 = extractvalue %dx.types.ResRet.f32 %4049, 0
  %4051 = extractvalue %dx.types.ResRet.f32 %4049, 1
  %4052 = extractvalue %dx.types.ResRet.f32 %4049, 2
  %4053 = fmul fast float %4050, %3657
  %4054 = fmul fast float %4051, %3658
  %4055 = fmul fast float %4052, %3659
  %4056 = fmul fast float %4050, %3660
  %4057 = fmul fast float %4051, %3661
  %4058 = fmul fast float %4052, %3662
  br label %4059

; <label>:4059                                    ; preds = %4038, %4010, %4006
  %4060 = phi float [ %4053, %4038 ], [ %3657, %4010 ], [ %3657, %4006 ]
  %4061 = phi float [ %4054, %4038 ], [ %3658, %4010 ], [ %3658, %4006 ]
  %4062 = phi float [ %4055, %4038 ], [ %3659, %4010 ], [ %3659, %4006 ]
  %4063 = phi float [ %4056, %4038 ], [ %3660, %4010 ], [ %3660, %4006 ]
  %4064 = phi float [ %4057, %4038 ], [ %3661, %4010 ], [ %3661, %4006 ]
  %4065 = phi float [ %4058, %4038 ], [ %3662, %4010 ], [ %3662, %4006 ]
  %4066 = phi float [ %4035, %4038 ], [ %4035, %4010 ], [ 1.000000e+00, %4006 ]
  %4067 = fmul fast float %4066, %4007
  %4068 = fmul fast float %4067, %4060
  %4069 = fmul fast float %4067, %4061
  %4070 = fmul fast float %4067, %4062
  %4071 = fadd fast float %4068, %3447
  %4072 = fadd fast float %4069, %3448
  %4073 = fadd fast float %4070, %3449
  %4074 = fmul fast float %4067, %4063
  %4075 = fmul fast float %4067, %4064
  %4076 = fmul fast float %4067, %4065
  %4077 = fadd fast float %4074, %3444
  %4078 = fadd fast float %4075, %3445
  %4079 = fadd fast float %4076, %3446
  br label %3515

; <label>:4080                                    ; preds = %3656
  %4081 = fadd fast float %3657, %3447
  %4082 = fadd fast float %3658, %3448
  %4083 = fadd fast float %3659, %3449
  %4084 = fadd fast float %3660, %3444
  %4085 = fadd fast float %3661, %3445
  %4086 = fadd fast float %3662, %3446
  br label %3515

; <label>:4087                                    ; preds = %3443
  %4088 = fsub fast float %3466, %565
  %4089 = fsub fast float %3467, %566
  %4090 = fsub fast float %3468, %567
  %4091 = call float @dx.op.dot3.f32(i32 55, float %4088, float %4089, float %4090, float %4088, float %4089, float %4090)  ; Dot3(ax,ay,az,bx,by,bz)
  %4092 = call float @dx.op.unary.f32(i32 25, float %4091)  ; Rsqrt(value)
  %4093 = fmul fast float %4092, %4088
  %4094 = fmul fast float %4092, %4089
  %4095 = fmul fast float %4092, %4090
  %4096 = lshr i32 %3459, 14
  %4097 = and i32 %4096, 7
  %4098 = icmp eq i32 %4097, 0
  br i1 %4098, label %4099, label %4316

; <label>:4099                                    ; preds = %4087
  %4100 = fsub fast float -0.000000e+00, %272
  %4101 = fsub fast float -0.000000e+00, %273
  %4102 = fsub fast float -0.000000e+00, %274
  %4103 = call float @dx.op.dot3.f32(i32 55, float %4100, float %4101, float %4102, float %2879, float %2880, float %2881)  ; Dot3(ax,ay,az,bx,by,bz)
  %4104 = fmul fast float %4103, 2.000000e+00
  %4105 = fmul fast float %4104, %2879
  %4106 = fmul fast float %4104, %2880
  %4107 = fmul fast float %4104, %2881
  %4108 = fsub fast float %4100, %4105
  %4109 = fsub fast float %4101, %4106
  %4110 = fsub fast float %4102, %4107
  %4111 = call float @dx.op.unary.f32(i32 24, float %4091)  ; Sqrt(value)
  %4112 = fdiv fast float %4088, %4111
  %4113 = fdiv fast float %4089, %4111
  %4114 = fdiv fast float %4090, %4111
  %4115 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %4112, float %4113, float %4114)  ; Dot3(ax,ay,az,bx,by,bz)
  %4116 = fmul fast float %3496, %3496
  %4117 = fadd fast float %4091, %3479
  %4118 = call float @dx.op.binary.f32(i32 35, float %4116, float %4117)  ; FMax(a,b)
  %4119 = fdiv fast float %4116, %4118
  %4120 = fmul fast float %4091, %3471
  %4121 = fmul fast float %4120, %4120
  %4122 = fsub fast float 1.000000e+00, %4121
  %4123 = call float @dx.op.unary.f32(i32 7, float %4122)  ; Saturate(value)
  %4124 = fmul fast float %4119, 0x3FE61933C0000000
  %4125 = fsub fast float 0x3FE1E88A00000000, %4124
  %4126 = fmul fast float %4119, 0x4024F72B80000000
  %4127 = fsub fast float 0x40324246A0000000, %4126
  %4128 = fmul fast float %4127, %4119
  %4129 = fadd fast float %4128, 0xC0276BFDA0000000
  %4130 = fmul fast float %4129, %4119
  %4131 = fadd fast float %4130, 0x4013FDD020000000
  %4132 = fmul fast float %4115, 5.000000e-01
  %4133 = fadd fast float %4132, 5.000000e-01
  %4134 = call float @dx.op.unary.f32(i32 23, float %4133)  ; Log(value)
  %4135 = fmul fast float %4131, %4134
  %4136 = call float @dx.op.unary.f32(i32 21, float %4135)  ; Exp(value)
  %4137 = fmul fast float %4125, %4115
  %4138 = fsub fast float %4133, %4136
  %4139 = fmul fast float %4137, %4138
  %4140 = fadd fast float %4139, %4136
  %4141 = call float @dx.op.unary.f32(i32 7, float %4115)  ; Saturate(value)
  %4142 = call float @dx.op.binary.f32(i32 35, float %4141, float %4140)  ; FMax(a,b)
  %4143 = fmul fast float %4119, 0x400921FB60000000
  %4144 = fmul fast float %4123, %4123
  %4145 = fmul fast float %4144, %4143
  %4146 = fmul fast float %4145, %4142
  %4147 = fcmp ogt float %4146, 0.000000e+00
  br i1 %4147, label %4148, label %4308

; <label>:4148                                    ; preds = %4099
  %4149 = fsub fast float %4091, %4116
  %4150 = fcmp fast olt float %4149, 0.000000e+00
  %4151 = fmul fast float %4091, 0x3FEFF7CEE0000000
  %4152 = select i1 %4150, float %4151, float %4116
  %4153 = fsub fast float %4091, %4152
  %4154 = call float @dx.op.unary.f32(i32 24, float %4153)  ; Sqrt(value)
  %4155 = fdiv fast float 1.000000e+00, %4111
  %4156 = fmul fast float %4155, %4154
  %4157 = call float @dx.op.dot3.f32(i32 55, float %4112, float %4113, float %4114, float %4108, float %4109, float %4110)  ; Dot3(ax,ay,az,bx,by,bz)
  %4158 = fcmp fast olt float %4157, %4156
  br i1 %4158, label %4159, label %4188

; <label>:4159                                    ; preds = %4148
  %4160 = fmul fast float %4157, %4112
  %4161 = fmul fast float %4157, %4113
  %4162 = fmul fast float %4157, %4114
  %4163 = fsub fast float %4108, %4160
  %4164 = fsub fast float %4109, %4161
  %4165 = fsub fast float %4110, %4162
  %4166 = fmul fast float %4155, %3496
  %4167 = fmul fast float %4156, %4112
  %4168 = fmul fast float %4156, %4113
  %4169 = fmul fast float %4156, %4114
  %4170 = fmul fast float %4163, %4163
  %4171 = fmul fast float %4164, %4164
  %4172 = fadd fast float %4170, %4171
  %4173 = fmul fast float %4165, %4165
  %4174 = fadd fast float %4172, %4173
  %4175 = call float @dx.op.unary.f32(i32 24, float %4174)  ; Sqrt(value)
  %4176 = fdiv fast float %4166, %4175
  %4177 = fmul fast float %4176, %4163
  %4178 = fmul fast float %4176, %4164
  %4179 = fmul fast float %4176, %4165
  %4180 = fadd fast float %4177, %4167
  %4181 = fadd fast float %4178, %4168
  %4182 = fadd fast float %4179, %4169
  %4183 = call float @dx.op.dot3.f32(i32 55, float %4180, float %4181, float %4182, float %4180, float %4181, float %4182)  ; Dot3(ax,ay,az,bx,by,bz)
  %4184 = call float @dx.op.unary.f32(i32 25, float %4183)  ; Rsqrt(value)
  %4185 = fmul fast float %4180, %4184
  %4186 = fmul fast float %4181, %4184
  %4187 = fmul fast float %4182, %4184
  br label %4188

; <label>:4188                                    ; preds = %4159, %4148
  %4189 = phi float [ %4185, %4159 ], [ %4108, %4148 ]
  %4190 = phi float [ %4186, %4159 ], [ %4109, %4148 ]
  %4191 = phi float [ %4187, %4159 ], [ %4110, %4148 ]
  %4192 = fmul fast float %3496, 5.000000e-01
  %4193 = fmul fast float %4192, %4155
  %4194 = fmul fast float %3311, %3311
  %4195 = fadd fast float %4193, %4194
  %4196 = call float @dx.op.unary.f32(i32 7, float %4195)  ; Saturate(value)
  %4197 = fdiv fast float %4194, %4196
  %4198 = fadd fast float %4189, %272
  %4199 = fadd fast float %4190, %273
  %4200 = fadd fast float %4191, %274
  %4201 = call float @dx.op.dot3.f32(i32 55, float %4198, float %4199, float %4200, float %4198, float %4199, float %4200)  ; Dot3(ax,ay,az,bx,by,bz)
  %4202 = call float @dx.op.unary.f32(i32 25, float %4201)  ; Rsqrt(value)
  %4203 = fmul fast float %4202, %4198
  %4204 = fmul fast float %4202, %4199
  %4205 = fmul fast float %4202, %4200
  %4206 = call float @dx.op.unary.f32(i32 6, float %3281)  ; FAbs(value)
  %4207 = call float @dx.op.binary.f32(i32 35, float %4206, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %4208 = call float @dx.op.unary.f32(i32 7, float %4207)  ; Saturate(value)
  %4209 = call float @dx.op.dot3.f32(i32 55, float %4189, float %4190, float %4191, float %4203, float %4204, float %4205)  ; Dot3(ax,ay,az,bx,by,bz)
  %4210 = call float @dx.op.unary.f32(i32 7, float %4209)  ; Saturate(value)
  %4211 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %4203, float %4204, float %4205)  ; Dot3(ax,ay,az,bx,by,bz)
  %4212 = call float @dx.op.unary.f32(i32 7, float %4211)  ; Saturate(value)
  %4213 = call float @dx.op.unary.f32(i32 6, float %4211)  ; FAbs(value)
  %4214 = call float @dx.op.binary.f32(i32 35, float %4213, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %4215 = call float @dx.op.unary.f32(i32 7, float %4214)  ; Saturate(value)
  %4216 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %4189, float %4190, float %4191)  ; Dot3(ax,ay,az,bx,by,bz)
  %4217 = call float @dx.op.unary.f32(i32 7, float %4216)  ; Saturate(value)
  %4218 = fsub fast float 1.000000e+00, %4210
  %4219 = fmul fast float %4218, %4218
  %4220 = fmul fast float %4219, %4219
  %4221 = fmul fast float %4220, %4218
  %4222 = fmul fast float %4221, 0x3FEEB851E0000000
  %4223 = fadd fast float %4222, 0x3FA47AE140000000
  %4224 = call float @dx.op.binary.f32(i32 35, float %4194, float 0x3F60624DE0000000)  ; FMax(a,b)
  %4225 = fmul fast float %4224, %4224
  %4226 = fmul fast float %4225, %4208
  %4227 = fsub fast float %4208, %4226
  %4228 = fmul fast float %4227, %4208
  %4229 = fadd fast float %4228, %4225
  %4230 = call float @dx.op.unary.f32(i32 24, float %4229)  ; Sqrt(value)
  %4231 = fmul fast float %4230, %4217
  %4232 = fmul fast float %4225, %4217
  %4233 = fsub fast float %4217, %4232
  %4234 = fmul fast float %4233, %4217
  %4235 = fadd fast float %4234, %4225
  %4236 = call float @dx.op.unary.f32(i32 24, float %4235)  ; Sqrt(value)
  %4237 = fmul fast float %4236, %4208
  %4238 = fadd fast float %4237, %4231
  %4239 = fdiv fast float 5.000000e-01, %4238
  %4240 = fmul fast float %4225, %4212
  %4241 = fsub fast float %4240, %4212
  %4242 = fmul fast float %4241, %4212
  %4243 = fadd fast float %4242, 1.000000e+00
  %4244 = fmul fast float %4243, %4243
  %4245 = fdiv fast float 1.000000e+00, %4244
  %4246 = fdiv fast float 2.000000e+00, %4225
  %4247 = fadd fast float %4246, -1.000000e+00
  %4248 = call float @dx.op.unary.f32(i32 23, float %4247)  ; Log(value)
  %4249 = fmul fast float %4248, 0x3FAC71C720000000
  %4250 = call float @dx.op.unary.f32(i32 7, float %4249)  ; Saturate(value)
  %4251 = fadd fast float %4221, %4210
  %4252 = fsub fast float 1.000000e+00, %4217
  %4253 = fmul fast float %4252, %4252
  %4254 = fmul fast float %4253, %4253
  %4255 = fmul fast float %4254, %4252
  %4256 = fsub fast float 1.000000e+00, %4255
  %4257 = fsub fast float 1.000000e+00, %4208
  %4258 = fmul fast float %4257, %4257
  %4259 = fmul fast float %4258, %4258
  %4260 = fmul fast float %4259, %4257
  %4261 = fsub fast float 1.000000e+00, %4260
  %4262 = fmul fast float %4256, %4261
  %4263 = fmul fast float %4250, 0x40019999A0000000
  %4264 = fadd fast float %4263, -5.000000e-01
  %4265 = call float @dx.op.unary.f32(i32 7, float %4264)  ; Saturate(value)
  %4266 = fsub fast float %4262, %4251
  %4267 = fmul fast float %4265, %4266
  %4268 = fadd fast float %4267, %4251
  %4269 = fmul fast float %4250, %4250
  %4270 = fmul fast float %4269, 3.450000e+01
  %4271 = fmul fast float %4250, 5.900000e+01
  %4272 = fsub fast float 2.450000e+01, %4271
  %4273 = fadd fast float %4272, %4270
  %4274 = fmul fast float %4273, %4210
  %4275 = fmul fast float %4250, 0x40524CCCC0000000
  %4276 = fadd fast float %4275, 0xC035333340000000
  %4277 = call float @dx.op.binary.f32(i32 35, float %4276, float 0x4021CCCCC0000000)  ; FMax(a,b)
  %4278 = call float @dx.op.unary.f32(i32 24, float %4215)  ; Sqrt(value)
  %4279 = fmul fast float %4277, %4278
  %4280 = fsub fast float -0.000000e+00, %4279
  %4281 = call float @dx.op.unary.f32(i32 21, float %4280)  ; Exp(value)
  %4282 = fmul fast float %4274, %4281
  %4283 = fadd fast float %4268, %4282
  %4284 = call float @dx.op.binary.f32(i32 35, float %4283, float 0.000000e+00)  ; FMax(a,b)
  %4285 = fmul fast float %4284, %4146
  %4286 = and i32 %3459, 32
  %4287 = icmp ne i32 %4286, 0
  %4288 = fmul fast float %4285, %3474
  %4289 = fmul fast float %4285, %3475
  %4290 = fmul fast float %4285, %3476
  %4291 = select i1 %4287, float %4288, float 0.000000e+00
  %4292 = select i1 %4287, float %4289, float 0.000000e+00
  %4293 = select i1 %4287, float %4290, float 0.000000e+00
  %4294 = and i32 %3459, 64
  %4295 = icmp ne i32 %4294, 0
  %4296 = fmul fast float %4197, %4197
  %4297 = fmul fast float %4296, %4146
  %4298 = fmul fast float %4297, %4225
  %4299 = fmul fast float %4298, %4239
  %4300 = fmul fast float %4299, %4245
  %4301 = fmul fast float %4300, %4223
  %4302 = fmul fast float %4301, %3474
  %4303 = fmul fast float %4301, %3475
  %4304 = fmul fast float %4301, %3476
  %4305 = select i1 %4295, float %4302, float 0.000000e+00
  %4306 = select i1 %4295, float %4303, float 0.000000e+00
  %4307 = select i1 %4295, float %4304, float 0.000000e+00
  br label %4308

; <label>:4308                                    ; preds = %4188, %4099
  %4309 = phi float [ %4291, %4188 ], [ 0.000000e+00, %4099 ]
  %4310 = phi float [ %4292, %4188 ], [ 0.000000e+00, %4099 ]
  %4311 = phi float [ %4293, %4188 ], [ 0.000000e+00, %4099 ]
  %4312 = phi float [ %4305, %4188 ], [ 0.000000e+00, %4099 ]
  %4313 = phi float [ %4306, %4188 ], [ 0.000000e+00, %4099 ]
  %4314 = phi float [ %4307, %4188 ], [ 0.000000e+00, %4099 ]
  %4315 = zext i1 %4147 to i32
  br label %6175

; <label>:4316                                    ; preds = %4087
  %4317 = icmp eq i32 %4097, 3
  br i1 %4317, label %4318, label %5101

; <label>:4318                                    ; preds = %4316
  %4319 = fmul fast float %4091, %3471
  %4320 = fmul fast float %4319, %4319
  %4321 = fsub fast float 1.000000e+00, %4320
  %4322 = call float @dx.op.unary.f32(i32 7, float %4321)  ; Saturate(value)
  %4323 = fsub fast float %3512, %565
  %4324 = fsub fast float %3513, %566
  %4325 = fsub fast float %3514, %567
  %4326 = call float @dx.op.dot3.f32(i32 55, float %4323, float %4324, float %4325, float %4323, float %4324, float %4325)  ; Dot3(ax,ay,az,bx,by,bz)
  %4327 = call float @dx.op.unary.f32(i32 25, float %4326)  ; Rsqrt(value)
  %4328 = fmul fast float %4327, %4323
  %4329 = fmul fast float %4327, %4324
  %4330 = fmul fast float %4327, %4325
  %4331 = call float @dx.op.dot3.f32(i32 55, float %3491, float %3492, float %3493, float %4328, float %4329, float %4330)  ; Dot3(ax,ay,az,bx,by,bz)
  %4332 = fmul fast float %4331, %3482
  %4333 = fadd fast float %4332, %3485
  %4334 = call float @dx.op.unary.f32(i32 7, float %4333)  ; Saturate(value)
  %4335 = fmul float %4322, %4334
  %4336 = fmul float %4335, %4335
  %4337 = fcmp fast ogt float %4336, 0.000000e+00
  br i1 %4337, label %4338, label %5093

; <label>:4338                                    ; preds = %4318
  %4339 = fmul fast float %3507, %3496
  %4340 = fmul fast float %3508, %3496
  %4341 = fmul fast float %3509, %3496
  %4342 = fmul fast float %3499, %3496
  %4343 = fmul fast float %3500, %3496
  %4344 = fmul fast float %3501, %3496
  %4345 = fsub fast float %4088, %4339
  %4346 = fsub fast float %4089, %4340
  %4347 = fsub fast float %4090, %4341
  %4348 = fsub fast float %4345, %4342
  %4349 = fsub fast float %4346, %4343
  %4350 = fsub fast float %4347, %4344
  %4351 = fadd fast float %4339, %4088
  %4352 = fadd fast float %4340, %4089
  %4353 = fadd fast float %4341, %4090
  %4354 = fsub fast float %4351, %4342
  %4355 = fsub fast float %4352, %4343
  %4356 = fsub fast float %4353, %4344
  %4357 = fadd fast float %4351, %4342
  %4358 = fadd fast float %4352, %4343
  %4359 = fadd fast float %4353, %4344
  %4360 = fmul fast float %4348, %3299
  %4361 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %3300, float %4360)  ; FMad(a,b,c)
  %4362 = call float @dx.op.tertiary.f32(i32 46, float %4350, float %3301, float %4361)  ; FMad(a,b,c)
  %4363 = fmul fast float %4348, %3304
  %4364 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %3307, float %4363)  ; FMad(a,b,c)
  %4365 = call float @dx.op.tertiary.f32(i32 46, float %4350, float %3310, float %4364)  ; FMad(a,b,c)
  %4366 = fmul fast float %4348, %2879
  %4367 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %2880, float %4366)  ; FMad(a,b,c)
  %4368 = call float @dx.op.tertiary.f32(i32 46, float %4350, float %2881, float %4367)  ; FMad(a,b,c)
  %4369 = fmul fast float %4354, %3299
  %4370 = call float @dx.op.tertiary.f32(i32 46, float %4355, float %3300, float %4369)  ; FMad(a,b,c)
  %4371 = call float @dx.op.tertiary.f32(i32 46, float %4356, float %3301, float %4370)  ; FMad(a,b,c)
  %4372 = fmul fast float %4354, %3304
  %4373 = call float @dx.op.tertiary.f32(i32 46, float %4355, float %3307, float %4372)  ; FMad(a,b,c)
  %4374 = call float @dx.op.tertiary.f32(i32 46, float %4356, float %3310, float %4373)  ; FMad(a,b,c)
  %4375 = fmul fast float %4354, %2879
  %4376 = call float @dx.op.tertiary.f32(i32 46, float %4355, float %2880, float %4375)  ; FMad(a,b,c)
  %4377 = call float @dx.op.tertiary.f32(i32 46, float %4356, float %2881, float %4376)  ; FMad(a,b,c)
  %4378 = fmul fast float %4357, %3299
  %4379 = call float @dx.op.tertiary.f32(i32 46, float %4358, float %3300, float %4378)  ; FMad(a,b,c)
  %4380 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %3301, float %4379)  ; FMad(a,b,c)
  %4381 = fmul fast float %4357, %3304
  %4382 = call float @dx.op.tertiary.f32(i32 46, float %4358, float %3307, float %4381)  ; FMad(a,b,c)
  %4383 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %3310, float %4382)  ; FMad(a,b,c)
  %4384 = fmul fast float %4357, %2879
  %4385 = call float @dx.op.tertiary.f32(i32 46, float %4358, float %2880, float %4384)  ; FMad(a,b,c)
  %4386 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %2881, float %4385)  ; FMad(a,b,c)
  %4387 = fadd fast float %4380, %4362
  %4388 = fadd fast float %4383, %4365
  %4389 = fadd fast float %4386, %4368
  %4390 = fmul fast float %4387, 5.000000e-01
  %4391 = fmul fast float %4388, 5.000000e-01
  %4392 = fmul fast float %4389, 5.000000e-01
  %4393 = fsub fast float %4371, %4380
  %4394 = fsub fast float %4374, %4383
  %4395 = fsub fast float %4377, %4386
  %4396 = fmul fast float %4393, 5.000000e-01
  %4397 = fmul fast float %4394, 5.000000e-01
  %4398 = fmul fast float %4395, 5.000000e-01
  %4399 = fsub fast float %4371, %4362
  %4400 = fsub fast float %4374, %4365
  %4401 = fsub fast float %4377, %4368
  %4402 = fmul fast float %4399, 5.000000e-01
  %4403 = fmul fast float %4400, 5.000000e-01
  %4404 = fmul fast float %4401, 5.000000e-01
  %4405 = fmul fast float %4390, %3322
  %4406 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %4392, float %4405)  ; FMad(a,b,c)
  %4407 = fmul fast float %4390, %3323
  %4408 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %4392, float %4407)  ; FMad(a,b,c)
  %4409 = fmul fast float %4396, %3322
  %4410 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %4398, float %4409)  ; FMad(a,b,c)
  %4411 = fmul fast float %4396, %3323
  %4412 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %4398, float %4411)  ; FMad(a,b,c)
  %4413 = fmul fast float %4402, %3322
  %4414 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %4404, float %4413)  ; FMad(a,b,c)
  %4415 = fmul fast float %4402, %3323
  %4416 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %4404, float %4415)  ; FMad(a,b,c)
  %4417 = fmul fast float %4416, %4397
  %4418 = fmul fast float %4412, %4403
  %4419 = fsub fast float %4417, %4418
  %4420 = fmul fast float %4414, %4412
  %4421 = fmul fast float %4416, %4410
  %4422 = fsub fast float %4420, %4421
  %4423 = fmul fast float %4410, %4403
  %4424 = fmul fast float %4414, %4397
  %4425 = fsub fast float %4423, %4424
  %4426 = call float @dx.op.dot3.f32(i32 55, float %4419, float %4422, float %4425, float %4406, float %4391, float %4408)  ; Dot3(ax,ay,az,bx,by,bz)
  %4427 = fcmp fast olt float %4426, 0x3EE4F8B580000000
  br i1 %4427, label %4736, label %4428

; <label>:4428                                    ; preds = %4338
  %4429 = call float @dx.op.dot3.f32(i32 55, float %4410, float %4397, float %4412, float %4410, float %4397, float %4412)  ; Dot3(ax,ay,az,bx,by,bz)
  %4430 = call float @dx.op.dot3.f32(i32 55, float %4414, float %4403, float %4416, float %4414, float %4403, float %4416)  ; Dot3(ax,ay,az,bx,by,bz)
  %4431 = call float @dx.op.dot3.f32(i32 55, float %4410, float %4397, float %4412, float %4414, float %4403, float %4416)  ; Dot3(ax,ay,az,bx,by,bz)
  %4432 = call float @dx.op.unary.f32(i32 6, float %4431)  ; FAbs(value)
  %4433 = fmul fast float %4430, %4429
  %4434 = call float @dx.op.unary.f32(i32 24, float %4433)  ; Sqrt(value)
  %4435 = fdiv fast float %4432, %4434
  %4436 = fcmp fast ogt float %4435, 0x3F4A36E2E0000000
  br i1 %4436, label %4437, label %4509

; <label>:4437                                    ; preds = %4428
  %4438 = fadd fast float %4430, %4429
  %4439 = fmul fast float %4431, %4431
  %4440 = fsub fast float %4433, %4439
  %4441 = call float @dx.op.unary.f32(i32 24, float %4440)  ; Sqrt(value)
  %4442 = fmul fast float %4441, 2.000000e+00
  %4443 = fsub fast float %4438, %4442
  %4444 = call float @dx.op.unary.f32(i32 24, float %4443)  ; Sqrt(value)
  %4445 = fadd fast float %4442, %4438
  %4446 = call float @dx.op.unary.f32(i32 24, float %4445)  ; Sqrt(value)
  %4447 = fadd fast float %4446, %4444
  %4448 = fmul fast float %4447, 5.000000e-01
  %4449 = fmul fast float %4448, %4448
  %4450 = fsub fast float %4444, %4446
  %4451 = fmul fast float %4450, 5.000000e-01
  %4452 = fmul fast float %4451, %4451
  %4453 = fcmp fast ogt float %4429, %4430
  br i1 %4453, label %4454, label %4472

; <label>:4454                                    ; preds = %4437
  %4455 = fmul fast float %4431, %4410
  %4456 = fmul fast float %4431, %4397
  %4457 = fmul fast float %4431, %4412
  %4458 = fsub fast float %4449, %4429
  %4459 = fmul fast float %4458, %4414
  %4460 = fmul fast float %4458, %4403
  %4461 = fmul fast float %4458, %4416
  %4462 = fadd fast float %4459, %4455
  %4463 = fadd fast float %4460, %4456
  %4464 = fadd fast float %4461, %4457
  %4465 = fsub fast float %4452, %4429
  %4466 = fmul fast float %4465, %4414
  %4467 = fmul fast float %4465, %4403
  %4468 = fmul fast float %4465, %4416
  %4469 = fadd fast float %4466, %4455
  %4470 = fadd fast float %4467, %4456
  %4471 = fadd fast float %4468, %4457
  br label %4490

; <label>:4472                                    ; preds = %4437
  %4473 = fmul fast float %4431, %4414
  %4474 = fmul fast float %4431, %4403
  %4475 = fmul fast float %4431, %4416
  %4476 = fsub fast float %4449, %4430
  %4477 = fmul fast float %4476, %4410
  %4478 = fmul fast float %4476, %4397
  %4479 = fmul fast float %4476, %4412
  %4480 = fadd fast float %4477, %4473
  %4481 = fadd fast float %4478, %4474
  %4482 = fadd fast float %4479, %4475
  %4483 = fsub fast float %4452, %4430
  %4484 = fmul fast float %4483, %4410
  %4485 = fmul fast float %4483, %4397
  %4486 = fmul fast float %4483, %4412
  %4487 = fadd fast float %4484, %4473
  %4488 = fadd fast float %4485, %4474
  %4489 = fadd fast float %4486, %4475
  br label %4490

; <label>:4490                                    ; preds = %4472, %4454
  %4491 = phi float [ %4462, %4454 ], [ %4480, %4472 ]
  %4492 = phi float [ %4463, %4454 ], [ %4481, %4472 ]
  %4493 = phi float [ %4464, %4454 ], [ %4482, %4472 ]
  %4494 = phi float [ %4469, %4454 ], [ %4487, %4472 ]
  %4495 = phi float [ %4470, %4454 ], [ %4488, %4472 ]
  %4496 = phi float [ %4471, %4454 ], [ %4489, %4472 ]
  %4497 = fdiv fast float 1.000000e+00, %4449
  %4498 = fdiv fast float 1.000000e+00, %4452
  %4499 = call float @dx.op.dot3.f32(i32 55, float %4491, float %4492, float %4493, float %4491, float %4492, float %4493)  ; Dot3(ax,ay,az,bx,by,bz)
  %4500 = call float @dx.op.unary.f32(i32 25, float %4499)  ; Rsqrt(value)
  %4501 = fmul fast float %4500, %4491
  %4502 = fmul fast float %4500, %4492
  %4503 = fmul fast float %4500, %4493
  %4504 = call float @dx.op.dot3.f32(i32 55, float %4494, float %4495, float %4496, float %4494, float %4495, float %4496)  ; Dot3(ax,ay,az,bx,by,bz)
  %4505 = call float @dx.op.unary.f32(i32 25, float %4504)  ; Rsqrt(value)
  %4506 = fmul fast float %4505, %4494
  %4507 = fmul fast float %4505, %4495
  %4508 = fmul fast float %4505, %4496
  br label %4520

; <label>:4509                                    ; preds = %4428
  %4510 = fdiv fast float 1.000000e+00, %4429
  %4511 = fdiv fast float 1.000000e+00, %4430
  %4512 = call float @dx.op.unary.f32(i32 24, float %4510)  ; Sqrt(value)
  %4513 = fmul fast float %4512, %4410
  %4514 = fmul fast float %4512, %4397
  %4515 = fmul fast float %4512, %4412
  %4516 = call float @dx.op.unary.f32(i32 24, float %4511)  ; Sqrt(value)
  %4517 = fmul fast float %4516, %4414
  %4518 = fmul fast float %4516, %4403
  %4519 = fmul fast float %4516, %4416
  br label %4520

; <label>:4520                                    ; preds = %4509, %4490
  %4521 = phi float [ %4501, %4490 ], [ %4513, %4509 ]
  %4522 = phi float [ %4502, %4490 ], [ %4514, %4509 ]
  %4523 = phi float [ %4503, %4490 ], [ %4515, %4509 ]
  %4524 = phi float [ %4506, %4490 ], [ %4517, %4509 ]
  %4525 = phi float [ %4507, %4490 ], [ %4518, %4509 ]
  %4526 = phi float [ %4508, %4490 ], [ %4519, %4509 ]
  %4527 = phi float [ %4497, %4490 ], [ %4510, %4509 ]
  %4528 = phi float [ %4498, %4490 ], [ %4511, %4509 ]
  %4529 = fmul fast float %4526, %4522
  %4530 = fmul fast float %4525, %4523
  %4531 = fsub fast float %4529, %4530
  %4532 = fmul fast float %4524, %4523
  %4533 = fmul fast float %4526, %4521
  %4534 = fsub fast float %4532, %4533
  %4535 = fmul fast float %4525, %4521
  %4536 = fmul fast float %4524, %4522
  %4537 = fsub fast float %4535, %4536
  %4538 = call float @dx.op.dot3.f32(i32 55, float %4406, float %4391, float %4408, float %4531, float %4534, float %4537)  ; Dot3(ax,ay,az,bx,by,bz)
  %4539 = fcmp fast olt float %4538, 0.000000e+00
  %4540 = fsub fast float -0.000000e+00, %4531
  %4541 = fsub fast float -0.000000e+00, %4534
  %4542 = fsub fast float -0.000000e+00, %4537
  %4543 = select i1 %4539, float %4540, float %4531
  %4544 = select i1 %4539, float %4541, float %4534
  %4545 = select i1 %4539, float %4542, float %4537
  %4546 = call float @dx.op.dot3.f32(i32 55, float %4543, float %4544, float %4545, float %4406, float %4391, float %4408)  ; Dot3(ax,ay,az,bx,by,bz)
  %4547 = call float @dx.op.dot3.f32(i32 55, float %4521, float %4522, float %4523, float %4406, float %4391, float %4408)  ; Dot3(ax,ay,az,bx,by,bz)
  %4548 = fdiv fast float %4547, %4546
  %4549 = call float @dx.op.dot3.f32(i32 55, float %4524, float %4525, float %4526, float %4406, float %4391, float %4408)  ; Dot3(ax,ay,az,bx,by,bz)
  %4550 = fdiv fast float %4549, %4546
  %4551 = fmul fast float %4546, %4546
  %4552 = fmul fast float %4551, %4527
  %4553 = fmul fast float %4551, %4528
  %4554 = fmul fast float %4552, %4553
  %4555 = fmul fast float %4548, %4548
  %4556 = fadd fast float %4555, 1.000000e+00
  %4557 = fmul fast float %4550, %4550
  %4558 = fadd fast float %4557, %4556
  %4559 = fmul fast float %4558, %4554
  %4560 = fsub fast float %4559, %4552
  %4561 = fsub fast float %4560, %4553
  %4562 = fmul fast float %4556, %4552
  %4563 = fsub fast float 1.000000e+00, %4562
  %4564 = fadd fast float %4557, 1.000000e+00
  %4565 = fmul fast float %4564, %4553
  %4566 = fsub fast float %4563, %4565
  %4567 = call float @dx.op.unary.f32(i32 6, float %4554)  ; FAbs(value)
  %4568 = call float @dx.op.unary.f32(i32 6, float %4561)  ; FAbs(value)
  %4569 = call float @dx.op.unary.f32(i32 6, float %4566)  ; FAbs(value)
  %4570 = call float @dx.op.binary.f32(i32 35, float %4567, float %4568)  ; FMax(a,b)
  %4571 = call float @dx.op.binary.f32(i32 35, float %4570, float %4569)  ; FMax(a,b)
  %4572 = call float @dx.op.binary.f32(i32 35, float %4571, float 1.000000e+00)  ; FMax(a,b)
  %4573 = fcmp fast ult float %4572, 0x42A05EF3A0000000
  br i1 %4573, label %4579, label %4574

; <label>:4574                                    ; preds = %4520
  %4575 = fdiv fast float %4554, %4572
  %4576 = fdiv fast float %4561, %4572
  %4577 = fdiv fast float %4566, %4572
  %4578 = fdiv fast float 1.000000e+00, %4572
  br label %4579

; <label>:4579                                    ; preds = %4574, %4520
  %4580 = phi float [ %4575, %4574 ], [ %4554, %4520 ]
  %4581 = phi float [ %4576, %4574 ], [ %4561, %4520 ]
  %4582 = phi float [ %4577, %4574 ], [ %4566, %4520 ]
  %4583 = phi float [ %4578, %4574 ], [ 1.000000e+00, %4520 ]
  %4584 = fmul fast float %4581, 0x3FD5555560000000
  %4585 = fmul fast float %4582, 0x3FD5555560000000
  %4586 = fmul fast float %4585, %4585
  %4587 = fsub fast float %4584, %4586
  %4588 = fmul fast float %4585, %4584
  %4589 = fsub fast float %4580, %4588
  %4590 = fsub fast float -0.000000e+00, %4584
  %4591 = call float @dx.op.dot2.f32(i32 54, float %4585, float %4590, float %4580, float %4584)  ; Dot2(ax,ay,bx,by)
  %4592 = fmul fast float %4587, 4.000000e+00
  %4593 = fsub fast float -0.000000e+00, %4589
  %4594 = call float @dx.op.dot2.f32(i32 54, float %4592, float %4593, float %4591, float %4589)  ; Dot2(ax,ay,bx,by)
  %4595 = call float @dx.op.binary.f32(i32 35, float %4594, float 0.000000e+00)  ; FMax(a,b)
  %4596 = call float @dx.op.binary.f32(i32 36, float %4595, float 0x47EFFFFFE0000000)  ; FMin(a,b)
  %4597 = fmul fast float %4582, 0xBFE5555560000000
  %4598 = fmul fast float %4597, %4587
  %4599 = fadd fast float %4598, %4589
  %4600 = fsub fast float -0.000000e+00, %4599
  %4601 = call float @dx.op.unary.f32(i32 24, float %4596)  ; Sqrt(value)
  %4602 = fdiv fast float %4601, %4600
  %4603 = call float @dx.op.unary.f32(i32 17, float %4602)  ; Atan(value)
  %4604 = fadd fast float %4603, 0x400921FB60000000
  %4605 = fadd fast float %4603, 0xC00921FB60000000
  %4606 = fcmp ogt float %4599, -0.000000e+00
  %4607 = fcmp oeq float %4599, -0.000000e+00
  %4608 = fcmp fast oge float %4601, 0.000000e+00
  %4609 = fcmp fast olt float %4601, 0.000000e+00
  %4610 = and i1 %4606, %4608
  %4611 = select i1 %4610, float %4604, float %4603
  %4612 = and i1 %4606, %4609
  %4613 = select i1 %4612, float %4605, float %4611
  %4614 = and i1 %4607, %4609
  %4615 = and i1 %4607, %4608
  %4616 = fmul fast float %4613, 0x3FD5555560000000
  %4617 = select i1 %4614, float 0xBFE0C15240000000, float %4616
  %4618 = select i1 %4615, float 0x3FE0C15240000000, float %4617
  %4619 = fsub fast float -0.000000e+00, %4587
  %4620 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4619)  ; FMax(a,b)
  %4621 = call float @dx.op.unary.f32(i32 24, float %4620)  ; Sqrt(value)
  %4622 = fmul fast float %4621, 2.000000e+00
  %4623 = call float @dx.op.unary.f32(i32 12, float %4618)  ; Cos(value)
  %4624 = fadd fast float %4618, 0x4000C15240000000
  %4625 = call float @dx.op.unary.f32(i32 12, float %4624)  ; Cos(value)
  %4626 = fadd fast float %4625, %4623
  %4627 = fmul fast float %4622, %4626
  %4628 = fmul fast float %4582, 0x3FE5555560000000
  %4629 = fcmp fast ogt float %4627, %4628
  %4630 = select i1 %4629, float %4623, float %4625
  %4631 = fmul float %4622, %4630
  %4632 = fsub fast float %4631, %4585
  %4633 = fmul fast float %4589, %4580
  %4634 = fmul fast float %4581, 0x3FE5555560000000
  %4635 = fmul fast float %4591, %4634
  %4636 = fsub fast float %4635, %4633
  %4637 = fsub fast float -0.000000e+00, %4636
  %4638 = fmul fast float %4601, %4580
  %4639 = fdiv fast float %4638, %4637
  %4640 = call float @dx.op.unary.f32(i32 17, float %4639)  ; Atan(value)
  %4641 = fadd fast float %4640, 0x400921FB60000000
  %4642 = fadd fast float %4640, 0xC00921FB60000000
  %4643 = fcmp ogt float %4636, -0.000000e+00
  %4644 = fcmp oeq float %4636, -0.000000e+00
  %4645 = fcmp fast oge float %4638, 0.000000e+00
  %4646 = fcmp fast olt float %4638, 0.000000e+00
  %4647 = and i1 %4643, %4645
  %4648 = select i1 %4647, float %4641, float %4640
  %4649 = and i1 %4643, %4646
  %4650 = select i1 %4649, float %4642, float %4648
  %4651 = and i1 %4644, %4646
  %4652 = and i1 %4644, %4645
  %4653 = fmul fast float %4650, 0x3FD5555560000000
  %4654 = select i1 %4651, float 0xBFE0C15240000000, float %4653
  %4655 = select i1 %4652, float 0x3FE0C15240000000, float %4654
  %4656 = fsub fast float -0.000000e+00, %4591
  %4657 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4656)  ; FMax(a,b)
  %4658 = call float @dx.op.unary.f32(i32 24, float %4657)  ; Sqrt(value)
  %4659 = fmul fast float %4658, 2.000000e+00
  %4660 = call float @dx.op.unary.f32(i32 12, float %4655)  ; Cos(value)
  %4661 = fadd fast float %4655, 0x4000C15240000000
  %4662 = call float @dx.op.unary.f32(i32 12, float %4661)  ; Cos(value)
  %4663 = fadd fast float %4662, %4660
  %4664 = fmul fast float %4659, %4663
  %4665 = fcmp fast olt float %4664, %4634
  %4666 = select i1 %4665, float %4660, float %4662
  %4667 = fmul float %4659, %4666
  %4668 = fsub fast float -0.000000e+00, %4580
  %4669 = fadd fast float %4667, %4584
  %4670 = fmul fast float %4632, %4669
  %4671 = fsub fast float -0.000000e+00, %4670
  %4672 = fmul fast float %4583, %4668
  %4673 = fsub fast float %4671, %4672
  %4674 = fmul fast float %4673, %4584
  %4675 = fmul fast float %4585, %4668
  %4676 = fmul fast float %4675, %4632
  %4677 = fsub fast float %4674, %4676
  %4678 = fmul fast float %4673, %4585
  %4679 = fmul fast float %4583, %4584
  %4680 = fmul fast float %4679, %4669
  %4681 = fsub fast float %4680, %4678
  %4682 = fdiv fast float %4668, %4669
  %4683 = fdiv fast float %4677, %4681
  %4684 = fdiv fast float %4632, %4583
  %4685 = fcmp fast olt float %4682, %4684
  %4686 = fcmp fast olt float %4682, %4683
  %4687 = and i1 %4686, %4685
  br i1 %4687, label %4694, label %4688

; <label>:4688                                    ; preds = %4579
  %4689 = fcmp fast olt float %4684, %4683
  %4690 = fcmp fast olt float %4684, %4682
  %4691 = and i1 %4690, %4689
  %4692 = select i1 %4691, float %4684, float %4683
  %4693 = select i1 %4691, float %4683, float %4684
  br label %4694

; <label>:4694                                    ; preds = %4688, %4579
  %4695 = phi float [ %4683, %4579 ], [ %4682, %4688 ]
  %4696 = phi float [ %4682, %4579 ], [ %4692, %4688 ]
  %4697 = phi float [ %4684, %4579 ], [ %4693, %4688 ]
  %4698 = fmul fast float %4552, %4548
  %4699 = fsub fast float %4552, %4696
  %4700 = fdiv fast float %4698, %4699
  %4701 = fmul fast float %4550, %4553
  %4702 = fsub fast float %4553, %4696
  %4703 = fdiv fast float %4701, %4702
  %4704 = fmul fast float %4700, %4521
  %4705 = call float @dx.op.tertiary.f32(i32 46, float %4703, float %4524, float %4704)  ; FMad(a,b,c)
  %4706 = fadd fast float %4705, %4543
  %4707 = fmul fast float %4700, %4522
  %4708 = call float @dx.op.tertiary.f32(i32 46, float %4703, float %4525, float %4707)  ; FMad(a,b,c)
  %4709 = fadd fast float %4708, %4544
  %4710 = fmul fast float %4700, %4523
  %4711 = call float @dx.op.tertiary.f32(i32 46, float %4703, float %4526, float %4710)  ; FMad(a,b,c)
  %4712 = fadd fast float %4711, %4545
  %4713 = call float @dx.op.dot3.f32(i32 55, float %4706, float %4709, float %4712, float %4706, float %4709, float %4712)  ; Dot3(ax,ay,az,bx,by,bz)
  %4714 = call float @dx.op.unary.f32(i32 25, float %4713)  ; Rsqrt(value)
  %4715 = fsub fast float -0.000000e+00, %4696
  %4716 = fdiv fast float %4715, %4697
  %4717 = call float @dx.op.unary.f32(i32 24, float %4716)  ; Sqrt(value)
  %4718 = fdiv fast float %4715, %4695
  %4719 = call float @dx.op.unary.f32(i32 24, float %4718)  ; Sqrt(value)
  %4720 = fmul fast float %4719, %4717
  %4721 = fmul fast float %4717, %4717
  %4722 = fadd fast float %4721, 1.000000e+00
  %4723 = fmul fast float %4719, %4719
  %4724 = fadd fast float %4723, 1.000000e+00
  %4725 = fmul fast float %4724, %4722
  %4726 = call float @dx.op.unary.f32(i32 25, float %4725)  ; Rsqrt(value)
  %4727 = fmul fast float %4720, %4726
  %4728 = fmul fast float %4712, 0x3FDFC00000000000
  %4729 = fmul fast float %4728, %4714
  %4730 = fmul fast float %4727, 9.921875e-01
  %4731 = fadd fast float %4729, 5.000000e-01
  %4732 = fadd fast float %4730, 3.906250e-03
  %4733 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %24, %dx.types.Handle %40, float %4731, float %4732, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %4734 = extractvalue %dx.types.ResRet.f32 %4733, 3
  %4735 = fmul fast float %4734, %4727
  br label %4736

; <label>:4736                                    ; preds = %4694, %4338
  %4737 = phi float [ %4735, %4694 ], [ 0.000000e+00, %4338 ]
  %4738 = fmul fast float %4390, %3327
  %4739 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %4392, float %4738)  ; FMad(a,b,c)
  %4740 = fmul fast float %4390, %3328
  %4741 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %4392, float %4740)  ; FMad(a,b,c)
  %4742 = fmul fast float %4396, %3327
  %4743 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %4398, float %4742)  ; FMad(a,b,c)
  %4744 = fmul fast float %4396, %3328
  %4745 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %4398, float %4744)  ; FMad(a,b,c)
  %4746 = fmul fast float %4402, %3327
  %4747 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %4404, float %4746)  ; FMad(a,b,c)
  %4748 = fmul fast float %4402, %3328
  %4749 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %4404, float %4748)  ; FMad(a,b,c)
  %4750 = fmul fast float %4749, %4397
  %4751 = fmul fast float %4745, %4403
  %4752 = fsub fast float %4750, %4751
  %4753 = fmul fast float %4747, %4745
  %4754 = fmul fast float %4749, %4743
  %4755 = fsub fast float %4753, %4754
  %4756 = fmul fast float %4743, %4403
  %4757 = fmul fast float %4747, %4397
  %4758 = fsub fast float %4756, %4757
  %4759 = call float @dx.op.dot3.f32(i32 55, float %4752, float %4755, float %4758, float %4739, float %4391, float %4741)  ; Dot3(ax,ay,az,bx,by,bz)
  %4760 = fcmp fast olt float %4759, 0x3EE4F8B580000000
  br i1 %4760, label %5069, label %4761

; <label>:4761                                    ; preds = %4736
  %4762 = call float @dx.op.dot3.f32(i32 55, float %4743, float %4397, float %4745, float %4743, float %4397, float %4745)  ; Dot3(ax,ay,az,bx,by,bz)
  %4763 = call float @dx.op.dot3.f32(i32 55, float %4747, float %4403, float %4749, float %4747, float %4403, float %4749)  ; Dot3(ax,ay,az,bx,by,bz)
  %4764 = call float @dx.op.dot3.f32(i32 55, float %4743, float %4397, float %4745, float %4747, float %4403, float %4749)  ; Dot3(ax,ay,az,bx,by,bz)
  %4765 = call float @dx.op.unary.f32(i32 6, float %4764)  ; FAbs(value)
  %4766 = fmul fast float %4763, %4762
  %4767 = call float @dx.op.unary.f32(i32 24, float %4766)  ; Sqrt(value)
  %4768 = fdiv fast float %4765, %4767
  %4769 = fcmp fast ogt float %4768, 0x3F4A36E2E0000000
  br i1 %4769, label %4770, label %4842

; <label>:4770                                    ; preds = %4761
  %4771 = fadd fast float %4763, %4762
  %4772 = fmul fast float %4764, %4764
  %4773 = fsub fast float %4766, %4772
  %4774 = call float @dx.op.unary.f32(i32 24, float %4773)  ; Sqrt(value)
  %4775 = fmul fast float %4774, 2.000000e+00
  %4776 = fsub fast float %4771, %4775
  %4777 = call float @dx.op.unary.f32(i32 24, float %4776)  ; Sqrt(value)
  %4778 = fadd fast float %4775, %4771
  %4779 = call float @dx.op.unary.f32(i32 24, float %4778)  ; Sqrt(value)
  %4780 = fadd fast float %4779, %4777
  %4781 = fmul fast float %4780, 5.000000e-01
  %4782 = fmul fast float %4781, %4781
  %4783 = fsub fast float %4777, %4779
  %4784 = fmul fast float %4783, 5.000000e-01
  %4785 = fmul fast float %4784, %4784
  %4786 = fcmp fast ogt float %4762, %4763
  br i1 %4786, label %4787, label %4805

; <label>:4787                                    ; preds = %4770
  %4788 = fmul fast float %4764, %4743
  %4789 = fmul fast float %4764, %4397
  %4790 = fmul fast float %4764, %4745
  %4791 = fsub fast float %4782, %4762
  %4792 = fmul fast float %4791, %4747
  %4793 = fmul fast float %4791, %4403
  %4794 = fmul fast float %4791, %4749
  %4795 = fadd fast float %4792, %4788
  %4796 = fadd fast float %4793, %4789
  %4797 = fadd fast float %4794, %4790
  %4798 = fsub fast float %4785, %4762
  %4799 = fmul fast float %4798, %4747
  %4800 = fmul fast float %4798, %4403
  %4801 = fmul fast float %4798, %4749
  %4802 = fadd fast float %4799, %4788
  %4803 = fadd fast float %4800, %4789
  %4804 = fadd fast float %4801, %4790
  br label %4823

; <label>:4805                                    ; preds = %4770
  %4806 = fmul fast float %4764, %4747
  %4807 = fmul fast float %4764, %4403
  %4808 = fmul fast float %4764, %4749
  %4809 = fsub fast float %4782, %4763
  %4810 = fmul fast float %4809, %4743
  %4811 = fmul fast float %4809, %4397
  %4812 = fmul fast float %4809, %4745
  %4813 = fadd fast float %4810, %4806
  %4814 = fadd fast float %4811, %4807
  %4815 = fadd fast float %4812, %4808
  %4816 = fsub fast float %4785, %4763
  %4817 = fmul fast float %4816, %4743
  %4818 = fmul fast float %4816, %4397
  %4819 = fmul fast float %4816, %4745
  %4820 = fadd fast float %4817, %4806
  %4821 = fadd fast float %4818, %4807
  %4822 = fadd fast float %4819, %4808
  br label %4823

; <label>:4823                                    ; preds = %4805, %4787
  %4824 = phi float [ %4795, %4787 ], [ %4813, %4805 ]
  %4825 = phi float [ %4796, %4787 ], [ %4814, %4805 ]
  %4826 = phi float [ %4797, %4787 ], [ %4815, %4805 ]
  %4827 = phi float [ %4802, %4787 ], [ %4820, %4805 ]
  %4828 = phi float [ %4803, %4787 ], [ %4821, %4805 ]
  %4829 = phi float [ %4804, %4787 ], [ %4822, %4805 ]
  %4830 = fdiv fast float 1.000000e+00, %4782
  %4831 = fdiv fast float 1.000000e+00, %4785
  %4832 = call float @dx.op.dot3.f32(i32 55, float %4824, float %4825, float %4826, float %4824, float %4825, float %4826)  ; Dot3(ax,ay,az,bx,by,bz)
  %4833 = call float @dx.op.unary.f32(i32 25, float %4832)  ; Rsqrt(value)
  %4834 = fmul fast float %4833, %4824
  %4835 = fmul fast float %4833, %4825
  %4836 = fmul fast float %4833, %4826
  %4837 = call float @dx.op.dot3.f32(i32 55, float %4827, float %4828, float %4829, float %4827, float %4828, float %4829)  ; Dot3(ax,ay,az,bx,by,bz)
  %4838 = call float @dx.op.unary.f32(i32 25, float %4837)  ; Rsqrt(value)
  %4839 = fmul fast float %4838, %4827
  %4840 = fmul fast float %4838, %4828
  %4841 = fmul fast float %4838, %4829
  br label %4853

; <label>:4842                                    ; preds = %4761
  %4843 = fdiv fast float 1.000000e+00, %4762
  %4844 = fdiv fast float 1.000000e+00, %4763
  %4845 = call float @dx.op.unary.f32(i32 24, float %4843)  ; Sqrt(value)
  %4846 = fmul fast float %4845, %4743
  %4847 = fmul fast float %4845, %4397
  %4848 = fmul fast float %4845, %4745
  %4849 = call float @dx.op.unary.f32(i32 24, float %4844)  ; Sqrt(value)
  %4850 = fmul fast float %4849, %4747
  %4851 = fmul fast float %4849, %4403
  %4852 = fmul fast float %4849, %4749
  br label %4853

; <label>:4853                                    ; preds = %4842, %4823
  %4854 = phi float [ %4834, %4823 ], [ %4846, %4842 ]
  %4855 = phi float [ %4835, %4823 ], [ %4847, %4842 ]
  %4856 = phi float [ %4836, %4823 ], [ %4848, %4842 ]
  %4857 = phi float [ %4839, %4823 ], [ %4850, %4842 ]
  %4858 = phi float [ %4840, %4823 ], [ %4851, %4842 ]
  %4859 = phi float [ %4841, %4823 ], [ %4852, %4842 ]
  %4860 = phi float [ %4830, %4823 ], [ %4843, %4842 ]
  %4861 = phi float [ %4831, %4823 ], [ %4844, %4842 ]
  %4862 = fmul fast float %4859, %4855
  %4863 = fmul fast float %4858, %4856
  %4864 = fsub fast float %4862, %4863
  %4865 = fmul fast float %4857, %4856
  %4866 = fmul fast float %4859, %4854
  %4867 = fsub fast float %4865, %4866
  %4868 = fmul fast float %4858, %4854
  %4869 = fmul fast float %4857, %4855
  %4870 = fsub fast float %4868, %4869
  %4871 = call float @dx.op.dot3.f32(i32 55, float %4739, float %4391, float %4741, float %4864, float %4867, float %4870)  ; Dot3(ax,ay,az,bx,by,bz)
  %4872 = fcmp fast olt float %4871, 0.000000e+00
  %4873 = fsub fast float -0.000000e+00, %4864
  %4874 = fsub fast float -0.000000e+00, %4867
  %4875 = fsub fast float -0.000000e+00, %4870
  %4876 = select i1 %4872, float %4873, float %4864
  %4877 = select i1 %4872, float %4874, float %4867
  %4878 = select i1 %4872, float %4875, float %4870
  %4879 = call float @dx.op.dot3.f32(i32 55, float %4876, float %4877, float %4878, float %4739, float %4391, float %4741)  ; Dot3(ax,ay,az,bx,by,bz)
  %4880 = call float @dx.op.dot3.f32(i32 55, float %4854, float %4855, float %4856, float %4739, float %4391, float %4741)  ; Dot3(ax,ay,az,bx,by,bz)
  %4881 = fdiv fast float %4880, %4879
  %4882 = call float @dx.op.dot3.f32(i32 55, float %4857, float %4858, float %4859, float %4739, float %4391, float %4741)  ; Dot3(ax,ay,az,bx,by,bz)
  %4883 = fdiv fast float %4882, %4879
  %4884 = fmul fast float %4879, %4879
  %4885 = fmul fast float %4884, %4860
  %4886 = fmul fast float %4884, %4861
  %4887 = fmul fast float %4885, %4886
  %4888 = fmul fast float %4881, %4881
  %4889 = fadd fast float %4888, 1.000000e+00
  %4890 = fmul fast float %4883, %4883
  %4891 = fadd fast float %4890, %4889
  %4892 = fmul fast float %4891, %4887
  %4893 = fsub fast float %4892, %4885
  %4894 = fsub fast float %4893, %4886
  %4895 = fmul fast float %4889, %4885
  %4896 = fsub fast float 1.000000e+00, %4895
  %4897 = fadd fast float %4890, 1.000000e+00
  %4898 = fmul fast float %4897, %4886
  %4899 = fsub fast float %4896, %4898
  %4900 = call float @dx.op.unary.f32(i32 6, float %4887)  ; FAbs(value)
  %4901 = call float @dx.op.unary.f32(i32 6, float %4894)  ; FAbs(value)
  %4902 = call float @dx.op.unary.f32(i32 6, float %4899)  ; FAbs(value)
  %4903 = call float @dx.op.binary.f32(i32 35, float %4900, float %4901)  ; FMax(a,b)
  %4904 = call float @dx.op.binary.f32(i32 35, float %4903, float %4902)  ; FMax(a,b)
  %4905 = call float @dx.op.binary.f32(i32 35, float %4904, float 1.000000e+00)  ; FMax(a,b)
  %4906 = fcmp fast ult float %4905, 0x42A05EF3A0000000
  br i1 %4906, label %4912, label %4907

; <label>:4907                                    ; preds = %4853
  %4908 = fdiv fast float %4887, %4905
  %4909 = fdiv fast float %4894, %4905
  %4910 = fdiv fast float %4899, %4905
  %4911 = fdiv fast float 1.000000e+00, %4905
  br label %4912

; <label>:4912                                    ; preds = %4907, %4853
  %4913 = phi float [ %4908, %4907 ], [ %4887, %4853 ]
  %4914 = phi float [ %4909, %4907 ], [ %4894, %4853 ]
  %4915 = phi float [ %4910, %4907 ], [ %4899, %4853 ]
  %4916 = phi float [ %4911, %4907 ], [ 1.000000e+00, %4853 ]
  %4917 = fmul fast float %4914, 0x3FD5555560000000
  %4918 = fmul fast float %4915, 0x3FD5555560000000
  %4919 = fmul fast float %4918, %4918
  %4920 = fsub fast float %4917, %4919
  %4921 = fmul fast float %4918, %4917
  %4922 = fsub fast float %4913, %4921
  %4923 = fsub fast float -0.000000e+00, %4917
  %4924 = call float @dx.op.dot2.f32(i32 54, float %4918, float %4923, float %4913, float %4917)  ; Dot2(ax,ay,bx,by)
  %4925 = fmul fast float %4920, 4.000000e+00
  %4926 = fsub fast float -0.000000e+00, %4922
  %4927 = call float @dx.op.dot2.f32(i32 54, float %4925, float %4926, float %4924, float %4922)  ; Dot2(ax,ay,bx,by)
  %4928 = call float @dx.op.binary.f32(i32 35, float %4927, float 0.000000e+00)  ; FMax(a,b)
  %4929 = call float @dx.op.binary.f32(i32 36, float %4928, float 0x47EFFFFFE0000000)  ; FMin(a,b)
  %4930 = fmul fast float %4915, 0xBFE5555560000000
  %4931 = fmul fast float %4930, %4920
  %4932 = fadd fast float %4931, %4922
  %4933 = fsub fast float -0.000000e+00, %4932
  %4934 = call float @dx.op.unary.f32(i32 24, float %4929)  ; Sqrt(value)
  %4935 = fdiv fast float %4934, %4933
  %4936 = call float @dx.op.unary.f32(i32 17, float %4935)  ; Atan(value)
  %4937 = fadd fast float %4936, 0x400921FB60000000
  %4938 = fadd fast float %4936, 0xC00921FB60000000
  %4939 = fcmp ogt float %4932, -0.000000e+00
  %4940 = fcmp oeq float %4932, -0.000000e+00
  %4941 = fcmp fast oge float %4934, 0.000000e+00
  %4942 = fcmp fast olt float %4934, 0.000000e+00
  %4943 = and i1 %4939, %4941
  %4944 = select i1 %4943, float %4937, float %4936
  %4945 = and i1 %4939, %4942
  %4946 = select i1 %4945, float %4938, float %4944
  %4947 = and i1 %4940, %4942
  %4948 = and i1 %4940, %4941
  %4949 = fmul fast float %4946, 0x3FD5555560000000
  %4950 = select i1 %4947, float 0xBFE0C15240000000, float %4949
  %4951 = select i1 %4948, float 0x3FE0C15240000000, float %4950
  %4952 = fsub fast float -0.000000e+00, %4920
  %4953 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4952)  ; FMax(a,b)
  %4954 = call float @dx.op.unary.f32(i32 24, float %4953)  ; Sqrt(value)
  %4955 = fmul fast float %4954, 2.000000e+00
  %4956 = call float @dx.op.unary.f32(i32 12, float %4951)  ; Cos(value)
  %4957 = fadd fast float %4951, 0x4000C15240000000
  %4958 = call float @dx.op.unary.f32(i32 12, float %4957)  ; Cos(value)
  %4959 = fadd fast float %4958, %4956
  %4960 = fmul fast float %4955, %4959
  %4961 = fmul fast float %4915, 0x3FE5555560000000
  %4962 = fcmp fast ogt float %4960, %4961
  %4963 = select i1 %4962, float %4956, float %4958
  %4964 = fmul float %4955, %4963
  %4965 = fsub fast float %4964, %4918
  %4966 = fmul fast float %4922, %4913
  %4967 = fmul fast float %4914, 0x3FE5555560000000
  %4968 = fmul fast float %4924, %4967
  %4969 = fsub fast float %4968, %4966
  %4970 = fsub fast float -0.000000e+00, %4969
  %4971 = fmul fast float %4934, %4913
  %4972 = fdiv fast float %4971, %4970
  %4973 = call float @dx.op.unary.f32(i32 17, float %4972)  ; Atan(value)
  %4974 = fadd fast float %4973, 0x400921FB60000000
  %4975 = fadd fast float %4973, 0xC00921FB60000000
  %4976 = fcmp ogt float %4969, -0.000000e+00
  %4977 = fcmp oeq float %4969, -0.000000e+00
  %4978 = fcmp fast oge float %4971, 0.000000e+00
  %4979 = fcmp fast olt float %4971, 0.000000e+00
  %4980 = and i1 %4976, %4978
  %4981 = select i1 %4980, float %4974, float %4973
  %4982 = and i1 %4976, %4979
  %4983 = select i1 %4982, float %4975, float %4981
  %4984 = and i1 %4977, %4979
  %4985 = and i1 %4977, %4978
  %4986 = fmul fast float %4983, 0x3FD5555560000000
  %4987 = select i1 %4984, float 0xBFE0C15240000000, float %4986
  %4988 = select i1 %4985, float 0x3FE0C15240000000, float %4987
  %4989 = fsub fast float -0.000000e+00, %4924
  %4990 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4989)  ; FMax(a,b)
  %4991 = call float @dx.op.unary.f32(i32 24, float %4990)  ; Sqrt(value)
  %4992 = fmul fast float %4991, 2.000000e+00
  %4993 = call float @dx.op.unary.f32(i32 12, float %4988)  ; Cos(value)
  %4994 = fadd fast float %4988, 0x4000C15240000000
  %4995 = call float @dx.op.unary.f32(i32 12, float %4994)  ; Cos(value)
  %4996 = fadd fast float %4995, %4993
  %4997 = fmul fast float %4992, %4996
  %4998 = fcmp fast olt float %4997, %4967
  %4999 = select i1 %4998, float %4993, float %4995
  %5000 = fmul float %4992, %4999
  %5001 = fsub fast float -0.000000e+00, %4913
  %5002 = fadd fast float %5000, %4917
  %5003 = fmul fast float %4965, %5002
  %5004 = fsub fast float -0.000000e+00, %5003
  %5005 = fmul fast float %4916, %5001
  %5006 = fsub fast float %5004, %5005
  %5007 = fmul fast float %5006, %4917
  %5008 = fmul fast float %4918, %5001
  %5009 = fmul fast float %5008, %4965
  %5010 = fsub fast float %5007, %5009
  %5011 = fmul fast float %5006, %4918
  %5012 = fmul fast float %4916, %4917
  %5013 = fmul fast float %5012, %5002
  %5014 = fsub fast float %5013, %5011
  %5015 = fdiv fast float %5001, %5002
  %5016 = fdiv fast float %5010, %5014
  %5017 = fdiv fast float %4965, %4916
  %5018 = fcmp fast olt float %5015, %5017
  %5019 = fcmp fast olt float %5015, %5016
  %5020 = and i1 %5019, %5018
  br i1 %5020, label %5027, label %5021

; <label>:5021                                    ; preds = %4912
  %5022 = fcmp fast olt float %5017, %5016
  %5023 = fcmp fast olt float %5017, %5015
  %5024 = and i1 %5023, %5022
  %5025 = select i1 %5024, float %5017, float %5016
  %5026 = select i1 %5024, float %5016, float %5017
  br label %5027

; <label>:5027                                    ; preds = %5021, %4912
  %5028 = phi float [ %5016, %4912 ], [ %5015, %5021 ]
  %5029 = phi float [ %5015, %4912 ], [ %5025, %5021 ]
  %5030 = phi float [ %5017, %4912 ], [ %5026, %5021 ]
  %5031 = fmul fast float %4885, %4881
  %5032 = fsub fast float %4885, %5029
  %5033 = fdiv fast float %5031, %5032
  %5034 = fmul fast float %4883, %4886
  %5035 = fsub fast float %4886, %5029
  %5036 = fdiv fast float %5034, %5035
  %5037 = fmul fast float %5033, %4854
  %5038 = call float @dx.op.tertiary.f32(i32 46, float %5036, float %4857, float %5037)  ; FMad(a,b,c)
  %5039 = fadd fast float %5038, %4876
  %5040 = fmul fast float %5033, %4855
  %5041 = call float @dx.op.tertiary.f32(i32 46, float %5036, float %4858, float %5040)  ; FMad(a,b,c)
  %5042 = fadd fast float %5041, %4877
  %5043 = fmul fast float %5033, %4856
  %5044 = call float @dx.op.tertiary.f32(i32 46, float %5036, float %4859, float %5043)  ; FMad(a,b,c)
  %5045 = fadd fast float %5044, %4878
  %5046 = call float @dx.op.dot3.f32(i32 55, float %5039, float %5042, float %5045, float %5039, float %5042, float %5045)  ; Dot3(ax,ay,az,bx,by,bz)
  %5047 = call float @dx.op.unary.f32(i32 25, float %5046)  ; Rsqrt(value)
  %5048 = fsub fast float -0.000000e+00, %5029
  %5049 = fdiv fast float %5048, %5030
  %5050 = call float @dx.op.unary.f32(i32 24, float %5049)  ; Sqrt(value)
  %5051 = fdiv fast float %5048, %5028
  %5052 = call float @dx.op.unary.f32(i32 24, float %5051)  ; Sqrt(value)
  %5053 = fmul fast float %5052, %5050
  %5054 = fmul fast float %5050, %5050
  %5055 = fadd fast float %5054, 1.000000e+00
  %5056 = fmul fast float %5052, %5052
  %5057 = fadd fast float %5056, 1.000000e+00
  %5058 = fmul fast float %5057, %5055
  %5059 = call float @dx.op.unary.f32(i32 25, float %5058)  ; Rsqrt(value)
  %5060 = fmul fast float %5053, %5059
  %5061 = fmul fast float %5045, 0x3FDFC00000000000
  %5062 = fmul fast float %5061, %5047
  %5063 = fmul fast float %5060, 9.921875e-01
  %5064 = fadd fast float %5062, 5.000000e-01
  %5065 = fadd fast float %5063, 3.906250e-03
  %5066 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %24, %dx.types.Handle %40, float %5064, float %5065, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %5067 = extractvalue %dx.types.ResRet.f32 %5066, 3
  %5068 = fmul fast float %5067, %5060
  br label %5069

; <label>:5069                                    ; preds = %5027, %4736
  %5070 = phi float [ %5068, %5027 ], [ 0.000000e+00, %4736 ]
  %5071 = and i32 %3459, 32
  %5072 = icmp eq i32 %5071, 0
  br i1 %5072, label %5077, label %5073

; <label>:5073                                    ; preds = %5069
  %5074 = fmul fast float %3287, 0x400921FB60000000
  %5075 = fmul fast float %5074, %4336
  %5076 = fmul fast float %5075, %4737
  br label %5077

; <label>:5077                                    ; preds = %5073, %5069
  %5078 = phi float [ %5076, %5073 ], [ 0.000000e+00, %5069 ]
  %5079 = and i32 %3459, 64
  %5080 = icmp eq i32 %5079, 0
  br i1 %5080, label %5085, label %5081

; <label>:5081                                    ; preds = %5077
  %5082 = fmul fast float %3290, 0x400921FB60000000
  %5083 = fmul fast float %5082, %4336
  %5084 = fmul fast float %5083, %5070
  br label %5085

; <label>:5085                                    ; preds = %5081, %5077
  %5086 = phi float [ %5084, %5081 ], [ 0.000000e+00, %5077 ]
  %5087 = fmul fast float %5078, %3474
  %5088 = fmul fast float %5078, %3475
  %5089 = fmul fast float %5078, %3476
  %5090 = fmul fast float %5086, %3474
  %5091 = fmul fast float %5086, %3475
  %5092 = fmul fast float %5086, %3476
  br label %5093

; <label>:5093                                    ; preds = %5085, %4318
  %5094 = phi float [ %5087, %5085 ], [ 0.000000e+00, %4318 ]
  %5095 = phi float [ %5088, %5085 ], [ 0.000000e+00, %4318 ]
  %5096 = phi float [ %5089, %5085 ], [ 0.000000e+00, %4318 ]
  %5097 = phi float [ %5090, %5085 ], [ 0.000000e+00, %4318 ]
  %5098 = phi float [ %5091, %5085 ], [ 0.000000e+00, %4318 ]
  %5099 = phi float [ %5092, %5085 ], [ 0.000000e+00, %4318 ]
  %5100 = zext i1 %4337 to i32
  br label %6175

; <label>:5101                                    ; preds = %4316
  %5102 = icmp eq i32 %4097, 1
  br i1 %5102, label %5103, label %5663

; <label>:5103                                    ; preds = %5101
  %5104 = fmul fast float %3504, 5.000000e-01
  %5105 = fmul fast float %5104, %3507
  %5106 = fmul fast float %5104, %3508
  %5107 = fmul fast float %5104, %3509
  %5108 = fsub fast float %3466, %5105
  %5109 = fsub fast float %3467, %5106
  %5110 = fsub fast float %3468, %5107
  %5111 = fmul fast float %3507, %3504
  %5112 = fmul fast float %3508, %3504
  %5113 = fmul fast float %3509, %3504
  %5114 = fsub fast float %565, %5108
  %5115 = fsub fast float %566, %5109
  %5116 = fsub fast float %567, %5110
  %5117 = call float @dx.op.dot3.f32(i32 55, float %5114, float %5115, float %5116, float %5111, float %5112, float %5113)  ; Dot3(ax,ay,az,bx,by,bz)
  %5118 = call float @dx.op.dot3.f32(i32 55, float %5111, float %5112, float %5113, float %5111, float %5112, float %5113)  ; Dot3(ax,ay,az,bx,by,bz)
  %5119 = fdiv fast float %5117, %5118
  %5120 = call float @dx.op.unary.f32(i32 7, float %5119)  ; Saturate(value)
  %5121 = fmul fast float %5120, %5111
  %5122 = fmul fast float %5120, %5112
  %5123 = fmul fast float %5120, %5113
  %5124 = fsub fast float %5108, %565
  %5125 = fadd fast float %5121, %5124
  %5126 = fsub fast float %5109, %566
  %5127 = fadd fast float %5122, %5126
  %5128 = fsub fast float %5110, %567
  %5129 = fadd fast float %5123, %5128
  %5130 = call float @dx.op.dot3.f32(i32 55, float %5125, float %5127, float %5129, float %5125, float %5127, float %5129)  ; Dot3(ax,ay,az,bx,by,bz)
  %5131 = call float @dx.op.unary.f32(i32 25, float %5130)  ; Rsqrt(value)
  %5132 = fmul fast float %5125, %5131
  %5133 = fmul fast float %5127, %5131
  %5134 = fmul fast float %5129, %5131
  %5135 = call float @dx.op.dot3.f32(i32 55, float %5132, float %5133, float %5134, float %2879, float %2880, float %2881)  ; Dot3(ax,ay,az,bx,by,bz)
  %5136 = fcmp fast ogt float %5135, 0.000000e+00
  %5137 = fmul fast float %4091, %3471
  %5138 = fmul fast float %5137, %5137
  %5139 = fsub fast float 1.000000e+00, %5138
  %5140 = call float @dx.op.unary.f32(i32 7, float %5139)  ; Saturate(value)
  %5141 = fmul fast float %5140, %5140
  %5142 = fcmp fast ogt float %5141, 0.000000e+00
  %5143 = and i1 %5136, %5142
  br i1 %5143, label %5144, label %5655

; <label>:5144                                    ; preds = %5103
  %5145 = fmul fast float %5119, %5111
  %5146 = fmul fast float %5119, %5112
  %5147 = fmul fast float %5119, %5113
  %5148 = fadd fast float %5145, %5124
  %5149 = fadd fast float %5146, %5126
  %5150 = fadd fast float %5147, %5128
  %5151 = call float @dx.op.dot3.f32(i32 55, float %5148, float %5149, float %5150, float %5148, float %5149, float %5150)  ; Dot3(ax,ay,az,bx,by,bz)
  %5152 = call float @dx.op.unary.f32(i32 25, float %5151)  ; Rsqrt(value)
  %5153 = fmul fast float %5148, %5152
  %5154 = fsub fast float -0.000000e+00, %5153
  %5155 = fmul fast float %5149, %5152
  %5156 = fsub fast float -0.000000e+00, %5155
  %5157 = fmul fast float %5150, %5152
  %5158 = fsub fast float -0.000000e+00, %5157
  %5159 = fmul fast float %3508, %5158
  %5160 = fmul fast float %3509, %5156
  %5161 = fsub fast float %5159, %5160
  %5162 = fmul fast float %3509, %5154
  %5163 = fmul fast float %3507, %5158
  %5164 = fsub fast float %5162, %5163
  %5165 = fmul fast float %3507, %5156
  %5166 = fmul fast float %3508, %5154
  %5167 = fsub fast float %5165, %5166
  %5168 = fmul fast float %3496, 5.000000e-01
  %5169 = fmul fast float %5161, %5168
  %5170 = fmul fast float %5164, %5168
  %5171 = fmul fast float %5167, %5168
  %5172 = fsub fast float %4088, %5105
  %5173 = fsub fast float %4089, %5106
  %5174 = fsub fast float %4090, %5107
  %5175 = fsub fast float %5172, %5169
  %5176 = fsub fast float %5173, %5170
  %5177 = fsub fast float %5174, %5171
  %5178 = fadd fast float %5105, %4088
  %5179 = fadd fast float %5106, %4089
  %5180 = fadd fast float %5107, %4090
  %5181 = fsub fast float %5178, %5169
  %5182 = fsub fast float %5179, %5170
  %5183 = fsub fast float %5180, %5171
  %5184 = fadd fast float %5169, %5178
  %5185 = fadd fast float %5170, %5179
  %5186 = fadd fast float %5171, %5180
  %5187 = fadd fast float %5169, %5172
  %5188 = fadd fast float %5170, %5173
  %5189 = fadd fast float %5171, %5174
  %5190 = fmul fast float %5175, %3299
  %5191 = call float @dx.op.tertiary.f32(i32 46, float %5176, float %3300, float %5190)  ; FMad(a,b,c)
  %5192 = call float @dx.op.tertiary.f32(i32 46, float %5177, float %3301, float %5191)  ; FMad(a,b,c)
  %5193 = fmul fast float %5175, %3304
  %5194 = call float @dx.op.tertiary.f32(i32 46, float %5176, float %3307, float %5193)  ; FMad(a,b,c)
  %5195 = call float @dx.op.tertiary.f32(i32 46, float %5177, float %3310, float %5194)  ; FMad(a,b,c)
  %5196 = fmul fast float %5175, %2879
  %5197 = call float @dx.op.tertiary.f32(i32 46, float %5176, float %2880, float %5196)  ; FMad(a,b,c)
  %5198 = call float @dx.op.tertiary.f32(i32 46, float %5177, float %2881, float %5197)  ; FMad(a,b,c)
  %5199 = fmul fast float %5181, %3299
  %5200 = call float @dx.op.tertiary.f32(i32 46, float %5182, float %3300, float %5199)  ; FMad(a,b,c)
  %5201 = call float @dx.op.tertiary.f32(i32 46, float %5183, float %3301, float %5200)  ; FMad(a,b,c)
  %5202 = fmul fast float %5181, %3304
  %5203 = call float @dx.op.tertiary.f32(i32 46, float %5182, float %3307, float %5202)  ; FMad(a,b,c)
  %5204 = call float @dx.op.tertiary.f32(i32 46, float %5183, float %3310, float %5203)  ; FMad(a,b,c)
  %5205 = fmul fast float %5181, %2879
  %5206 = call float @dx.op.tertiary.f32(i32 46, float %5182, float %2880, float %5205)  ; FMad(a,b,c)
  %5207 = call float @dx.op.tertiary.f32(i32 46, float %5183, float %2881, float %5206)  ; FMad(a,b,c)
  %5208 = fmul fast float %5184, %3299
  %5209 = call float @dx.op.tertiary.f32(i32 46, float %5185, float %3300, float %5208)  ; FMad(a,b,c)
  %5210 = call float @dx.op.tertiary.f32(i32 46, float %5186, float %3301, float %5209)  ; FMad(a,b,c)
  %5211 = fmul fast float %5184, %3304
  %5212 = call float @dx.op.tertiary.f32(i32 46, float %5185, float %3307, float %5211)  ; FMad(a,b,c)
  %5213 = call float @dx.op.tertiary.f32(i32 46, float %5186, float %3310, float %5212)  ; FMad(a,b,c)
  %5214 = fmul fast float %5184, %2879
  %5215 = call float @dx.op.tertiary.f32(i32 46, float %5185, float %2880, float %5214)  ; FMad(a,b,c)
  %5216 = call float @dx.op.tertiary.f32(i32 46, float %5186, float %2881, float %5215)  ; FMad(a,b,c)
  %5217 = fmul fast float %5187, %3299
  %5218 = call float @dx.op.tertiary.f32(i32 46, float %5188, float %3300, float %5217)  ; FMad(a,b,c)
  %5219 = call float @dx.op.tertiary.f32(i32 46, float %5189, float %3301, float %5218)  ; FMad(a,b,c)
  %5220 = fmul fast float %5187, %3304
  %5221 = call float @dx.op.tertiary.f32(i32 46, float %5188, float %3307, float %5220)  ; FMad(a,b,c)
  %5222 = call float @dx.op.tertiary.f32(i32 46, float %5189, float %3310, float %5221)  ; FMad(a,b,c)
  %5223 = fmul fast float %5187, %2879
  %5224 = call float @dx.op.tertiary.f32(i32 46, float %5188, float %2880, float %5223)  ; FMad(a,b,c)
  %5225 = call float @dx.op.tertiary.f32(i32 46, float %5189, float %2881, float %5224)  ; FMad(a,b,c)
  %5226 = fmul fast float %5192, %3322
  %5227 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5198, float %5226)  ; FMad(a,b,c)
  %5228 = fmul fast float %5192, %3323
  %5229 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5198, float %5228)  ; FMad(a,b,c)
  %5230 = fmul fast float %5201, %3322
  %5231 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5207, float %5230)  ; FMad(a,b,c)
  %5232 = fmul fast float %5201, %3323
  %5233 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5207, float %5232)  ; FMad(a,b,c)
  %5234 = fmul fast float %5210, %3322
  %5235 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5216, float %5234)  ; FMad(a,b,c)
  %5236 = fmul fast float %5210, %3323
  %5237 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5216, float %5236)  ; FMad(a,b,c)
  %5238 = fmul fast float %5219, %3322
  %5239 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5225, float %5238)  ; FMad(a,b,c)
  %5240 = fmul fast float %5219, %3323
  %5241 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5225, float %5240)  ; FMad(a,b,c)
  %5242 = fsub fast float %5239, %5227
  %5243 = fsub fast float %5222, %5195
  %5244 = fsub fast float %5241, %5229
  %5245 = fsub fast float %5231, %5227
  %5246 = fsub fast float %5204, %5195
  %5247 = fsub fast float %5233, %5229
  %5248 = fmul fast float %5244, %5246
  %5249 = fmul fast float %5247, %5243
  %5250 = fsub fast float %5248, %5249
  %5251 = fmul fast float %5242, %5247
  %5252 = fmul fast float %5244, %5245
  %5253 = fsub fast float %5251, %5252
  %5254 = fmul fast float %5245, %5243
  %5255 = fmul fast float %5242, %5246
  %5256 = fsub fast float %5254, %5255
  %5257 = call float @dx.op.dot3.f32(i32 55, float %5227, float %5195, float %5229, float %5250, float %5253, float %5256)  ; Dot3(ax,ay,az,bx,by,bz)
  %5258 = fcmp fast olt float %5257, 0.000000e+00
  br i1 %5258, label %5417, label %5259

; <label>:5259                                    ; preds = %5144
  %5260 = call float @dx.op.dot3.f32(i32 55, float %5227, float %5195, float %5229, float %5227, float %5195, float %5229)  ; Dot3(ax,ay,az,bx,by,bz)
  %5261 = call float @dx.op.unary.f32(i32 25, float %5260)  ; Rsqrt(value)
  %5262 = fmul fast float %5261, %5227
  %5263 = fmul fast float %5261, %5195
  %5264 = fmul fast float %5261, %5229
  %5265 = call float @dx.op.dot3.f32(i32 55, float %5231, float %5204, float %5233, float %5231, float %5204, float %5233)  ; Dot3(ax,ay,az,bx,by,bz)
  %5266 = call float @dx.op.unary.f32(i32 25, float %5265)  ; Rsqrt(value)
  %5267 = fmul fast float %5266, %5231
  %5268 = fmul fast float %5266, %5204
  %5269 = fmul fast float %5266, %5233
  %5270 = call float @dx.op.dot3.f32(i32 55, float %5235, float %5213, float %5237, float %5235, float %5213, float %5237)  ; Dot3(ax,ay,az,bx,by,bz)
  %5271 = call float @dx.op.unary.f32(i32 25, float %5270)  ; Rsqrt(value)
  %5272 = fmul fast float %5271, %5235
  %5273 = fmul fast float %5271, %5213
  %5274 = fmul fast float %5271, %5237
  %5275 = call float @dx.op.dot3.f32(i32 55, float %5239, float %5222, float %5241, float %5239, float %5222, float %5241)  ; Dot3(ax,ay,az,bx,by,bz)
  %5276 = call float @dx.op.unary.f32(i32 25, float %5275)  ; Rsqrt(value)
  %5277 = fmul fast float %5276, %5239
  %5278 = fmul fast float %5276, %5222
  %5279 = fmul fast float %5276, %5241
  %5280 = call float @dx.op.dot3.f32(i32 55, float %5262, float %5263, float %5264, float %5267, float %5268, float %5269)  ; Dot3(ax,ay,az,bx,by,bz)
  %5281 = call float @dx.op.unary.f32(i32 6, float %5280)  ; FAbs(value)
  %5282 = fmul fast float %5281, 0x3F8DBCFA00000000
  %5283 = fadd fast float %5282, 0x3FDFC6E900000000
  %5284 = fmul fast float %5283, %5281
  %5285 = fadd fast float %5284, 0x3FEB573B80000000
  %5286 = fadd fast float %5281, 0x4010A58D80000000
  %5287 = fmul fast float %5286, %5281
  %5288 = fadd fast float %5287, 0x400B573B80000000
  %5289 = fdiv fast float %5285, %5288
  %5290 = fcmp fast ogt float %5280, 0.000000e+00
  br i1 %5290, label %5298, label %5291

; <label>:5291                                    ; preds = %5259
  %5292 = fmul fast float %5280, %5280
  %5293 = fsub fast float 1.000000e+00, %5292
  %5294 = call float @dx.op.binary.f32(i32 35, float %5293, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5295 = call float @dx.op.unary.f32(i32 25, float %5294)  ; Rsqrt(value)
  %5296 = fmul fast float %5295, 5.000000e-01
  %5297 = fsub fast float %5296, %5289
  br label %5298

; <label>:5298                                    ; preds = %5291, %5259
  %5299 = phi float [ %5297, %5291 ], [ %5289, %5259 ]
  %5300 = fmul fast float %5269, %5263
  %5301 = fmul fast float %5268, %5264
  %5302 = fsub fast float %5300, %5301
  %5303 = fmul fast float %5267, %5264
  %5304 = fmul fast float %5269, %5262
  %5305 = fsub fast float %5303, %5304
  %5306 = fmul fast float %5268, %5262
  %5307 = fmul fast float %5267, %5263
  %5308 = fsub fast float %5306, %5307
  %5309 = fmul fast float %5299, %5302
  %5310 = fmul fast float %5299, %5305
  %5311 = fmul fast float %5299, %5308
  %5312 = call float @dx.op.dot3.f32(i32 55, float %5267, float %5268, float %5269, float %5272, float %5273, float %5274)  ; Dot3(ax,ay,az,bx,by,bz)
  %5313 = call float @dx.op.unary.f32(i32 6, float %5312)  ; FAbs(value)
  %5314 = fmul fast float %5313, 0x3F8DBCFA00000000
  %5315 = fadd fast float %5314, 0x3FDFC6E900000000
  %5316 = fmul fast float %5315, %5313
  %5317 = fadd fast float %5316, 0x3FEB573B80000000
  %5318 = fadd fast float %5313, 0x4010A58D80000000
  %5319 = fmul fast float %5318, %5313
  %5320 = fadd fast float %5319, 0x400B573B80000000
  %5321 = fdiv fast float %5317, %5320
  %5322 = fcmp fast ogt float %5312, 0.000000e+00
  br i1 %5322, label %5330, label %5323

; <label>:5323                                    ; preds = %5298
  %5324 = fmul fast float %5312, %5312
  %5325 = fsub fast float 1.000000e+00, %5324
  %5326 = call float @dx.op.binary.f32(i32 35, float %5325, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5327 = call float @dx.op.unary.f32(i32 25, float %5326)  ; Rsqrt(value)
  %5328 = fmul fast float %5327, 5.000000e-01
  %5329 = fsub fast float %5328, %5321
  br label %5330

; <label>:5330                                    ; preds = %5323, %5298
  %5331 = phi float [ %5329, %5323 ], [ %5321, %5298 ]
  %5332 = fmul fast float %5274, %5268
  %5333 = fmul fast float %5273, %5269
  %5334 = fsub fast float %5332, %5333
  %5335 = fmul fast float %5272, %5269
  %5336 = fmul fast float %5274, %5267
  %5337 = fsub fast float %5335, %5336
  %5338 = fmul fast float %5273, %5267
  %5339 = fmul fast float %5272, %5268
  %5340 = fsub fast float %5338, %5339
  %5341 = fmul fast float %5331, %5334
  %5342 = fmul fast float %5331, %5337
  %5343 = fmul fast float %5331, %5340
  %5344 = fadd fast float %5341, %5309
  %5345 = fadd fast float %5342, %5310
  %5346 = fadd fast float %5343, %5311
  %5347 = call float @dx.op.dot3.f32(i32 55, float %5272, float %5273, float %5274, float %5277, float %5278, float %5279)  ; Dot3(ax,ay,az,bx,by,bz)
  %5348 = call float @dx.op.unary.f32(i32 6, float %5347)  ; FAbs(value)
  %5349 = fmul fast float %5348, 0x3F8DBCFA00000000
  %5350 = fadd fast float %5349, 0x3FDFC6E900000000
  %5351 = fmul fast float %5350, %5348
  %5352 = fadd fast float %5351, 0x3FEB573B80000000
  %5353 = fadd fast float %5348, 0x4010A58D80000000
  %5354 = fmul fast float %5353, %5348
  %5355 = fadd fast float %5354, 0x400B573B80000000
  %5356 = fdiv fast float %5352, %5355
  %5357 = fcmp fast ogt float %5347, 0.000000e+00
  br i1 %5357, label %5365, label %5358

; <label>:5358                                    ; preds = %5330
  %5359 = fmul fast float %5347, %5347
  %5360 = fsub fast float 1.000000e+00, %5359
  %5361 = call float @dx.op.binary.f32(i32 35, float %5360, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5362 = call float @dx.op.unary.f32(i32 25, float %5361)  ; Rsqrt(value)
  %5363 = fmul fast float %5362, 5.000000e-01
  %5364 = fsub fast float %5363, %5356
  br label %5365

; <label>:5365                                    ; preds = %5358, %5330
  %5366 = phi float [ %5364, %5358 ], [ %5356, %5330 ]
  %5367 = fmul fast float %5279, %5273
  %5368 = fmul fast float %5278, %5274
  %5369 = fsub fast float %5367, %5368
  %5370 = fmul fast float %5277, %5274
  %5371 = fmul fast float %5279, %5272
  %5372 = fsub fast float %5370, %5371
  %5373 = fmul fast float %5278, %5272
  %5374 = fmul fast float %5277, %5273
  %5375 = fsub fast float %5373, %5374
  %5376 = fmul fast float %5366, %5369
  %5377 = fmul fast float %5366, %5372
  %5378 = fmul fast float %5366, %5375
  %5379 = fadd fast float %5344, %5376
  %5380 = fadd fast float %5345, %5377
  %5381 = fadd fast float %5346, %5378
  %5382 = call float @dx.op.dot3.f32(i32 55, float %5277, float %5278, float %5279, float %5262, float %5263, float %5264)  ; Dot3(ax,ay,az,bx,by,bz)
  %5383 = call float @dx.op.unary.f32(i32 6, float %5382)  ; FAbs(value)
  %5384 = fmul fast float %5383, 0x3F8DBCFA00000000
  %5385 = fadd fast float %5384, 0x3FDFC6E900000000
  %5386 = fmul fast float %5385, %5383
  %5387 = fadd fast float %5386, 0x3FEB573B80000000
  %5388 = fadd fast float %5383, 0x4010A58D80000000
  %5389 = fmul fast float %5388, %5383
  %5390 = fadd fast float %5389, 0x400B573B80000000
  %5391 = fdiv fast float %5387, %5390
  %5392 = fcmp fast ogt float %5382, 0.000000e+00
  br i1 %5392, label %5400, label %5393

; <label>:5393                                    ; preds = %5365
  %5394 = fmul fast float %5382, %5382
  %5395 = fsub fast float 1.000000e+00, %5394
  %5396 = call float @dx.op.binary.f32(i32 35, float %5395, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5397 = call float @dx.op.unary.f32(i32 25, float %5396)  ; Rsqrt(value)
  %5398 = fmul fast float %5397, 5.000000e-01
  %5399 = fsub fast float %5398, %5391
  br label %5400

; <label>:5400                                    ; preds = %5393, %5365
  %5401 = phi float [ %5399, %5393 ], [ %5391, %5365 ]
  %5402 = fmul fast float %5278, %5264
  %5403 = fmul fast float %5279, %5263
  %5404 = fsub fast float %5402, %5403
  %5405 = fmul fast float %5279, %5262
  %5406 = fmul fast float %5277, %5264
  %5407 = fsub fast float %5405, %5406
  %5408 = fmul fast float %5277, %5263
  %5409 = fmul fast float %5278, %5262
  %5410 = fsub fast float %5408, %5409
  %5411 = fmul fast float %5401, %5404
  %5412 = fmul fast float %5401, %5407
  %5413 = fmul fast float %5401, %5410
  %5414 = fadd fast float %5379, %5411
  %5415 = fadd fast float %5380, %5412
  %5416 = fadd fast float %5381, %5413
  br label %5417

; <label>:5417                                    ; preds = %5400, %5144
  %5418 = phi float [ %5414, %5400 ], [ 0.000000e+00, %5144 ]
  %5419 = phi float [ %5415, %5400 ], [ 0.000000e+00, %5144 ]
  %5420 = phi float [ %5416, %5400 ], [ 0.000000e+00, %5144 ]
  %5421 = fmul fast float %5418, %5418
  %5422 = fmul fast float %5419, %5419
  %5423 = fadd fast float %5422, %5421
  %5424 = fmul fast float %5420, %5420
  %5425 = fadd fast float %5423, %5424
  %5426 = call float @dx.op.unary.f32(i32 24, float %5425)  ; Sqrt(value)
  %5427 = fmul fast float %5426, %5426
  %5428 = fadd fast float %5427, %5420
  %5429 = fadd fast float %5426, 1.000000e+00
  %5430 = fdiv fast float %5428, %5429
  %5431 = call float @dx.op.binary.f32(i32 35, float %5430, float 0.000000e+00)  ; FMax(a,b)
  %5432 = fmul fast float %5192, %3327
  %5433 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5198, float %5432)  ; FMad(a,b,c)
  %5434 = fmul fast float %5192, %3328
  %5435 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5198, float %5434)  ; FMad(a,b,c)
  %5436 = fmul fast float %5201, %3327
  %5437 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5207, float %5436)  ; FMad(a,b,c)
  %5438 = fmul fast float %5201, %3328
  %5439 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5207, float %5438)  ; FMad(a,b,c)
  %5440 = fmul fast float %5210, %3327
  %5441 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5216, float %5440)  ; FMad(a,b,c)
  %5442 = fmul fast float %5210, %3328
  %5443 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5216, float %5442)  ; FMad(a,b,c)
  %5444 = fmul fast float %5219, %3327
  %5445 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5225, float %5444)  ; FMad(a,b,c)
  %5446 = fmul fast float %5219, %3328
  %5447 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5225, float %5446)  ; FMad(a,b,c)
  %5448 = fsub fast float %5445, %5433
  %5449 = fsub fast float %5447, %5435
  %5450 = fsub fast float %5437, %5433
  %5451 = fsub fast float %5439, %5435
  %5452 = fmul fast float %5449, %5246
  %5453 = fmul fast float %5451, %5243
  %5454 = fsub fast float %5452, %5453
  %5455 = fmul fast float %5448, %5451
  %5456 = fmul fast float %5449, %5450
  %5457 = fsub fast float %5455, %5456
  %5458 = fmul fast float %5450, %5243
  %5459 = fmul fast float %5448, %5246
  %5460 = fsub fast float %5458, %5459
  %5461 = call float @dx.op.dot3.f32(i32 55, float %5433, float %5195, float %5435, float %5454, float %5457, float %5460)  ; Dot3(ax,ay,az,bx,by,bz)
  %5462 = fcmp fast olt float %5461, 0.000000e+00
  br i1 %5462, label %5621, label %5463

; <label>:5463                                    ; preds = %5417
  %5464 = call float @dx.op.dot3.f32(i32 55, float %5433, float %5195, float %5435, float %5433, float %5195, float %5435)  ; Dot3(ax,ay,az,bx,by,bz)
  %5465 = call float @dx.op.unary.f32(i32 25, float %5464)  ; Rsqrt(value)
  %5466 = fmul fast float %5465, %5433
  %5467 = fmul fast float %5465, %5195
  %5468 = fmul fast float %5465, %5435
  %5469 = call float @dx.op.dot3.f32(i32 55, float %5437, float %5204, float %5439, float %5437, float %5204, float %5439)  ; Dot3(ax,ay,az,bx,by,bz)
  %5470 = call float @dx.op.unary.f32(i32 25, float %5469)  ; Rsqrt(value)
  %5471 = fmul fast float %5470, %5437
  %5472 = fmul fast float %5470, %5204
  %5473 = fmul fast float %5470, %5439
  %5474 = call float @dx.op.dot3.f32(i32 55, float %5441, float %5213, float %5443, float %5441, float %5213, float %5443)  ; Dot3(ax,ay,az,bx,by,bz)
  %5475 = call float @dx.op.unary.f32(i32 25, float %5474)  ; Rsqrt(value)
  %5476 = fmul fast float %5475, %5441
  %5477 = fmul fast float %5475, %5213
  %5478 = fmul fast float %5475, %5443
  %5479 = call float @dx.op.dot3.f32(i32 55, float %5445, float %5222, float %5447, float %5445, float %5222, float %5447)  ; Dot3(ax,ay,az,bx,by,bz)
  %5480 = call float @dx.op.unary.f32(i32 25, float %5479)  ; Rsqrt(value)
  %5481 = fmul fast float %5480, %5445
  %5482 = fmul fast float %5480, %5222
  %5483 = fmul fast float %5480, %5447
  %5484 = call float @dx.op.dot3.f32(i32 55, float %5466, float %5467, float %5468, float %5471, float %5472, float %5473)  ; Dot3(ax,ay,az,bx,by,bz)
  %5485 = call float @dx.op.unary.f32(i32 6, float %5484)  ; FAbs(value)
  %5486 = fmul fast float %5485, 0x3F8DBCFA00000000
  %5487 = fadd fast float %5486, 0x3FDFC6E900000000
  %5488 = fmul fast float %5487, %5485
  %5489 = fadd fast float %5488, 0x3FEB573B80000000
  %5490 = fadd fast float %5485, 0x4010A58D80000000
  %5491 = fmul fast float %5490, %5485
  %5492 = fadd fast float %5491, 0x400B573B80000000
  %5493 = fdiv fast float %5489, %5492
  %5494 = fcmp fast ogt float %5484, 0.000000e+00
  br i1 %5494, label %5502, label %5495

; <label>:5495                                    ; preds = %5463
  %5496 = fmul fast float %5484, %5484
  %5497 = fsub fast float 1.000000e+00, %5496
  %5498 = call float @dx.op.binary.f32(i32 35, float %5497, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5499 = call float @dx.op.unary.f32(i32 25, float %5498)  ; Rsqrt(value)
  %5500 = fmul fast float %5499, 5.000000e-01
  %5501 = fsub fast float %5500, %5493
  br label %5502

; <label>:5502                                    ; preds = %5495, %5463
  %5503 = phi float [ %5501, %5495 ], [ %5493, %5463 ]
  %5504 = fmul fast float %5473, %5467
  %5505 = fmul fast float %5472, %5468
  %5506 = fsub fast float %5504, %5505
  %5507 = fmul fast float %5471, %5468
  %5508 = fmul fast float %5473, %5466
  %5509 = fsub fast float %5507, %5508
  %5510 = fmul fast float %5472, %5466
  %5511 = fmul fast float %5471, %5467
  %5512 = fsub fast float %5510, %5511
  %5513 = fmul fast float %5503, %5506
  %5514 = fmul fast float %5503, %5509
  %5515 = fmul fast float %5503, %5512
  %5516 = call float @dx.op.dot3.f32(i32 55, float %5471, float %5472, float %5473, float %5476, float %5477, float %5478)  ; Dot3(ax,ay,az,bx,by,bz)
  %5517 = call float @dx.op.unary.f32(i32 6, float %5516)  ; FAbs(value)
  %5518 = fmul fast float %5517, 0x3F8DBCFA00000000
  %5519 = fadd fast float %5518, 0x3FDFC6E900000000
  %5520 = fmul fast float %5519, %5517
  %5521 = fadd fast float %5520, 0x3FEB573B80000000
  %5522 = fadd fast float %5517, 0x4010A58D80000000
  %5523 = fmul fast float %5522, %5517
  %5524 = fadd fast float %5523, 0x400B573B80000000
  %5525 = fdiv fast float %5521, %5524
  %5526 = fcmp fast ogt float %5516, 0.000000e+00
  br i1 %5526, label %5534, label %5527

; <label>:5527                                    ; preds = %5502
  %5528 = fmul fast float %5516, %5516
  %5529 = fsub fast float 1.000000e+00, %5528
  %5530 = call float @dx.op.binary.f32(i32 35, float %5529, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5531 = call float @dx.op.unary.f32(i32 25, float %5530)  ; Rsqrt(value)
  %5532 = fmul fast float %5531, 5.000000e-01
  %5533 = fsub fast float %5532, %5525
  br label %5534

; <label>:5534                                    ; preds = %5527, %5502
  %5535 = phi float [ %5533, %5527 ], [ %5525, %5502 ]
  %5536 = fmul fast float %5478, %5472
  %5537 = fmul fast float %5477, %5473
  %5538 = fsub fast float %5536, %5537
  %5539 = fmul fast float %5476, %5473
  %5540 = fmul fast float %5478, %5471
  %5541 = fsub fast float %5539, %5540
  %5542 = fmul fast float %5477, %5471
  %5543 = fmul fast float %5476, %5472
  %5544 = fsub fast float %5542, %5543
  %5545 = fmul fast float %5535, %5538
  %5546 = fmul fast float %5535, %5541
  %5547 = fmul fast float %5535, %5544
  %5548 = fadd fast float %5545, %5513
  %5549 = fadd fast float %5546, %5514
  %5550 = fadd fast float %5547, %5515
  %5551 = call float @dx.op.dot3.f32(i32 55, float %5476, float %5477, float %5478, float %5481, float %5482, float %5483)  ; Dot3(ax,ay,az,bx,by,bz)
  %5552 = call float @dx.op.unary.f32(i32 6, float %5551)  ; FAbs(value)
  %5553 = fmul fast float %5552, 0x3F8DBCFA00000000
  %5554 = fadd fast float %5553, 0x3FDFC6E900000000
  %5555 = fmul fast float %5554, %5552
  %5556 = fadd fast float %5555, 0x3FEB573B80000000
  %5557 = fadd fast float %5552, 0x4010A58D80000000
  %5558 = fmul fast float %5557, %5552
  %5559 = fadd fast float %5558, 0x400B573B80000000
  %5560 = fdiv fast float %5556, %5559
  %5561 = fcmp fast ogt float %5551, 0.000000e+00
  br i1 %5561, label %5569, label %5562

; <label>:5562                                    ; preds = %5534
  %5563 = fmul fast float %5551, %5551
  %5564 = fsub fast float 1.000000e+00, %5563
  %5565 = call float @dx.op.binary.f32(i32 35, float %5564, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5566 = call float @dx.op.unary.f32(i32 25, float %5565)  ; Rsqrt(value)
  %5567 = fmul fast float %5566, 5.000000e-01
  %5568 = fsub fast float %5567, %5560
  br label %5569

; <label>:5569                                    ; preds = %5562, %5534
  %5570 = phi float [ %5568, %5562 ], [ %5560, %5534 ]
  %5571 = fmul fast float %5483, %5477
  %5572 = fmul fast float %5482, %5478
  %5573 = fsub fast float %5571, %5572
  %5574 = fmul fast float %5481, %5478
  %5575 = fmul fast float %5483, %5476
  %5576 = fsub fast float %5574, %5575
  %5577 = fmul fast float %5482, %5476
  %5578 = fmul fast float %5481, %5477
  %5579 = fsub fast float %5577, %5578
  %5580 = fmul fast float %5570, %5573
  %5581 = fmul fast float %5570, %5576
  %5582 = fmul fast float %5570, %5579
  %5583 = fadd fast float %5548, %5580
  %5584 = fadd fast float %5549, %5581
  %5585 = fadd fast float %5550, %5582
  %5586 = call float @dx.op.dot3.f32(i32 55, float %5481, float %5482, float %5483, float %5466, float %5467, float %5468)  ; Dot3(ax,ay,az,bx,by,bz)
  %5587 = call float @dx.op.unary.f32(i32 6, float %5586)  ; FAbs(value)
  %5588 = fmul fast float %5587, 0x3F8DBCFA00000000
  %5589 = fadd fast float %5588, 0x3FDFC6E900000000
  %5590 = fmul fast float %5589, %5587
  %5591 = fadd fast float %5590, 0x3FEB573B80000000
  %5592 = fadd fast float %5587, 0x4010A58D80000000
  %5593 = fmul fast float %5592, %5587
  %5594 = fadd fast float %5593, 0x400B573B80000000
  %5595 = fdiv fast float %5591, %5594
  %5596 = fcmp fast ogt float %5586, 0.000000e+00
  br i1 %5596, label %5604, label %5597

; <label>:5597                                    ; preds = %5569
  %5598 = fmul fast float %5586, %5586
  %5599 = fsub fast float 1.000000e+00, %5598
  %5600 = call float @dx.op.binary.f32(i32 35, float %5599, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5601 = call float @dx.op.unary.f32(i32 25, float %5600)  ; Rsqrt(value)
  %5602 = fmul fast float %5601, 5.000000e-01
  %5603 = fsub fast float %5602, %5595
  br label %5604

; <label>:5604                                    ; preds = %5597, %5569
  %5605 = phi float [ %5603, %5597 ], [ %5595, %5569 ]
  %5606 = fmul fast float %5482, %5468
  %5607 = fmul fast float %5483, %5467
  %5608 = fsub fast float %5606, %5607
  %5609 = fmul fast float %5483, %5466
  %5610 = fmul fast float %5481, %5468
  %5611 = fsub fast float %5609, %5610
  %5612 = fmul fast float %5481, %5467
  %5613 = fmul fast float %5482, %5466
  %5614 = fsub fast float %5612, %5613
  %5615 = fmul fast float %5605, %5608
  %5616 = fmul fast float %5605, %5611
  %5617 = fmul fast float %5605, %5614
  %5618 = fadd fast float %5583, %5615
  %5619 = fadd fast float %5584, %5616
  %5620 = fadd fast float %5585, %5617
  br label %5621

; <label>:5621                                    ; preds = %5604, %5417
  %5622 = phi float [ %5618, %5604 ], [ 0.000000e+00, %5417 ]
  %5623 = phi float [ %5619, %5604 ], [ 0.000000e+00, %5417 ]
  %5624 = phi float [ %5620, %5604 ], [ 0.000000e+00, %5417 ]
  %5625 = fmul fast float %5622, %5622
  %5626 = fmul fast float %5623, %5623
  %5627 = fadd fast float %5626, %5625
  %5628 = fmul fast float %5624, %5624
  %5629 = fadd fast float %5627, %5628
  %5630 = call float @dx.op.unary.f32(i32 24, float %5629)  ; Sqrt(value)
  %5631 = fmul fast float %5630, %5630
  %5632 = fadd fast float %5631, %5624
  %5633 = fadd fast float %5630, 1.000000e+00
  %5634 = fdiv fast float %5632, %5633
  %5635 = call float @dx.op.binary.f32(i32 35, float %5634, float 0.000000e+00)  ; FMax(a,b)
  %5636 = fmul fast float %5141, 0x400921FB60000000
  %5637 = and i32 %3459, 32
  %5638 = icmp ne i32 %5637, 0
  %5639 = select i1 %5638, float 1.000000e+00, float 0.000000e+00
  %5640 = fmul fast float %5639, %3287
  %5641 = fmul fast float %5640, %5636
  %5642 = fmul fast float %5431, %5641
  %5643 = fmul fast float %5642, %3474
  %5644 = fmul fast float %5642, %3475
  %5645 = fmul fast float %5642, %3476
  %5646 = and i32 %3459, 64
  %5647 = icmp ne i32 %5646, 0
  %5648 = select i1 %5647, float 1.000000e+00, float 0.000000e+00
  %5649 = fmul fast float %5648, %3290
  %5650 = fmul fast float %5649, %5636
  %5651 = fmul fast float %5650, %5635
  %5652 = fmul fast float %5651, %3474
  %5653 = fmul fast float %5651, %3475
  %5654 = fmul fast float %5651, %3476
  br label %5655

; <label>:5655                                    ; preds = %5621, %5103
  %5656 = phi float [ %5643, %5621 ], [ 0.000000e+00, %5103 ]
  %5657 = phi float [ %5644, %5621 ], [ 0.000000e+00, %5103 ]
  %5658 = phi float [ %5645, %5621 ], [ 0.000000e+00, %5103 ]
  %5659 = phi float [ %5652, %5621 ], [ 0.000000e+00, %5103 ]
  %5660 = phi float [ %5653, %5621 ], [ 0.000000e+00, %5103 ]
  %5661 = phi float [ %5654, %5621 ], [ 0.000000e+00, %5103 ]
  %5662 = zext i1 %5143 to i32
  br label %6175

; <label>:5663                                    ; preds = %5101
  %5664 = icmp eq i32 %4097, 4
  br i1 %5664, label %5665, label %6175

; <label>:5665                                    ; preds = %5663
  %5666 = fmul fast float %4091, %3471
  %5667 = fmul fast float %5666, %5666
  %5668 = fsub fast float 1.000000e+00, %5667
  %5669 = call float @dx.op.unary.f32(i32 7, float %5668)  ; Saturate(value)
  %5670 = fmul fast float %5669, %5669
  %5671 = fcmp fast ogt float %5670, 0.000000e+00
  br i1 %5671, label %5672, label %6167

; <label>:5672                                    ; preds = %5665
  %5673 = fmul fast float %3496, 5.000000e-01
  %5674 = fmul fast float %3504, 5.000000e-01
  %5675 = fmul fast float %3507, %5673
  %5676 = fmul fast float %3508, %5673
  %5677 = fmul fast float %3509, %5673
  %5678 = fmul fast float %5674, %3499
  %5679 = fmul fast float %5674, %3500
  %5680 = fmul fast float %5674, %3501
  %5681 = fsub fast float %4088, %5675
  %5682 = fsub fast float %4089, %5676
  %5683 = fsub fast float %4090, %5677
  %5684 = fsub fast float %5681, %5678
  %5685 = fsub fast float %5682, %5679
  %5686 = fsub fast float %5683, %5680
  %5687 = fadd fast float %5675, %4088
  %5688 = fadd fast float %5676, %4089
  %5689 = fadd fast float %5677, %4090
  %5690 = fsub fast float %5687, %5678
  %5691 = fsub fast float %5688, %5679
  %5692 = fsub fast float %5689, %5680
  %5693 = fadd fast float %5687, %5678
  %5694 = fadd fast float %5688, %5679
  %5695 = fadd fast float %5689, %5680
  %5696 = fadd fast float %5681, %5678
  %5697 = fadd fast float %5682, %5679
  %5698 = fadd fast float %5683, %5680
  %5699 = fmul fast float %5684, %3299
  %5700 = call float @dx.op.tertiary.f32(i32 46, float %5685, float %3300, float %5699)  ; FMad(a,b,c)
  %5701 = call float @dx.op.tertiary.f32(i32 46, float %5686, float %3301, float %5700)  ; FMad(a,b,c)
  %5702 = fmul fast float %5684, %3304
  %5703 = call float @dx.op.tertiary.f32(i32 46, float %5685, float %3307, float %5702)  ; FMad(a,b,c)
  %5704 = call float @dx.op.tertiary.f32(i32 46, float %5686, float %3310, float %5703)  ; FMad(a,b,c)
  %5705 = fmul fast float %5684, %2879
  %5706 = call float @dx.op.tertiary.f32(i32 46, float %5685, float %2880, float %5705)  ; FMad(a,b,c)
  %5707 = call float @dx.op.tertiary.f32(i32 46, float %5686, float %2881, float %5706)  ; FMad(a,b,c)
  %5708 = fmul fast float %5690, %3299
  %5709 = call float @dx.op.tertiary.f32(i32 46, float %5691, float %3300, float %5708)  ; FMad(a,b,c)
  %5710 = call float @dx.op.tertiary.f32(i32 46, float %5692, float %3301, float %5709)  ; FMad(a,b,c)
  %5711 = fmul fast float %5690, %3304
  %5712 = call float @dx.op.tertiary.f32(i32 46, float %5691, float %3307, float %5711)  ; FMad(a,b,c)
  %5713 = call float @dx.op.tertiary.f32(i32 46, float %5692, float %3310, float %5712)  ; FMad(a,b,c)
  %5714 = fmul fast float %5690, %2879
  %5715 = call float @dx.op.tertiary.f32(i32 46, float %5691, float %2880, float %5714)  ; FMad(a,b,c)
  %5716 = call float @dx.op.tertiary.f32(i32 46, float %5692, float %2881, float %5715)  ; FMad(a,b,c)
  %5717 = fmul fast float %5693, %3299
  %5718 = call float @dx.op.tertiary.f32(i32 46, float %5694, float %3300, float %5717)  ; FMad(a,b,c)
  %5719 = call float @dx.op.tertiary.f32(i32 46, float %5695, float %3301, float %5718)  ; FMad(a,b,c)
  %5720 = fmul fast float %5693, %3304
  %5721 = call float @dx.op.tertiary.f32(i32 46, float %5694, float %3307, float %5720)  ; FMad(a,b,c)
  %5722 = call float @dx.op.tertiary.f32(i32 46, float %5695, float %3310, float %5721)  ; FMad(a,b,c)
  %5723 = fmul fast float %5693, %2879
  %5724 = call float @dx.op.tertiary.f32(i32 46, float %5694, float %2880, float %5723)  ; FMad(a,b,c)
  %5725 = call float @dx.op.tertiary.f32(i32 46, float %5695, float %2881, float %5724)  ; FMad(a,b,c)
  %5726 = fmul fast float %5696, %3299
  %5727 = call float @dx.op.tertiary.f32(i32 46, float %5697, float %3300, float %5726)  ; FMad(a,b,c)
  %5728 = call float @dx.op.tertiary.f32(i32 46, float %5698, float %3301, float %5727)  ; FMad(a,b,c)
  %5729 = fmul fast float %5696, %3304
  %5730 = call float @dx.op.tertiary.f32(i32 46, float %5697, float %3307, float %5729)  ; FMad(a,b,c)
  %5731 = call float @dx.op.tertiary.f32(i32 46, float %5698, float %3310, float %5730)  ; FMad(a,b,c)
  %5732 = fmul fast float %5696, %2879
  %5733 = call float @dx.op.tertiary.f32(i32 46, float %5697, float %2880, float %5732)  ; FMad(a,b,c)
  %5734 = call float @dx.op.tertiary.f32(i32 46, float %5698, float %2881, float %5733)  ; FMad(a,b,c)
  %5735 = fmul fast float %5701, %3322
  %5736 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5707, float %5735)  ; FMad(a,b,c)
  %5737 = fmul fast float %5701, %3323
  %5738 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5707, float %5737)  ; FMad(a,b,c)
  %5739 = fmul fast float %5710, %3322
  %5740 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5716, float %5739)  ; FMad(a,b,c)
  %5741 = fmul fast float %5710, %3323
  %5742 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5716, float %5741)  ; FMad(a,b,c)
  %5743 = fmul fast float %5719, %3322
  %5744 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5725, float %5743)  ; FMad(a,b,c)
  %5745 = fmul fast float %5719, %3323
  %5746 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5725, float %5745)  ; FMad(a,b,c)
  %5747 = fmul fast float %5728, %3322
  %5748 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5734, float %5747)  ; FMad(a,b,c)
  %5749 = fmul fast float %5728, %3323
  %5750 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5734, float %5749)  ; FMad(a,b,c)
  %5751 = fsub fast float %5748, %5736
  %5752 = fsub fast float %5731, %5704
  %5753 = fsub fast float %5750, %5738
  %5754 = fsub fast float %5740, %5736
  %5755 = fsub fast float %5713, %5704
  %5756 = fsub fast float %5742, %5738
  %5757 = fmul fast float %5753, %5755
  %5758 = fmul fast float %5756, %5752
  %5759 = fsub fast float %5757, %5758
  %5760 = fmul fast float %5751, %5756
  %5761 = fmul fast float %5753, %5754
  %5762 = fsub fast float %5760, %5761
  %5763 = fmul fast float %5754, %5752
  %5764 = fmul fast float %5751, %5755
  %5765 = fsub fast float %5763, %5764
  %5766 = call float @dx.op.dot3.f32(i32 55, float %5736, float %5704, float %5738, float %5759, float %5762, float %5765)  ; Dot3(ax,ay,az,bx,by,bz)
  %5767 = fcmp fast olt float %5766, 0.000000e+00
  br i1 %5767, label %5926, label %5768

; <label>:5768                                    ; preds = %5672
  %5769 = call float @dx.op.dot3.f32(i32 55, float %5736, float %5704, float %5738, float %5736, float %5704, float %5738)  ; Dot3(ax,ay,az,bx,by,bz)
  %5770 = call float @dx.op.unary.f32(i32 25, float %5769)  ; Rsqrt(value)
  %5771 = fmul fast float %5770, %5736
  %5772 = fmul fast float %5770, %5704
  %5773 = fmul fast float %5770, %5738
  %5774 = call float @dx.op.dot3.f32(i32 55, float %5740, float %5713, float %5742, float %5740, float %5713, float %5742)  ; Dot3(ax,ay,az,bx,by,bz)
  %5775 = call float @dx.op.unary.f32(i32 25, float %5774)  ; Rsqrt(value)
  %5776 = fmul fast float %5775, %5740
  %5777 = fmul fast float %5775, %5713
  %5778 = fmul fast float %5775, %5742
  %5779 = call float @dx.op.dot3.f32(i32 55, float %5744, float %5722, float %5746, float %5744, float %5722, float %5746)  ; Dot3(ax,ay,az,bx,by,bz)
  %5780 = call float @dx.op.unary.f32(i32 25, float %5779)  ; Rsqrt(value)
  %5781 = fmul fast float %5780, %5744
  %5782 = fmul fast float %5780, %5722
  %5783 = fmul fast float %5780, %5746
  %5784 = call float @dx.op.dot3.f32(i32 55, float %5748, float %5731, float %5750, float %5748, float %5731, float %5750)  ; Dot3(ax,ay,az,bx,by,bz)
  %5785 = call float @dx.op.unary.f32(i32 25, float %5784)  ; Rsqrt(value)
  %5786 = fmul fast float %5785, %5748
  %5787 = fmul fast float %5785, %5731
  %5788 = fmul fast float %5785, %5750
  %5789 = call float @dx.op.dot3.f32(i32 55, float %5771, float %5772, float %5773, float %5776, float %5777, float %5778)  ; Dot3(ax,ay,az,bx,by,bz)
  %5790 = call float @dx.op.unary.f32(i32 6, float %5789)  ; FAbs(value)
  %5791 = fmul fast float %5790, 0x3F8DBCFA00000000
  %5792 = fadd fast float %5791, 0x3FDFC6E900000000
  %5793 = fmul fast float %5792, %5790
  %5794 = fadd fast float %5793, 0x3FEB573B80000000
  %5795 = fadd fast float %5790, 0x4010A58D80000000
  %5796 = fmul fast float %5795, %5790
  %5797 = fadd fast float %5796, 0x400B573B80000000
  %5798 = fdiv fast float %5794, %5797
  %5799 = fcmp fast ogt float %5789, 0.000000e+00
  br i1 %5799, label %5807, label %5800

; <label>:5800                                    ; preds = %5768
  %5801 = fmul fast float %5789, %5789
  %5802 = fsub fast float 1.000000e+00, %5801
  %5803 = call float @dx.op.binary.f32(i32 35, float %5802, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5804 = call float @dx.op.unary.f32(i32 25, float %5803)  ; Rsqrt(value)
  %5805 = fmul fast float %5804, 5.000000e-01
  %5806 = fsub fast float %5805, %5798
  br label %5807

; <label>:5807                                    ; preds = %5800, %5768
  %5808 = phi float [ %5806, %5800 ], [ %5798, %5768 ]
  %5809 = fmul fast float %5778, %5772
  %5810 = fmul fast float %5777, %5773
  %5811 = fsub fast float %5809, %5810
  %5812 = fmul fast float %5776, %5773
  %5813 = fmul fast float %5778, %5771
  %5814 = fsub fast float %5812, %5813
  %5815 = fmul fast float %5777, %5771
  %5816 = fmul fast float %5776, %5772
  %5817 = fsub fast float %5815, %5816
  %5818 = fmul fast float %5808, %5811
  %5819 = fmul fast float %5808, %5814
  %5820 = fmul fast float %5808, %5817
  %5821 = call float @dx.op.dot3.f32(i32 55, float %5776, float %5777, float %5778, float %5781, float %5782, float %5783)  ; Dot3(ax,ay,az,bx,by,bz)
  %5822 = call float @dx.op.unary.f32(i32 6, float %5821)  ; FAbs(value)
  %5823 = fmul fast float %5822, 0x3F8DBCFA00000000
  %5824 = fadd fast float %5823, 0x3FDFC6E900000000
  %5825 = fmul fast float %5824, %5822
  %5826 = fadd fast float %5825, 0x3FEB573B80000000
  %5827 = fadd fast float %5822, 0x4010A58D80000000
  %5828 = fmul fast float %5827, %5822
  %5829 = fadd fast float %5828, 0x400B573B80000000
  %5830 = fdiv fast float %5826, %5829
  %5831 = fcmp fast ogt float %5821, 0.000000e+00
  br i1 %5831, label %5839, label %5832

; <label>:5832                                    ; preds = %5807
  %5833 = fmul fast float %5821, %5821
  %5834 = fsub fast float 1.000000e+00, %5833
  %5835 = call float @dx.op.binary.f32(i32 35, float %5834, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5836 = call float @dx.op.unary.f32(i32 25, float %5835)  ; Rsqrt(value)
  %5837 = fmul fast float %5836, 5.000000e-01
  %5838 = fsub fast float %5837, %5830
  br label %5839

; <label>:5839                                    ; preds = %5832, %5807
  %5840 = phi float [ %5838, %5832 ], [ %5830, %5807 ]
  %5841 = fmul fast float %5783, %5777
  %5842 = fmul fast float %5782, %5778
  %5843 = fsub fast float %5841, %5842
  %5844 = fmul fast float %5781, %5778
  %5845 = fmul fast float %5783, %5776
  %5846 = fsub fast float %5844, %5845
  %5847 = fmul fast float %5782, %5776
  %5848 = fmul fast float %5781, %5777
  %5849 = fsub fast float %5847, %5848
  %5850 = fmul fast float %5840, %5843
  %5851 = fmul fast float %5840, %5846
  %5852 = fmul fast float %5840, %5849
  %5853 = fadd fast float %5850, %5818
  %5854 = fadd fast float %5851, %5819
  %5855 = fadd fast float %5852, %5820
  %5856 = call float @dx.op.dot3.f32(i32 55, float %5781, float %5782, float %5783, float %5786, float %5787, float %5788)  ; Dot3(ax,ay,az,bx,by,bz)
  %5857 = call float @dx.op.unary.f32(i32 6, float %5856)  ; FAbs(value)
  %5858 = fmul fast float %5857, 0x3F8DBCFA00000000
  %5859 = fadd fast float %5858, 0x3FDFC6E900000000
  %5860 = fmul fast float %5859, %5857
  %5861 = fadd fast float %5860, 0x3FEB573B80000000
  %5862 = fadd fast float %5857, 0x4010A58D80000000
  %5863 = fmul fast float %5862, %5857
  %5864 = fadd fast float %5863, 0x400B573B80000000
  %5865 = fdiv fast float %5861, %5864
  %5866 = fcmp fast ogt float %5856, 0.000000e+00
  br i1 %5866, label %5874, label %5867

; <label>:5867                                    ; preds = %5839
  %5868 = fmul fast float %5856, %5856
  %5869 = fsub fast float 1.000000e+00, %5868
  %5870 = call float @dx.op.binary.f32(i32 35, float %5869, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5871 = call float @dx.op.unary.f32(i32 25, float %5870)  ; Rsqrt(value)
  %5872 = fmul fast float %5871, 5.000000e-01
  %5873 = fsub fast float %5872, %5865
  br label %5874

; <label>:5874                                    ; preds = %5867, %5839
  %5875 = phi float [ %5873, %5867 ], [ %5865, %5839 ]
  %5876 = fmul fast float %5788, %5782
  %5877 = fmul fast float %5787, %5783
  %5878 = fsub fast float %5876, %5877
  %5879 = fmul fast float %5786, %5783
  %5880 = fmul fast float %5788, %5781
  %5881 = fsub fast float %5879, %5880
  %5882 = fmul fast float %5787, %5781
  %5883 = fmul fast float %5786, %5782
  %5884 = fsub fast float %5882, %5883
  %5885 = fmul fast float %5875, %5878
  %5886 = fmul fast float %5875, %5881
  %5887 = fmul fast float %5875, %5884
  %5888 = fadd fast float %5853, %5885
  %5889 = fadd fast float %5854, %5886
  %5890 = fadd fast float %5855, %5887
  %5891 = call float @dx.op.dot3.f32(i32 55, float %5786, float %5787, float %5788, float %5771, float %5772, float %5773)  ; Dot3(ax,ay,az,bx,by,bz)
  %5892 = call float @dx.op.unary.f32(i32 6, float %5891)  ; FAbs(value)
  %5893 = fmul fast float %5892, 0x3F8DBCFA00000000
  %5894 = fadd fast float %5893, 0x3FDFC6E900000000
  %5895 = fmul fast float %5894, %5892
  %5896 = fadd fast float %5895, 0x3FEB573B80000000
  %5897 = fadd fast float %5892, 0x4010A58D80000000
  %5898 = fmul fast float %5897, %5892
  %5899 = fadd fast float %5898, 0x400B573B80000000
  %5900 = fdiv fast float %5896, %5899
  %5901 = fcmp fast ogt float %5891, 0.000000e+00
  br i1 %5901, label %5909, label %5902

; <label>:5902                                    ; preds = %5874
  %5903 = fmul fast float %5891, %5891
  %5904 = fsub fast float 1.000000e+00, %5903
  %5905 = call float @dx.op.binary.f32(i32 35, float %5904, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5906 = call float @dx.op.unary.f32(i32 25, float %5905)  ; Rsqrt(value)
  %5907 = fmul fast float %5906, 5.000000e-01
  %5908 = fsub fast float %5907, %5900
  br label %5909

; <label>:5909                                    ; preds = %5902, %5874
  %5910 = phi float [ %5908, %5902 ], [ %5900, %5874 ]
  %5911 = fmul fast float %5787, %5773
  %5912 = fmul fast float %5788, %5772
  %5913 = fsub fast float %5911, %5912
  %5914 = fmul fast float %5788, %5771
  %5915 = fmul fast float %5786, %5773
  %5916 = fsub fast float %5914, %5915
  %5917 = fmul fast float %5786, %5772
  %5918 = fmul fast float %5787, %5771
  %5919 = fsub fast float %5917, %5918
  %5920 = fmul fast float %5910, %5913
  %5921 = fmul fast float %5910, %5916
  %5922 = fmul fast float %5910, %5919
  %5923 = fadd fast float %5888, %5920
  %5924 = fadd fast float %5889, %5921
  %5925 = fadd fast float %5890, %5922
  br label %5926

; <label>:5926                                    ; preds = %5909, %5672
  %5927 = phi float [ %5923, %5909 ], [ 0.000000e+00, %5672 ]
  %5928 = phi float [ %5924, %5909 ], [ 0.000000e+00, %5672 ]
  %5929 = phi float [ %5925, %5909 ], [ 0.000000e+00, %5672 ]
  %5930 = fmul fast float %5927, %5927
  %5931 = fmul fast float %5928, %5928
  %5932 = fadd fast float %5931, %5930
  %5933 = fmul fast float %5929, %5929
  %5934 = fadd fast float %5932, %5933
  %5935 = call float @dx.op.unary.f32(i32 24, float %5934)  ; Sqrt(value)
  %5936 = fmul fast float %5935, %5935
  %5937 = fadd fast float %5936, %5929
  %5938 = fadd fast float %5935, 1.000000e+00
  %5939 = fdiv fast float %5937, %5938
  %5940 = call float @dx.op.binary.f32(i32 35, float %5939, float 0.000000e+00)  ; FMax(a,b)
  %5941 = fmul fast float %5701, %3327
  %5942 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5707, float %5941)  ; FMad(a,b,c)
  %5943 = fmul fast float %5701, %3328
  %5944 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5707, float %5943)  ; FMad(a,b,c)
  %5945 = fmul fast float %5710, %3327
  %5946 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5716, float %5945)  ; FMad(a,b,c)
  %5947 = fmul fast float %5710, %3328
  %5948 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5716, float %5947)  ; FMad(a,b,c)
  %5949 = fmul fast float %5719, %3327
  %5950 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5725, float %5949)  ; FMad(a,b,c)
  %5951 = fmul fast float %5719, %3328
  %5952 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5725, float %5951)  ; FMad(a,b,c)
  %5953 = fmul fast float %5728, %3327
  %5954 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5734, float %5953)  ; FMad(a,b,c)
  %5955 = fmul fast float %5728, %3328
  %5956 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5734, float %5955)  ; FMad(a,b,c)
  %5957 = fsub fast float %5954, %5942
  %5958 = fsub fast float %5956, %5944
  %5959 = fsub fast float %5946, %5942
  %5960 = fsub fast float %5948, %5944
  %5961 = fmul fast float %5958, %5755
  %5962 = fmul fast float %5960, %5752
  %5963 = fsub fast float %5961, %5962
  %5964 = fmul fast float %5957, %5960
  %5965 = fmul fast float %5958, %5959
  %5966 = fsub fast float %5964, %5965
  %5967 = fmul fast float %5959, %5752
  %5968 = fmul fast float %5957, %5755
  %5969 = fsub fast float %5967, %5968
  %5970 = call float @dx.op.dot3.f32(i32 55, float %5942, float %5704, float %5944, float %5963, float %5966, float %5969)  ; Dot3(ax,ay,az,bx,by,bz)
  %5971 = fcmp fast olt float %5970, 0.000000e+00
  br i1 %5971, label %6130, label %5972

; <label>:5972                                    ; preds = %5926
  %5973 = call float @dx.op.dot3.f32(i32 55, float %5942, float %5704, float %5944, float %5942, float %5704, float %5944)  ; Dot3(ax,ay,az,bx,by,bz)
  %5974 = call float @dx.op.unary.f32(i32 25, float %5973)  ; Rsqrt(value)
  %5975 = fmul fast float %5974, %5942
  %5976 = fmul fast float %5974, %5704
  %5977 = fmul fast float %5974, %5944
  %5978 = call float @dx.op.dot3.f32(i32 55, float %5946, float %5713, float %5948, float %5946, float %5713, float %5948)  ; Dot3(ax,ay,az,bx,by,bz)
  %5979 = call float @dx.op.unary.f32(i32 25, float %5978)  ; Rsqrt(value)
  %5980 = fmul fast float %5979, %5946
  %5981 = fmul fast float %5979, %5713
  %5982 = fmul fast float %5979, %5948
  %5983 = call float @dx.op.dot3.f32(i32 55, float %5950, float %5722, float %5952, float %5950, float %5722, float %5952)  ; Dot3(ax,ay,az,bx,by,bz)
  %5984 = call float @dx.op.unary.f32(i32 25, float %5983)  ; Rsqrt(value)
  %5985 = fmul fast float %5984, %5950
  %5986 = fmul fast float %5984, %5722
  %5987 = fmul fast float %5984, %5952
  %5988 = call float @dx.op.dot3.f32(i32 55, float %5954, float %5731, float %5956, float %5954, float %5731, float %5956)  ; Dot3(ax,ay,az,bx,by,bz)
  %5989 = call float @dx.op.unary.f32(i32 25, float %5988)  ; Rsqrt(value)
  %5990 = fmul fast float %5989, %5954
  %5991 = fmul fast float %5989, %5731
  %5992 = fmul fast float %5989, %5956
  %5993 = call float @dx.op.dot3.f32(i32 55, float %5975, float %5976, float %5977, float %5980, float %5981, float %5982)  ; Dot3(ax,ay,az,bx,by,bz)
  %5994 = call float @dx.op.unary.f32(i32 6, float %5993)  ; FAbs(value)
  %5995 = fmul fast float %5994, 0x3F8DBCFA00000000
  %5996 = fadd fast float %5995, 0x3FDFC6E900000000
  %5997 = fmul fast float %5996, %5994
  %5998 = fadd fast float %5997, 0x3FEB573B80000000
  %5999 = fadd fast float %5994, 0x4010A58D80000000
  %6000 = fmul fast float %5999, %5994
  %6001 = fadd fast float %6000, 0x400B573B80000000
  %6002 = fdiv fast float %5998, %6001
  %6003 = fcmp fast ogt float %5993, 0.000000e+00
  br i1 %6003, label %6011, label %6004

; <label>:6004                                    ; preds = %5972
  %6005 = fmul fast float %5993, %5993
  %6006 = fsub fast float 1.000000e+00, %6005
  %6007 = call float @dx.op.binary.f32(i32 35, float %6006, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6008 = call float @dx.op.unary.f32(i32 25, float %6007)  ; Rsqrt(value)
  %6009 = fmul fast float %6008, 5.000000e-01
  %6010 = fsub fast float %6009, %6002
  br label %6011

; <label>:6011                                    ; preds = %6004, %5972
  %6012 = phi float [ %6010, %6004 ], [ %6002, %5972 ]
  %6013 = fmul fast float %5982, %5976
  %6014 = fmul fast float %5981, %5977
  %6015 = fsub fast float %6013, %6014
  %6016 = fmul fast float %5980, %5977
  %6017 = fmul fast float %5982, %5975
  %6018 = fsub fast float %6016, %6017
  %6019 = fmul fast float %5981, %5975
  %6020 = fmul fast float %5980, %5976
  %6021 = fsub fast float %6019, %6020
  %6022 = fmul fast float %6012, %6015
  %6023 = fmul fast float %6012, %6018
  %6024 = fmul fast float %6012, %6021
  %6025 = call float @dx.op.dot3.f32(i32 55, float %5980, float %5981, float %5982, float %5985, float %5986, float %5987)  ; Dot3(ax,ay,az,bx,by,bz)
  %6026 = call float @dx.op.unary.f32(i32 6, float %6025)  ; FAbs(value)
  %6027 = fmul fast float %6026, 0x3F8DBCFA00000000
  %6028 = fadd fast float %6027, 0x3FDFC6E900000000
  %6029 = fmul fast float %6028, %6026
  %6030 = fadd fast float %6029, 0x3FEB573B80000000
  %6031 = fadd fast float %6026, 0x4010A58D80000000
  %6032 = fmul fast float %6031, %6026
  %6033 = fadd fast float %6032, 0x400B573B80000000
  %6034 = fdiv fast float %6030, %6033
  %6035 = fcmp fast ogt float %6025, 0.000000e+00
  br i1 %6035, label %6043, label %6036

; <label>:6036                                    ; preds = %6011
  %6037 = fmul fast float %6025, %6025
  %6038 = fsub fast float 1.000000e+00, %6037
  %6039 = call float @dx.op.binary.f32(i32 35, float %6038, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6040 = call float @dx.op.unary.f32(i32 25, float %6039)  ; Rsqrt(value)
  %6041 = fmul fast float %6040, 5.000000e-01
  %6042 = fsub fast float %6041, %6034
  br label %6043

; <label>:6043                                    ; preds = %6036, %6011
  %6044 = phi float [ %6042, %6036 ], [ %6034, %6011 ]
  %6045 = fmul fast float %5987, %5981
  %6046 = fmul fast float %5986, %5982
  %6047 = fsub fast float %6045, %6046
  %6048 = fmul fast float %5985, %5982
  %6049 = fmul fast float %5987, %5980
  %6050 = fsub fast float %6048, %6049
  %6051 = fmul fast float %5986, %5980
  %6052 = fmul fast float %5985, %5981
  %6053 = fsub fast float %6051, %6052
  %6054 = fmul fast float %6044, %6047
  %6055 = fmul fast float %6044, %6050
  %6056 = fmul fast float %6044, %6053
  %6057 = fadd fast float %6054, %6022
  %6058 = fadd fast float %6055, %6023
  %6059 = fadd fast float %6056, %6024
  %6060 = call float @dx.op.dot3.f32(i32 55, float %5985, float %5986, float %5987, float %5990, float %5991, float %5992)  ; Dot3(ax,ay,az,bx,by,bz)
  %6061 = call float @dx.op.unary.f32(i32 6, float %6060)  ; FAbs(value)
  %6062 = fmul fast float %6061, 0x3F8DBCFA00000000
  %6063 = fadd fast float %6062, 0x3FDFC6E900000000
  %6064 = fmul fast float %6063, %6061
  %6065 = fadd fast float %6064, 0x3FEB573B80000000
  %6066 = fadd fast float %6061, 0x4010A58D80000000
  %6067 = fmul fast float %6066, %6061
  %6068 = fadd fast float %6067, 0x400B573B80000000
  %6069 = fdiv fast float %6065, %6068
  %6070 = fcmp fast ogt float %6060, 0.000000e+00
  br i1 %6070, label %6078, label %6071

; <label>:6071                                    ; preds = %6043
  %6072 = fmul fast float %6060, %6060
  %6073 = fsub fast float 1.000000e+00, %6072
  %6074 = call float @dx.op.binary.f32(i32 35, float %6073, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6075 = call float @dx.op.unary.f32(i32 25, float %6074)  ; Rsqrt(value)
  %6076 = fmul fast float %6075, 5.000000e-01
  %6077 = fsub fast float %6076, %6069
  br label %6078

; <label>:6078                                    ; preds = %6071, %6043
  %6079 = phi float [ %6077, %6071 ], [ %6069, %6043 ]
  %6080 = fmul fast float %5992, %5986
  %6081 = fmul fast float %5991, %5987
  %6082 = fsub fast float %6080, %6081
  %6083 = fmul fast float %5990, %5987
  %6084 = fmul fast float %5992, %5985
  %6085 = fsub fast float %6083, %6084
  %6086 = fmul fast float %5991, %5985
  %6087 = fmul fast float %5990, %5986
  %6088 = fsub fast float %6086, %6087
  %6089 = fmul fast float %6079, %6082
  %6090 = fmul fast float %6079, %6085
  %6091 = fmul fast float %6079, %6088
  %6092 = fadd fast float %6057, %6089
  %6093 = fadd fast float %6058, %6090
  %6094 = fadd fast float %6059, %6091
  %6095 = call float @dx.op.dot3.f32(i32 55, float %5990, float %5991, float %5992, float %5975, float %5976, float %5977)  ; Dot3(ax,ay,az,bx,by,bz)
  %6096 = call float @dx.op.unary.f32(i32 6, float %6095)  ; FAbs(value)
  %6097 = fmul fast float %6096, 0x3F8DBCFA00000000
  %6098 = fadd fast float %6097, 0x3FDFC6E900000000
  %6099 = fmul fast float %6098, %6096
  %6100 = fadd fast float %6099, 0x3FEB573B80000000
  %6101 = fadd fast float %6096, 0x4010A58D80000000
  %6102 = fmul fast float %6101, %6096
  %6103 = fadd fast float %6102, 0x400B573B80000000
  %6104 = fdiv fast float %6100, %6103
  %6105 = fcmp fast ogt float %6095, 0.000000e+00
  br i1 %6105, label %6113, label %6106

; <label>:6106                                    ; preds = %6078
  %6107 = fmul fast float %6095, %6095
  %6108 = fsub fast float 1.000000e+00, %6107
  %6109 = call float @dx.op.binary.f32(i32 35, float %6108, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6110 = call float @dx.op.unary.f32(i32 25, float %6109)  ; Rsqrt(value)
  %6111 = fmul fast float %6110, 5.000000e-01
  %6112 = fsub fast float %6111, %6104
  br label %6113

; <label>:6113                                    ; preds = %6106, %6078
  %6114 = phi float [ %6112, %6106 ], [ %6104, %6078 ]
  %6115 = fmul fast float %5991, %5977
  %6116 = fmul fast float %5992, %5976
  %6117 = fsub fast float %6115, %6116
  %6118 = fmul fast float %5992, %5975
  %6119 = fmul fast float %5990, %5977
  %6120 = fsub fast float %6118, %6119
  %6121 = fmul fast float %5990, %5976
  %6122 = fmul fast float %5991, %5975
  %6123 = fsub fast float %6121, %6122
  %6124 = fmul fast float %6114, %6117
  %6125 = fmul fast float %6114, %6120
  %6126 = fmul fast float %6114, %6123
  %6127 = fadd fast float %6092, %6124
  %6128 = fadd fast float %6093, %6125
  %6129 = fadd fast float %6094, %6126
  br label %6130

; <label>:6130                                    ; preds = %6113, %5926
  %6131 = phi float [ %6127, %6113 ], [ 0.000000e+00, %5926 ]
  %6132 = phi float [ %6128, %6113 ], [ 0.000000e+00, %5926 ]
  %6133 = phi float [ %6129, %6113 ], [ 0.000000e+00, %5926 ]
  %6134 = fmul fast float %6131, %6131
  %6135 = fmul fast float %6132, %6132
  %6136 = fadd fast float %6135, %6134
  %6137 = fmul fast float %6133, %6133
  %6138 = fadd fast float %6136, %6137
  %6139 = call float @dx.op.unary.f32(i32 24, float %6138)  ; Sqrt(value)
  %6140 = fmul fast float %6139, %6139
  %6141 = fadd fast float %6140, %6133
  %6142 = fadd fast float %6139, 1.000000e+00
  %6143 = fdiv fast float %6141, %6142
  %6144 = call float @dx.op.binary.f32(i32 35, float %6143, float 0.000000e+00)  ; FMax(a,b)
  %6145 = and i32 %3459, 32
  %6146 = icmp eq i32 %6145, 0
  br i1 %6146, label %6151, label %6147

; <label>:6147                                    ; preds = %6130
  %6148 = fmul fast float %3287, 0x400921FB60000000
  %6149 = fmul fast float %6148, %5670
  %6150 = fmul fast float %6149, %5940
  br label %6151

; <label>:6151                                    ; preds = %6147, %6130
  %6152 = phi float [ %6150, %6147 ], [ 0.000000e+00, %6130 ]
  %6153 = and i32 %3459, 64
  %6154 = icmp eq i32 %6153, 0
  br i1 %6154, label %6159, label %6155

; <label>:6155                                    ; preds = %6151
  %6156 = fmul fast float %3290, 0x400921FB60000000
  %6157 = fmul fast float %6156, %5670
  %6158 = fmul fast float %6157, %6144
  br label %6159

; <label>:6159                                    ; preds = %6155, %6151
  %6160 = phi float [ %6158, %6155 ], [ 0.000000e+00, %6151 ]
  %6161 = fmul fast float %6152, %3474
  %6162 = fmul fast float %6152, %3475
  %6163 = fmul fast float %6152, %3476
  %6164 = fmul fast float %6160, %3474
  %6165 = fmul fast float %6160, %3475
  %6166 = fmul fast float %6160, %3476
  br label %6167

; <label>:6167                                    ; preds = %6159, %5665
  %6168 = phi float [ %6161, %6159 ], [ 0.000000e+00, %5665 ]
  %6169 = phi float [ %6162, %6159 ], [ 0.000000e+00, %5665 ]
  %6170 = phi float [ %6163, %6159 ], [ 0.000000e+00, %5665 ]
  %6171 = phi float [ %6164, %6159 ], [ 0.000000e+00, %5665 ]
  %6172 = phi float [ %6165, %6159 ], [ 0.000000e+00, %5665 ]
  %6173 = phi float [ %6166, %6159 ], [ 0.000000e+00, %5665 ]
  %6174 = zext i1 %5671 to i32
  br label %6175

; <label>:6175                                    ; preds = %6167, %5663, %5655, %5093, %4308
  %6176 = phi float [ %4112, %4308 ], [ %4093, %5093 ], [ %4093, %5655 ], [ %4093, %6167 ], [ %4093, %5663 ]
  %6177 = phi float [ %4113, %4308 ], [ %4094, %5093 ], [ %4094, %5655 ], [ %4094, %6167 ], [ %4094, %5663 ]
  %6178 = phi float [ %4114, %4308 ], [ %4095, %5093 ], [ %4095, %5655 ], [ %4095, %6167 ], [ %4095, %5663 ]
  %6179 = phi float [ %4309, %4308 ], [ %5094, %5093 ], [ %5656, %5655 ], [ %6168, %6167 ], [ 0.000000e+00, %5663 ]
  %6180 = phi float [ %4310, %4308 ], [ %5095, %5093 ], [ %5657, %5655 ], [ %6169, %6167 ], [ 0.000000e+00, %5663 ]
  %6181 = phi float [ %4311, %4308 ], [ %5096, %5093 ], [ %5658, %5655 ], [ %6170, %6167 ], [ 0.000000e+00, %5663 ]
  %6182 = phi float [ %4312, %4308 ], [ %5097, %5093 ], [ %5659, %5655 ], [ %6171, %6167 ], [ 0.000000e+00, %5663 ]
  %6183 = phi float [ %4313, %4308 ], [ %5098, %5093 ], [ %5660, %5655 ], [ %6172, %6167 ], [ 0.000000e+00, %5663 ]
  %6184 = phi float [ %4314, %4308 ], [ %5099, %5093 ], [ %5661, %5655 ], [ %6173, %6167 ], [ 0.000000e+00, %5663 ]
  %6185 = phi i32 [ %4315, %4308 ], [ %5100, %5093 ], [ %5662, %5655 ], [ %6174, %6167 ], [ 0, %5663 ]
  %6186 = and i32 %3459, 256
  %6187 = icmp eq i32 %6186, 0
  br i1 %6187, label %6528, label %6188

; <label>:6188                                    ; preds = %6175
  %6189 = mul i32 %3488, 52
  %6190 = add i32 %6189, %3336
  %6191 = shl i32 %6190, 2
  %6192 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6191, i32 undef)  ; BufferLoad(srv,index,wot)
  %6193 = extractvalue %dx.types.ResRet.f32 %6192, 0
  %6194 = extractvalue %dx.types.ResRet.f32 %6192, 1
  %6195 = extractvalue %dx.types.ResRet.f32 %6192, 2
  %6196 = extractvalue %dx.types.ResRet.f32 %6192, 3
  %6197 = add i32 %6191, 16
  %6198 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6197, i32 undef)  ; BufferLoad(srv,index,wot)
  %6199 = extractvalue %dx.types.ResRet.f32 %6198, 0
  %6200 = extractvalue %dx.types.ResRet.f32 %6198, 1
  %6201 = extractvalue %dx.types.ResRet.f32 %6198, 2
  %6202 = extractvalue %dx.types.ResRet.f32 %6198, 3
  %6203 = add i32 %6191, 32
  %6204 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6203, i32 undef)  ; BufferLoad(srv,index,wot)
  %6205 = extractvalue %dx.types.ResRet.f32 %6204, 0
  %6206 = extractvalue %dx.types.ResRet.f32 %6204, 1
  %6207 = extractvalue %dx.types.ResRet.f32 %6204, 2
  %6208 = extractvalue %dx.types.ResRet.f32 %6204, 3
  %6209 = add i32 %6191, 48
  %6210 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6209, i32 undef)  ; BufferLoad(srv,index,wot)
  %6211 = extractvalue %dx.types.ResRet.f32 %6210, 0
  %6212 = extractvalue %dx.types.ResRet.f32 %6210, 1
  %6213 = extractvalue %dx.types.ResRet.f32 %6210, 2
  %6214 = extractvalue %dx.types.ResRet.f32 %6210, 3
  %6215 = add i32 %6191, 68
  %6216 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %6215, i32 undef)  ; BufferLoad(srv,index,wot)
  %6217 = add i32 %6191, 76
  %6218 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6217, i32 undef)  ; BufferLoad(srv,index,wot)
  %6219 = extractvalue %dx.types.ResRet.f32 %6218, 0
  %6220 = add i32 %6191, 80
  %6221 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6220, i32 undef)  ; BufferLoad(srv,index,wot)
  %6222 = extractvalue %dx.types.ResRet.f32 %6221, 0
  %6223 = add i32 %6191, 84
  %6224 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6223, i32 undef)  ; BufferLoad(srv,index,wot)
  %6225 = extractvalue %dx.types.ResRet.f32 %6224, 0
  %6226 = add i32 %6191, 96
  %6227 = add i32 %6191, 192
  %6228 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6227, i32 undef)  ; BufferLoad(srv,index,wot)
  %6229 = extractvalue %dx.types.ResRet.f32 %6228, 2
  %6230 = extractvalue %dx.types.ResRet.f32 %6228, 3
  %6231 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6226, i32 undef)  ; BufferLoad(srv,index,wot)
  %6232 = extractvalue %dx.types.ResRet.f32 %6231, 0
  %6233 = extractvalue %dx.types.ResRet.f32 %6231, 1
  %6234 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 0
  %6235 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 0
  store float %6232, float* %6234, align 4
  store float %6233, float* %6235, align 4
  %6236 = add i32 %6191, 112
  %6237 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6236, i32 undef)  ; BufferLoad(srv,index,wot)
  %6238 = extractvalue %dx.types.ResRet.f32 %6237, 0
  %6239 = extractvalue %dx.types.ResRet.f32 %6237, 1
  %6240 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 1
  %6241 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 1
  store float %6238, float* %6240, align 4
  store float %6239, float* %6241, align 4
  %6242 = add i32 %6191, 128
  %6243 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6242, i32 undef)  ; BufferLoad(srv,index,wot)
  %6244 = extractvalue %dx.types.ResRet.f32 %6243, 0
  %6245 = extractvalue %dx.types.ResRet.f32 %6243, 1
  %6246 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 2
  %6247 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 2
  store float %6244, float* %6246, align 4
  store float %6245, float* %6247, align 4
  %6248 = add i32 %6191, 144
  %6249 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6248, i32 undef)  ; BufferLoad(srv,index,wot)
  %6250 = extractvalue %dx.types.ResRet.f32 %6249, 0
  %6251 = extractvalue %dx.types.ResRet.f32 %6249, 1
  %6252 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 3
  %6253 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 3
  store float %6250, float* %6252, align 4
  store float %6251, float* %6253, align 4
  %6254 = add i32 %6191, 160
  %6255 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6254, i32 undef)  ; BufferLoad(srv,index,wot)
  %6256 = extractvalue %dx.types.ResRet.f32 %6255, 0
  %6257 = extractvalue %dx.types.ResRet.f32 %6255, 1
  %6258 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 4
  %6259 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 4
  store float %6256, float* %6258, align 4
  store float %6257, float* %6259, align 4
  %6260 = add i32 %6191, 176
  %6261 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6260, i32 undef)  ; BufferLoad(srv,index,wot)
  %6262 = extractvalue %dx.types.ResRet.f32 %6261, 0
  %6263 = extractvalue %dx.types.ResRet.f32 %6261, 1
  %6264 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 5
  %6265 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 5
  store float %6262, float* %6264, align 4
  store float %6263, float* %6265, align 4
  %6266 = icmp ne i32 %6185, 0
  %6267 = and i32 %3459, 16
  %6268 = icmp ne i32 %6267, 0
  %6269 = and i1 %6268, %6266
  br i1 %6269, label %6270, label %6307

; <label>:6270                                    ; preds = %6188
  %6271 = extractvalue %dx.types.ResRet.i32 %6216, 0
  %6272 = and i32 %6271, 65535
  %6273 = uitofp i32 %6272 to float
  %6274 = fsub fast float -0.000000e+00, %6176
  %6275 = fsub fast float -0.000000e+00, %6177
  %6276 = fsub fast float -0.000000e+00, %6178
  %6277 = fmul fast float %3507, %6274
  %6278 = call float @dx.op.tertiary.f32(i32 46, float %3508, float %6275, float %6277)  ; FMad(a,b,c)
  %6279 = call float @dx.op.tertiary.f32(i32 46, float %3509, float %6276, float %6278)  ; FMad(a,b,c)
  %6280 = fmul fast float %3499, %6274
  %6281 = call float @dx.op.tertiary.f32(i32 46, float %3500, float %6275, float %6280)  ; FMad(a,b,c)
  %6282 = call float @dx.op.tertiary.f32(i32 46, float %3501, float %6276, float %6281)  ; FMad(a,b,c)
  %6283 = fmul fast float %3491, %6274
  %6284 = call float @dx.op.tertiary.f32(i32 46, float %3492, float %6275, float %6283)  ; FMad(a,b,c)
  %6285 = call float @dx.op.tertiary.f32(i32 46, float %3493, float %6276, float %6284)  ; FMad(a,b,c)
  %6286 = fmul fast float %6285, 5.000000e-01
  %6287 = fadd fast float %6286, 5.000000e-01
  %6288 = fdiv fast float %6282, %6279
  %6289 = call float @dx.op.unary.f32(i32 17, float %6288)  ; Atan(value)
  %6290 = fadd fast float %6289, 0x400921FB60000000
  %6291 = fadd fast float %6289, 0xC00921FB60000000
  %6292 = fcmp fast olt float %6279, 0.000000e+00
  %6293 = fcmp fast oeq float %6279, 0.000000e+00
  %6294 = fcmp fast oge float %6282, 0.000000e+00
  %6295 = fcmp fast olt float %6282, 0.000000e+00
  %6296 = and i1 %6292, %6294
  %6297 = select i1 %6296, float %6290, float %6289
  %6298 = and i1 %6292, %6295
  %6299 = select i1 %6298, float %6291, float %6297
  %6300 = and i1 %6293, %6295
  %6301 = and i1 %6293, %6294
  %6302 = fmul fast float %6299, 0x3FC45F3060000000
  %6303 = select i1 %6300, float -2.500000e-01, float %6302
  %6304 = select i1 %6301, float 2.500000e-01, float %6303
  %6305 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %33, %dx.types.Handle %41, float %6304, float %6287, float %6273, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %6306 = extractvalue %dx.types.ResRet.f32 %6305, 0
  br label %6307

; <label>:6307                                    ; preds = %6270, %6188
  %6308 = phi float [ %6306, %6270 ], [ 1.000000e+00, %6188 ]
  %6309 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 30)  ; CBufferLoadLegacy(handle,regIndex)
  %6310 = extractvalue %dx.types.CBufRet.i32 %6309, 0
  %6311 = extractvalue %dx.types.CBufRet.i32 %6309, 1
  %6312 = extractvalue %dx.types.CBufRet.i32 %6309, 2
  %6313 = and i32 %3459, 6144
  %6314 = icmp ne i32 %6313, 0
  %6315 = and i1 %6314, %6266
  br i1 %6315, label %6316, label %6528

; <label>:6316                                    ; preds = %6307
  %6317 = call float @dx.op.dot3.f32(i32 55, float %3491, float %3492, float %3493, float %6176, float %6177, float %6178)  ; Dot3(ax,ay,az,bx,by,bz)
  %6318 = fmul fast float %6317, %6222
  %6319 = fadd fast float %6318, %6225
  %6320 = call float @dx.op.unary.f32(i32 7, float %6319)  ; Saturate(value)
  %6321 = fmul fast float %6320, %6320
  %6322 = fcmp fast ogt float %6321, 0.000000e+00
  br i1 %6322, label %6323, label %6528

; <label>:6323                                    ; preds = %6316
  %6324 = icmp eq i32 %6313, 4096
  br i1 %6324, label %6325, label %6369

; <label>:6325                                    ; preds = %6323
  %6326 = call float @dx.op.unary.f32(i32 6, float %4088)  ; FAbs(value)
  %6327 = call float @dx.op.unary.f32(i32 6, float %4089)  ; FAbs(value)
  %6328 = call float @dx.op.unary.f32(i32 6, float %4090)  ; FAbs(value)
  %6329 = call float @dx.op.binary.f32(i32 35, float %6326, float %6327)  ; FMax(a,b)
  %6330 = call float @dx.op.binary.f32(i32 35, float %6329, float %6328)  ; FMax(a,b)
  %6331 = fcmp fast oge float %6328, %6327
  %6332 = fcmp fast oge float %6328, %6326
  %6333 = and i1 %6332, %6331
  br i1 %6333, label %6334, label %6340

; <label>:6334                                    ; preds = %6325
  %6335 = fsub fast float -0.000000e+00, %4088
  %6336 = fcmp fast olt float %4090, 0.000000e+00
  %6337 = select i1 %6336, float %6335, float %4088
  %6338 = fsub fast float -0.000000e+00, %4089
  %6339 = select i1 %6336, float 5.000000e+00, float 4.000000e+00
  br label %6352

; <label>:6340                                    ; preds = %6325
  %6341 = fcmp fast ult float %6327, %6326
  %6342 = fsub fast float -0.000000e+00, %4090
  br i1 %6341, label %6347, label %6343

; <label>:6343                                    ; preds = %6340
  %6344 = fcmp fast olt float %4089, 0.000000e+00
  %6345 = select i1 %6344, float %6342, float %4090
  %6346 = select i1 %6344, float 3.000000e+00, float 2.000000e+00
  br label %6352

; <label>:6347                                    ; preds = %6340
  %6348 = fcmp fast olt float %4088, 0.000000e+00
  %6349 = select i1 %6348, float %4090, float %6342
  %6350 = fsub fast float -0.000000e+00, %4089
  %6351 = select i1 %6348, float 1.000000e+00, float 0.000000e+00
  br label %6352

; <label>:6352                                    ; preds = %6347, %6343, %6334
  %6353 = phi float [ %6337, %6334 ], [ %4088, %6343 ], [ %6349, %6347 ]
  %6354 = phi float [ %6338, %6334 ], [ %6345, %6343 ], [ %6350, %6347 ]
  %6355 = phi float [ %6339, %6334 ], [ %6346, %6343 ], [ %6351, %6347 ]
  %6356 = fsub fast float -0.000000e+00, %6353
  %6357 = fdiv fast float %6356, %6330
  %6358 = fsub fast float -0.000000e+00, %6354
  %6359 = fdiv fast float %6358, %6330
  %6360 = fmul fast float %6330, %6207
  %6361 = fsub fast float %6208, %6360
  %6362 = fdiv fast float %6361, %6330
  %6363 = fsub fast float 1.000000e+00, %6362
  %6364 = fptoui float %6355 to i32
  %6365 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 %6364
  %6366 = load float, float* %6365, align 4
  %6367 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 %6364
  %6368 = load float, float* %6367, align 4
  br label %6396

; <label>:6369                                    ; preds = %6323
  %6370 = fmul fast float %6193, %565
  %6371 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6194, float %6370)  ; FMad(a,b,c)
  %6372 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6195, float %6371)  ; FMad(a,b,c)
  %6373 = fadd fast float %6372, %6196
  %6374 = fmul fast float %6199, %565
  %6375 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6200, float %6374)  ; FMad(a,b,c)
  %6376 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6201, float %6375)  ; FMad(a,b,c)
  %6377 = fadd fast float %6376, %6202
  %6378 = fmul fast float %6205, %565
  %6379 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6206, float %6378)  ; FMad(a,b,c)
  %6380 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6207, float %6379)  ; FMad(a,b,c)
  %6381 = fadd fast float %6380, %6208
  %6382 = fmul fast float %6211, %565
  %6383 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6212, float %6382)  ; FMad(a,b,c)
  %6384 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6213, float %6383)  ; FMad(a,b,c)
  %6385 = fadd fast float %6384, %6214
  %6386 = fdiv fast float 1.000000e+00, %6385
  %6387 = fmul fast float %6386, %6373
  %6388 = fmul fast float %6377, %6386
  %6389 = fsub fast float -0.000000e+00, %6388
  %6390 = fmul fast float %6386, %6381
  %6391 = fsub fast float 1.000000e+00, %6390
  %6392 = call float @dx.op.unary.f32(i32 6, float %6389)  ; FAbs(value)
  %6393 = call float @dx.op.unary.f32(i32 6, float %6387)  ; FAbs(value)
  %6394 = call float @dx.op.binary.f32(i32 35, float %6393, float %6392)  ; FMax(a,b)
  %6395 = call float @dx.op.binary.f32(i32 35, float %6394, float %6391)  ; FMax(a,b)
  br label %6396

; <label>:6396                                    ; preds = %6369, %6352
  %6397 = phi float [ %6368, %6352 ], [ %6233, %6369 ]
  %6398 = phi float [ %6366, %6352 ], [ %6232, %6369 ]
  %6399 = phi float [ %6363, %6352 ], [ %6395, %6369 ]
  %6400 = phi float [ %6357, %6352 ], [ %6387, %6369 ]
  %6401 = phi float [ %6359, %6352 ], [ %6389, %6369 ]
  %6402 = phi float [ %6362, %6352 ], [ %6390, %6369 ]
  %6403 = fcmp fast ole float %6399, 1.000000e+00
  %6404 = fmul fast float %6400, %6229
  %6405 = fmul fast float %6401, %6230
  %6406 = fadd fast float %6404, %6398
  %6407 = fadd fast float %6405, %6397
  %6408 = fcmp fast oge float %6398, 0.000000e+00
  %6409 = and i1 %6408, %6403
  %6410 = add i32 %6310, -1
  %6411 = lshr i32 %6410, 1
  %6412 = fmul fast float %6406, %134
  %6413 = fmul fast float %6407, %134
  %6414 = fadd fast float %6412, -5.000000e-01
  %6415 = fadd fast float %6413, -5.000000e-01
  %6416 = call float @dx.op.unary.f32(i32 22, float %6414)  ; Frc(value)
  %6417 = call float @dx.op.unary.f32(i32 22, float %6415)  ; Frc(value)
  %6418 = fsub fast float 1.000000e+00, %6416
  %6419 = fsub fast float 1.000000e+00, %6417
  %6420 = fmul fast float %6419, %6418
  %6421 = fmul fast float %6419, %6416
  %6422 = fmul fast float %6418, %6417
  %6423 = fmul fast float %6417, %6416
  %6424 = call float @dx.op.unary.f32(i32 27, float %6414)  ; Round_ni(value)
  %6425 = fptosi float %6424 to i32
  %6426 = sub i32 %6425, %6411
  %6427 = sitofp i32 %6426 to float
  %6428 = fmul fast float %6427, %135
  %6429 = fadd fast float %6428, %135
  %6430 = fmul fast float %135, 2.000000e+00
  %6431 = icmp eq i32 %6310, 0
  br i1 %6431, label %6519, label %6432

; <label>:6432                                    ; preds = %6396
  %6433 = call float @dx.op.unary.f32(i32 27, float %6415)  ; Round_ni(value)
  %6434 = fptosi float %6433 to i32
  %6435 = sub i32 %6434, %6411
  %6436 = sitofp i32 %6435 to float
  %6437 = fmul fast float %6436, %135
  %6438 = fadd fast float %6437, %135
  br label %6439

; <label>:6439                                    ; preds = %6512, %6432
  %6440 = phi float [ %6513, %6512 ], [ %6438, %6432 ]
  %6441 = phi float [ %6508, %6512 ], [ 0.000000e+00, %6432 ]
  %6442 = phi i32 [ %6515, %6512 ], [ %6311, %6432 ]
  %6443 = phi i32 [ %6516, %6512 ], [ 0, %6432 ]
  br label %6444

; <label>:6444                                    ; preds = %6444, %6439
  %6445 = phi float [ %6508, %6444 ], [ %6441, %6439 ]
  %6446 = phi float [ %6509, %6444 ], [ %6429, %6439 ]
  %6447 = phi i32 [ %6510, %6444 ], [ 0, %6439 ]
  %6448 = add i32 %6447, %6442
  %6449 = add i32 %6448, %6312
  %6450 = add i32 %6448, 35
  %6451 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %6450)  ; CBufferLoadLegacy(handle,regIndex)
  %6452 = extractvalue %dx.types.CBufRet.f32 %6451, 0
  %6453 = fmul fast float %6452, %6423
  %6454 = extractvalue %dx.types.CBufRet.f32 %6451, 1
  %6455 = fmul fast float %6454, %6422
  %6456 = fadd fast float %6455, %6453
  %6457 = extractvalue %dx.types.CBufRet.f32 %6451, 2
  %6458 = fmul fast float %6457, %6421
  %6459 = fadd fast float %6456, %6458
  %6460 = extractvalue %dx.types.CBufRet.f32 %6451, 3
  %6461 = fmul fast float %6460, %6420
  %6462 = fadd fast float %6459, %6461
  %6463 = add i32 %6448, 36
  %6464 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %6463)  ; CBufferLoadLegacy(handle,regIndex)
  %6465 = extractvalue %dx.types.CBufRet.f32 %6464, 0
  %6466 = fmul fast float %6465, %6423
  %6467 = extractvalue %dx.types.CBufRet.f32 %6464, 1
  %6468 = fmul fast float %6467, %6422
  %6469 = fadd fast float %6468, %6466
  %6470 = extractvalue %dx.types.CBufRet.f32 %6464, 2
  %6471 = fmul fast float %6470, %6421
  %6472 = fadd fast float %6469, %6471
  %6473 = extractvalue %dx.types.CBufRet.f32 %6464, 3
  %6474 = fmul fast float %6473, %6420
  %6475 = fadd fast float %6472, %6474
  %6476 = add i32 %6449, 35
  %6477 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %6476)  ; CBufferLoadLegacy(handle,regIndex)
  %6478 = extractvalue %dx.types.CBufRet.f32 %6477, 0
  %6479 = fmul fast float %6478, %6423
  %6480 = extractvalue %dx.types.CBufRet.f32 %6477, 1
  %6481 = fmul fast float %6480, %6422
  %6482 = fadd fast float %6481, %6479
  %6483 = extractvalue %dx.types.CBufRet.f32 %6477, 2
  %6484 = fmul fast float %6483, %6421
  %6485 = fadd fast float %6482, %6484
  %6486 = extractvalue %dx.types.CBufRet.f32 %6477, 3
  %6487 = fmul fast float %6486, %6420
  %6488 = fadd fast float %6485, %6487
  %6489 = add i32 %6449, 36
  %6490 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %6489)  ; CBufferLoadLegacy(handle,regIndex)
  %6491 = extractvalue %dx.types.CBufRet.f32 %6490, 0
  %6492 = fmul fast float %6491, %6423
  %6493 = extractvalue %dx.types.CBufRet.f32 %6490, 1
  %6494 = fmul fast float %6493, %6422
  %6495 = fadd fast float %6494, %6492
  %6496 = extractvalue %dx.types.CBufRet.f32 %6490, 2
  %6497 = fmul fast float %6496, %6421
  %6498 = fadd fast float %6495, %6497
  %6499 = extractvalue %dx.types.CBufRet.f32 %6490, 3
  %6500 = fmul fast float %6499, %6420
  %6501 = fadd fast float %6498, %6500
  %6502 = call %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32 74, %dx.types.Handle %30, %dx.types.Handle %36, float %6446, float %6440, float undef, float undef, i32 0, i32 0, i32 0, float %6402)  ; TextureGatherCmp(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,channel,compareValue)
  %6503 = extractvalue %dx.types.ResRet.f32 %6502, 0
  %6504 = extractvalue %dx.types.ResRet.f32 %6502, 1
  %6505 = extractvalue %dx.types.ResRet.f32 %6502, 2
  %6506 = extractvalue %dx.types.ResRet.f32 %6502, 3
  %6507 = call float @dx.op.dot4.f32(i32 56, float %6506, float %6505, float %6503, float %6504, float %6462, float %6475, float %6488, float %6501)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %6508 = fadd fast float %6507, %6445
  %6509 = fadd fast float %6446, %6430
  %6510 = add i32 %6447, 2
  %6511 = icmp ult i32 %6510, %6310
  br i1 %6511, label %6444, label %6512

; <label>:6512                                    ; preds = %6444
  %6513 = fadd fast float %6440, %6430
  %6514 = shl i32 %6312, 1
  %6515 = add i32 %6442, %6514
  %6516 = add i32 %6443, 2
  %6517 = icmp ult i32 %6516, %6310
  br i1 %6517, label %6439, label %6518

; <label>:6518                                    ; preds = %6512
  br label %6519

; <label>:6519                                    ; preds = %6518, %6396
  %6520 = phi float [ 0.000000e+00, %6396 ], [ %6508, %6518 ]
  %6521 = call float @dx.op.unary.f32(i32 7, float %6520)  ; Saturate(value)
  %6522 = fadd fast float %6521, -1.000000e+00
  %6523 = select i1 %6409, float %6522, float 0.000000e+00
  %6524 = fmul fast float %6321, %6219
  %6525 = fmul fast float %6524, %6523
  %6526 = fadd fast float %6525, 1.000000e+00
  %6527 = fmul fast float %6526, %6308
  br label %6528

; <label>:6528                                    ; preds = %6519, %6316, %6307, %6175
  %6529 = phi float [ 1.000000e+00, %6175 ], [ %6527, %6519 ], [ %6308, %6316 ], [ %6308, %6307 ]
  %6530 = fmul fast float %6529, %6179
  %6531 = fmul fast float %6529, %6180
  %6532 = fmul fast float %6529, %6181
  %6533 = fadd fast float %6530, %3447
  %6534 = fadd fast float %6531, %3448
  %6535 = fadd fast float %6532, %3449
  %6536 = fmul fast float %6529, %6182
  %6537 = fmul fast float %6529, %6183
  %6538 = fmul fast float %6529, %6184
  %6539 = fadd fast float %6536, %3444
  %6540 = fadd fast float %6537, %3445
  %6541 = fadd fast float %6538, %3446
  br label %3515

; <label>:6542                                    ; preds = %3515
  br label %6543

; <label>:6543                                    ; preds = %6542, %3438
  %6544 = phi float [ %3403, %3438 ], [ %3516, %6542 ]
  %6545 = phi float [ %3404, %3438 ], [ %3517, %6542 ]
  %6546 = phi float [ %3405, %3438 ], [ %3518, %6542 ]
  %6547 = phi float [ %3406, %3438 ], [ %3519, %6542 ]
  %6548 = phi float [ %3407, %3438 ], [ %3520, %6542 ]
  %6549 = phi float [ %3408, %3438 ], [ %3521, %6542 ]
  %6550 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 2)  ; CBufferLoadLegacy(handle,regIndex)
  %6551 = extractvalue %dx.types.CBufRet.f32 %6550, 1
  %6552 = fmul fast float %2756, 0x3F40600000000000
  %6553 = fadd fast float %6552, 0x3FEFFCB940000000
  %6554 = fmul fast float %2757, 0x3F40600000000000
  %6555 = fadd fast float %6554, 0x3FEFFCB940000000
  %6556 = fmul fast float %2758, 0x3F40600000000000
  %6557 = fadd fast float %6556, 0x3FEFFCB940000000
  %6558 = call float @dx.op.unary.f32(i32 7, float %6553)  ; Saturate(value)
  %6559 = call float @dx.op.unary.f32(i32 7, float %6555)  ; Saturate(value)
  %6560 = call float @dx.op.unary.f32(i32 7, float %6557)  ; Saturate(value)
  %6561 = fadd fast float %6558, -1.000000e+00
  %6562 = fadd fast float %6559, -1.000000e+00
  %6563 = fadd fast float %6560, -1.000000e+00
  %6564 = fmul fast float %6561, %6551
  %6565 = fmul fast float %6562, %6551
  %6566 = fmul fast float %6563, %6551
  %6567 = fadd fast float %6564, 1.000000e+00
  %6568 = fadd fast float %6565, 1.000000e+00
  %6569 = fadd fast float %6566, 1.000000e+00
  %6570 = fmul fast float %6567, %6547
  %6571 = fmul fast float %6568, %6548
  %6572 = fmul fast float %6569, %6549
  %6573 = add nuw nsw i32 %3409, 1
  %6574 = icmp eq i32 %3409, %3399
  br i1 %6574, label %6575, label %3402

; <label>:6575                                    ; preds = %6543
  br label %6576

; <label>:6576                                    ; preds = %6575, %3393, %3387
  %6577 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6544, %6575 ]
  %6578 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6545, %6575 ]
  %6579 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6546, %6575 ]
  %6580 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6570, %6575 ]
  %6581 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6571, %6575 ]
  %6582 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6572, %6575 ]
  %6583 = fmul fast float %6580, %129
  %6584 = fmul fast float %6581, %129
  %6585 = fmul fast float %6582, %129
  %6586 = fmul fast float %6577, %129
  %6587 = fmul fast float %6578, %129
  %6588 = fmul fast float %6579, %129
  %6589 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %6590 = extractvalue %dx.types.CBufRet.f32 %6589, 0
  %6591 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 1)  ; CBufferLoadLegacy(handle,regIndex)
  %6592 = extractvalue %dx.types.CBufRet.f32 %6591, 1
  %6593 = extractvalue %dx.types.CBufRet.f32 %6589, 1
  %6594 = fsub fast float -0.000000e+00, %272
  %6595 = fsub fast float -0.000000e+00, %273
  %6596 = fsub fast float -0.000000e+00, %274
  %6597 = call float @dx.op.dot3.f32(i32 55, float %6594, float %6595, float %6596, float %2879, float %2880, float %2881)  ; Dot3(ax,ay,az,bx,by,bz)
  %6598 = fmul fast float %6597, 2.000000e+00
  %6599 = fmul fast float %6598, %2879
  %6600 = fmul fast float %6598, %2880
  %6601 = fmul fast float %6598, %2881
  %6602 = fsub fast float %6594, %6599
  %6603 = fsub fast float %6595, %6600
  %6604 = fsub fast float %6596, %6601
  %6605 = and i32 %2884, 2
  %6606 = icmp ne i32 %6605, 0
  %6607 = and i32 %2884, 4
  %6608 = icmp ne i32 %6607, 0
  %6609 = icmp eq i32 %3341, 0
  br i1 %6609, label %7302, label %6610

; <label>:6610                                    ; preds = %6576
  %6611 = add i32 %3391, %3389
  %6612 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %21, i32 %6611, i32 0)  ; BufferLoad(srv,index,wot)
  %6613 = extractvalue %dx.types.ResRet.i32 %6612, 0
  %6614 = and i32 %6613, 65535
  %6615 = lshr i32 %6613, 16
  %6616 = lshr i32 %6614, 5
  %6617 = lshr i32 %6613, 21
  %6618 = icmp ugt i32 %6616, %6617
  br i1 %6618, label %7302, label %6619

; <label>:6619                                    ; preds = %6610
  br label %6620

; <label>:6620                                    ; preds = %7294, %6619
  %6621 = phi float [ %7295, %7294 ], [ 0.000000e+00, %6619 ]
  %6622 = phi float [ %7296, %7294 ], [ 0.000000e+00, %6619 ]
  %6623 = phi float [ %7297, %7294 ], [ 0.000000e+00, %6619 ]
  %6624 = phi float [ %7298, %7294 ], [ 1.000000e+00, %6619 ]
  %6625 = phi i32 [ %7299, %7294 ], [ %6616, %6619 ]
  %6626 = add i32 %3390, %3388
  %6627 = add i32 %6626, %6625
  %6628 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %29, i32 %6627, i32 0)  ; BufferLoad(srv,index,wot)
  %6629 = extractvalue %dx.types.ResRet.i32 %6628, 0
  %6630 = shl i32 %6625, 5
  %6631 = sub nsw i32 %6614, %6630
  %6632 = call i32 @dx.op.binary.i32(i32 37, i32 %6631, i32 0)  ; IMax(a,b)
  %6633 = call i32 @dx.op.binary.i32(i32 38, i32 %6632, i32 31)  ; IMin(a,b)
  %6634 = add nuw nsw i32 %6630, 32
  %6635 = icmp uge i32 %6614, %6634
  %6636 = icmp ult i32 %6615, %6630
  %6637 = or i1 %6636, %6635
  br i1 %6637, label %6646, label %6638

; <label>:6638                                    ; preds = %6620
  %6639 = sub nsw i32 %6615, %6630
  %6640 = call i32 @dx.op.binary.i32(i32 37, i32 %6639, i32 0)  ; IMax(a,b)
  %6641 = call i32 @dx.op.binary.i32(i32 38, i32 %6640, i32 31)  ; IMin(a,b)
  %6642 = sub i32 1, %6633
  %6643 = add i32 %6642, %6641
  %6644 = call i32 @dx.op.binary.i32(i32 37, i32 %6643, i32 0)  ; IMax(a,b)
  %6645 = call i32 @dx.op.binary.i32(i32 38, i32 %6644, i32 32)  ; IMin(a,b)
  br label %6646

; <label>:6646                                    ; preds = %6638, %6620
  %6647 = phi i32 [ %6645, %6638 ], [ 0, %6620 ]
  %6648 = icmp eq i32 %6647, 32
  br i1 %6648, label %6655, label %6649

; <label>:6649                                    ; preds = %6646
  %6650 = and i32 %6647, 31
  %6651 = shl i32 1, %6650
  %6652 = add i32 %6651, -1
  %6653 = and i32 %6633, 31
  %6654 = shl i32 %6652, %6653
  br label %6655

; <label>:6655                                    ; preds = %6649, %6646
  %6656 = phi i32 [ %6654, %6649 ], [ -1, %6646 ]
  %6657 = and i32 %6656, %6629
  %6658 = icmp eq i32 %6657, 0
  br i1 %6658, label %7294, label %6659

; <label>:6659                                    ; preds = %6655
  br label %6660

; <label>:6660                                    ; preds = %7285, %6659
  %6661 = phi float [ %7286, %7285 ], [ %6621, %6659 ]
  %6662 = phi float [ %7287, %7285 ], [ %6622, %6659 ]
  %6663 = phi float [ %7288, %7285 ], [ %6623, %6659 ]
  %6664 = phi float [ %7289, %7285 ], [ %6624, %6659 ]
  %6665 = phi i32 [ %6669, %7285 ], [ %6657, %6659 ]
  %6666 = call i32 @dx.op.unaryBits.i32(i32 32, i32 %6665)  ; FirstbitLo(value)
  %6667 = and i32 %6666, 31
  %6668 = shl i32 1, %6667
  %6669 = xor i32 %6668, %6665
  %6670 = add i32 %6666, %6630
  %6671 = add i32 %6670, %3333
  %6672 = shl i32 %6671, 2
  %6673 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %6672, i32 undef)  ; BufferLoad(srv,index,wot)
  %6674 = extractvalue %dx.types.ResRet.i32 %6673, 0
  %6675 = lshr i32 %6674, 16
  %6676 = and i32 %6675, 3
  %6677 = icmp eq i32 %6676, 1
  br i1 %6677, label %6678, label %6682

; <label>:6678                                    ; preds = %6660
  %6679 = and i32 %6674, 786432
  %6680 = icmp eq i32 %6679, 262144
  %6681 = select i1 %6680, i32 2, i32 1
  br label %6682

; <label>:6682                                    ; preds = %6678, %6660
  %6683 = phi i32 [ %6676, %6660 ], [ %6681, %6678 ]
  switch i32 %6683, label %7285 [
    i32 1, label %6997
    i32 2, label %6684
  ]

; <label>:6684                                    ; preds = %6682
  %6685 = mul i32 %6670, 44
  %6686 = add i32 %6685, %3338
  %6687 = shl i32 %6686, 2
  %6688 = add i32 %6687, 16
  %6689 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6688, i32 undef)  ; BufferLoad(srv,index,wot)
  %6690 = extractvalue %dx.types.ResRet.f32 %6689, 0
  %6691 = extractvalue %dx.types.ResRet.f32 %6689, 1
  %6692 = extractvalue %dx.types.ResRet.f32 %6689, 2
  %6693 = extractvalue %dx.types.ResRet.f32 %6689, 3
  %6694 = add i32 %6687, 32
  %6695 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6694, i32 undef)  ; BufferLoad(srv,index,wot)
  %6696 = extractvalue %dx.types.ResRet.f32 %6695, 0
  %6697 = extractvalue %dx.types.ResRet.f32 %6695, 1
  %6698 = extractvalue %dx.types.ResRet.f32 %6695, 2
  %6699 = extractvalue %dx.types.ResRet.f32 %6695, 3
  %6700 = add i32 %6687, 48
  %6701 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6700, i32 undef)  ; BufferLoad(srv,index,wot)
  %6702 = extractvalue %dx.types.ResRet.f32 %6701, 0
  %6703 = extractvalue %dx.types.ResRet.f32 %6701, 1
  %6704 = extractvalue %dx.types.ResRet.f32 %6701, 2
  %6705 = extractvalue %dx.types.ResRet.f32 %6701, 3
  %6706 = add i32 %6687, 80
  %6707 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6706, i32 undef)  ; BufferLoad(srv,index,wot)
  %6708 = extractvalue %dx.types.ResRet.f32 %6707, 0
  %6709 = extractvalue %dx.types.ResRet.f32 %6707, 1
  %6710 = extractvalue %dx.types.ResRet.f32 %6707, 2
  %6711 = add i32 %6687, 92
  %6712 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6711, i32 undef)  ; BufferLoad(srv,index,wot)
  %6713 = extractvalue %dx.types.ResRet.f32 %6712, 0
  %6714 = add i32 %6687, 96
  %6715 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6714, i32 undef)  ; BufferLoad(srv,index,wot)
  %6716 = extractvalue %dx.types.ResRet.f32 %6715, 0
  %6717 = extractvalue %dx.types.ResRet.f32 %6715, 1
  %6718 = extractvalue %dx.types.ResRet.f32 %6715, 2
  %6719 = add i32 %6687, 108
  %6720 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6719, i32 undef)  ; BufferLoad(srv,index,wot)
  %6721 = extractvalue %dx.types.ResRet.f32 %6720, 0
  %6722 = add i32 %6687, 112
  %6723 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6722, i32 undef)  ; BufferLoad(srv,index,wot)
  %6724 = extractvalue %dx.types.ResRet.f32 %6723, 0
  %6725 = extractvalue %dx.types.ResRet.f32 %6723, 1
  %6726 = extractvalue %dx.types.ResRet.f32 %6723, 2
  %6727 = and i32 %6674, 4
  %6728 = icmp ne i32 %6727, 0
  %6729 = and i1 %6606, %6728
  br i1 %6729, label %6730, label %6748

; <label>:6730                                    ; preds = %6684
  %6731 = lshr i32 %6674, 5
  %6732 = and i32 %6731, 511
  %6733 = mul nuw nsw i32 %6732, 3
  %6734 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %6733, i32 0)  ; BufferLoad(srv,index,wot)
  %6735 = extractvalue %dx.types.ResRet.f32 %6734, 0
  %6736 = extractvalue %dx.types.ResRet.f32 %6734, 1
  %6737 = extractvalue %dx.types.ResRet.f32 %6734, 2
  %6738 = extractvalue %dx.types.ResRet.f32 %6734, 3
  %6739 = add nuw nsw i32 %6733, 1
  %6740 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %6739, i32 0)  ; BufferLoad(srv,index,wot)
  %6741 = extractvalue %dx.types.ResRet.f32 %6740, 0
  %6742 = extractvalue %dx.types.ResRet.f32 %6740, 1
  %6743 = extractvalue %dx.types.ResRet.f32 %6740, 2
  %6744 = extractvalue %dx.types.ResRet.f32 %6740, 3
  %6745 = add nuw nsw i32 %6733, 2
  %6746 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %6745, i32 0)  ; BufferLoad(srv,index,wot)
  %6747 = extractvalue %dx.types.ResRet.f32 %6746, 0
  br label %6748

; <label>:6748                                    ; preds = %6730, %6684
  %6749 = phi float [ %6747, %6730 ], [ 0.000000e+00, %6684 ]
  %6750 = phi float [ %6741, %6730 ], [ 0.000000e+00, %6684 ]
  %6751 = phi float [ %6742, %6730 ], [ 0.000000e+00, %6684 ]
  %6752 = phi float [ %6743, %6730 ], [ 0.000000e+00, %6684 ]
  %6753 = phi float [ %6744, %6730 ], [ 0.000000e+00, %6684 ]
  %6754 = phi float [ %6735, %6730 ], [ 0.000000e+00, %6684 ]
  %6755 = phi float [ %6736, %6730 ], [ 0.000000e+00, %6684 ]
  %6756 = phi float [ %6737, %6730 ], [ 0.000000e+00, %6684 ]
  %6757 = phi float [ %6738, %6730 ], [ 0.000000e+00, %6684 ]
  %6758 = lshr i32 %6674, 2
  %6759 = zext i1 %6729 to i32
  %6760 = and i32 %6759, %6758
  %6761 = icmp eq i32 %6760, 0
  %6762 = fsub fast float 1.000000e+00, %3283
  %6763 = call float @dx.op.unary.f32(i32 7, float %6762)  ; Saturate(value)
  %6764 = call float @dx.op.unary.f32(i32 24, float %6763)  ; Sqrt(value)
  %6765 = fadd fast float %6764, %3283
  %6766 = fmul fast float %6765, %6762
  %6767 = fsub fast float %6602, %2879
  %6768 = fsub fast float %6603, %2880
  %6769 = fsub fast float %6604, %2881
  %6770 = fmul fast float %6766, %6767
  %6771 = fmul fast float %6766, %6768
  %6772 = fmul fast float %6766, %6769
  %6773 = fadd fast float %6770, %2879
  %6774 = fadd fast float %6771, %2880
  %6775 = fadd fast float %6772, %2881
  %6776 = fmul fast float %6690, %565
  %6777 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6693, float %6776)  ; FMad(a,b,c)
  %6778 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6698, float %6777)  ; FMad(a,b,c)
  %6779 = fadd fast float %6778, %6703
  %6780 = fmul fast float %6691, %565
  %6781 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6696, float %6780)  ; FMad(a,b,c)
  %6782 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6699, float %6781)  ; FMad(a,b,c)
  %6783 = fadd fast float %6782, %6704
  %6784 = fmul fast float %6692, %565
  %6785 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6697, float %6784)  ; FMad(a,b,c)
  %6786 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6702, float %6785)  ; FMad(a,b,c)
  %6787 = fadd fast float %6786, %6705
  %6788 = fmul fast float %6773, %6690
  %6789 = call float @dx.op.tertiary.f32(i32 46, float %6774, float %6693, float %6788)  ; FMad(a,b,c)
  %6790 = call float @dx.op.tertiary.f32(i32 46, float %6775, float %6698, float %6789)  ; FMad(a,b,c)
  %6791 = fmul fast float %6773, %6691
  %6792 = call float @dx.op.tertiary.f32(i32 46, float %6774, float %6696, float %6791)  ; FMad(a,b,c)
  %6793 = call float @dx.op.tertiary.f32(i32 46, float %6775, float %6699, float %6792)  ; FMad(a,b,c)
  %6794 = fmul fast float %6773, %6692
  %6795 = call float @dx.op.tertiary.f32(i32 46, float %6774, float %6697, float %6794)  ; FMad(a,b,c)
  %6796 = call float @dx.op.tertiary.f32(i32 46, float %6775, float %6702, float %6795)  ; FMad(a,b,c)
  %6797 = and i32 %6674, 1
  %6798 = icmp eq i32 %6797, 0
  br i1 %6798, label %6822, label %6799

; <label>:6799                                    ; preds = %6748
  %6800 = fsub fast float -0.000000e+00, %6724
  %6801 = fsub fast float -0.000000e+00, %6725
  %6802 = fsub fast float -0.000000e+00, %6726
  %6803 = fdiv fast float 1.000000e+00, %6790
  %6804 = fdiv fast float 1.000000e+00, %6793
  %6805 = fdiv fast float 1.000000e+00, %6796
  %6806 = fcmp fast ogt float %6790, 0.000000e+00
  %6807 = fcmp fast ogt float %6793, 0.000000e+00
  %6808 = fcmp fast ogt float %6796, 0.000000e+00
  %6809 = select i1 %6806, float %6724, float %6800
  %6810 = fsub float %6809, %6779
  %6811 = fmul float %6810, %6803
  %6812 = select i1 %6807, float %6725, float %6801
  %6813 = fsub float %6812, %6783
  %6814 = fmul float %6813, %6804
  %6815 = select i1 %6808, float %6726, float %6802
  %6816 = fsub float %6815, %6787
  %6817 = fmul float %6816, %6805
  %6818 = call float @dx.op.binary.f32(i32 36, float %6811, float %6814)  ; FMin(a,b)
  %6819 = call float @dx.op.binary.f32(i32 36, float %6818, float %6817)  ; FMin(a,b)
  %6820 = fcmp fast oge float %6819, 0.000000e+00
  %6821 = zext i1 %6820 to i32
  br label %6822

; <label>:6822                                    ; preds = %6799, %6748
  %6823 = phi float [ %6819, %6799 ], [ 1.000000e+00, %6748 ]
  %6824 = phi i32 [ %6821, %6799 ], [ 1, %6748 ]
  %6825 = icmp eq i32 %6824, 0
  br i1 %6825, label %6989, label %6826

; <label>:6826                                    ; preds = %6822
  %6827 = fmul fast float %6823, %6790
  %6828 = fmul fast float %6823, %6793
  %6829 = fmul fast float %6823, %6796
  %6830 = fsub fast float %6779, %6708
  %6831 = fadd fast float %6827, %6830
  %6832 = fsub fast float %6783, %6709
  %6833 = fadd fast float %6828, %6832
  %6834 = fsub fast float %6787, %6710
  %6835 = fadd fast float %6829, %6834
  %6836 = fmul fast float %6831, %6831
  %6837 = fmul fast float %6833, %6833
  %6838 = fadd fast float %6836, %6837
  %6839 = fmul fast float %6835, %6835
  %6840 = fadd fast float %6838, %6839
  %6841 = call float @dx.op.unary.f32(i32 24, float %6840)  ; Sqrt(value)
  br i1 %6798, label %6848, label %6842

; <label>:6842                                    ; preds = %6826
  %6843 = call float @dx.op.unary.f32(i32 7, float %3283)  ; Saturate(value)
  %6844 = fmul fast float %6843, 2.000000e+00
  %6845 = fsub fast float 3.000000e+00, %6844
  %6846 = fmul fast float %6843, %6843
  %6847 = fmul fast float %6846, %6845
  br label %6848

; <label>:6848                                    ; preds = %6842, %6826
  %6849 = phi float [ %6847, %6842 ], [ 1.000000e+00, %6826 ]
  %6850 = fmul fast float %3282, 2.000000e+00
  %6851 = call float @dx.op.unary.f32(i32 7, float %6850)  ; Saturate(value)
  %6852 = fsub fast float 1.000000e+00, %6851
  %6853 = fmul fast float %6852, %2882
  %6854 = fadd fast float %6853, %6851
  %6855 = fmul fast float %6854, %3283
  %6856 = fmul fast float %6855, %6823
  %6857 = fdiv fast float %6856, %6841
  %6858 = fsub fast float %6855, %6857
  %6859 = fmul fast float %6858, %6849
  %6860 = fadd fast float %6859, %6857
  %6861 = fsub fast float %6790, %6831
  %6862 = fsub fast float %6793, %6833
  %6863 = fsub fast float %6796, %6835
  %6864 = fmul fast float %6849, %6861
  %6865 = fmul fast float %6849, %6862
  %6866 = fmul fast float %6849, %6863
  %6867 = fadd fast float %6864, %6831
  %6868 = fadd fast float %6865, %6833
  %6869 = fadd fast float %6866, %6835
  %6870 = lshr i32 %6674, 5
  %6871 = and i32 %6870, 511
  %6872 = uitofp i32 %6871 to float
  %6873 = fmul fast float %6860, %6590
  %6874 = fadd fast float %6873, 1.000000e+00
  %6875 = call float @dx.op.unary.f32(i32 23, float %6874)  ; Log(value)
  %6876 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %31, %dx.types.Handle %39, float %6867, float %6868, float %6869, float %6872, i32 undef, i32 undef, i32 undef, float %6875)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %6877 = extractvalue %dx.types.ResRet.f32 %6876, 0
  %6878 = extractvalue %dx.types.ResRet.f32 %6876, 1
  %6879 = extractvalue %dx.types.ResRet.f32 %6876, 2
  %6880 = extractvalue %dx.types.ResRet.f32 %6876, 3
  %6881 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %26, %dx.types.Handle %39, float %6867, float %6868, float %6869, float %6872, i32 undef, i32 undef, i32 undef, float %6875)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %6882 = extractvalue %dx.types.ResRet.f32 %6881, 0
  %6883 = call float @dx.op.binary.f32(i32 36, float %6880, float %6882)  ; FMin(a,b)
  %6884 = fmul fast float %6592, %3290
  %6885 = fmul fast float %6877, %6884
  %6886 = fmul fast float %6878, %6884
  %6887 = fmul fast float %6879, %6884
  br i1 %6761, label %6938, label %6888

; <label>:6888                                    ; preds = %6848
  %6889 = and i32 %6674, 8
  %6890 = icmp ne i32 %6889, 0
  %6891 = call float @dx.op.dot3.f32(i32 55, float %6867, float %6868, float %6869, float %6867, float %6868, float %6869)  ; Dot3(ax,ay,az,bx,by,bz)
  %6892 = call float @dx.op.unary.f32(i32 25, float %6891)  ; Rsqrt(value)
  %6893 = fmul fast float %6892, %6867
  %6894 = fmul fast float %6892, %6868
  %6895 = fmul fast float %6892, %6869
  %6896 = fmul fast float %6894, 0xBFF05F8CE0000000
  %6897 = fmul fast float %6895, 0x3FF05F8CE0000000
  %6898 = fmul fast float %6893, 0xBFF05F8CE0000000
  %6899 = fmul fast float %6893, 0x3FEB756F20000000
  %6900 = fmul fast float %6899, %6894
  %6901 = fmul fast float %6895, 0xBFEB756F20000000
  %6902 = fmul fast float %6901, %6894
  %6903 = fmul fast float %6895, %6895
  %6904 = fmul fast float %6903, 0x3FE7C7ADC0000000
  %6905 = fadd fast float %6904, 0xBFCFB4E7C0000000
  %6906 = fmul fast float %6901, %6893
  %6907 = fmul fast float %6893, %6893
  %6908 = fmul fast float %6894, %6894
  %6909 = fsub fast float %6907, %6908
  %6910 = fmul fast float %6754, 0x3FEC5BF9E0000000
  %6911 = fmul fast float %6896, %6755
  %6912 = fadd fast float %6911, %6910
  %6913 = fmul fast float %6897, %6756
  %6914 = fadd fast float %6912, %6913
  %6915 = fmul fast float %6898, %6757
  %6916 = fadd fast float %6914, %6915
  %6917 = fmul fast float %6900, %6750
  %6918 = fadd fast float %6916, %6917
  %6919 = fmul fast float %6902, %6751
  %6920 = fadd fast float %6918, %6919
  %6921 = fmul fast float %6905, %6752
  %6922 = fmul fast float %6906, %6753
  %6923 = fmul fast float %6749, 0x3FDB756F20000000
  %6924 = fmul fast float %6923, %6909
  %6925 = fadd fast float %6920, %6922
  %6926 = fadd fast float %6925, %6924
  %6927 = fadd fast float %6926, %6921
  %6928 = fmul fast float %6927, 0x3FD45F3060000000
  %6929 = call float @dx.op.dot3.f32(i32 55, float %2797, float %2836, float %2875, float 0x3FCB38DDA0000000, float 0x3FE6E286E0000000, float 0x3FB27A0FA0000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6930 = call float @dx.op.binary.f32(i32 35, float %6928, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6931 = fdiv fast float %6929, %6930
  %6932 = select i1 %6890, float 6.550400e+04, float 1.000000e+00
  %6933 = call float @dx.op.binary.f32(i32 35, float %6931, float 0.000000e+00)  ; FMax(a,b)
  %6934 = call float @dx.op.binary.f32(i32 36, float %6933, float %6932)  ; FMin(a,b)
  %6935 = fmul fast float %6934, %6885
  %6936 = fmul fast float %6934, %6886
  %6937 = fmul fast float %6934, %6887
  br label %6938

; <label>:6938                                    ; preds = %6888, %6848
  %6939 = phi float [ %6935, %6888 ], [ %6885, %6848 ]
  %6940 = phi float [ %6936, %6888 ], [ %6886, %6848 ]
  %6941 = phi float [ %6937, %6888 ], [ %6887, %6848 ]
  %6942 = fsub fast float -0.000000e+00, %6716
  %6943 = fsub fast float -0.000000e+00, %6717
  %6944 = fsub fast float -0.000000e+00, %6718
  %6945 = fsub fast float %6942, %6779
  %6946 = fsub fast float %6943, %6783
  %6947 = fsub fast float %6944, %6787
  %6948 = fmul fast float %6945, %6945
  %6949 = fmul fast float %6946, %6946
  %6950 = fmul fast float %6947, %6947
  %6951 = fcmp fast olt float %6779, %6942
  %6952 = fcmp fast olt float %6783, %6943
  %6953 = fcmp fast olt float %6787, %6944
  %6954 = select i1 %6951, float %6948, float 0.000000e+00
  %6955 = select i1 %6952, float %6949, float 0.000000e+00
  %6956 = select i1 %6953, float %6950, float 0.000000e+00
  %6957 = fsub fast float %6779, %6716
  %6958 = fsub fast float %6783, %6717
  %6959 = fsub fast float %6787, %6718
  %6960 = fmul fast float %6957, %6957
  %6961 = fmul fast float %6958, %6958
  %6962 = fmul fast float %6959, %6959
  %6963 = fcmp fast ogt float %6779, %6716
  %6964 = fcmp fast ogt float %6783, %6717
  %6965 = fcmp fast ogt float %6787, %6718
  %6966 = select i1 %6963, float %6960, float 0.000000e+00
  %6967 = select i1 %6964, float %6961, float 0.000000e+00
  %6968 = select i1 %6965, float %6962, float 0.000000e+00
  %6969 = call float @dx.op.dot3.f32(i32 55, float %6954, float %6955, float %6956, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot3(ax,ay,az,bx,by,bz)
  %6970 = call float @dx.op.dot3.f32(i32 55, float %6966, float %6967, float %6968, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot3(ax,ay,az,bx,by,bz)
  %6971 = fadd fast float %6970, %6969
  %6972 = call float @dx.op.unary.f32(i32 24, float %6971)  ; Sqrt(value)
  %6973 = fmul fast float %6972, %6713
  %6974 = call float @dx.op.unary.f32(i32 7, float %6973)  ; Saturate(value)
  %6975 = fsub fast float 1.000000e+00, %6974
  %6976 = fmul fast float %6975, 2.000000e+00
  %6977 = fsub fast float 3.000000e+00, %6976
  %6978 = fmul fast float %6975, %6975
  %6979 = fmul fast float %6978, %6721
  %6980 = fmul fast float %6979, %6977
  %6981 = fmul fast float %6980, %6664
  %6982 = fmul fast float %6981, %6939
  %6983 = fmul fast float %6981, %6940
  %6984 = fmul fast float %6981, %6941
  %6985 = fmul fast float %6980, %6883
  %6986 = fsub fast float 1.000000e+00, %6985
  %6987 = call float @dx.op.unary.f32(i32 7, float %6986)  ; Saturate(value)
  %6988 = fmul fast float %6987, %6664
  br label %6989

; <label>:6989                                    ; preds = %6938, %6822
  %6990 = phi float [ %6988, %6938 ], [ %6664, %6822 ]
  %6991 = phi float [ %6982, %6938 ], [ 0.000000e+00, %6822 ]
  %6992 = phi float [ %6983, %6938 ], [ 0.000000e+00, %6822 ]
  %6993 = phi float [ %6984, %6938 ], [ 0.000000e+00, %6822 ]
  %6994 = fadd fast float %6991, %6661
  %6995 = fadd fast float %6992, %6662
  %6996 = fadd fast float %6993, %6663
  br label %7285

; <label>:6997                                    ; preds = %6682
  %6998 = mul i32 %6670, 44
  %6999 = add i32 %6998, %3338
  %7000 = shl i32 %6999, 2
  %7001 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7000, i32 undef)  ; BufferLoad(srv,index,wot)
  %7002 = extractvalue %dx.types.ResRet.f32 %7001, 0
  %7003 = extractvalue %dx.types.ResRet.f32 %7001, 1
  %7004 = extractvalue %dx.types.ResRet.f32 %7001, 2
  %7005 = add i32 %7000, 16
  %7006 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7005, i32 undef)  ; BufferLoad(srv,index,wot)
  %7007 = extractvalue %dx.types.ResRet.f32 %7006, 0
  %7008 = extractvalue %dx.types.ResRet.f32 %7006, 1
  %7009 = extractvalue %dx.types.ResRet.f32 %7006, 2
  %7010 = extractvalue %dx.types.ResRet.f32 %7006, 3
  %7011 = add i32 %7000, 32
  %7012 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7011, i32 undef)  ; BufferLoad(srv,index,wot)
  %7013 = extractvalue %dx.types.ResRet.f32 %7012, 0
  %7014 = extractvalue %dx.types.ResRet.f32 %7012, 1
  %7015 = extractvalue %dx.types.ResRet.f32 %7012, 2
  %7016 = extractvalue %dx.types.ResRet.f32 %7012, 3
  %7017 = add i32 %7000, 48
  %7018 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7017, i32 undef)  ; BufferLoad(srv,index,wot)
  %7019 = extractvalue %dx.types.ResRet.f32 %7018, 0
  %7020 = extractvalue %dx.types.ResRet.f32 %7018, 1
  %7021 = extractvalue %dx.types.ResRet.f32 %7018, 2
  %7022 = extractvalue %dx.types.ResRet.f32 %7018, 3
  %7023 = add i32 %7000, 64
  %7024 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7023, i32 undef)  ; BufferLoad(srv,index,wot)
  %7025 = extractvalue %dx.types.ResRet.f32 %7024, 0
  %7026 = add i32 %7000, 68
  %7027 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7026, i32 undef)  ; BufferLoad(srv,index,wot)
  %7028 = extractvalue %dx.types.ResRet.f32 %7027, 0
  %7029 = add i32 %7000, 72
  %7030 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7029, i32 undef)  ; BufferLoad(srv,index,wot)
  %7031 = extractvalue %dx.types.ResRet.f32 %7030, 0
  %7032 = add i32 %7000, 80
  %7033 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7032, i32 undef)  ; BufferLoad(srv,index,wot)
  %7034 = extractvalue %dx.types.ResRet.f32 %7033, 0
  %7035 = extractvalue %dx.types.ResRet.f32 %7033, 1
  %7036 = extractvalue %dx.types.ResRet.f32 %7033, 2
  %7037 = add i32 %7000, 92
  %7038 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7037, i32 undef)  ; BufferLoad(srv,index,wot)
  %7039 = extractvalue %dx.types.ResRet.f32 %7038, 0
  %7040 = and i32 %6674, 4
  %7041 = icmp ne i32 %7040, 0
  %7042 = and i1 %6606, %7041
  br i1 %7042, label %7043, label %7061

; <label>:7043                                    ; preds = %6997
  %7044 = lshr i32 %6674, 5
  %7045 = and i32 %7044, 511
  %7046 = mul nuw nsw i32 %7045, 3
  %7047 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %7046, i32 0)  ; BufferLoad(srv,index,wot)
  %7048 = extractvalue %dx.types.ResRet.f32 %7047, 0
  %7049 = extractvalue %dx.types.ResRet.f32 %7047, 1
  %7050 = extractvalue %dx.types.ResRet.f32 %7047, 2
  %7051 = extractvalue %dx.types.ResRet.f32 %7047, 3
  %7052 = add nuw nsw i32 %7046, 1
  %7053 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %7052, i32 0)  ; BufferLoad(srv,index,wot)
  %7054 = extractvalue %dx.types.ResRet.f32 %7053, 0
  %7055 = extractvalue %dx.types.ResRet.f32 %7053, 1
  %7056 = extractvalue %dx.types.ResRet.f32 %7053, 2
  %7057 = extractvalue %dx.types.ResRet.f32 %7053, 3
  %7058 = add nuw nsw i32 %7046, 2
  %7059 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %7058, i32 0)  ; BufferLoad(srv,index,wot)
  %7060 = extractvalue %dx.types.ResRet.f32 %7059, 0
  br label %7061

; <label>:7061                                    ; preds = %7043, %6997
  %7062 = phi float [ %7060, %7043 ], [ 0.000000e+00, %6997 ]
  %7063 = phi float [ %7054, %7043 ], [ 0.000000e+00, %6997 ]
  %7064 = phi float [ %7055, %7043 ], [ 0.000000e+00, %6997 ]
  %7065 = phi float [ %7056, %7043 ], [ 0.000000e+00, %6997 ]
  %7066 = phi float [ %7057, %7043 ], [ 0.000000e+00, %6997 ]
  %7067 = phi float [ %7048, %7043 ], [ 0.000000e+00, %6997 ]
  %7068 = phi float [ %7049, %7043 ], [ 0.000000e+00, %6997 ]
  %7069 = phi float [ %7050, %7043 ], [ 0.000000e+00, %6997 ]
  %7070 = phi float [ %7051, %7043 ], [ 0.000000e+00, %6997 ]
  %7071 = lshr i32 %6674, 2
  %7072 = zext i1 %7042 to i32
  %7073 = and i32 %7072, %7071
  %7074 = icmp eq i32 %7073, 0
  %7075 = fsub fast float 1.000000e+00, %3283
  %7076 = call float @dx.op.unary.f32(i32 7, float %7075)  ; Saturate(value)
  %7077 = call float @dx.op.unary.f32(i32 24, float %7076)  ; Sqrt(value)
  %7078 = fadd fast float %7077, %3283
  %7079 = fmul fast float %7078, %7075
  %7080 = fsub fast float %6602, %2879
  %7081 = fsub fast float %6603, %2880
  %7082 = fsub fast float %6604, %2881
  %7083 = fmul fast float %7079, %7080
  %7084 = fmul fast float %7079, %7081
  %7085 = fmul fast float %7079, %7082
  %7086 = fadd fast float %7083, %2879
  %7087 = fadd fast float %7084, %2880
  %7088 = fadd fast float %7085, %2881
  %7089 = fadd fast float %7031, %7025
  %7090 = and i32 %6674, 1
  %7091 = icmp eq i32 %7090, 0
  br i1 %7091, label %7111, label %7092

; <label>:7092                                    ; preds = %7061
  %7093 = fsub fast float %565, %7002
  %7094 = fsub fast float %566, %7003
  %7095 = fsub fast float %567, %7004
  %7096 = call float @dx.op.dot3.f32(i32 55, float %7086, float %7087, float %7088, float %7093, float %7094, float %7095)  ; Dot3(ax,ay,az,bx,by,bz)
  %7097 = fmul fast float %7096, 2.000000e+00
  %7098 = call float @dx.op.dot3.f32(i32 55, float %7093, float %7094, float %7095, float %7093, float %7094, float %7095)  ; Dot3(ax,ay,az,bx,by,bz)
  %7099 = fmul fast float %7089, %7089
  %7100 = fsub fast float %7098, %7099
  %7101 = fmul fast float %7097, %7097
  %7102 = fmul fast float %7100, 4.000000e+00
  %7103 = fsub fast float %7101, %7102
  %7104 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7103)  ; FMax(a,b)
  %7105 = call float @dx.op.unary.f32(i32 24, float %7104)  ; Sqrt(value)
  %7106 = fsub fast float %7105, %7097
  %7107 = call float @dx.op.unary.f32(i32 6, float %7106)  ; FAbs(value)
  %7108 = fmul fast float %7107, 5.000000e-01
  %7109 = fcmp fast oge float %7108, 0.000000e+00
  %7110 = zext i1 %7109 to i32
  br label %7111

; <label>:7111                                    ; preds = %7092, %7061
  %7112 = phi float [ %7108, %7092 ], [ 1.000000e+00, %7061 ]
  %7113 = phi i32 [ %7110, %7092 ], [ 1, %7061 ]
  %7114 = icmp eq i32 %7113, 0
  br i1 %7114, label %7277, label %7115

; <label>:7115                                    ; preds = %7111
  %7116 = fmul fast float %7007, %565
  %7117 = call float @dx.op.tertiary.f32(i32 46, float %566, float %7010, float %7116)  ; FMad(a,b,c)
  %7118 = call float @dx.op.tertiary.f32(i32 46, float %567, float %7015, float %7117)  ; FMad(a,b,c)
  %7119 = fmul fast float %7008, %565
  %7120 = call float @dx.op.tertiary.f32(i32 46, float %566, float %7013, float %7119)  ; FMad(a,b,c)
  %7121 = call float @dx.op.tertiary.f32(i32 46, float %567, float %7016, float %7120)  ; FMad(a,b,c)
  %7122 = fmul fast float %7009, %565
  %7123 = call float @dx.op.tertiary.f32(i32 46, float %566, float %7014, float %7122)  ; FMad(a,b,c)
  %7124 = call float @dx.op.tertiary.f32(i32 46, float %567, float %7019, float %7123)  ; FMad(a,b,c)
  %7125 = fmul fast float %7086, %7007
  %7126 = call float @dx.op.tertiary.f32(i32 46, float %7087, float %7010, float %7125)  ; FMad(a,b,c)
  %7127 = call float @dx.op.tertiary.f32(i32 46, float %7088, float %7015, float %7126)  ; FMad(a,b,c)
  %7128 = fmul fast float %7086, %7008
  %7129 = call float @dx.op.tertiary.f32(i32 46, float %7087, float %7013, float %7128)  ; FMad(a,b,c)
  %7130 = call float @dx.op.tertiary.f32(i32 46, float %7088, float %7016, float %7129)  ; FMad(a,b,c)
  %7131 = fmul fast float %7086, %7009
  %7132 = call float @dx.op.tertiary.f32(i32 46, float %7087, float %7014, float %7131)  ; FMad(a,b,c)
  %7133 = call float @dx.op.tertiary.f32(i32 46, float %7088, float %7019, float %7132)  ; FMad(a,b,c)
  %7134 = fmul fast float %7127, %7112
  %7135 = fmul fast float %7130, %7112
  %7136 = fmul fast float %7133, %7112
  %7137 = fsub fast float %7020, %7034
  %7138 = fadd fast float %7137, %7118
  %7139 = fadd fast float %7138, %7134
  %7140 = fsub fast float %7021, %7035
  %7141 = fadd fast float %7140, %7121
  %7142 = fadd fast float %7141, %7135
  %7143 = fsub fast float %7022, %7036
  %7144 = fadd fast float %7143, %7124
  %7145 = fadd fast float %7144, %7136
  %7146 = fmul fast float %7139, %7139
  %7147 = fmul fast float %7142, %7142
  %7148 = fadd fast float %7147, %7146
  %7149 = fmul fast float %7145, %7145
  %7150 = fadd fast float %7148, %7149
  %7151 = call float @dx.op.unary.f32(i32 24, float %7150)  ; Sqrt(value)
  br i1 %7091, label %7158, label %7152

; <label>:7152                                    ; preds = %7115
  %7153 = call float @dx.op.unary.f32(i32 7, float %3283)  ; Saturate(value)
  %7154 = fmul fast float %7153, 2.000000e+00
  %7155 = fsub fast float 3.000000e+00, %7154
  %7156 = fmul fast float %7153, %7153
  %7157 = fmul fast float %7156, %7155
  br label %7158

; <label>:7158                                    ; preds = %7152, %7115
  %7159 = phi float [ %7157, %7152 ], [ 1.000000e+00, %7115 ]
  %7160 = fmul fast float %3282, 2.000000e+00
  %7161 = call float @dx.op.unary.f32(i32 7, float %7160)  ; Saturate(value)
  %7162 = fsub fast float 1.000000e+00, %7161
  %7163 = fmul fast float %7162, %2882
  %7164 = fadd fast float %7163, %7161
  %7165 = fmul fast float %7164, %3283
  %7166 = fmul fast float %7165, %7112
  %7167 = fdiv fast float %7166, %7151
  %7168 = fsub fast float %7165, %7167
  %7169 = fmul fast float %7168, %7159
  %7170 = fadd fast float %7169, %7167
  %7171 = fsub fast float %7127, %7139
  %7172 = fsub fast float %7130, %7142
  %7173 = fsub fast float %7133, %7145
  %7174 = fmul fast float %7159, %7171
  %7175 = fmul fast float %7159, %7172
  %7176 = fmul fast float %7159, %7173
  %7177 = fadd fast float %7174, %7139
  %7178 = fadd fast float %7175, %7142
  %7179 = fadd fast float %7176, %7145
  %7180 = lshr i32 %6674, 5
  %7181 = and i32 %7180, 511
  %7182 = uitofp i32 %7181 to float
  %7183 = fmul fast float %7170, %6590
  %7184 = fadd fast float %7183, 1.000000e+00
  %7185 = call float @dx.op.unary.f32(i32 23, float %7184)  ; Log(value)
  %7186 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %31, %dx.types.Handle %39, float %7177, float %7178, float %7179, float %7182, i32 undef, i32 undef, i32 undef, float %7185)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %7187 = extractvalue %dx.types.ResRet.f32 %7186, 0
  %7188 = extractvalue %dx.types.ResRet.f32 %7186, 1
  %7189 = extractvalue %dx.types.ResRet.f32 %7186, 2
  %7190 = extractvalue %dx.types.ResRet.f32 %7186, 3
  %7191 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %26, %dx.types.Handle %39, float %7177, float %7178, float %7179, float %7182, i32 undef, i32 undef, i32 undef, float %7185)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %7192 = extractvalue %dx.types.ResRet.f32 %7191, 0
  %7193 = call float @dx.op.binary.f32(i32 36, float %7190, float %7192)  ; FMin(a,b)
  %7194 = fmul fast float %6592, %3290
  %7195 = fmul fast float %7187, %7194
  %7196 = fmul fast float %7188, %7194
  %7197 = fmul fast float %7189, %7194
  br i1 %7074, label %7248, label %7198

; <label>:7198                                    ; preds = %7158
  %7199 = and i32 %6674, 8
  %7200 = icmp ne i32 %7199, 0
  %7201 = call float @dx.op.dot3.f32(i32 55, float %7177, float %7178, float %7179, float %7177, float %7178, float %7179)  ; Dot3(ax,ay,az,bx,by,bz)
  %7202 = call float @dx.op.unary.f32(i32 25, float %7201)  ; Rsqrt(value)
  %7203 = fmul fast float %7202, %7177
  %7204 = fmul fast float %7202, %7178
  %7205 = fmul fast float %7202, %7179
  %7206 = fmul fast float %7204, 0xBFF05F8CE0000000
  %7207 = fmul fast float %7205, 0x3FF05F8CE0000000
  %7208 = fmul fast float %7203, 0xBFF05F8CE0000000
  %7209 = fmul fast float %7203, 0x3FEB756F20000000
  %7210 = fmul fast float %7209, %7204
  %7211 = fmul fast float %7205, 0xBFEB756F20000000
  %7212 = fmul fast float %7211, %7204
  %7213 = fmul fast float %7205, %7205
  %7214 = fmul fast float %7213, 0x3FE7C7ADC0000000
  %7215 = fadd fast float %7214, 0xBFCFB4E7C0000000
  %7216 = fmul fast float %7211, %7203
  %7217 = fmul fast float %7203, %7203
  %7218 = fmul fast float %7204, %7204
  %7219 = fsub fast float %7217, %7218
  %7220 = fmul fast float %7067, 0x3FEC5BF9E0000000
  %7221 = fmul fast float %7206, %7068
  %7222 = fadd fast float %7221, %7220
  %7223 = fmul fast float %7207, %7069
  %7224 = fadd fast float %7222, %7223
  %7225 = fmul fast float %7208, %7070
  %7226 = fadd fast float %7224, %7225
  %7227 = fmul fast float %7210, %7063
  %7228 = fadd fast float %7226, %7227
  %7229 = fmul fast float %7212, %7064
  %7230 = fadd fast float %7228, %7229
  %7231 = fmul fast float %7215, %7065
  %7232 = fmul fast float %7216, %7066
  %7233 = fmul fast float %7062, 0x3FDB756F20000000
  %7234 = fmul fast float %7233, %7219
  %7235 = fadd fast float %7230, %7232
  %7236 = fadd fast float %7235, %7234
  %7237 = fadd fast float %7236, %7231
  %7238 = fmul fast float %7237, 0x3FD45F3060000000
  %7239 = call float @dx.op.dot3.f32(i32 55, float %2797, float %2836, float %2875, float 0x3FCB38DDA0000000, float 0x3FE6E286E0000000, float 0x3FB27A0FA0000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7240 = call float @dx.op.binary.f32(i32 35, float %7238, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %7241 = fdiv fast float %7239, %7240
  %7242 = select i1 %7200, float 6.550400e+04, float 1.000000e+00
  %7243 = call float @dx.op.binary.f32(i32 35, float %7241, float 0.000000e+00)  ; FMax(a,b)
  %7244 = call float @dx.op.binary.f32(i32 36, float %7243, float %7242)  ; FMin(a,b)
  %7245 = fmul fast float %7244, %7195
  %7246 = fmul fast float %7244, %7196
  %7247 = fmul fast float %7244, %7197
  br label %7248

; <label>:7248                                    ; preds = %7198, %7158
  %7249 = phi float [ %7245, %7198 ], [ %7195, %7158 ]
  %7250 = phi float [ %7246, %7198 ], [ %7196, %7158 ]
  %7251 = phi float [ %7247, %7198 ], [ %7197, %7158 ]
  %7252 = fsub fast float %565, %7002
  %7253 = fsub fast float %566, %7003
  %7254 = fsub fast float %567, %7004
  %7255 = fmul fast float %7252, %7252
  %7256 = fmul fast float %7253, %7253
  %7257 = fadd fast float %7255, %7256
  %7258 = fmul fast float %7254, %7254
  %7259 = fadd fast float %7257, %7258
  %7260 = call float @dx.op.unary.f32(i32 24, float %7259)  ; Sqrt(value)
  %7261 = fsub fast float %7089, %7260
  %7262 = fmul fast float %7261, %7028
  %7263 = call float @dx.op.unary.f32(i32 7, float %7262)  ; Saturate(value)
  %7264 = fmul fast float %7263, 2.000000e+00
  %7265 = fsub fast float 3.000000e+00, %7264
  %7266 = fmul fast float %7263, %7263
  %7267 = fmul fast float %7266, %7039
  %7268 = fmul fast float %7267, %7265
  %7269 = fmul fast float %7268, %6664
  %7270 = fmul fast float %7269, %7249
  %7271 = fmul fast float %7269, %7250
  %7272 = fmul fast float %7269, %7251
  %7273 = fmul fast float %7268, %7193
  %7274 = fsub fast float 1.000000e+00, %7273
  %7275 = call float @dx.op.unary.f32(i32 7, float %7274)  ; Saturate(value)
  %7276 = fmul fast float %7275, %6664
  br label %7277

; <label>:7277                                    ; preds = %7248, %7111
  %7278 = phi float [ %7276, %7248 ], [ %6664, %7111 ]
  %7279 = phi float [ %7270, %7248 ], [ 0.000000e+00, %7111 ]
  %7280 = phi float [ %7271, %7248 ], [ 0.000000e+00, %7111 ]
  %7281 = phi float [ %7272, %7248 ], [ 0.000000e+00, %7111 ]
  %7282 = fadd fast float %7279, %6661
  %7283 = fadd fast float %7280, %6662
  %7284 = fadd fast float %7281, %6663
  br label %7285

; <label>:7285                                    ; preds = %7277, %6989, %6682
  %7286 = phi float [ %7282, %7277 ], [ %6994, %6989 ], [ %6661, %6682 ]
  %7287 = phi float [ %7283, %7277 ], [ %6995, %6989 ], [ %6662, %6682 ]
  %7288 = phi float [ %7284, %7277 ], [ %6996, %6989 ], [ %6663, %6682 ]
  %7289 = phi float [ %7278, %7277 ], [ %6990, %6989 ], [ %6664, %6682 ]
  %7290 = fcmp ugt float %7289, 0.000000e+00
  %7291 = icmp ne i32 %6665, %6668
  %7292 = and i1 %7291, %7290
  br i1 %7292, label %6660, label %7293

; <label>:7293                                    ; preds = %7285
  br label %7294

; <label>:7294                                    ; preds = %7293, %6655
  %7295 = phi float [ %6621, %6655 ], [ %7286, %7293 ]
  %7296 = phi float [ %6622, %6655 ], [ %7287, %7293 ]
  %7297 = phi float [ %6623, %6655 ], [ %7288, %7293 ]
  %7298 = phi float [ %6624, %6655 ], [ %7289, %7293 ]
  %7299 = add nuw nsw i32 %6625, 1
  %7300 = icmp eq i32 %6625, %6617
  br i1 %7300, label %7301, label %6620

; <label>:7301                                    ; preds = %7294
  br label %7302

; <label>:7302                                    ; preds = %7301, %6610, %6576
  %7303 = phi float [ 0.000000e+00, %6576 ], [ 0.000000e+00, %6610 ], [ %7295, %7301 ]
  %7304 = phi float [ 0.000000e+00, %6576 ], [ 0.000000e+00, %6610 ], [ %7296, %7301 ]
  %7305 = phi float [ 0.000000e+00, %6576 ], [ 0.000000e+00, %6610 ], [ %7297, %7301 ]
  %7306 = phi float [ 1.000000e+00, %6576 ], [ 1.000000e+00, %6610 ], [ %7298, %7301 ]
  %7307 = and i32 %2884, 10
  %7308 = icmp eq i32 %7307, 10
  br i1 %7308, label %7309, label %7324

; <label>:7309                                    ; preds = %7302
  %7310 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %28, i32 0, i32 0)  ; BufferLoad(srv,index,wot)
  %7311 = extractvalue %dx.types.ResRet.f32 %7310, 0
  %7312 = extractvalue %dx.types.ResRet.f32 %7310, 1
  %7313 = extractvalue %dx.types.ResRet.f32 %7310, 2
  %7314 = extractvalue %dx.types.ResRet.f32 %7310, 3
  %7315 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %28, i32 1, i32 0)  ; BufferLoad(srv,index,wot)
  %7316 = extractvalue %dx.types.ResRet.f32 %7315, 0
  %7317 = extractvalue %dx.types.ResRet.f32 %7315, 1
  %7318 = extractvalue %dx.types.ResRet.f32 %7315, 2
  %7319 = extractvalue %dx.types.ResRet.f32 %7315, 3
  %7320 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %28, i32 2, i32 0)  ; BufferLoad(srv,index,wot)
  %7321 = extractvalue %dx.types.ResRet.f32 %7320, 0
  %7322 = fmul float %7311, 0x3FEC5BF9E0000000
  %7323 = fmul float %7321, 0x3FDB756F20000000
  br label %7324

; <label>:7324                                    ; preds = %7309, %7302
  %7325 = phi float [ %7323, %7309 ], [ 0.000000e+00, %7302 ]
  %7326 = phi float [ %7316, %7309 ], [ 0.000000e+00, %7302 ]
  %7327 = phi float [ %7317, %7309 ], [ 0.000000e+00, %7302 ]
  %7328 = phi float [ %7318, %7309 ], [ 0.000000e+00, %7302 ]
  %7329 = phi float [ %7319, %7309 ], [ 0.000000e+00, %7302 ]
  %7330 = phi float [ %7322, %7309 ], [ 0.000000e+00, %7302 ]
  %7331 = phi float [ %7312, %7309 ], [ 0.000000e+00, %7302 ]
  %7332 = phi float [ %7313, %7309 ], [ 0.000000e+00, %7302 ]
  %7333 = phi float [ %7314, %7309 ], [ 0.000000e+00, %7302 ]
  %7334 = fmul fast float %3282, 2.000000e+00
  %7335 = call float @dx.op.unary.f32(i32 7, float %7334)  ; Saturate(value)
  %7336 = fsub fast float 1.000000e+00, %7335
  %7337 = fmul fast float %7336, %2882
  %7338 = fadd fast float %7337, %7335
  %7339 = fsub fast float 1.000000e+00, %3283
  %7340 = call float @dx.op.unary.f32(i32 7, float %7339)  ; Saturate(value)
  %7341 = call float @dx.op.unary.f32(i32 24, float %7340)  ; Sqrt(value)
  %7342 = fadd fast float %7341, %3283
  %7343 = fmul fast float %7342, %7339
  %7344 = fsub fast float %6602, %2879
  %7345 = fsub fast float %6603, %2880
  %7346 = fsub fast float %6604, %2881
  %7347 = fmul fast float %7343, %7344
  %7348 = fmul fast float %7343, %7345
  %7349 = fmul fast float %7343, %7346
  %7350 = fadd fast float %7347, %2879
  %7351 = fadd fast float %7348, %2880
  %7352 = fadd fast float %7349, %2881
  %7353 = fmul fast float %6593, %3283
  %7354 = fmul fast float %7353, %7338
  %7355 = fadd fast float %7354, 1.000000e+00
  %7356 = call float @dx.op.unary.f32(i32 23, float %7355)  ; Log(value)
  %7357 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %25, %dx.types.Handle %39, float %7350, float %7351, float %7352, float 0.000000e+00, i32 undef, i32 undef, i32 undef, float %7356)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %7358 = extractvalue %dx.types.ResRet.f32 %7357, 0
  %7359 = extractvalue %dx.types.ResRet.f32 %7357, 1
  %7360 = extractvalue %dx.types.ResRet.f32 %7357, 2
  %7361 = fmul fast float %6592, %3290
  %7362 = fmul fast float %7358, %7361
  %7363 = fmul fast float %7359, %7361
  %7364 = fmul fast float %7360, %7361
  br i1 %6606, label %7365, label %7407

; <label>:7365                                    ; preds = %7324
  %7366 = call float @dx.op.dot3.f32(i32 55, float %7350, float %7351, float %7352, float %7350, float %7351, float %7352)  ; Dot3(ax,ay,az,bx,by,bz)
  %7367 = call float @dx.op.unary.f32(i32 25, float %7366)  ; Rsqrt(value)
  %7368 = fmul fast float %7367, %7350
  %7369 = fmul fast float %7367, %7351
  %7370 = fmul fast float %7367, %7352
  %7371 = fmul fast float %7370, %7370
  %7372 = fmul fast float %7371, 0x3FE7C7ADC0000000
  %7373 = fadd fast float %7372, 0xBFCFB4E7C0000000
  %7374 = fmul fast float %7368, %7368
  %7375 = fmul fast float %7369, %7369
  %7376 = fsub fast float %7374, %7375
  %7377 = fmul fast float %7369, %7331
  %7378 = fmul fast float %7370, %7332
  %7379 = fmul fast float %7368, %7333
  %7380 = fmul fast float %7368, %7326
  %7381 = fmul fast float %7370, %7327
  %7382 = fmul fast float %7373, %7328
  %7383 = fmul fast float %7368, %7329
  %7384 = fmul fast float %7383, %7370
  %7385 = fmul fast float %7376, %7325
  %7386 = fsub fast float %7380, %7381
  %7387 = fmul fast float %7386, %7369
  %7388 = fsub fast float %7387, %7384
  %7389 = fmul fast float %7388, 0x3FEB756F20000000
  %7390 = fsub fast float %7378, %7379
  %7391 = fsub fast float %7390, %7377
  %7392 = fmul fast float %7391, 0x3FF05F8CE0000000
  %7393 = fadd fast float %7385, %7330
  %7394 = fadd fast float %7393, %7382
  %7395 = fadd fast float %7394, %7392
  %7396 = fadd fast float %7395, %7389
  %7397 = fmul fast float %7396, 0x3FD45F3060000000
  %7398 = call float @dx.op.dot3.f32(i32 55, float %2797, float %2836, float %2875, float 0x3FCB38DDA0000000, float 0x3FE6E286E0000000, float 0x3FB27A0FA0000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7399 = call float @dx.op.binary.f32(i32 35, float %7397, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %7400 = fdiv fast float %7398, %7399
  %7401 = select i1 %6608, float 6.550400e+04, float 1.000000e+00
  %7402 = call float @dx.op.binary.f32(i32 35, float %7400, float 0.000000e+00)  ; FMax(a,b)
  %7403 = call float @dx.op.binary.f32(i32 36, float %7402, float %7401)  ; FMin(a,b)
  %7404 = fmul fast float %7403, %7362
  %7405 = fmul fast float %7403, %7363
  %7406 = fmul fast float %7403, %7364
  br label %7407

; <label>:7407                                    ; preds = %7365, %7324
  %7408 = phi float [ %7404, %7365 ], [ %7362, %7324 ]
  %7409 = phi float [ %7405, %7365 ], [ %7363, %7324 ]
  %7410 = phi float [ %7406, %7365 ], [ %7364, %7324 ]
  %7411 = fmul fast float %7408, %7306
  %7412 = fmul fast float %7409, %7306
  %7413 = fmul fast float %7410, %7306
  %7414 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %88, float %89, float %90)  ; Dot3(ax,ay,az,bx,by,bz)
  %7415 = fsub fast float -0.000000e+00, %98
  %7416 = fcmp fast ule float %7414, %7415
  %7417 = fcmp fast ogt float %7414, %98
  %7418 = or i1 %7416, %7417
  br i1 %7418, label %7458, label %7419

; <label>:7419                                    ; preds = %7407
  %7420 = fmul fast float %7414, %7414
  %7421 = fsub fast float 1.000000e+00, %7420
  %7422 = call float @dx.op.unary.f32(i32 24, float %7421)  ; Sqrt(value)
  %7423 = fdiv fast float %7414, %7422
  %7424 = fmul fast float %7423, %101
  %7425 = fsub fast float -0.000000e+00, %7424
  %7426 = fmul fast float %7424, %7424
  %7427 = fsub fast float 1.000000e+00, %7426
  %7428 = call float @dx.op.unary.f32(i32 24, float %7427)  ; Sqrt(value)
  %7429 = fmul fast float %7428, %7422
  %7430 = call float @dx.op.unary.f32(i32 6, float %7425)  ; FAbs(value)
  %7431 = fmul fast float %7430, 0x3FC593EE60000000
  %7432 = fsub fast float 0x3FF9135FC0000000, %7431
  %7433 = fsub fast float 1.000000e+00, %7430
  %7434 = call float @dx.op.unary.f32(i32 24, float %7433)  ; Sqrt(value)
  %7435 = fmul fast float %7432, %7434
  %7436 = fsub fast float 0x400921FB60000000, %7435
  %7437 = fcmp ole float %7424, -0.000000e+00
  %7438 = select i1 %7437, float %7435, float %7436
  %7439 = fmul fast float %7438, %7414
  %7440 = fmul fast float %7429, %101
  %7441 = fsub fast float %7439, %7440
  %7442 = fmul fast float %7441, %100
  %7443 = fmul fast float %7429, %102
  %7444 = fdiv fast float 1.000000e+00, %7443
  %7445 = fcmp fast olt float %7443, 1.000000e+00
  %7446 = select i1 %7445, float %7443, float %7444
  %7447 = fmul fast float %7446, %7446
  %7448 = fmul fast float %7447, 0x3FB658D4A0000000
  %7449 = fadd fast float %7448, 0xBFD3523E80000000
  %7450 = fmul fast float %7449, %7447
  %7451 = fadd fast float %7450, 1.000000e+00
  %7452 = fmul fast float %7451, %7446
  %7453 = fsub fast float 0x3FF921FB60000000, %7452
  %7454 = select i1 %7445, float %7452, float %7453
  %7455 = fadd fast float %7454, %7442
  %7456 = fmul fast float %7455, 0x3FD45F3060000000
  %7457 = fdiv fast float %7456, %100
  br label %7458

; <label>:7458                                    ; preds = %7419, %7407
  %7459 = phi float [ %7457, %7419 ], [ %7414, %7407 ]
  %7460 = call float @dx.op.unary.f32(i32 7, float %7459)  ; Saturate(value)
  %7461 = call float @dx.op.dot3.f32(i32 55, float %88, float %89, float %90, float %6602, float %6603, float %6604)  ; Dot3(ax,ay,az,bx,by,bz)
  %7462 = fmul fast float %7461, %88
  %7463 = fmul fast float %7461, %89
  %7464 = fmul fast float %7461, %90
  %7465 = fsub fast float %6602, %7462
  %7466 = fsub fast float %6603, %7463
  %7467 = fsub fast float %6604, %7464
  %7468 = fcmp fast olt float %7461, %97
  br i1 %7468, label %7469, label %7487

; <label>:7469                                    ; preds = %7458
  %7470 = fmul fast float %97, %88
  %7471 = fmul fast float %97, %89
  %7472 = fmul fast float %97, %90
  %7473 = call float @dx.op.dot3.f32(i32 55, float %7465, float %7466, float %7467, float %7465, float %7466, float %7467)  ; Dot3(ax,ay,az,bx,by,bz)
  %7474 = call float @dx.op.unary.f32(i32 25, float %7473)  ; Rsqrt(value)
  %7475 = fmul fast float %7474, %98
  %7476 = fmul fast float %7475, %7465
  %7477 = fmul fast float %7475, %7466
  %7478 = fmul fast float %7475, %7467
  %7479 = fadd fast float %7476, %7470
  %7480 = fadd fast float %7477, %7471
  %7481 = fadd fast float %7478, %7472
  %7482 = call float @dx.op.dot3.f32(i32 55, float %7479, float %7480, float %7481, float %7479, float %7480, float %7481)  ; Dot3(ax,ay,az,bx,by,bz)
  %7483 = call float @dx.op.unary.f32(i32 25, float %7482)  ; Rsqrt(value)
  %7484 = fmul fast float %7479, %7483
  %7485 = fmul fast float %7480, %7483
  %7486 = fmul fast float %7481, %7483
  br label %7487

; <label>:7487                                    ; preds = %7469, %7458
  %7488 = phi float [ %7484, %7469 ], [ %6602, %7458 ]
  %7489 = phi float [ %7485, %7469 ], [ %6603, %7458 ]
  %7490 = phi float [ %7486, %7469 ], [ %6604, %7458 ]
  %7491 = fcmp fast ogt float %7460, 0.000000e+00
  br i1 %7491, label %7492, label %7599

; <label>:7492                                    ; preds = %7487
  %7493 = fmul fast float %3311, %3311
  %7494 = fadd fast float %7493, %103
  %7495 = call float @dx.op.unary.f32(i32 7, float %7494)  ; Saturate(value)
  %7496 = fdiv fast float %7493, %7495
  %7497 = fadd fast float %7488, %272
  %7498 = fadd fast float %7489, %273
  %7499 = fadd fast float %7490, %274
  %7500 = call float @dx.op.dot3.f32(i32 55, float %7497, float %7498, float %7499, float %7497, float %7498, float %7499)  ; Dot3(ax,ay,az,bx,by,bz)
  %7501 = call float @dx.op.unary.f32(i32 25, float %7500)  ; Rsqrt(value)
  %7502 = fmul fast float %7501, %7497
  %7503 = fmul fast float %7501, %7498
  %7504 = fmul fast float %7501, %7499
  %7505 = call float @dx.op.unary.f32(i32 6, float %3281)  ; FAbs(value)
  %7506 = call float @dx.op.binary.f32(i32 35, float %7505, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %7507 = call float @dx.op.unary.f32(i32 7, float %7506)  ; Saturate(value)
  %7508 = call float @dx.op.dot3.f32(i32 55, float %7488, float %7489, float %7490, float %7502, float %7503, float %7504)  ; Dot3(ax,ay,az,bx,by,bz)
  %7509 = call float @dx.op.unary.f32(i32 7, float %7508)  ; Saturate(value)
  %7510 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %7502, float %7503, float %7504)  ; Dot3(ax,ay,az,bx,by,bz)
  %7511 = call float @dx.op.unary.f32(i32 7, float %7510)  ; Saturate(value)
  %7512 = call float @dx.op.unary.f32(i32 6, float %7510)  ; FAbs(value)
  %7513 = call float @dx.op.binary.f32(i32 35, float %7512, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %7514 = call float @dx.op.unary.f32(i32 7, float %7513)  ; Saturate(value)
  %7515 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %7488, float %7489, float %7490)  ; Dot3(ax,ay,az,bx,by,bz)
  %7516 = call float @dx.op.unary.f32(i32 7, float %7515)  ; Saturate(value)
  %7517 = fsub fast float 1.000000e+00, %7509
  %7518 = fmul fast float %7517, %7517
  %7519 = fmul fast float %7518, %7518
  %7520 = fmul fast float %7519, %7517
  %7521 = fmul fast float %7520, 0x3FEEB851E0000000
  %7522 = fadd fast float %7521, 0x3FA47AE140000000
  %7523 = call float @dx.op.binary.f32(i32 35, float %7493, float 0x3F60624DE0000000)  ; FMax(a,b)
  %7524 = fmul fast float %7523, %7523
  %7525 = fmul fast float %7524, %7507
  %7526 = fsub fast float %7507, %7525
  %7527 = fmul fast float %7526, %7507
  %7528 = fadd fast float %7527, %7524
  %7529 = call float @dx.op.unary.f32(i32 24, float %7528)  ; Sqrt(value)
  %7530 = fmul fast float %7529, %7516
  %7531 = fmul fast float %7524, %7516
  %7532 = fsub fast float %7516, %7531
  %7533 = fmul fast float %7532, %7516
  %7534 = fadd fast float %7533, %7524
  %7535 = call float @dx.op.unary.f32(i32 24, float %7534)  ; Sqrt(value)
  %7536 = fmul fast float %7535, %7507
  %7537 = fadd fast float %7536, %7530
  %7538 = fdiv fast float 5.000000e-01, %7537
  %7539 = fmul fast float %7524, %7511
  %7540 = fsub fast float %7539, %7511
  %7541 = fmul fast float %7540, %7511
  %7542 = fadd fast float %7541, 1.000000e+00
  %7543 = fmul fast float %7542, %7542
  %7544 = fdiv fast float 1.000000e+00, %7543
  %7545 = fdiv fast float 2.000000e+00, %7524
  %7546 = fadd fast float %7545, -1.000000e+00
  %7547 = call float @dx.op.unary.f32(i32 23, float %7546)  ; Log(value)
  %7548 = fmul fast float %7547, 0x3FAC71C720000000
  %7549 = call float @dx.op.unary.f32(i32 7, float %7548)  ; Saturate(value)
  %7550 = fadd fast float %7520, %7509
  %7551 = fsub fast float 1.000000e+00, %7516
  %7552 = fmul fast float %7551, %7551
  %7553 = fmul fast float %7552, %7552
  %7554 = fmul fast float %7553, %7551
  %7555 = fsub fast float 1.000000e+00, %7554
  %7556 = fsub fast float 1.000000e+00, %7507
  %7557 = fmul fast float %7556, %7556
  %7558 = fmul fast float %7557, %7557
  %7559 = fmul fast float %7558, %7556
  %7560 = fsub fast float 1.000000e+00, %7559
  %7561 = fmul fast float %7555, %7560
  %7562 = fmul fast float %7549, 0x40019999A0000000
  %7563 = fadd fast float %7562, -5.000000e-01
  %7564 = call float @dx.op.unary.f32(i32 7, float %7563)  ; Saturate(value)
  %7565 = fsub fast float %7561, %7550
  %7566 = fmul fast float %7564, %7565
  %7567 = fadd fast float %7566, %7550
  %7568 = fmul fast float %7549, %7549
  %7569 = fmul fast float %7568, 3.450000e+01
  %7570 = fmul fast float %7549, 5.900000e+01
  %7571 = fsub fast float 2.450000e+01, %7570
  %7572 = fadd fast float %7571, %7569
  %7573 = fmul fast float %7572, %7509
  %7574 = fmul fast float %7549, 0x40524CCCC0000000
  %7575 = fadd fast float %7574, 0xC035333340000000
  %7576 = call float @dx.op.binary.f32(i32 35, float %7575, float 0x4021CCCCC0000000)  ; FMax(a,b)
  %7577 = call float @dx.op.unary.f32(i32 24, float %7514)  ; Sqrt(value)
  %7578 = fmul fast float %7576, %7577
  %7579 = fsub fast float -0.000000e+00, %7578
  %7580 = call float @dx.op.unary.f32(i32 21, float %7579)  ; Exp(value)
  %7581 = fmul fast float %7573, %7580
  %7582 = fadd fast float %7567, %7581
  %7583 = call float @dx.op.binary.f32(i32 35, float %7582, float 0.000000e+00)  ; FMax(a,b)
  %7584 = fmul fast float %3280, %7460
  %7585 = fmul fast float %7583, %7584
  %7586 = fmul fast float %7585, %92
  %7587 = fmul fast float %7585, %93
  %7588 = fmul fast float %7585, %94
  %7589 = fmul fast float %7584, %95
  %7590 = fmul fast float %7496, %7496
  %7591 = fmul fast float %7590, %7589
  %7592 = fmul fast float %7591, %7524
  %7593 = fmul fast float %7592, %7538
  %7594 = fmul fast float %7593, %7544
  %7595 = fmul fast float %7594, %7522
  %7596 = fmul fast float %7595, %92
  %7597 = fmul fast float %7595, %93
  %7598 = fmul fast float %7595, %94
  br label %7599

; <label>:7599                                    ; preds = %7492, %7487
  %7600 = phi float [ %7586, %7492 ], [ 0.000000e+00, %7487 ]
  %7601 = phi float [ %7587, %7492 ], [ 0.000000e+00, %7487 ]
  %7602 = phi float [ %7588, %7492 ], [ 0.000000e+00, %7487 ]
  %7603 = phi float [ %7596, %7492 ], [ 0.000000e+00, %7487 ]
  %7604 = phi float [ %7597, %7492 ], [ 0.000000e+00, %7487 ]
  %7605 = phi float [ %7598, %7492 ], [ 0.000000e+00, %7487 ]
  %7606 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 2)  ; CBufferLoadLegacy(handle,regIndex)
  %7607 = extractvalue %dx.types.CBufRet.f32 %7606, 0
  %7608 = fmul fast float %2756, 0x3F40600000000000
  %7609 = fadd fast float %7608, 0x3FEFFCB940000000
  %7610 = fmul fast float %2757, 0x3F40600000000000
  %7611 = fadd fast float %7610, 0x3FEFFCB940000000
  %7612 = fmul fast float %2758, 0x3F40600000000000
  %7613 = fadd fast float %7612, 0x3FEFFCB940000000
  %7614 = call float @dx.op.unary.f32(i32 7, float %7609)  ; Saturate(value)
  %7615 = call float @dx.op.unary.f32(i32 7, float %7611)  ; Saturate(value)
  %7616 = call float @dx.op.unary.f32(i32 7, float %7613)  ; Saturate(value)
  %7617 = fadd fast float %7614, -1.000000e+00
  %7618 = fadd fast float %7615, -1.000000e+00
  %7619 = fadd fast float %7616, -1.000000e+00
  %7620 = fmul fast float %7617, %7607
  %7621 = fmul fast float %7618, %7607
  %7622 = fmul fast float %7619, %7607
  %7623 = fadd fast float %7620, 1.000000e+00
  %7624 = fadd fast float %7621, 1.000000e+00
  %7625 = fadd fast float %7622, 1.000000e+00
  %7626 = fmul fast float %7623, %7600
  %7627 = fmul fast float %7624, %7601
  %7628 = fmul fast float %7625, %7602
  %7629 = and i32 %2884, 16
  %7630 = icmp eq i32 %7629, 0
  br i1 %7630, label %7646, label %7631

; <label>:7631                                    ; preds = %7599
  %7632 = fadd fast float %7306, 0xBF9EB851E0000000
  %7633 = fmul fast float %7632, 0x3FF07EAE20000000
  %7634 = call float @dx.op.unary.f32(i32 7, float %7633)  ; Saturate(value)
  %7635 = fmul fast float %7634, 2.000000e+00
  %7636 = fsub fast float 3.000000e+00, %7635
  %7637 = fmul fast float %7634, %7634
  %7638 = fmul fast float %7637, %7636
  %7639 = fadd fast float %3283, -2.500000e-01
  %7640 = call float @dx.op.unary.f32(i32 7, float %7639)  ; Saturate(value)
  %7641 = fadd fast float %7638, %7640
  %7642 = call float @dx.op.unary.f32(i32 7, float %7641)  ; Saturate(value)
  %7643 = fmul fast float %7642, %7603
  %7644 = fmul fast float %7642, %7604
  %7645 = fmul fast float %7642, %7605
  br label %7646

; <label>:7646                                    ; preds = %7631, %7599
  %7647 = phi float [ %7643, %7631 ], [ %7603, %7599 ]
  %7648 = phi float [ %7644, %7631 ], [ %7604, %7599 ]
  %7649 = phi float [ %7645, %7631 ], [ %7605, %7599 ]
  %7650 = fdiv fast float 0x3FA47AE140000000, %3285
  %7651 = fadd fast float %7650, 0x3FEEB851E0000000
  %7652 = fadd fast float %7303, %6586
  %7653 = fadd fast float %7652, %7411
  %7654 = fadd fast float %7653, %7647
  %7655 = fadd fast float %7304, %6587
  %7656 = fadd fast float %7655, %7412
  %7657 = fadd fast float %7656, %7648
  %7658 = fadd fast float %7305, %6588
  %7659 = fadd fast float %7658, %7413
  %7660 = fadd fast float %7659, %7649
  %7661 = fmul fast float %3287, %2797
  %7662 = fmul fast float %3287, %2836
  %7663 = fmul fast float %3287, %2875
  %7664 = fmul fast float %7661, %7614
  %7665 = fmul fast float %7662, %7615
  %7666 = fmul fast float %7663, %7616
  %7667 = fadd fast float %7664, %6583
  %7668 = fadd fast float %7667, %7626
  %7669 = fmul fast float %7668, %2756
  %7670 = fadd fast float %7665, %6584
  %7671 = fadd fast float %7670, %7627
  %7672 = fmul fast float %7671, %2757
  %7673 = fadd fast float %7666, %6585
  %7674 = fadd fast float %7673, %7628
  %7675 = fmul fast float %7674, %2758
  %7676 = and i32 %2884, 1
  %7677 = icmp ne i32 %7676, 0
  %7678 = select i1 %7677, float 1.000000e+00, float 0.000000e+00
  %7679 = fmul fast float %7678, %7654
  %7680 = fmul fast float %7679, %7651
  %7681 = fmul fast float %7678, %7657
  %7682 = fmul fast float %7681, %7651
  %7683 = fmul fast float %7678, %7651
  %7684 = fmul fast float %7683, %7660
  %7685 = fadd fast float %7680, %7669
  %7686 = fadd fast float %7682, %7672
  %7687 = fadd fast float %7684, %7675
  %7688 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %11, %dx.types.Handle %38, float %661, float %662, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %7689 = extractvalue %dx.types.ResRet.f32 %7688, 0
  %7690 = fsub fast float %7689, %660
  %7691 = fdiv fast float 1.000000e+00, %7690
  %7692 = fmul fast float %7691, %659
  %7693 = fsub fast float %7692, %50
  %7694 = fmul fast float %7693, 5.000000e-01
  %7695 = call float @dx.op.unary.f32(i32 7, float %7694)  ; Saturate(value)
  %7696 = fmul fast float %7695, %7695
  %7697 = fmul fast float %7696, 5.000000e-01
  %7698 = fadd fast float %727, 5.000000e-01
  %7699 = fadd fast float %7698, %7697
  %7700 = call float @dx.op.unary.f32(i32 7, float %7699)  ; Saturate(value)
  %7701 = fmul fast float %7700, %60
  %7702 = fsub fast float 1.000000e+00, %67
  %7703 = fmul fast float %7685, %7702
  %7704 = fmul fast float %7686, %7702
  %7705 = fmul fast float %7687, %7702
  %7706 = fadd fast float %7703, %64
  %7707 = fmul fast float %7701, %127
  %7708 = fmul fast float %7707, %7706
  %7709 = fadd fast float %7704, %65
  %7710 = fmul fast float %7707, %7709
  %7711 = fadd fast float %7705, %66
  %7712 = fmul fast float %7707, %7711
  %glass_r5_spec_r = fmul float %7654, %7651
  %glass_r5_exposed_r = fmul float %glass_r5_spec_r, %127
  %r9Scaled_r = fmul float %glass_r5_exposed_r, %setting_reflection_strength
  %dirtReflectionr = fmul float %r9Scaled_r, %glass_r5_reflection_scale
  %dirtReflectionLossr = fmul float %dirtAmount, 0x3FE6666660000000
  %dirtReflectionKeepr = fsub float 1.000000e+00, %dirtReflectionLossr
  %dirtKeptr = fmul float %dirtReflectionr, %dirtReflectionKeepr
  %dirtGreyr = fmul float %dirtAmount, 0x3FB47AE140000000
  %dirtSceneLitr = fmul float %dirtGreyr, %7668
  %dirtExposedr = fmul float %dirtSceneLitr, %127
  %glass_r5_out_r = fadd float %dirtKeptr, %dirtExposedr
  %glass_r5_spec_g = fmul float %7657, %7651
  %glass_r5_exposed_g = fmul float %glass_r5_spec_g, %127
  %r9Scaled_g = fmul float %glass_r5_exposed_g, %setting_reflection_strength
  %dirtReflectiong = fmul float %r9Scaled_g, %glass_r5_reflection_scale
  %dirtReflectionLossg = fmul float %dirtAmount, 0x3FE6666660000000
  %dirtReflectionKeepg = fsub float 1.000000e+00, %dirtReflectionLossg
  %dirtKeptg = fmul float %dirtReflectiong, %dirtReflectionKeepg
  %dirtGreyg = fmul float %dirtAmount, 0x3FB47AE140000000
  %dirtSceneLitg = fmul float %dirtGreyg, %7671
  %dirtExposedg = fmul float %dirtSceneLitg, %127
  %glass_r5_out_g = fadd float %dirtKeptg, %dirtExposedg
  %glass_r5_spec_b = fmul float %7660, %7651
  %glass_r5_exposed_b = fmul float %glass_r5_spec_b, %127
  %r9Scaled_b = fmul float %glass_r5_exposed_b, %setting_reflection_strength
  %dirtReflectionb = fmul float %r9Scaled_b, %glass_r5_reflection_scale
  %dirtReflectionLossb = fmul float %dirtAmount, 0x3FE6666660000000
  %dirtReflectionKeepb = fsub float 1.000000e+00, %dirtReflectionLossb
  %dirtKeptb = fmul float %dirtReflectionb, %dirtReflectionKeepb
  %dirtGreyb = fmul float %dirtAmount, 0x3FB47AE140000000
  %dirtSceneLitb = fmul float %dirtGreyb, %7674
  %dirtExposedb = fmul float %dirtSceneLitb, %127
  %glass_r5_out_b = fadd float %dirtKeptb, %dirtExposedb
  %r8Output0 = select i1 %r8Marked, float %glass_r5_out_r, float %7708
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %r8Output0)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  %r8Output1 = select i1 %r8Marked, float %glass_r5_out_g, float %7710
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %r8Output1)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  %r8Output2 = select i1 %r8Marked, float %glass_r5_out_b, float %7712
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %r8Output2)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  %r8Output3 = select i1 %r8Marked, float %glass_r5_alpha, float %7701
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %r8Output3)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32, %dx.types.Handle, %dx.types.Handle, float, float, float, float, i32, i32, i32, float, float) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32, %dx.types.Handle, %dx.types.Handle, float, float, float, float, i32, i32, i32, float) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32, %dx.types.Handle, %dx.types.Handle, float, float, float, float, i32, i32, i32, float) #2

; Function Attrs: nounwind readnone
declare i32 @dx.op.legacyF32ToF16(i32, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32, %dx.types.Handle, i32, i32) #2

; Function Attrs: nounwind readnone
declare i32 @dx.op.unaryBits.i32(i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot2.f32(i32, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32, %dx.types.Handle, i32, i32) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.entryPoints = !{!61}

!0 = !{!"dxcoob 1.8.2505.0"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, !48, !52}
!5 = !{!6, !8, !9, !10, !12, !13, !14, !16, !17, !18, !19, !20, !21, !22, !23, !24, !26, !27, !28, !29, !30, !31, !32, !34, !35, !36, !38, !40, !41, !42, !43, !44, !45, !46, !47}
!6 = !{i32 0, %"class.Texture2D<float>"* undef, !"", i32 0, i32 65, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %struct.ByteAddressBuffer* undef, !"", i32 0, i32 66, i32 1, i32 11, i32 0, null}
!9 = !{i32 2, %"class.Texture2DArray<float>"* undef, !"", i32 0, i32 67, i32 1, i32 7, i32 0, !7}
!10 = !{i32 3, %"class.StructuredBuffer<vector<float, 4> >"* undef, !"", i32 0, i32 69, i32 1, i32 12, i32 0, !11}
!11 = !{i32 1, i32 16}
!12 = !{i32 4, %"class.TextureCubeArray<vector<float, 4> >"* undef, !"", i32 0, i32 70, i32 1, i32 9, i32 0, !7}
!13 = !{i32 5, %"class.Texture2D<float>"* undef, !"", i32 0, i32 71, i32 1, i32 2, i32 0, !7}
!14 = !{i32 6, %"class.StructuredBuffer<unsigned int>"* undef, !"", i32 0, i32 73, i32 1, i32 12, i32 0, !15}
!15 = !{i32 1, i32 4}
!16 = !{i32 7, %"class.StructuredBuffer<vector<float, 4> >"* undef, !"", i32 0, i32 74, i32 1, i32 12, i32 0, !11}
!17 = !{i32 8, %"class.Texture2DArray<float>"* undef, !"", i32 0, i32 76, i32 1, i32 7, i32 0, !7}
!18 = !{i32 9, %"class.TextureCubeArray<float>"* undef, !"", i32 0, i32 78, i32 1, i32 9, i32 0, !7}
!19 = !{i32 10, %"class.TextureCubeArray<vector<float, 4> >"* undef, !"", i32 0, i32 80, i32 1, i32 9, i32 0, !7}
!20 = !{i32 11, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 81, i32 1, i32 2, i32 0, !7}
!21 = !{i32 12, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 82, i32 1, i32 2, i32 0, !7}
!22 = !{i32 13, %"class.Texture2DArray<vector<float, 4> >"* undef, !"", i32 0, i32 84, i32 1, i32 7, i32 0, !7}
!23 = !{i32 14, %"class.StructuredBuffer<unsigned int>"* undef, !"", i32 0, i32 85, i32 1, i32 12, i32 0, !15}
!24 = !{i32 15, %"class.Texture3D<vector<unsigned int, 2> >"* undef, !"", i32 0, i32 91, i32 1, i32 4, i32 0, !25}
!25 = !{i32 0, i32 5}
!26 = !{i32 16, %"class.Texture3D<vector<float, 4> >"* undef, !"", i32 0, i32 95, i32 1, i32 4, i32 0, !7}
!27 = !{i32 17, %"class.Buffer<unsigned int>"* undef, !"", i32 0, i32 98, i32 1, i32 10, i32 0, !25}
!28 = !{i32 18, %"class.Buffer<unsigned int>"* undef, !"", i32 0, i32 100, i32 1, i32 10, i32 0, !25}
!29 = !{i32 19, %"class.Texture3D<unsigned int>"* undef, !"", i32 0, i32 105, i32 1, i32 4, i32 0, !25}
!30 = !{i32 20, %"class.Texture3D<vector<float, 4> >"* undef, !"", i32 0, i32 106, i32 1, i32 4, i32 0, !7}
!31 = !{i32 21, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 107, i32 1, i32 2, i32 0, !7}
!32 = !{i32 22, %"class.StructuredBuffer<GiGridCellDesc>"* undef, !"", i32 0, i32 108, i32 1, i32 12, i32 0, !33}
!33 = !{i32 1, i32 32}
!34 = !{i32 23, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 109, i32 1, i32 2, i32 0, !7}
!35 = !{i32 24, %"class.Texture2D<float>"* undef, !"", i32 0, i32 114, i32 1, i32 2, i32 0, !7}
!36 = !{i32 25, %"class.StructuredBuffer<ProbeContainer>"* undef, !"", i32 0, i32 116, i32 1, i32 12, i32 0, !37}
!37 = !{i32 1, i32 144}
!38 = !{i32 26, %"hostlayout.class.StructuredBuffer<DenseProbeVolume>"* undef, !"", i32 0, i32 117, i32 1, i32 12, i32 0, !39}
!39 = !{i32 1, i32 112}
!40 = !{i32 27, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 121, i32 1, i32 2, i32 0, !7}
!41 = !{i32 28, %"class.StructuredBuffer<GiGridCellTreeOffsets>"* undef, !"", i32 0, i32 123, i32 1, i32 12, i32 0, !11}
!42 = !{i32 29, %"class.StructuredBuffer<GiGridNode>"* undef, !"", i32 0, i32 128, i32 1, i32 12, i32 0, !11}
!43 = !{i32 30, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 32, i32 1, i32 2, i32 0, !7}
!44 = !{i32 31, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 33, i32 1, i32 2, i32 0, !7}
!45 = !{i32 32, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 34, i32 1, i32 2, i32 0, !7}
!46 = !{i32 33, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 35, i32 1, i32 2, i32 0, !7}
!47 = !{i32 34, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 36, i32 1, i32 2, i32 0, !7}
!48 = !{!49, !50, !51}
!49 = !{i32 0, %common_shadercomponents_configuration_collections_worldglobal_collection* undef, !"", i32 0, i32 2, i32 1, i32 212, null}
!50 = !{i32 1, %common_shadercomponents_configuration_collections_worldseasonalevent_collection* undef, !"", i32 0, i32 3, i32 1, i32 76, null}
!51 = !{i32 2, %hostlayout.PerPassConstants* undef, !"", i32 0, i32 4, i32 1, i32 7804, null}
!52 = !{!53, !54, !55, !56, !57, !58, !59, !60}
!53 = !{i32 0, %struct.SamplerState* undef, !"", i32 0, i32 0, i32 1, i32 0, null}
!54 = !{i32 1, %struct.SamplerState* undef, !"", i32 0, i32 1, i32 1, i32 0, null}
!55 = !{i32 2, %struct.SamplerState* undef, !"", i32 0, i32 2, i32 1, i32 0, null}
!56 = !{i32 3, %struct.SamplerState* undef, !"", i32 0, i32 4, i32 1, i32 0, null}
!57 = !{i32 4, %struct.SamplerState* undef, !"", i32 0, i32 5, i32 1, i32 0, null}
!58 = !{i32 5, %struct.SamplerState* undef, !"", i32 0, i32 7, i32 1, i32 0, null}
!59 = !{i32 6, %struct.SamplerState* undef, !"", i32 0, i32 8, i32 1, i32 0, null}
!60 = !{i32 7, %struct.SamplerComparisonState* undef, !"", i32 0, i32 9, i32 1, i32 1, null}
!61 = !{void ()* @ShaderDomain_Ps, !"ShaderDomain_Ps", !62, !4, !79}
!62 = !{!63, !77, null}
!63 = !{!64, !67, !70, !72, !74, !76}
!64 = !{i32 0, !"TEXCOORD", i8 9, i8 0, !65, i8 2, i32 1, i8 4, i32 0, i8 0, !66}
!65 = !{i32 0}
!66 = !{i32 3, i32 15}
!67 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !68, i8 2, i32 1, i8 3, i32 1, i8 0, !69}
!68 = !{i32 1}
!69 = !{i32 3, i32 7}
!70 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !71, i8 2, i32 1, i8 4, i32 2, i8 0, !66}
!71 = !{i32 2}
!72 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !73, i8 2, i32 1, i8 3, i32 3, i8 0, !69}
!73 = !{i32 3}
!74 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !75, i8 2, i32 1, i8 3, i32 4, i8 0, !69}
!75 = !{i32 4}
!76 = !{i32 5, !"SV_Position", i8 9, i8 3, !65, i8 4, i32 1, i8 4, i32 5, i8 0, !66}
!77 = !{!78}
!78 = !{i32 0, !"SV_Target", i8 9, i8 16, !65, i8 0, i32 1, i8 4, i32 0, i8 0, !66}
!79 = !{i32 0, i64 16}
!80 = distinct !{!80, !"dx.controlflow.hints", i32 1}
!81 = distinct !{!81, !"dx.controlflow.hints", i32 1}
!82 = distinct !{!82, !"dx.controlflow.hints", i32 1}
!83 = !{!84, !84, i64 0}
!84 = !{!"float", !85, i64 0}
!85 = !{!"omnipotent char", !86, i64 0}
!86 = !{!"Simple C/C++ TBAA"}
!87 = !{!88, !90, !91, !93, !95, !96, !98, !99, !101, !102}
!88 = distinct !{!88, !89, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z: %lodId"}
!89 = distinct !{!89, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z"}
!90 = distinct !{!90, !89, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z: %lodT"}
!91 = distinct !{!91, !92, !"\01?getCell@GiGridProbeResources@@QAA?AUGiGridProbeCellResources@@IV?$vector@I$01@@M@Z: %agg.result"}
!92 = distinct !{!92, !"\01?getCell@GiGridProbeResources@@QAA?AUGiGridProbeCellResources@@IV?$vector@I$01@@M@Z"}
!93 = distinct !{!93, !94, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %agg.result"}
!94 = distinct !{!94, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z"}
!95 = distinct !{!95, !94, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %debug"}
!96 = distinct !{!96, !97, !"\01?sampleProbe2@GiGridProbeSampler_SHL1@@QAA?AUWeightedProbeSample@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %agg.result"}
!97 = distinct !{!97, !"\01?sampleProbe2@GiGridProbeSampler_SHL1@@QAA?AUWeightedProbeSample@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z"}
!98 = distinct !{!98, !97, !"\01?sampleProbe2@GiGridProbeSampler_SHL1@@QAA?AUWeightedProbeSample@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %debug"}
!99 = distinct !{!99, !100, !"\01?sampleProbe2@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@UProbeDebug@@@Z: %agg.result"}
!100 = distinct !{!100, !"\01?sampleProbe2@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@UProbeDebug@@@Z"}
!101 = distinct !{!101, !100, !"\01?sampleProbe2@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@UProbeDebug@@@Z: %debug"}
!102 = distinct !{!102, !103, !"\01?sampleProbe@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@@Z: %agg.result"}
!103 = distinct !{!103, !"\01?sampleProbe@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@@Z"}
!104 = distinct !{!104, !105}
!105 = !{!"llvm.loop.unroll.disable"}
!106 = !{!107, !109, !110, !112, !114, !115, !96, !98, !99, !101, !102}
!107 = distinct !{!107, !108, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z: %lodId"}
!108 = distinct !{!108, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z"}
!109 = distinct !{!109, !108, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z: %lodT"}
!110 = distinct !{!110, !111, !"\01?getCell@GiGridProbeResources@@QAA?AUGiGridProbeCellResources@@IV?$vector@I$01@@M@Z: %agg.result"}
!111 = distinct !{!111, !"\01?getCell@GiGridProbeResources@@QAA?AUGiGridProbeCellResources@@IV?$vector@I$01@@M@Z"}
!112 = distinct !{!112, !113, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %agg.result"}
!113 = distinct !{!113, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z"}
!114 = distinct !{!114, !113, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %debug"}
!115 = distinct !{!115, !116, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@@Z: %agg.result"}
!116 = distinct !{!116, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@@Z"}
!117 = distinct !{!117, !"dx.controlflow.hints", i32 1}

