from pathlib import Path
import importlib.util,json,struct,zipfile,hashlib,tempfile,math,sys
base=Path('glass_builder04/reskate_glass/builder').resolve();sys.path.insert(0,str(base));import prepare_native as b;from dirt_bake import bake,sample,encode_marker
# Check every preset and every quantized mask value survives the actual half-float carrier.
for profile in [42,43,44,45,46]:
 for q in range(32):
  x=struct.unpack('<e',struct.pack('<e',encode_marker(profile,q/31)))[0];assert math.floor(x)==profile;assert abs((x-math.floor(x))*32/31-q/31)<1e-8
# Distinct top/bottom rows check glTF V versus Blender image row orientation.
assert sample(bytes([0,255,255,0]),2,2,0,1,1)==0
assert sample(bytes([0,255,255,0]),2,2,0,0,1)==1
points=[(0,0,0),(2,0,0),(2,2,0),(0,2,0)];doc,bin=b.parse_glb(b.write_glb(points,[0,1,2,0,2,3]));uv=[(0,0),(1,0),(1,1),(0,0),(1,1),(0,1)]
uvraw=b''.join(struct.pack('<2f',*p) for p in uv);offset=len(bin);bin+=uvraw;doc['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(uvraw)});doc['accessors'].append({'bufferView':2,'componentType':5126,'count':6,'type':'VEC2'});doc['meshes'][0]['primitives'][0]['attributes']['TEXCOORD_0']=2;doc['buffers'][0]['byteLength']=len(bin)
j=json.dumps(doc).encode();j+=b' '*((-len(j))%4);bin+=b'\0'*((-len(bin))%4);glb=struct.pack('<4sII',b'glTF',2,28+len(j)+len(bin))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(bin),0x004e4942)+bin
profiles=json.loads((base/'profiles.json').read_text());mask=bytes([0,255,0,255]);md={'file':'dirt.mask','width':2,'height':2,'strength':1,'sha256':hashlib.sha256(mask).hexdigest()}
manifest={'schema':1,'kind':'reskate-glass-authoring','materials':{'g':{'settings':profiles['Balanced'],'dirt_mask':md}},'objects':[{'name':'pane','mesh':'pane.glb','material_slots':['g']}],'files':{'pane.glb':hashlib.sha256(glb).hexdigest()}}
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);archive=p/'input.zip'
 with zipfile.ZipFile(archive,'w') as z:z.writestr('glass-authoring.json',json.dumps(manifest));z.writestr('pane.glb',glb);z.writestr('dirt.mask',mask)
 b.prepare(archive,p/'normalized');recipe=json.loads((p/'normalized/glass-build-recipe.json').read_text());samples=recipe['objects'][0]['dirt_samples'];d,data=b.parse_glb((p/'normalized/meshes/glass_0000.glb').read_bytes());geometry=b.positions(d,data)[0][0]
 assert len(samples)==len(geometry)==6144;assert min(samples)==0 and max(samples)==1
 print('PASS: mask orientation, 160 exact half markers, UV subdivision and sample/vertex alignment')
 # Persist synthetic normalized input so it can be compiled in a later focused fixture if needed.
