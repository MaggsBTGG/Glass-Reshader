;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; POSITION                 0   xyzw        0     NONE   float   xyzw
; TEXCOORD                 1   xyzw        1     NONE   float   xyzw
; SV_InstanceID            0   x           2   INSTID    uint   x   
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; TEXCOORD                 0   xyzw        0     NONE   float   xyzw
; TEXCOORD                 1   xyz         1     NONE   float   xyz 
; TEXCOORD                 2   xyzw        2     NONE   float   xyzw
; TEXCOORD                 3   xyz         3     NONE   float   xyz 
; TEXCOORD                 4   xyz         4     NONE   float   xyz 
; SV_Position              0   xyzw        5      POS   float   xyzw
;
; shader hash: 089e62183e85d528f2725aaba21042dc
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Vertex Shader
; OutputPositionPresent=1
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 3
; SigOutputElements: 6
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 3
; SigOutputVectors[0]: 6
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: ShaderDomain_Vs
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; POSITION                 0                              
; TEXCOORD                 1                              
; SV_InstanceID            0                              
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; TEXCOORD                 0                 linear       
; TEXCOORD                 1                 linear       
; TEXCOORD                 2                 linear       
; TEXCOORD                 3                 linear       
; TEXCOORD                 4                 linear       
; SV_Position              0          noperspective       
;
; Buffer Definitions:
;
; cbuffer 
; {
;
;   [4 x i8] (type annotation not present)
;
; }
;
; cbuffer 
; {
;
;   [7804 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [16 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [4 x i8] (type annotation not present)
; }
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
;                                   cbuffer      NA          NA     CB0            cb0     1
;                                   cbuffer      NA          NA     CB1            cb4     1
;                                   sampler      NA          NA      S0             s3     1
;                                   sampler      NA          NA      S1             s8     1
;                                   texture  struct         r/o      T0            t90     1
;                                   texture     f32          2d      T1           t129     1
;                                   texture     f32          3d      T2           t130     1
;                                   texture     f32          3d      T3           t131     1
;                                   texture     f32          3d      T4           t132     1
;                                   texture     f32          2d      T5           t133     1
;                                   texture     f32          3d      T6           t134     1
;                                   texture     f32          2d      T7           t135     1
;                                   texture     f32          3d      T8           t136     1
;                                   texture     f32          2d      T9           t137     1
;                                   texture     f32          3d     T10           t138     1
;                                   texture  struct         r/o     T11             t0     1
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.CBufRet.f32 = type { float, float, float, float }
%dx.types.CBufRet.i32 = type { i32, i32, i32, i32 }
%dx.types.ResRet.i32 = type { i32, i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.StructuredBuffer<vector<float, 4> >" = type { <4 x float> }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }
%"class.Texture3D<vector<float, 4> >" = type { <4 x float>, %"class.Texture3D<vector<float, 4> >::mips_type" }
%"class.Texture3D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture3D<vector<float, 3> >" = type { <3 x float>, %"class.Texture3D<vector<float, 3> >::mips_type" }
%"class.Texture3D<vector<float, 3> >::mips_type" = type { i32 }
%"class.Texture3D<float>" = type { float, %"class.Texture3D<float>::mips_type" }
%"class.Texture3D<float>::mips_type" = type { i32 }
%"class.StructuredBuffer<PerInstanceData>" = type { %struct.PerInstanceData }
%struct.PerInstanceData = type { i32 }
%PerDispatchConstants = type { i32 }
%hostlayout.PerPassConstants = type { [3 x <4 x float>], <4 x float>, <4 x float>, [4 x [4 x <4 x float>]], <4 x float>, [3 x <4 x i32>], [4 x <4 x float>], [5 x <4 x i32>], <4 x float>, [120 x <4 x float>], [4 x <4 x i32>], <4 x float>, [8 x <4 x float>], [8 x <4 x float>], <4 x float>, %struct.TerrainHeightFieldParameters, [5 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], %struct.TerrainColorParameters, [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [4 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [120 x <4 x float>], [4 x <4 x float>], [8 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], %struct.TerrainVirtualTexureParameters, [7 x <4 x float>], [4 x <4 x float>], <4 x float>, [4 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], [8 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], [3 x <4 x float>], [5 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [4 x <4 x float>], <4 x float>, <4 x float>, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, float, <3 x float>, float, <3 x float>, float, <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, float, i32, i32, float, float, float, i32, float, i32, float, float, float, float, i32, float, i32, i32, i32, i32, i32, float, float, i32, i32, i32, float, i32, i32, i32, float, float, float, float, float, float, float, i32, float, float, i32, i32 }
%struct.TerrainHeightFieldParameters = type { <4 x float>, <4 x float>, <4 x float>, <2 x i32>, float, float }
%struct.TerrainColorParameters = type { <4 x float>, <3 x float>, float }
%struct.TerrainVirtualTexureParameters = type { <4 x float>, <2 x i32>, i32, i32, <4 x float>, i32, <3 x float> }
%struct.SamplerState = type { i32 }

define void @ShaderDomain_Vs() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 11, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 10, i32 138, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 9, i32 137, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %4 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 8, i32 136, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %5 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 7, i32 135, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %6 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 6, i32 134, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %7 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 5, i32 133, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %8 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 4, i32 132, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %9 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 3, i32 131, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %10 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 2, i32 130, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %11 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 129, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %12 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 90, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %13 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 1, i32 8, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %14 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 0, i32 3, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %15 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 1, i32 4, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %16 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %17 = call i32 @dx.op.loadInput.i32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef), !dx.precise !34  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef), !dx.precise !34  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 2, i32 undef), !dx.precise !34  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 421)  ; CBufferLoadLegacy(handle,regIndex)
  %26 = extractvalue %dx.types.CBufRet.f32 %25, 0
  %27 = extractvalue %dx.types.CBufRet.f32 %25, 1
  %28 = extractvalue %dx.types.CBufRet.f32 %25, 2
  %29 = extractvalue %dx.types.CBufRet.f32 %25, 3
  %30 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 422)  ; CBufferLoadLegacy(handle,regIndex)
  %31 = extractvalue %dx.types.CBufRet.f32 %30, 0
  %32 = extractvalue %dx.types.CBufRet.f32 %30, 1
  %33 = extractvalue %dx.types.CBufRet.f32 %30, 2
  %34 = extractvalue %dx.types.CBufRet.f32 %30, 3
  %35 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 423)  ; CBufferLoadLegacy(handle,regIndex)
  %36 = extractvalue %dx.types.CBufRet.f32 %35, 0
  %37 = extractvalue %dx.types.CBufRet.f32 %35, 1
  %38 = extractvalue %dx.types.CBufRet.f32 %35, 2
  %39 = extractvalue %dx.types.CBufRet.f32 %35, 3
  %40 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 424)  ; CBufferLoadLegacy(handle,regIndex)
  %41 = extractvalue %dx.types.CBufRet.f32 %40, 0
  %42 = extractvalue %dx.types.CBufRet.f32 %40, 1
  %43 = extractvalue %dx.types.CBufRet.f32 %40, 2
  %44 = extractvalue %dx.types.CBufRet.f32 %40, 3
  %45 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 455)  ; CBufferLoadLegacy(handle,regIndex)
  %46 = extractvalue %dx.types.CBufRet.f32 %45, 0
  %47 = extractvalue %dx.types.CBufRet.f32 %45, 1
  %48 = extractvalue %dx.types.CBufRet.f32 %45, 2
  %49 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %16, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %50 = extractvalue %dx.types.CBufRet.i32 %49, 0
  %51 = add i32 %50, %17
  %52 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %1, i32 %51, i32 0)  ; BufferLoad(srv,index,wot)
  %53 = extractvalue %dx.types.ResRet.i32 %52, 0
  %54 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %12, i32 %53, i32 0)  ; BufferLoad(srv,index,wot)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = bitcast float %55 to i32
  %57 = and i32 %56, 1
  %58 = lshr i32 %56, 1
  %59 = and i32 %58, 65535
  %60 = lshr i32 %56, 18
  %61 = and i32 %60, 1
  %62 = icmp eq i32 %57, 0
  %63 = select i1 %62, i32 0, i32 %59
  %64 = add i32 %53, 1
  %65 = add i32 %64, %61
  %66 = add i32 %65, %63
  %67 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %12, i32 %66, i32 0)  ; BufferLoad(srv,index,wot)
  %68 = extractvalue %dx.types.ResRet.f32 %67, 0
  %69 = extractvalue %dx.types.ResRet.f32 %67, 1
  %70 = extractvalue %dx.types.ResRet.f32 %67, 2
  %71 = extractvalue %dx.types.ResRet.f32 %67, 3
  %72 = add i32 %66, 1
  %73 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %12, i32 %72, i32 0)  ; BufferLoad(srv,index,wot)
  %74 = extractvalue %dx.types.ResRet.f32 %73, 0
  %75 = extractvalue %dx.types.ResRet.f32 %73, 1
  %76 = extractvalue %dx.types.ResRet.f32 %73, 2
  %77 = extractvalue %dx.types.ResRet.f32 %73, 3
  %78 = add i32 %66, 2
  %79 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %12, i32 %78, i32 0)  ; BufferLoad(srv,index,wot)
  %80 = extractvalue %dx.types.ResRet.f32 %79, 0
  %81 = extractvalue %dx.types.ResRet.f32 %79, 1
  %82 = extractvalue %dx.types.ResRet.f32 %79, 2
  %83 = extractvalue %dx.types.ResRet.f32 %79, 3
  %84 = fmul fast float %21, 2.550000e+02
  %85 = fadd fast float %84, 2.500000e-01
  %86 = fptoui float %85 to i32
  %87 = fmul fast float %18, 0x3FE6A09E60000000
  %88 = fmul fast float %19, 0x3FE6A09E60000000
  %89 = fmul fast float %20, 0x3FF921FB60000000
  %90 = fadd fast float %87, 0xBFE6A09E60000000
  %91 = fadd fast float %88, 0xBFE6A09E60000000
  %92 = and i32 %86, 16
  %93 = and i32 %86, 32
  %94 = and i32 %86, 192
  %95 = uitofp i32 %92 to float
  %96 = uitofp i32 %93 to float
  %97 = uitofp i32 %94 to float
  %98 = fmul fast float %95, 0x3FA6A09E60000000
  %99 = fmul fast float %96, 0x3F96A09E60000000
  %100 = fmul fast float %97, 0x3F9921FB60000000
  %101 = fadd fast float %90, %98
  %102 = fadd fast float %91, %99
  %103 = fadd fast float %100, %89
  %104 = call float @dx.op.dot2.f32(i32 54, float %101, float %102, float %101, float %102)  ; Dot2(ax,ay,bx,by)
  %105 = fsub fast float 1.000000e+00, %104
  %106 = call float @dx.op.unary.f32(i32 6, float %105)  ; FAbs(value)
  %107 = call float @dx.op.unary.f32(i32 24, float %106)  ; Sqrt(value)
  %108 = fsub fast float -0.000000e+00, %107
  %109 = and i32 %86, 1
  %110 = icmp ne i32 %109, 0
  %111 = select i1 %110, float %108, float %107
  %112 = and i32 %86, 4
  %113 = icmp ne i32 %112, 0
  %114 = select i1 %113, float %111, float %101
  %115 = select i1 %113, float %101, float %111
  %116 = and i32 %86, 2
  %117 = icmp ne i32 %116, 0
  %118 = select i1 %117, float %102, float %114
  %119 = select i1 %117, float %115, float %102
  %120 = select i1 %117, float %114, float %115
  %121 = fsub fast float -0.000000e+00, %120
  %122 = fsub fast float -0.000000e+00, %119
  %123 = select i1 %117, float %122, float %114
  %124 = select i1 %117, float %114, float 0.000000e+00
  %125 = select i1 %117, float 0.000000e+00, float %121
  %126 = call float @dx.op.dot3.f32(i32 55, float %123, float %124, float %125, float %123, float %124, float %125)  ; Dot3(ax,ay,az,bx,by,bz)
  %127 = call float @dx.op.unary.f32(i32 25, float %126)  ; Rsqrt(value)
  %128 = fmul fast float %123, %127
  %129 = fmul fast float %124, %127
  %130 = fmul fast float %125, %127
  %131 = fmul fast float %130, %119
  %132 = fmul fast float %129, %118
  %133 = fsub fast float %131, %132
  %134 = fmul fast float %128, %118
  %135 = fmul fast float %130, %120
  %136 = fsub fast float %134, %135
  %137 = fmul fast float %129, %120
  %138 = fmul fast float %128, %119
  %139 = fsub fast float %137, %138
  %140 = call float @dx.op.unary.f32(i32 6, float %103)  ; FAbs(value)
  %141 = call float @dx.op.unary.f32(i32 13, float %140)  ; Sin(value)
  %142 = call float @dx.op.unary.f32(i32 12, float %140)  ; Cos(value)
  %143 = fmul fast float %128, %142
  %144 = fmul fast float %129, %142
  %145 = fmul fast float %130, %142
  %146 = fmul fast float %133, %141
  %147 = fmul fast float %136, %141
  %148 = fmul fast float %139, %141
  %149 = fadd fast float %146, %143
  %150 = fadd fast float %147, %144
  %151 = fadd fast float %148, %145
  %152 = fmul fast float %151, %119
  %153 = fmul fast float %150, %118
  %154 = fsub fast float %152, %153
  %155 = fmul fast float %149, %118
  %156 = fmul fast float %151, %120
  %157 = fsub fast float %155, %156
  %158 = fmul fast float %150, %120
  %159 = fmul fast float %149, %119
  %160 = fsub fast float %158, %159
  %161 = fsub fast float -0.000000e+00, %154
  %162 = fsub fast float -0.000000e+00, %157
  %163 = fsub fast float -0.000000e+00, %160
  %164 = and i32 %86, 8
  %165 = icmp ne i32 %164, 0
  %166 = select i1 %165, float %161, float %154
  %167 = select i1 %165, float %162, float %157
  %168 = select i1 %165, float %163, float %160
  %169 = fsub fast float -0.000000e+00, %149
  %170 = fsub fast float -0.000000e+00, %150
  %171 = fsub fast float -0.000000e+00, %151
  %172 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 479)  ; CBufferLoadLegacy(handle,regIndex)
  %173 = extractvalue %dx.types.CBufRet.f32 %172, 3
  %174 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %15, i32 484)  ; CBufferLoadLegacy(handle,regIndex)
  %175 = extractvalue %dx.types.CBufRet.i32 %174, 2
  %176 = icmp eq i32 %175, 0
  %177 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 446)  ; CBufferLoadLegacy(handle,regIndex)
  %178 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 447)  ; CBufferLoadLegacy(handle,regIndex)
  %179 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 448)  ; CBufferLoadLegacy(handle,regIndex)
  %180 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 449)  ; CBufferLoadLegacy(handle,regIndex)
  %181 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 439)  ; CBufferLoadLegacy(handle,regIndex)
  %182 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 477)  ; CBufferLoadLegacy(handle,regIndex)
  %183 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 475)  ; CBufferLoadLegacy(handle,regIndex)
  %184 = extractvalue %dx.types.CBufRet.f32 %183, 0
  %185 = extractvalue %dx.types.CBufRet.f32 %183, 1
  %186 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 476)  ; CBufferLoadLegacy(handle,regIndex)
  %187 = extractvalue %dx.types.CBufRet.f32 %186, 0
  %188 = extractvalue %dx.types.CBufRet.f32 %186, 1
  %189 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 484)  ; CBufferLoadLegacy(handle,regIndex)
  %190 = extractvalue %dx.types.CBufRet.f32 %189, 3
  %191 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 486)  ; CBufferLoadLegacy(handle,regIndex)
  %192 = extractvalue %dx.types.CBufRet.f32 %191, 3
  %193 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 450)  ; CBufferLoadLegacy(handle,regIndex)
  %194 = extractvalue %dx.types.CBufRet.f32 %193, 0
  %195 = extractvalue %dx.types.CBufRet.f32 %193, 1
  %196 = extractvalue %dx.types.CBufRet.f32 %193, 2
  %197 = extractvalue %dx.types.CBufRet.f32 %193, 3
  %198 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 470)  ; CBufferLoadLegacy(handle,regIndex)
  %199 = extractvalue %dx.types.CBufRet.f32 %198, 0
  %200 = extractvalue %dx.types.CBufRet.f32 %198, 1
  %201 = extractvalue %dx.types.CBufRet.f32 %198, 2
  %202 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 451)  ; CBufferLoadLegacy(handle,regIndex)
  %203 = extractvalue %dx.types.CBufRet.f32 %202, 0
  %204 = extractvalue %dx.types.CBufRet.f32 %202, 1
  %205 = extractvalue %dx.types.CBufRet.f32 %202, 2
  %206 = extractvalue %dx.types.CBufRet.f32 %202, 3
  %207 = extractvalue %dx.types.CBufRet.i32 %174, 0
  %208 = icmp ne i32 %207, 0
  %209 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 445)  ; CBufferLoadLegacy(handle,regIndex)
  %210 = extractvalue %dx.types.CBufRet.f32 %209, 0
  %211 = extractvalue %dx.types.CBufRet.f32 %209, 1
  %212 = extractvalue %dx.types.CBufRet.f32 %209, 2
  %213 = extractvalue %dx.types.CBufRet.f32 %209, 3
  %214 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 441)  ; CBufferLoadLegacy(handle,regIndex)
  %215 = extractvalue %dx.types.CBufRet.f32 %214, 0
  %216 = extractvalue %dx.types.CBufRet.f32 %214, 1
  %217 = extractvalue %dx.types.CBufRet.f32 %214, 2
  %218 = extractvalue %dx.types.CBufRet.f32 %214, 3
  %219 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 474)  ; CBufferLoadLegacy(handle,regIndex)
  %220 = extractvalue %dx.types.CBufRet.f32 %219, 2
  %221 = extractvalue %dx.types.CBufRet.f32 %219, 3
  %222 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 444)  ; CBufferLoadLegacy(handle,regIndex)
  %223 = extractvalue %dx.types.CBufRet.f32 %222, 0
  %224 = extractvalue %dx.types.CBufRet.f32 %222, 1
  %225 = extractvalue %dx.types.CBufRet.f32 %222, 2
  %226 = extractvalue %dx.types.CBufRet.f32 %222, 3
  %227 = extractvalue %dx.types.CBufRet.f32 %191, 0
  %228 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 466)  ; CBufferLoadLegacy(handle,regIndex)
  %229 = extractvalue %dx.types.CBufRet.f32 %228, 0
  %230 = extractvalue %dx.types.CBufRet.f32 %228, 1
  %231 = extractvalue %dx.types.CBufRet.f32 %228, 2
  %232 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 464)  ; CBufferLoadLegacy(handle,regIndex)
  %233 = extractvalue %dx.types.CBufRet.f32 %232, 0
  %234 = extractvalue %dx.types.CBufRet.f32 %232, 1
  %235 = extractvalue %dx.types.CBufRet.f32 %232, 2
  %236 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 487)  ; CBufferLoadLegacy(handle,regIndex)
  %237 = extractvalue %dx.types.CBufRet.f32 %236, 0
  %238 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 468)  ; CBufferLoadLegacy(handle,regIndex)
  %239 = extractvalue %dx.types.CBufRet.f32 %238, 0
  %240 = extractvalue %dx.types.CBufRet.f32 %238, 1
  %241 = extractvalue %dx.types.CBufRet.f32 %238, 2
  %242 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 467)  ; CBufferLoadLegacy(handle,regIndex)
  %243 = extractvalue %dx.types.CBufRet.f32 %242, 0
  %244 = extractvalue %dx.types.CBufRet.f32 %242, 1
  %245 = extractvalue %dx.types.CBufRet.f32 %242, 2
  %246 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 485)  ; CBufferLoadLegacy(handle,regIndex)
  %247 = extractvalue %dx.types.CBufRet.f32 %246, 1
  %248 = extractvalue %dx.types.CBufRet.f32 %191, 1
  %249 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 462)  ; CBufferLoadLegacy(handle,regIndex)
  %250 = extractvalue %dx.types.CBufRet.f32 %249, 0
  %251 = extractvalue %dx.types.CBufRet.f32 %249, 1
  %252 = extractvalue %dx.types.CBufRet.f32 %249, 2
  %253 = extractvalue %dx.types.CBufRet.f32 %246, 2
  %254 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 465)  ; CBufferLoadLegacy(handle,regIndex)
  %255 = extractvalue %dx.types.CBufRet.f32 %254, 0
  %256 = extractvalue %dx.types.CBufRet.f32 %254, 1
  %257 = extractvalue %dx.types.CBufRet.f32 %254, 2
  %258 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 469)  ; CBufferLoadLegacy(handle,regIndex)
  %259 = extractvalue %dx.types.CBufRet.f32 %258, 0
  %260 = extractvalue %dx.types.CBufRet.f32 %258, 1
  %261 = extractvalue %dx.types.CBufRet.f32 %258, 2
  %262 = extractvalue %dx.types.CBufRet.i32 %174, 1
  %263 = icmp eq i32 %262, 0
  %264 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 443)  ; CBufferLoadLegacy(handle,regIndex)
  %265 = extractvalue %dx.types.CBufRet.f32 %264, 0
  %266 = extractvalue %dx.types.CBufRet.f32 %264, 1
  %267 = extractvalue %dx.types.CBufRet.f32 %264, 2
  %268 = extractvalue %dx.types.CBufRet.f32 %264, 3
  %269 = extractvalue %dx.types.CBufRet.f32 %186, 2
  %270 = extractvalue %dx.types.CBufRet.f32 %186, 3
  %271 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 442)  ; CBufferLoadLegacy(handle,regIndex)
  %272 = extractvalue %dx.types.CBufRet.f32 %271, 0
  %273 = extractvalue %dx.types.CBufRet.f32 %271, 1
  %274 = extractvalue %dx.types.CBufRet.f32 %271, 2
  %275 = extractvalue %dx.types.CBufRet.f32 %271, 3
  %276 = extractvalue %dx.types.CBufRet.f32 %183, 2
  %277 = extractvalue %dx.types.CBufRet.f32 %183, 3
  %278 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 463)  ; CBufferLoadLegacy(handle,regIndex)
  %279 = extractvalue %dx.types.CBufRet.f32 %278, 0
  %280 = extractvalue %dx.types.CBufRet.f32 %278, 1
  %281 = extractvalue %dx.types.CBufRet.f32 %278, 2
  %282 = extractvalue %dx.types.CBufRet.f32 %246, 0
  %283 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 440)  ; CBufferLoadLegacy(handle,regIndex)
  %284 = extractvalue %dx.types.CBufRet.f32 %283, 0
  %285 = extractvalue %dx.types.CBufRet.f32 %283, 1
  %286 = extractvalue %dx.types.CBufRet.f32 %283, 2
  %287 = extractvalue %dx.types.CBufRet.f32 %283, 3
  %288 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 438)  ; CBufferLoadLegacy(handle,regIndex)
  %289 = extractvalue %dx.types.CBufRet.f32 %288, 0
  %290 = extractvalue %dx.types.CBufRet.f32 %288, 1
  %291 = extractvalue %dx.types.CBufRet.f32 %288, 2
  %292 = extractvalue %dx.types.CBufRet.f32 %288, 3
  %293 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %15, i32 486)  ; CBufferLoadLegacy(handle,regIndex)
  %294 = extractvalue %dx.types.CBufRet.i32 %293, 2
  %295 = fmul float %22, %68
  %296 = call float @dx.op.tertiary.f32(i32 46, float %23, float %69, float %295), !dx.precise !34  ; FMad(a,b,c)
  %297 = call float @dx.op.tertiary.f32(i32 46, float %24, float %70, float %296), !dx.precise !34  ; FMad(a,b,c)
  %298 = fadd fast float %297, %71
  %299 = fmul float %22, %74
  %300 = call float @dx.op.tertiary.f32(i32 46, float %23, float %75, float %299), !dx.precise !34  ; FMad(a,b,c)
  %301 = call float @dx.op.tertiary.f32(i32 46, float %24, float %76, float %300), !dx.precise !34  ; FMad(a,b,c)
  %302 = fadd fast float %301, %77
  %303 = fmul float %22, %80
  %304 = call float @dx.op.tertiary.f32(i32 46, float %23, float %81, float %303), !dx.precise !34  ; FMad(a,b,c)
  %305 = call float @dx.op.tertiary.f32(i32 46, float %24, float %82, float %304), !dx.precise !34  ; FMad(a,b,c)
  %306 = fadd fast float %305, %83
  %307 = fsub fast float %71, %46
  %308 = fadd fast float %297, %307
  %309 = fsub fast float %77, %47
  %310 = fadd fast float %301, %309
  %311 = fsub fast float %83, %48
  %312 = fadd fast float %305, %311
  %313 = fmul fast float %308, %26
  %314 = call float @dx.op.tertiary.f32(i32 46, float %310, float %27, float %313)  ; FMad(a,b,c)
  %315 = call float @dx.op.tertiary.f32(i32 46, float %312, float %28, float %314)  ; FMad(a,b,c)
  %316 = fadd fast float %315, %29
  %317 = fmul fast float %308, %31
  %318 = call float @dx.op.tertiary.f32(i32 46, float %310, float %32, float %317)  ; FMad(a,b,c)
  %319 = call float @dx.op.tertiary.f32(i32 46, float %312, float %33, float %318)  ; FMad(a,b,c)
  %320 = fadd fast float %319, %34
  %321 = fmul fast float %308, %41
  %322 = call float @dx.op.tertiary.f32(i32 46, float %310, float %42, float %321)  ; FMad(a,b,c)
  %323 = call float @dx.op.tertiary.f32(i32 46, float %312, float %43, float %322)  ; FMad(a,b,c)
  %324 = fadd fast float %323, %44
  %325 = fdiv fast float %316, %324
  %326 = fdiv fast float %320, %324
  %327 = fmul fast float %325, 5.000000e-01
  %328 = fmul fast float %326, 5.000000e-01
  %329 = fadd fast float %327, 5.000000e-01
  %330 = fadd fast float %328, 5.000000e-01
  br i1 %176, label %331, label %341, !dx.controlflow.hints !49

; <label>:331                                     ; preds = %0
  %332 = fsub fast float %46, %298
  %333 = fsub fast float %47, %302
  %334 = fsub fast float %48, %306
  %335 = fmul fast float %332, %332
  %336 = fmul fast float %333, %333
  %337 = fadd fast float %336, %335
  %338 = fmul fast float %334, %334
  %339 = fadd fast float %337, %338
  %340 = call float @dx.op.unary.f32(i32 24, float %339)  ; Sqrt(value)
  br label %455

; <label>:341                                     ; preds = %0
  %342 = extractvalue %dx.types.CBufRet.f32 %246, 3
  %343 = extractvalue %dx.types.CBufRet.f32 %182, 1
  %344 = extractvalue %dx.types.CBufRet.f32 %182, 0
  %345 = extractvalue %dx.types.CBufRet.f32 %181, 2
  %346 = extractvalue %dx.types.CBufRet.f32 %181, 1
  %347 = extractvalue %dx.types.CBufRet.f32 %181, 0
  %348 = extractvalue %dx.types.CBufRet.f32 %180, 3
  %349 = extractvalue %dx.types.CBufRet.f32 %180, 2
  %350 = extractvalue %dx.types.CBufRet.f32 %180, 1
  %351 = extractvalue %dx.types.CBufRet.f32 %180, 0
  %352 = extractvalue %dx.types.CBufRet.f32 %179, 3
  %353 = extractvalue %dx.types.CBufRet.f32 %179, 2
  %354 = extractvalue %dx.types.CBufRet.f32 %179, 1
  %355 = extractvalue %dx.types.CBufRet.f32 %179, 0
  %356 = extractvalue %dx.types.CBufRet.f32 %178, 3
  %357 = extractvalue %dx.types.CBufRet.f32 %178, 2
  %358 = extractvalue %dx.types.CBufRet.f32 %178, 1
  %359 = extractvalue %dx.types.CBufRet.f32 %178, 0
  %360 = extractvalue %dx.types.CBufRet.f32 %177, 3
  %361 = extractvalue %dx.types.CBufRet.f32 %177, 2
  %362 = extractvalue %dx.types.CBufRet.f32 %177, 1
  %363 = extractvalue %dx.types.CBufRet.f32 %177, 0
  %364 = fsub fast float %46, %298
  %365 = fsub fast float %47, %302
  %366 = fsub fast float %48, %306
  %367 = fmul fast float %364, %364
  %368 = fmul fast float %365, %365
  %369 = fadd fast float %368, %367
  %370 = fmul fast float %366, %366
  %371 = fadd fast float %369, %370
  %372 = call float @dx.op.unary.f32(i32 24, float %371)  ; Sqrt(value)
  %373 = fmul fast float %298, %363
  %374 = call float @dx.op.tertiary.f32(i32 46, float %302, float %362, float %373)  ; FMad(a,b,c)
  %375 = call float @dx.op.tertiary.f32(i32 46, float %306, float %361, float %374)  ; FMad(a,b,c)
  %376 = fadd fast float %375, %360
  %377 = fmul fast float %298, %359
  %378 = call float @dx.op.tertiary.f32(i32 46, float %302, float %358, float %377)  ; FMad(a,b,c)
  %379 = call float @dx.op.tertiary.f32(i32 46, float %306, float %357, float %378)  ; FMad(a,b,c)
  %380 = fadd fast float %379, %356
  %381 = fmul fast float %298, %355
  %382 = call float @dx.op.tertiary.f32(i32 46, float %302, float %354, float %381)  ; FMad(a,b,c)
  %383 = call float @dx.op.tertiary.f32(i32 46, float %306, float %353, float %382)  ; FMad(a,b,c)
  %384 = fadd fast float %383, %352
  %385 = fmul fast float %298, %351
  %386 = call float @dx.op.tertiary.f32(i32 46, float %302, float %350, float %385)  ; FMad(a,b,c)
  %387 = call float @dx.op.tertiary.f32(i32 46, float %306, float %349, float %386)  ; FMad(a,b,c)
  %388 = fadd fast float %387, %348
  %389 = fdiv fast float %376, %388
  %390 = fdiv fast float %380, %388
  %391 = fdiv fast float %384, %388
  %392 = fsub fast float %391, %346
  %393 = fdiv fast float 1.000000e+00, %392
  %394 = fmul fast float %393, %347
  %395 = fsub fast float %394, %345
  %396 = fmul fast float %395, %342
  %397 = fmul fast float %389, 5.000000e-01
  %398 = fmul fast float %390, 5.000000e-01
  %399 = fadd fast float %397, 5.000000e-01
  %400 = fadd fast float %398, 5.000000e-01
  %401 = fmul fast float %399, %344
  %402 = fmul fast float %400, %343
  %403 = fcmp fast olt float %187, 0.000000e+00
  br i1 %403, label %404, label %410

; <label>:404                                     ; preds = %341
  %405 = call float @dx.op.unary.f32(i32 7, float %396)  ; Saturate(value)
  %406 = fmul fast float %405, %187
  %407 = fsub fast float 1.000000e+00, %406
  %408 = call float @dx.op.unary.f32(i32 23, float %407)  ; Log(value)
  %409 = fmul fast float %408, %188
  br label %433

; <label>:410                                     ; preds = %341
  %411 = fcmp fast olt float %184, 1.000000e+00
  br i1 %411, label %412, label %429

; <label>:412                                     ; preds = %410
  %413 = fsub fast float %396, %184
  %414 = fsub fast float 1.000000e+00, %184
  %415 = fdiv fast float %413, %414
  %416 = call float @dx.op.unary.f32(i32 23, float %415)  ; Log(value)
  %417 = fmul fast float %416, %188
  %418 = call float @dx.op.unary.f32(i32 21, float %417)  ; Exp(value)
  %419 = fsub fast float 1.000000e+00, %185
  %420 = fmul fast float %418, %419
  %421 = fadd fast float %420, %185
  %422 = fdiv fast float %396, %184
  %423 = call float @dx.op.unary.f32(i32 23, float %422)  ; Log(value)
  %424 = fmul fast float %423, %187
  %425 = call float @dx.op.unary.f32(i32 21, float %424)  ; Exp(value)
  %426 = fmul fast float %425, %185
  %427 = fcmp fast ole float %396, %184
  %428 = select i1 %427, float %426, float %421
  br label %433

; <label>:429                                     ; preds = %410
  %430 = call float @dx.op.unary.f32(i32 23, float %396)  ; Log(value)
  %431 = fmul fast float %430, %187
  %432 = call float @dx.op.unary.f32(i32 21, float %431)  ; Exp(value)
  br label %433

; <label>:433                                     ; preds = %429, %412, %404
  %434 = phi float [ %409, %404 ], [ %428, %412 ], [ %432, %429 ]
  %435 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %6, %dx.types.Handle %13, float %401, float %402, float %434, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %436 = extractvalue %dx.types.ResRet.f32 %435, 0
  %437 = extractvalue %dx.types.ResRet.f32 %435, 1
  %438 = extractvalue %dx.types.ResRet.f32 %435, 2
  %439 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %2, %dx.types.Handle %13, float %401, float %402, float %434, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %440 = extractvalue %dx.types.ResRet.f32 %439, 0
  %441 = fmul fast float %372, %190
  %442 = fsub fast float %441, %192
  %443 = call float @dx.op.unary.f32(i32 7, float %442)  ; Saturate(value)
  %444 = fmul fast float %443, %443
  %445 = fmul fast float %444, %443
  %446 = call float @dx.op.dot4.f32(i32 56, float %445, float %444, float %443, float 1.000000e+00, float %194, float %195, float %196, float %197)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %447 = call float @dx.op.unary.f32(i32 7, float %446)  ; Saturate(value)
  %448 = fadd fast float %440, -1.000000e+00
  %449 = fmul fast float %447, %173
  %450 = fmul fast float %449, %436
  %451 = fmul fast float %449, %437
  %452 = fmul fast float %449, %438
  %453 = fmul fast float %447, %448
  %454 = fadd fast float %453, 1.000000e+00
  br label %455

; <label>:455                                     ; preds = %433, %331
  %456 = phi float [ %340, %331 ], [ %372, %433 ]
  %457 = phi float [ %334, %331 ], [ %366, %433 ]
  %458 = phi float [ %333, %331 ], [ %365, %433 ]
  %459 = phi float [ %332, %331 ], [ %364, %433 ]
  %460 = phi float [ 0.000000e+00, %331 ], [ %450, %433 ]
  %461 = phi float [ 0.000000e+00, %331 ], [ %451, %433 ]
  %462 = phi float [ 0.000000e+00, %331 ], [ %452, %433 ]
  %463 = phi float [ 1.000000e+00, %331 ], [ %454, %433 ]
  %464 = icmp eq i32 %294, 0
  %465 = fsub fast float %302, %47
  %466 = uitofp i1 %208 to float
  %467 = fsub fast float %456, %227
  %468 = call float @dx.op.binary.f32(i32 35, float %467, float 0.000000e+00)  ; FMax(a,b)
  br i1 %464, label %469, label %647, !dx.controlflow.hints !50

; <label>:469                                     ; preds = %455
  %470 = call float @dx.op.dot3.f32(i32 55, float %459, float %458, float %457, float %459, float %458, float %457)  ; Dot3(ax,ay,az,bx,by,bz)
  %471 = call float @dx.op.unary.f32(i32 25, float %470)  ; Rsqrt(value)
  %472 = fmul fast float %471, %459
  %473 = fmul fast float %471, %458
  %474 = fmul fast float %471, %457
  %475 = call float @dx.op.dot3.f32(i32 55, float %279, float %280, float %281, float %472, float %473, float %474)  ; Dot3(ax,ay,az,bx,by,bz)
  %476 = fdiv fast float %472, %474
  %477 = call float @dx.op.unary.f32(i32 17, float %476)  ; Atan(value)
  %478 = fadd fast float %477, 0x400921FB60000000
  %479 = fadd fast float %477, 0xC00921FB60000000
  %480 = fcmp fast olt float %474, 0.000000e+00
  %481 = fcmp fast oeq float %474, 0.000000e+00
  %482 = fcmp fast oge float %472, 0.000000e+00
  %483 = fcmp fast olt float %472, 0.000000e+00
  %484 = and i1 %480, %482
  %485 = select i1 %484, float %478, float %477
  %486 = and i1 %480, %483
  %487 = select i1 %486, float %479, float %485
  %488 = and i1 %481, %483
  %489 = and i1 %481, %482
  %490 = fadd fast float %487, 0x400921FB60000000
  %491 = fmul fast float %490, 0x3FC45F3060000000
  %492 = fsub fast float 1.000000e+00, %491
  %493 = select i1 %488, float 7.500000e-01, float %492
  %494 = select i1 %489, float 2.500000e-01, float %493
  %495 = fmul fast float %473, 0x3FDFF00000000000
  %496 = fadd fast float %495, 0x3FE0080000000000
  %497 = call float @dx.op.unary.f32(i32 22, float %496)  ; Frc(value)
  %498 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %11, %dx.types.Handle %13, float %497, float 5.000000e-01, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %499 = extractvalue %dx.types.ResRet.f32 %498, 0
  %500 = fsub fast float 1.000000e+00, %499
  %501 = fmul fast float %494, %289
  %502 = fmul fast float %500, %290
  %503 = fadd fast float %501, %291
  %504 = fadd fast float %502, %292
  %505 = call float @dx.op.unary.f32(i32 7, float %503)  ; Saturate(value)
  %506 = call float @dx.op.unary.f32(i32 7, float %504)  ; Saturate(value)
  %507 = fadd fast float %505, %285
  %508 = fmul fast float %507, %284
  %509 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %5, %dx.types.Handle %14, float %508, float %506, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %510 = extractvalue %dx.types.ResRet.f32 %509, 0
  %511 = extractvalue %dx.types.ResRet.f32 %509, 1
  %512 = extractvalue %dx.types.ResRet.f32 %509, 2
  %513 = extractvalue %dx.types.ResRet.f32 %509, 3
  %514 = fadd fast float %505, %286
  %515 = fmul fast float %514, %284
  %516 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %3, %dx.types.Handle %14, float %515, float %506, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %517 = extractvalue %dx.types.ResRet.f32 %516, 0
  %518 = extractvalue %dx.types.ResRet.f32 %516, 1
  %519 = extractvalue %dx.types.ResRet.f32 %516, 2
  %520 = extractvalue %dx.types.ResRet.f32 %516, 3
  %521 = fsub fast float %510, %517
  %522 = fsub fast float %511, %518
  %523 = fsub fast float %512, %519
  %524 = fmul fast float %521, %287
  %525 = fmul fast float %522, %287
  %526 = fmul fast float %523, %287
  %527 = fadd fast float %524, %517
  %528 = fadd fast float %525, %518
  %529 = fadd fast float %526, %519
  %530 = fsub fast float %513, %520
  %531 = fmul fast float %530, %287
  %532 = fadd fast float %531, %520
  %533 = fmul fast float %527, %282
  %534 = fmul fast float %528, %282
  %535 = fmul fast float %529, %282
  %536 = fcmp fast oeq float %269, 1.000000e+00
  %537 = fcmp fast oeq float %270, 1.000000e+00
  %538 = fdiv fast float %225, %532
  %539 = fdiv fast float %226, %532
  %540 = fmul fast float %538, %456
  %541 = fmul fast float %539, %456
  %542 = fadd fast float %540, %223
  %543 = fadd fast float %541, %224
  %544 = call float @dx.op.unary.f32(i32 7, float %542)  ; Saturate(value)
  %545 = call float @dx.op.unary.f32(i32 7, float %543)  ; Saturate(value)
  %546 = fmul fast float %544, %544
  %547 = fmul fast float %545, %545
  %548 = fmul fast float %546, %544
  %549 = call float @dx.op.dot4.f32(i32 56, float %548, float %546, float %544, float 1.000000e+00, float %265, float %266, float %267, float %268)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %550 = call float @dx.op.unary.f32(i32 7, float %549)  ; Saturate(value)
  %551 = fmul fast float %547, %545
  %552 = call float @dx.op.dot4.f32(i32 56, float %551, float %547, float %545, float 1.000000e+00, float %203, float %204, float %205, float %206)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %553 = call float @dx.op.unary.f32(i32 7, float %552)  ; Saturate(value)
  %554 = fmul fast float %456, %221
  %555 = fadd fast float %554, %220
  %556 = call float @dx.op.unary.f32(i32 7, float %555)  ; Saturate(value)
  %557 = fmul fast float %556, %556
  %558 = fmul fast float %557, %556
  %559 = call float @dx.op.dot4.f32(i32 56, float %558, float %557, float %556, float 1.000000e+00, float %215, float %216, float %217, float %218)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %560 = call float @dx.op.unary.f32(i32 7, float %559)  ; Saturate(value)
  %561 = call float @dx.op.unary.f32(i32 6, float %465)  ; FAbs(value)
  %562 = fcmp fast olt float %561, 0x3F847AE140000000
  %563 = select i1 %562, float 0x3F847AE140000000, float %465
  %564 = fmul fast float %563, %210
  %565 = fadd fast float %564, %211
  %566 = call float @dx.op.unary.f32(i32 21, float %565)  ; Exp(value)
  %567 = fadd fast float %566, 1.000000e+00
  %568 = fdiv fast float %212, %567
  %569 = fsub fast float %568, %213
  %570 = fdiv fast float %569, %563
  %571 = fmul fast float %570, %468
  %572 = call float @dx.op.unary.f32(i32 6, float %571)  ; FAbs(value)
  %573 = fsub fast float -0.000000e+00, %572
  %574 = call float @dx.op.unary.f32(i32 21, float %573)  ; Exp(value)
  %575 = fsub fast float 1.000000e+00, %574
  %576 = fmul fast float %575, %560
  %577 = call float @dx.op.binary.f32(i32 35, float %550, float %576)  ; FMax(a,b)
  %578 = call float @dx.op.binary.f32(i32 35, float %553, float %576)  ; FMax(a,b)
  %579 = fmul fast float %475, %276
  %580 = fadd fast float %579, 1.000000e+00
  %581 = fmul fast float %580, %580
  %582 = fdiv fast float %277, %581
  %583 = select i1 %536, float 1.000000e+00, float 0.000000e+00
  %584 = select i1 %537, float 1.000000e+00, float 0.000000e+00
  %585 = fmul fast float %583, %584
  %586 = fmul fast float %578, %583
  %587 = fmul fast float %577, %584
  %588 = fmul fast float %578, %199
  %589 = fmul fast float %578, %200
  %590 = fmul fast float %578, %201
  %591 = fsub fast float %533, %588
  %592 = fsub fast float %534, %589
  %593 = fsub fast float %535, %590
  %594 = fmul fast float %591, %577
  %595 = fmul fast float %592, %577
  %596 = fmul fast float %593, %577
  %597 = fadd fast float %594, %588
  %598 = fadd fast float %595, %589
  %599 = fadd fast float %596, %590
  %600 = fmul fast float %586, %199
  %601 = fmul fast float %586, %200
  %602 = fmul fast float %586, %201
  %603 = fmul fast float %587, %533
  %604 = fmul fast float %587, %534
  %605 = fmul fast float %587, %535
  %606 = fadd fast float %600, %603
  %607 = fadd fast float %601, %604
  %608 = fadd fast float %602, %605
  %609 = fsub fast float %597, %606
  %610 = fsub fast float %598, %607
  %611 = fsub fast float %599, %608
  %612 = fmul fast float %609, %585
  %613 = fmul fast float %610, %585
  %614 = fmul fast float %611, %585
  %615 = fsub fast float 1.000000e+00, %577
  %616 = fmul fast float %615, %578
  %617 = fadd fast float %616, %577
  %618 = fadd fast float %586, %587
  %619 = fsub fast float %617, %618
  %620 = fmul fast float %619, %585
  %621 = fadd fast float %620, %618
  %622 = fsub fast float 1.000000e+00, %550
  %623 = fmul fast float %553, %622
  %624 = fadd fast float %623, %550
  %625 = fmul fast float %553, %583
  %626 = fmul fast float %550, %584
  %627 = fadd fast float %625, %626
  %628 = fsub fast float %624, %627
  %629 = fmul fast float %628, %585
  %630 = fadd fast float %629, %627
  %631 = fsub fast float 1.000000e+00, %275
  %632 = fmul fast float %630, %631
  %633 = fmul fast float %582, %632
  %634 = fmul fast float %633, %272
  %635 = fmul fast float %633, %273
  %636 = fmul fast float %633, %274
  %637 = fadd fast float %606, %634
  %638 = fadd fast float %637, %612
  %639 = fadd fast float %607, %635
  %640 = fadd fast float %639, %613
  %641 = fadd fast float %608, %636
  %642 = fadd fast float %641, %614
  %643 = fmul fast float %638, %466
  %644 = fmul fast float %640, %466
  %645 = fmul fast float %642, %466
  %646 = fmul fast float %621, %466
  br label %892

; <label>:647                                     ; preds = %455
  %648 = fsub fast float %298, %46
  %649 = fsub fast float %306, %48
  %650 = call float @dx.op.dot3.f32(i32 55, float %648, float %465, float %649, float %648, float %465, float %649)  ; Dot3(ax,ay,az,bx,by,bz)
  %651 = call float @dx.op.unary.f32(i32 25, float %650)  ; Rsqrt(value)
  %652 = fmul fast float %651, %648
  %653 = fmul fast float %651, %465
  %654 = fmul fast float %651, %649
  %655 = call float @dx.op.dot3.f32(i32 55, float %652, float %653, float %654, float %239, float %240, float %241)  ; Dot3(ax,ay,az,bx,by,bz)
  %656 = call float @dx.op.binary.f32(i32 35, float %655, float -1.000000e+00)  ; FMax(a,b)
  %657 = call float @dx.op.binary.f32(i32 36, float %656, float 1.000000e+00)  ; FMin(a,b)
  %658 = call float @dx.op.dot3.f32(i32 55, float %652, float %653, float %654, float %243, float %244, float %245)  ; Dot3(ax,ay,az,bx,by,bz)
  %659 = call float @dx.op.binary.f32(i32 35, float %658, float -1.000000e+00)  ; FMax(a,b)
  %660 = call float @dx.op.binary.f32(i32 36, float %659, float 1.000000e+00)  ; FMin(a,b)
  %661 = fmul fast float %248, %248
  %662 = fsub fast float 1.000000e+00, %661
  %663 = fmul fast float %662, 3.000000e+00
  %664 = fadd fast float %661, 2.000000e+00
  %665 = fmul fast float %664, 2.000000e+00
  %666 = fdiv fast float %663, %665
  %667 = fmul fast float %657, %657
  %668 = fadd fast float %667, 1.000000e+00
  %669 = fmul fast float %666, %668
  %670 = fadd fast float %661, 1.000000e+00
  %671 = fmul fast float %248, 2.000000e+00
  %672 = fmul fast float %657, %671
  %673 = fsub fast float %670, %672
  %674 = call float @dx.op.unary.f32(i32 6, float %673)  ; FAbs(value)
  %675 = call float @dx.op.unary.f32(i32 23, float %674)  ; Log(value)
  %676 = fmul fast float %675, 1.500000e+00
  %677 = call float @dx.op.unary.f32(i32 21, float %676)  ; Exp(value)
  %678 = fdiv fast float %669, %677
  %679 = fmul fast float %657, 0x3FD99999A0000000
  %680 = fadd fast float %679, 0x3FF1EB8520000000
  %681 = fmul fast float %660, %660
  %682 = fadd fast float %681, 1.000000e+00
  %683 = fmul fast float %682, %666
  %684 = fmul fast float %660, %671
  %685 = fsub fast float %670, %684
  %686 = call float @dx.op.unary.f32(i32 6, float %685)  ; FAbs(value)
  %687 = call float @dx.op.unary.f32(i32 23, float %686)  ; Log(value)
  %688 = fmul fast float %687, 1.500000e+00
  %689 = call float @dx.op.unary.f32(i32 21, float %688)  ; Exp(value)
  %690 = fdiv fast float %683, %689
  %691 = fmul fast float %660, 0x3FD99999A0000000
  %692 = fadd fast float %691, 0x3FF1EB8520000000
  %693 = fdiv fast float %468, %247
  %694 = fadd fast float %693, 3.125000e-02
  %695 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %10, %dx.types.Handle %13, float %329, float %330, float %694, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %696 = extractvalue %dx.types.ResRet.f32 %695, 0
  %697 = extractvalue %dx.types.ResRet.f32 %695, 1
  %698 = extractvalue %dx.types.ResRet.f32 %695, 2
  %699 = extractvalue %dx.types.ResRet.f32 %695, 3
  %700 = call float @dx.op.binary.f32(i32 35, float %696, float 0x3EB0C6F7A0000000)  ; FMax(a,b)
  %701 = call float @dx.op.binary.f32(i32 35, float %697, float 0x3EB0C6F7A0000000)  ; FMax(a,b)
  %702 = call float @dx.op.binary.f32(i32 35, float %698, float 0x3EB0C6F7A0000000)  ; FMax(a,b)
  %703 = call float @dx.op.binary.f32(i32 35, float %699, float 0x3EB0C6F7A0000000)  ; FMax(a,b)
  %704 = fmul fast float %703, %700
  %705 = fmul fast float %703, %701
  %706 = fmul fast float %703, %702
  %707 = fdiv fast float %704, %700
  %708 = fdiv fast float %705, %700
  %709 = fdiv fast float %706, %700
  %710 = fmul fast float %707, %259
  %711 = fmul fast float %708, %259
  %712 = fmul fast float %709, %259
  %713 = fdiv fast float %710, %253
  %714 = fdiv fast float %711, %253
  %715 = fdiv fast float %712, %253
  %716 = fmul fast float %713, %253
  %717 = fmul fast float %714, %253
  %718 = fmul fast float %715, %253
  %719 = fdiv fast float %716, %259
  %720 = fdiv fast float %717, %260
  %721 = fdiv fast float %718, %261
  %722 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %8, %dx.types.Handle %13, float %329, float %330, float %694, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %723 = extractvalue %dx.types.ResRet.f32 %722, 0
  %724 = extractvalue %dx.types.ResRet.f32 %722, 1
  %725 = extractvalue %dx.types.ResRet.f32 %722, 2
  %726 = fmul fast float %680, %255
  %727 = fmul fast float %700, %726
  %728 = fmul fast float %680, %256
  %729 = fmul fast float %701, %728
  %730 = fmul fast float %680, %257
  %731 = fmul fast float %702, %730
  %732 = fmul fast float %678, 0x3FF0CCCCC0000000
  %733 = fmul fast float %732, %250
  %734 = fmul fast float %733, %719
  %735 = fmul fast float %732, %251
  %736 = fmul fast float %735, %720
  %737 = fmul fast float %732, %252
  %738 = fmul fast float %737, %721
  %739 = fadd fast float %734, %727
  %740 = fadd fast float %736, %729
  %741 = fadd fast float %738, %731
  %742 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %7, i32 0, i32 0, i32 0, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %743 = extractvalue %dx.types.ResRet.f32 %742, 0
  %744 = extractvalue %dx.types.ResRet.f32 %742, 1
  %745 = extractvalue %dx.types.ResRet.f32 %742, 2
  %746 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %7, i32 0, i32 1, i32 0, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %747 = extractvalue %dx.types.ResRet.f32 %746, 0
  %748 = extractvalue %dx.types.ResRet.f32 %746, 1
  %749 = extractvalue %dx.types.ResRet.f32 %746, 2
  %750 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %7, i32 0, i32 2, i32 0, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %751 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %7, i32 0, i32 3, i32 0, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %752 = fmul fast float %743, %726
  %753 = fmul fast float %744, %728
  %754 = fmul fast float %745, %730
  %755 = fmul fast float %678, %250
  %756 = fmul fast float %755, %747
  %757 = fmul fast float %678, %251
  %758 = fmul fast float %757, %748
  %759 = fmul fast float %678, %252
  %760 = fmul fast float %759, %749
  %761 = fadd fast float %756, %752
  %762 = fadd fast float %758, %753
  %763 = fadd fast float %760, %754
  br i1 %263, label %832, label %764

; <label>:764                                     ; preds = %647
  %765 = extractvalue %dx.types.ResRet.f32 %751, 2
  %766 = extractvalue %dx.types.ResRet.f32 %751, 1
  %767 = extractvalue %dx.types.ResRet.f32 %751, 0
  %768 = extractvalue %dx.types.ResRet.f32 %750, 2
  %769 = extractvalue %dx.types.ResRet.f32 %750, 1
  %770 = extractvalue %dx.types.ResRet.f32 %750, 0
  %771 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %9, %dx.types.Handle %13, float %329, float %330, float %694, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %772 = extractvalue %dx.types.ResRet.f32 %771, 0
  %773 = extractvalue %dx.types.ResRet.f32 %771, 1
  %774 = extractvalue %dx.types.ResRet.f32 %771, 2
  %775 = extractvalue %dx.types.ResRet.f32 %771, 3
  %776 = call float @dx.op.binary.f32(i32 35, float %772, float 0x3EB0C6F7A0000000)  ; FMax(a,b)
  %777 = call float @dx.op.binary.f32(i32 35, float %773, float 0x3EB0C6F7A0000000)  ; FMax(a,b)
  %778 = call float @dx.op.binary.f32(i32 35, float %774, float 0x3EB0C6F7A0000000)  ; FMax(a,b)
  %779 = call float @dx.op.binary.f32(i32 35, float %775, float 0x3EB0C6F7A0000000)  ; FMax(a,b)
  %780 = fmul fast float %779, %776
  %781 = fmul fast float %779, %777
  %782 = fmul fast float %779, %778
  %783 = fdiv fast float %780, %776
  %784 = fdiv fast float %781, %776
  %785 = fdiv fast float %782, %776
  %786 = fmul fast float %783, %259
  %787 = fmul fast float %784, %259
  %788 = fmul fast float %785, %259
  %789 = fdiv fast float %786, %253
  %790 = fdiv fast float %787, %253
  %791 = fdiv fast float %788, %253
  %792 = fmul fast float %789, %253
  %793 = fmul fast float %790, %253
  %794 = fmul fast float %791, %253
  %795 = fdiv fast float %792, %259
  %796 = fdiv fast float %793, %260
  %797 = fdiv fast float %794, %261
  %798 = fmul fast float %692, %255
  %799 = fmul fast float %776, %798
  %800 = fmul fast float %692, %256
  %801 = fmul fast float %777, %800
  %802 = fmul fast float %692, %257
  %803 = fmul fast float %778, %802
  %804 = fmul fast float %690, 0x3FF0CCCCC0000000
  %805 = fmul fast float %804, %250
  %806 = fmul fast float %805, %795
  %807 = fmul fast float %804, %251
  %808 = fmul fast float %807, %796
  %809 = fmul fast float %804, %252
  %810 = fmul fast float %809, %797
  %811 = fadd fast float %799, %739
  %812 = fadd fast float %811, %806
  %813 = fadd fast float %801, %740
  %814 = fadd fast float %813, %808
  %815 = fadd fast float %803, %741
  %816 = fadd fast float %815, %810
  %817 = fmul fast float %770, %798
  %818 = fmul fast float %769, %800
  %819 = fmul fast float %768, %802
  %820 = fmul fast float %690, %250
  %821 = fmul fast float %820, %767
  %822 = fmul fast float %690, %251
  %823 = fmul fast float %822, %766
  %824 = fmul fast float %690, %252
  %825 = fmul fast float %824, %765
  %826 = fadd fast float %817, %761
  %827 = fadd fast float %826, %821
  %828 = fadd fast float %818, %762
  %829 = fadd fast float %828, %823
  %830 = fadd fast float %819, %763
  %831 = fadd fast float %830, %825
  br label %832

; <label>:832                                     ; preds = %764, %647
  %833 = phi float [ %812, %764 ], [ %739, %647 ]
  %834 = phi float [ %814, %764 ], [ %740, %647 ]
  %835 = phi float [ %816, %764 ], [ %741, %647 ]
  %836 = phi float [ %827, %764 ], [ %761, %647 ]
  %837 = phi float [ %829, %764 ], [ %762, %647 ]
  %838 = phi float [ %831, %764 ], [ %763, %647 ]
  %839 = fmul fast float %456, %221
  %840 = fadd fast float %839, %220
  %841 = call float @dx.op.unary.f32(i32 7, float %840)  ; Saturate(value)
  %842 = fmul fast float %841, %841
  %843 = fmul fast float %842, %841
  %844 = call float @dx.op.dot4.f32(i32 56, float %843, float %842, float %841, float 1.000000e+00, float %215, float %216, float %217, float %218)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %845 = call float @dx.op.unary.f32(i32 7, float %844)  ; Saturate(value)
  %846 = call float @dx.op.unary.f32(i32 6, float %465)  ; FAbs(value)
  %847 = fcmp fast olt float %846, 0x3F847AE140000000
  %848 = select i1 %847, float 0x3F847AE140000000, float %465
  %849 = fmul fast float %848, %210
  %850 = fadd fast float %849, %211
  %851 = call float @dx.op.unary.f32(i32 21, float %850)  ; Exp(value)
  %852 = fadd fast float %851, 1.000000e+00
  %853 = fdiv fast float %212, %852
  %854 = fsub fast float %853, %213
  %855 = fdiv fast float %854, %848
  %856 = fmul fast float %855, %468
  %857 = call float @dx.op.unary.f32(i32 6, float %856)  ; FAbs(value)
  %858 = fsub fast float -0.000000e+00, %857
  %859 = call float @dx.op.unary.f32(i32 21, float %858)  ; Exp(value)
  %860 = call float @dx.op.binary.f32(i32 35, float %859, float %237)  ; FMax(a,b)
  %861 = fsub fast float 1.000000e+00, %860
  %862 = fmul fast float %861, %845
  %863 = fsub fast float 1.000000e+00, %862
  %864 = fmul fast float %862, %466
  %865 = fmul fast float %836, %233
  %866 = fmul fast float %837, %234
  %867 = fmul fast float %838, %235
  %868 = fsub fast float %229, %833
  %869 = fadd fast float %868, %865
  %870 = fsub fast float %230, %834
  %871 = fadd fast float %870, %866
  %872 = fsub fast float %231, %835
  %873 = fadd fast float %872, %867
  %874 = fmul fast float %864, %869
  %875 = fmul fast float %864, %871
  %876 = fmul fast float %864, %873
  %877 = fadd fast float %874, %833
  %878 = fadd fast float %875, %834
  %879 = fadd fast float %876, %835
  %880 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %4, %dx.types.Handle %13, float %329, float %330, float %694, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %881 = extractvalue %dx.types.ResRet.f32 %880, 0
  %882 = extractvalue %dx.types.ResRet.f32 %880, 1
  %883 = extractvalue %dx.types.ResRet.f32 %880, 2
  %884 = fadd fast float %877, %881
  %885 = fadd fast float %878, %882
  %886 = fadd fast float %879, %883
  %887 = fadd fast float %723, %724
  %888 = fadd fast float %887, %725
  %889 = fmul fast float %888, 0x3FD5555560000000
  %890 = fmul fast float %889, %863
  %891 = fsub fast float 1.000000e+00, %890
  br label %892

; <label>:892                                     ; preds = %832, %469
  %893 = phi float [ %643, %469 ], [ %884, %832 ]
  %894 = phi float [ %644, %469 ], [ %885, %832 ]
  %895 = phi float [ %645, %469 ], [ %886, %832 ]
  %896 = phi float [ %646, %469 ], [ %891, %832 ]
  %897 = fmul fast float %893, %463
  %898 = fmul fast float %894, %463
  %899 = fmul fast float %895, %463
  %900 = fadd fast float %897, %460
  %901 = fadd fast float %898, %461
  %902 = fadd fast float %899, %462
  %903 = fsub fast float 1.000000e+00, %896
  %904 = fmul fast float %903, %463
  %905 = fsub fast float 1.000000e+00, %904
  %906 = fmul fast float %68, %169
  %907 = call float @dx.op.tertiary.f32(i32 46, float %170, float %69, float %906)  ; FMad(a,b,c)
  %908 = call float @dx.op.tertiary.f32(i32 46, float %171, float %70, float %907)  ; FMad(a,b,c)
  %909 = fmul fast float %74, %169
  %910 = call float @dx.op.tertiary.f32(i32 46, float %170, float %75, float %909)  ; FMad(a,b,c)
  %911 = call float @dx.op.tertiary.f32(i32 46, float %171, float %76, float %910)  ; FMad(a,b,c)
  %912 = fmul fast float %80, %169
  %913 = call float @dx.op.tertiary.f32(i32 46, float %170, float %81, float %912)  ; FMad(a,b,c)
  %914 = call float @dx.op.tertiary.f32(i32 46, float %171, float %82, float %913)  ; FMad(a,b,c)
  %915 = call float @dx.op.dot3.f32(i32 55, float %908, float %911, float %914, float %908, float %911, float %914)  ; Dot3(ax,ay,az,bx,by,bz)
  %916 = call float @dx.op.unary.f32(i32 25, float %915)  ; Rsqrt(value)
  %917 = fmul fast float %916, %908
  %918 = fmul fast float %916, %911
  %919 = fmul fast float %916, %914
  %920 = fmul fast float %166, %68
  %921 = call float @dx.op.tertiary.f32(i32 46, float %167, float %69, float %920)  ; FMad(a,b,c)
  %922 = call float @dx.op.tertiary.f32(i32 46, float %168, float %70, float %921)  ; FMad(a,b,c)
  %923 = fmul fast float %166, %74
  %924 = call float @dx.op.tertiary.f32(i32 46, float %167, float %75, float %923)  ; FMad(a,b,c)
  %925 = call float @dx.op.tertiary.f32(i32 46, float %168, float %76, float %924)  ; FMad(a,b,c)
  %926 = fmul fast float %166, %80
  %927 = call float @dx.op.tertiary.f32(i32 46, float %167, float %81, float %926)  ; FMad(a,b,c)
  %928 = call float @dx.op.tertiary.f32(i32 46, float %168, float %82, float %927)  ; FMad(a,b,c)
  %929 = call float @dx.op.dot3.f32(i32 55, float %922, float %925, float %928, float %922, float %925, float %928)  ; Dot3(ax,ay,az,bx,by,bz)
  %930 = call float @dx.op.unary.f32(i32 25, float %929)  ; Rsqrt(value)
  %931 = fmul fast float %930, %922
  %932 = fmul fast float %930, %925
  %933 = fmul fast float %930, %928
  %934 = fmul fast float %120, %68
  %935 = call float @dx.op.tertiary.f32(i32 46, float %119, float %69, float %934)  ; FMad(a,b,c)
  %936 = call float @dx.op.tertiary.f32(i32 46, float %118, float %70, float %935)  ; FMad(a,b,c)
  %937 = fmul fast float %120, %74
  %938 = call float @dx.op.tertiary.f32(i32 46, float %119, float %75, float %937)  ; FMad(a,b,c)
  %939 = call float @dx.op.tertiary.f32(i32 46, float %118, float %76, float %938)  ; FMad(a,b,c)
  %940 = fmul fast float %120, %80
  %941 = call float @dx.op.tertiary.f32(i32 46, float %119, float %81, float %940)  ; FMad(a,b,c)
  %942 = call float @dx.op.tertiary.f32(i32 46, float %118, float %82, float %941)  ; FMad(a,b,c)
  %943 = call float @dx.op.dot3.f32(i32 55, float %936, float %939, float %942, float %936, float %939, float %942)  ; Dot3(ax,ay,az,bx,by,bz)
  %944 = call float @dx.op.unary.f32(i32 25, float %943)  ; Rsqrt(value)
  %945 = fmul fast float %944, %936
  %946 = fmul fast float %944, %939
  %947 = fmul fast float %944, %942
  %948 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 482)  ; CBufferLoadLegacy(handle,regIndex)
  %949 = extractvalue %dx.types.CBufRet.f32 %948, 3
  %950 = extractvalue %dx.types.CBufRet.f32 %948, 2
  %951 = extractvalue %dx.types.CBufRet.f32 %182, 2
  %952 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %15, i32 211)  ; CBufferLoadLegacy(handle,regIndex)
  %953 = extractvalue %dx.types.CBufRet.f32 %952, 0
  %954 = extractvalue %dx.types.CBufRet.f32 %952, 1
  %955 = extractvalue %dx.types.CBufRet.f32 %952, 2
  %956 = extractvalue %dx.types.CBufRet.f32 %952, 3
  %957 = fsub fast float %324, %949
  %958 = fmul fast float %957, %950
  %959 = call float @dx.op.binary.f32(i32 35, float %958, float 0.000000e+00)  ; FMax(a,b)
  %960 = call float @dx.op.binary.f32(i32 36, float %959, float %951)  ; FMin(a,b)
  %961 = fmul fast float %960, %960
  %962 = fmul fast float %961, %960
  %963 = call float @dx.op.dot4.f32(i32 56, float %962, float %961, float %960, float 1.000000e+00, float %953, float %954, float %955, float %956)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %964 = call float @dx.op.unary.f32(i32 7, float %963)  ; Saturate(value)
  %965 = fsub fast float 1.000000e+00, %964
  %966 = call float @dx.op.tertiary.f32(i32 46, float 1.000000e+00, float %71, float %297), !dx.precise !34  ; FMad(a,b,c)
  %967 = call float @dx.op.tertiary.f32(i32 46, float 1.000000e+00, float %77, float %301), !dx.precise !34  ; FMad(a,b,c)
  %968 = call float @dx.op.tertiary.f32(i32 46, float 1.000000e+00, float %83, float %305), !dx.precise !34  ; FMad(a,b,c)
  %969 = fadd float %966, 0.000000e+00
  %970 = fadd float %967, 0.000000e+00
  %971 = fadd float %968, 0.000000e+00
  %972 = fsub float %969, %46
  %973 = fsub float %970, %47
  %974 = fsub float %971, %48
  %975 = fmul float %26, %972
  %976 = call float @dx.op.tertiary.f32(i32 46, float %973, float %27, float %975), !dx.precise !34  ; FMad(a,b,c)
  %977 = call float @dx.op.tertiary.f32(i32 46, float %974, float %28, float %976), !dx.precise !34  ; FMad(a,b,c)
  %978 = call float @dx.op.tertiary.f32(i32 46, float 1.000000e+00, float %29, float %977), !dx.precise !34  ; FMad(a,b,c)
  %979 = fmul float %31, %972
  %980 = call float @dx.op.tertiary.f32(i32 46, float %973, float %32, float %979), !dx.precise !34  ; FMad(a,b,c)
  %981 = call float @dx.op.tertiary.f32(i32 46, float %974, float %33, float %980), !dx.precise !34  ; FMad(a,b,c)
  %982 = call float @dx.op.tertiary.f32(i32 46, float 1.000000e+00, float %34, float %981), !dx.precise !34  ; FMad(a,b,c)
  %983 = fmul float %36, %972
  %984 = call float @dx.op.tertiary.f32(i32 46, float %973, float %37, float %983), !dx.precise !34  ; FMad(a,b,c)
  %985 = call float @dx.op.tertiary.f32(i32 46, float %974, float %38, float %984), !dx.precise !34  ; FMad(a,b,c)
  %986 = call float @dx.op.tertiary.f32(i32 46, float 1.000000e+00, float %39, float %985), !dx.precise !34  ; FMad(a,b,c)
  %987 = fmul float %41, %972
  %988 = call float @dx.op.tertiary.f32(i32 46, float %973, float %42, float %987), !dx.precise !34  ; FMad(a,b,c)
  %989 = call float @dx.op.tertiary.f32(i32 46, float %974, float %43, float %988), !dx.precise !34  ; FMad(a,b,c)
  %990 = call float @dx.op.tertiary.f32(i32 46, float 1.000000e+00, float %44, float %989), !dx.precise !34  ; FMad(a,b,c)
  %glassMarkerInput = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %profileInteger = call float @dx.op.unary.f32(i32 27, float %glassMarkerInput)
  %profileNegative = fsub float 0.000000e+00, %profileInteger
  %dirtTransport = fsub float 0.000000e+00, %glassMarkerInput
  %profile42 = fcmp oeq float %profileNegative, 0xC045000000000000
  %profile43 = fcmp oeq float %profileNegative, 0xC045800000000000
  %profile44 = fcmp oeq float %profileNegative, 0xC046000000000000
  %profile45 = fcmp oeq float %profileNegative, 0xC046800000000000
  %profile46 = fcmp oeq float %profileNegative, 0xC047000000000000
  %profileAny43 = or i1 %profile42, %profile43
  %profileAny44 = or i1 %profileAny43, %profile44
  %profileAny45 = or i1 %profileAny44, %profile45
  %glassMarked = or i1 %profileAny45, %profile46
  %glassCarrier = select i1 %glassMarked, float %dirtTransport, float %965
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %900)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %901)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %902)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %905)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %298)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 1, float %302)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 2, float %306)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 2, i32 0, i8 0, float %945)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 2, i32 0, i8 1, float %946)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 2, i32 0, i8 2, float %947)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 2, i32 0, i8 3, float %glassCarrier)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 3, i32 0, i8 0, float %917)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 3, i32 0, i8 1, float %918)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 3, i32 0, i8 2, float %919)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 4, i32 0, i8 0, float %931)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 4, i32 0, i8 1, float %932)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 4, i32 0, i8 2, float %933)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 5, i32 0, i8 0, float %978)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 5, i32 0, i8 1, float %982)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 5, i32 0, i8 2, float %986)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 5, i32 0, i8 3, float %990)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.loadInput.i32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot2.f32(i32, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32, %dx.types.Handle, %dx.types.Handle, float, float, float, float, i32, i32, i32, float) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32, %dx.types.Handle, i32, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32, %dx.types.Handle, i32, i32) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.entryPoints = !{!27}

!0 = !{!"dxcoob 1.8.2505.0"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"vs", i32 6, i32 0}
!4 = !{!5, null, !21, !24}
!5 = !{!6, !8, !10, !11, !12, !13, !14, !15, !16, !17, !18, !19}
!6 = !{i32 0, %"class.StructuredBuffer<vector<float, 4> >"* undef, !"", i32 0, i32 90, i32 1, i32 12, i32 0, !7}
!7 = !{i32 1, i32 16}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 129, i32 1, i32 2, i32 0, !9}
!9 = !{i32 0, i32 9}
!10 = !{i32 2, %"class.Texture3D<vector<float, 4> >"* undef, !"", i32 0, i32 130, i32 1, i32 4, i32 0, !9}
!11 = !{i32 3, %"class.Texture3D<vector<float, 4> >"* undef, !"", i32 0, i32 131, i32 1, i32 4, i32 0, !9}
!12 = !{i32 4, %"class.Texture3D<vector<float, 4> >"* undef, !"", i32 0, i32 132, i32 1, i32 4, i32 0, !9}
!13 = !{i32 5, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 133, i32 1, i32 2, i32 0, !9}
!14 = !{i32 6, %"class.Texture3D<vector<float, 3> >"* undef, !"", i32 0, i32 134, i32 1, i32 4, i32 0, !9}
!15 = !{i32 7, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 135, i32 1, i32 2, i32 0, !9}
!16 = !{i32 8, %"class.Texture3D<vector<float, 4> >"* undef, !"", i32 0, i32 136, i32 1, i32 4, i32 0, !9}
!17 = !{i32 9, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 137, i32 1, i32 2, i32 0, !9}
!18 = !{i32 10, %"class.Texture3D<float>"* undef, !"", i32 0, i32 138, i32 1, i32 4, i32 0, !9}
!19 = !{i32 11, %"class.StructuredBuffer<PerInstanceData>"* undef, !"", i32 0, i32 0, i32 1, i32 12, i32 0, !20}
!20 = !{i32 1, i32 4}
!21 = !{!22, !23}
!22 = !{i32 0, %PerDispatchConstants* undef, !"", i32 0, i32 0, i32 1, i32 4, null}
!23 = !{i32 1, %hostlayout.PerPassConstants* undef, !"", i32 0, i32 4, i32 1, i32 7804, null}
!24 = !{!25, !26}
!25 = !{i32 0, %struct.SamplerState* undef, !"", i32 0, i32 3, i32 1, i32 0, null}
!26 = !{i32 1, %struct.SamplerState* undef, !"", i32 0, i32 8, i32 1, i32 0, null}
!27 = !{void ()* @ShaderDomain_Vs, !"ShaderDomain_Vs", !28, !4, !48}
!28 = !{!29, !37, null}
!29 = !{!30, !33, !35}
!30 = !{i32 0, !"POSITION", i8 9, i8 0, !31, i8 0, i32 1, i8 4, i32 0, i8 0, !32}
!31 = !{i32 0}
!32 = !{i32 3, i32 15}
!33 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !34, i8 0, i32 1, i8 4, i32 1, i8 0, !32}
!34 = !{i32 1}
!35 = !{i32 2, !"SV_InstanceID", i8 5, i8 2, !31, i8 0, i32 1, i8 1, i32 2, i8 0, !36}
!36 = !{i32 3, i32 1}
!37 = !{!38, !39, !41, !43, !45, !47}
!38 = !{i32 0, !"TEXCOORD", i8 9, i8 0, !31, i8 2, i32 1, i8 4, i32 0, i8 0, !32}
!39 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !34, i8 2, i32 1, i8 3, i32 1, i8 0, !40}
!40 = !{i32 3, i32 7}
!41 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !42, i8 2, i32 1, i8 4, i32 2, i8 0, !32}
!42 = !{i32 2}
!43 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !44, i8 2, i32 1, i8 3, i32 3, i8 0, !40}
!44 = !{i32 3}
!45 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !46, i8 2, i32 1, i8 3, i32 4, i8 0, !40}
!46 = !{i32 4}
!47 = !{i32 5, !"SV_Position", i8 9, i8 3, !31, i8 4, i32 1, i8 4, i32 5, i8 0, !32}
!48 = !{i32 0, i64 16}
!49 = distinct !{!49, !"dx.controlflow.hints", i32 1}
!50 = distinct !{!50, !"dx.controlflow.hints", i32 1}

