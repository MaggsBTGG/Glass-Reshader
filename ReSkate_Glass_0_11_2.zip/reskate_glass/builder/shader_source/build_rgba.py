"""Build RGBA overlay shaders using a locally compiled DXC assembler.
Usage: python build_rgba.py /absolute/path/to/assemble
No new shader inputs, outputs, resources or interpolators are introduced.
"""
from pathlib import Path
import subprocess,sys,shutil
root=Path(__file__).resolve().parents[1];source=root/'shader_source';out=root/'shaders/RGBADirt';out.mkdir(exist_ok=True)
shutil.copyfile(root/'shaders/PixelDirt/vs.dxil',out/'vs.dxil')
for i in [6,7,8,9]:
 s=(source/f'pixel_ps_{i}.ll').read_text()
 old='  %pixelMask = extractvalue %dx.types.ResRet.f32 %pixelSample, 0'
 assert s.count(old)==1
 s=s.replace(old, '\n'.join([f'  %rgba{channel} = extractvalue %dx.types.ResRet.f32 %pixelSample, {index}' for index,channel in enumerate(['R','G','B'])])+'\n  %pixelMask = extractvalue %dx.types.ResRet.f32 %pixelSample, 3')
 old='  %dirtOpacityGap = fsub float 0x3FEE666660000000, %glass_r5_glass_alpha';assert old in s
 s=s.replace(old,'  %dirtOpacityGap = fsub float 1.000000e+00, %glass_r5_glass_alpha')
 s=s.replace('%glass_r5_reflection_scale = fdiv float %glass_r5_alpha,','%glass_r5_reflection_scale = fdiv float %glass_r5_glass_alpha,')
 s=s.replace('%dirtRoughGap = fsub float 0x3FE6666660000000, %setting_roughness','%dirtRoughGap = fsub float %setting_roughness, %setting_roughness')
 for channel in 'rgb':
  old=f'%dirtReflectionLoss{channel} = fmul float %dirtAmount, 0x3FE6666660000000';assert old in s
  s=s.replace(old,f'%dirtReflectionLoss{channel} = fmul float %dirtAmount, 1.000000e+00')
  old=f'%dirtGrey{channel} = fmul float %dirtAmount, 0x3FB47AE140000000';assert old in s
  s=s.replace(old,f'%dirtGrey{channel} = fmul float %rgba{channel.upper()}, %dirtStrength')
 # Metadata follows the proven shader contract verbatim.
 original=(source/f'pixel_ps_{i}.ll').read_text()
 assert s[s.index('!llvm.ident'):]==original[original.index('!llvm.ident'):]
 path=source/f'rgba_ps_{i}.ll';path.write_text(s)
 subprocess.run([sys.argv[1],str(path),str(out/f'ps_{i}.dxil')],check=True)
print('PASS: four RGBA shaders assembled; original vertex shader and binding/signature metadata retained')
