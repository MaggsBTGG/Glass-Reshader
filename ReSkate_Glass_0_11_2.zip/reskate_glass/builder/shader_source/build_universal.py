from pathlib import Path
import re,subprocess,struct,json
base=Path('glass_builder03/reskate_glass/builder');out=base/'shaders/Universal';out.mkdir(exist_ok=True)
markers={'Balanced':42,'LowReflection':43,'HighReflection':44,'ExtraClear':45,'Rough':46};profiles=json.loads((base/'profiles.json').read_text())
def fl(v):return '0x'+struct.pack('>d',struct.unpack('<f',struct.pack('<f',v))[0]).hex().upper()
def marker_code(inputvar,final):
 lines=[f'  %profile{value} = fcmp oeq float {inputvar}, {fl(-value)}' for value in markers.values()]
 current='%profile42'
 for v in [43,44,45,46]:
  name=f'%profileAny{v}' if v!=46 else final
  lines.append(f'  {name} = or i1 {current}, %profile{v}');current=name
 return '\n'.join(lines)
s=Path('builder03_tools/vs.ll').read_text()
s=s.replace('  %glassMarked = fcmp oeq float %glassMarkerInput, 4.200000e+01', '  %profileNegative = fsub float 0.000000e+00, %glassMarkerInput\n'+marker_code('%profileNegative','%glassMarked'))
s=s.replace('select i1 %glassMarked, float -4.200000e+01, float %965','select i1 %glassMarked, float %profileNegative, float %965')
s=re.sub(r'^!dx.viewIdState.*\n','',s,flags=re.M)
Path('builder03_tools/universal_vs.ll').write_text(s);subprocess.run(['builder03_tools/assemble','builder03_tools/universal_vs.ll',str(base/'shaders/vs.dxil')],check=True)
for i in [6,7,8,9]:
 s=Path(f'builder03_tools/ps_{i}.ll').read_text();m=re.search(r'^  %r8Marked = fcmp oeq float (%\d+), .+$',s,re.M);carrier=m.group(1)
 lines=marker_code(carrier,'%r8Marked')
 for name in ['reflection_strength','roughness','face_opacity','edge_opacity']:
  current=fl(profiles['Balanced'][name])
  for mode in ['LowReflection','HighReflection','ExtraClear','Rough']:
   v=markers[mode];var=f'%setting_{name}_{v}';lines+=f'\n  {var} = select i1 %profile{v}, float {fl(profiles[mode][name])}, float {current}';current=var
  lines+=f'\n  %setting_{name} = fadd float {current}, 0.000000e+00'
 lines+='\n  %setting_smoothness = fsub float 1.000000e+00, %setting_roughness\n  %setting_opacity_range = fsub float %setting_edge_opacity, %setting_face_opacity'
 s=s[:m.start()]+lines+s[m.end():]
 n=4530 if i in [6,8] else 2876
 s=re.sub(rf'^  %r8Glass{n} = .+$',f'  %r8Glass{n} = fadd float %setting_smoothness, 0.000000e+00',s,flags=re.M)
 s=re.sub(r'^  %glass_r5_target_grazing = .+$','  %glass_r5_target_grazing = fmul float %glass_r5_grazing5, %setting_opacity_range',s,flags=re.M)
 s=re.sub(r'^  %glass_r5_glass_alpha = .+$','  %glass_r5_glass_alpha = fadd float %glass_r5_target_grazing, %setting_face_opacity',s,flags=re.M)
 for channel in 'rgb':s=re.sub(rf'^  %r9Scaled_{channel} = .+$',f'  %r9Scaled_{channel} = fmul float %glass_r5_exposed_{channel}, %setting_reflection_strength',s,flags=re.M)
 s=re.sub(r'^!dx.viewIdState.*\n','',s,flags=re.M)
 path=Path(f'builder03_tools/universal_ps_{i}.ll');path.write_text(s);subprocess.run(['builder03_tools/assemble',str(path),str(out/f'ps_{i}.dxil')],check=True)
 # Preserve the entire pre-existing numerical instruction graph.
 before=dict(re.findall(r'^  (%\d+) = (.+)$',Path(f'builder03_tools/ps_{i}.ll').read_text(),re.M));after=dict(re.findall(r'^  (%\d+) = (.+)$',s,re.M));assert before==after
print('All five universal shaders validated; original numerical instructions retained')
(base/'profile-markers.json').write_text(json.dumps(markers,indent=2))
