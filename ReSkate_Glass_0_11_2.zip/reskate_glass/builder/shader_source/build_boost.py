"""Build 0..8 opacity gain variants; inputs/resources remain unchanged."""
from pathlib import Path
import subprocess,sys,shutil
root=Path(__file__).resolve().parents[1];source=root/'shader_source'
for mode,folder,prefix in [('mask','PixelDirtBoost','pixel'),('rgba','RGBADirtBoost','rgba')]:
 out=root/'shaders'/folder;out.mkdir(exist_ok=True);shutil.copyfile(root/'shaders/PixelDirt/vs.dxil',out/'vs.dxil')
 for i in [6,7,8,9]:
  original=(source/f'{prefix}_ps_{i}.ll').read_text();s=original
  needle='  %pixelDirt = fmul float %dirtStrength, %pixelMask';assert needle in s
  s=s.replace(needle,'''  %pixelBoostStrength = fmul float %dirtStrength, 8.000000e+00
  %pixelBoostRaw = fmul float %pixelBoostStrength, %pixelMask
  %pixelDirt = call float @dx.op.unary.f32(i32 7, float %pixelBoostRaw)''')
  if mode=='rgba':
   needle='  %dirtAmount = select i1 %pixelMode, float %pixelDirt, float %dirtStrength'
   s=s.replace(needle,needle+'''
  %rgbaSafeAlpha = call float @dx.op.binary.f32(i32 35, float %pixelMask, float 0x3EB0C6F7A0000000)
  %rgbaBoostScale = fdiv float %pixelDirt, %rgbaSafeAlpha''')
   for c in 'rgb':s=s.replace(f'%dirtGrey{c} = fmul float %rgba{c.upper()}, %dirtStrength',f'%dirtGrey{c} = fmul float %rgba{c.upper()}, %rgbaBoostScale')
  assert s[s.index('!llvm.ident'):]==original[original.index('!llvm.ident'):]
  path=source/f'boost_{mode}_ps_{i}.ll';path.write_text(s)
  subprocess.run([sys.argv[1],str(path),str(out/f'ps_{i}.dxil')],check=True)
print('PASS: eight gain shaders assembled and validated; metadata unchanged')
