Development sources for the universal shaders. build_universal.py reflects the development workspace layout; adjust paths to rebuild. assemble.cpp uses Microsoft DXC IDxcAssembler and IDxcValidator. Generated .ll and validated .dxil are both included for review. Runtime builders use the packaged validated .dxil and do not compile shaders on the creator computer.

RGBA overlay sources: build_rgba.py takes the path to a compiled assemble helper. It derives rgba_ps_6..9.ll from the compatible pixel shaders, retaining signatures and metadata; RGBADirt/vs.dxil is the unchanged compatible vertex shader. Texture RGB is premultiplied linear color and A is coverage.

Gain variants: build_boost.py derives PixelDirtBoost and RGBADirtBoost from compatible sources and takes an assembler path. Geometry strength is normalized by eight when the gain variants are selected. Coverage is clamped; premultiplied RGBA color is rescaled by clamped alpha.
