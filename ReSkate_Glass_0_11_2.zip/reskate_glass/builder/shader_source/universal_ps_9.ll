;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; TEXCOORD                 0   xyzw        0     NONE   float   xyzw
; TEXCOORD                 1   xyz         1     NONE   float   xyz 
; TEXCOORD                 2   xyzw        2     NONE   float   xyzw
; TEXCOORD                 3   xyz         3     NONE   float   xyz 
; TEXCOORD                 4   xyz         4     NONE   float   xyz 
; SV_Position              0   xyzw        5      POS   float   xyzw
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 0a694ed72a8e8655fbcc2a51584e8843
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 6
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 6
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: ShaderDomain_Ps
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; TEXCOORD                 0                 linear       
; TEXCOORD                 1                 linear       
; TEXCOORD                 2                 linear       
; TEXCOORD                 3                 linear       
; TEXCOORD                 4                 linear       
; SV_Position              0          noperspective       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
; cbuffer 
; {
;
;   [212 x i8] (type annotation not present)
;
; }
;
; cbuffer 
; {
;
;   [76 x i8] (type annotation not present)
;
; }
;
; cbuffer 
; {
;
;   [7804 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [16 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [4 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [16 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [4 x i8] (type annotation not present)
;
; }
;
; Resource bind info for 
; {
;
;   [32 x i8] (type annotation not present)
; }
;
; Resource bind info for 
; {
;
;   [144 x i8] (type annotation not present)
; }
;
; Resource bind info for 
; {
;
;   [112 x i8] (type annotation not present)
; }
;
; Resource bind info for 
; {
;
;   [16 x i8] (type annotation not present)
; }
;
; Resource bind info for 
; {
;
;   [16 x i8] (type annotation not present)
; }
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
;                                   cbuffer      NA          NA     CB0            cb2     1
;                                   cbuffer      NA          NA     CB1            cb3     1
;                                   cbuffer      NA          NA     CB2            cb4     1
;                                   sampler      NA          NA      S0             s0     1
;                                   sampler      NA          NA      S1             s1     1
;                                   sampler      NA          NA      S2             s2     1
;                                   sampler      NA          NA      S3             s4     1
;                                   sampler      NA          NA      S4             s5     1
;                                   sampler      NA          NA      S5             s7     1
;                                   sampler      NA          NA      S6             s8     1
;                                   sampler      NA          NA      S7             s9     1
;                                   texture     f32          2d      T0            t65     1
;                                   texture    byte         r/o      T1            t66     1
;                                   texture     f32     2darray      T2            t67     1
;                                   texture  struct         r/o      T3            t69     1
;                                   texture     f32   cubearray      T4            t70     1
;                                   texture     f32          2d      T5            t71     1
;                                   texture  struct         r/o      T6            t73     1
;                                   texture  struct         r/o      T7            t74     1
;                                   texture     f32     2darray      T8            t76     1
;                                   texture     f32   cubearray      T9            t78     1
;                                   texture     f32   cubearray     T10            t80     1
;                                   texture     f32          2d     T11            t81     1
;                                   texture     f32          2d     T12            t82     1
;                                   texture     f32     2darray     T13            t84     1
;                                   texture  struct         r/o     T14            t85     1
;                                   texture     u32          3d     T15            t91     1
;                                   texture     f32          3d     T16            t95     1
;                                   texture     u32         buf     T17            t98     1
;                                   texture     u32         buf     T18           t100     1
;                                   texture     u32          3d     T19           t105     1
;                                   texture     f32          3d     T20           t106     1
;                                   texture     f32          2d     T21           t107     1
;                                   texture  struct         r/o     T22           t108     1
;                                   texture     f32          2d     T23           t109     1
;                                   texture     f32          2d     T24           t114     1
;                                   texture  struct         r/o     T25           t116     1
;                                   texture  struct         r/o     T26           t117     1
;                                   texture     f32          2d     T27           t121     1
;                                   texture  struct         r/o     T28           t123     1
;                                   texture  struct         r/o     T29           t128     1
;                                   texture     f32          2d     T30            t32     1
;                                   texture     f32          2d     T31            t33     1
;                                   texture     f32          2d     T32            t34     1
;                                   texture     f32          2d     T33            t35     1
;                                   texture     f32          2d     T34            t36     1
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.CBufRet.f32 = type { float, float, float, float }
%dx.types.CBufRet.i32 = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%dx.types.ResRet.i32 = type { i32, i32, i32, i32, i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }
%struct.ByteAddressBuffer = type { i32 }
%"class.Texture2DArray<float>" = type { float, %"class.Texture2DArray<float>::mips_type" }
%"class.Texture2DArray<float>::mips_type" = type { i32 }
%"class.StructuredBuffer<vector<float, 4> >" = type { <4 x float> }
%"class.TextureCubeArray<vector<float, 4> >" = type { <4 x float> }
%"class.StructuredBuffer<unsigned int>" = type { i32 }
%"class.TextureCubeArray<float>" = type { float }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2DArray<vector<float, 4> >" = type { <4 x float>, %"class.Texture2DArray<vector<float, 4> >::mips_type" }
%"class.Texture2DArray<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture3D<vector<unsigned int, 2> >" = type { <2 x i32>, %"class.Texture3D<vector<unsigned int, 2> >::mips_type" }
%"class.Texture3D<vector<unsigned int, 2> >::mips_type" = type { i32 }
%"class.Texture3D<vector<float, 4> >" = type { <4 x float>, %"class.Texture3D<vector<float, 4> >::mips_type" }
%"class.Texture3D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Buffer<unsigned int>" = type { i32 }
%"class.Texture3D<unsigned int>" = type { i32, %"class.Texture3D<unsigned int>::mips_type" }
%"class.Texture3D<unsigned int>::mips_type" = type { i32 }
%"class.StructuredBuffer<GiGridCellDesc>" = type { %struct.GiGridCellDesc }
%struct.GiGridCellDesc = type { <4 x float>, i32, i32, i32, i32 }
%"class.StructuredBuffer<ProbeContainer>" = type { %struct.ProbeContainer }
%struct.ProbeContainer = type { [9 x <4 x float>] }
%"hostlayout.class.StructuredBuffer<DenseProbeVolume>" = type { %hostlayout.struct.DenseProbeVolume }
%hostlayout.struct.DenseProbeVolume = type { [3 x <4 x float>], <3 x i32>, i32, <3 x i32>, i32, <3 x float>, float, <3 x float>, float }
%"class.StructuredBuffer<GiGridCellTreeOffsets>" = type { %struct.GiGridCellTreeOffsets }
%struct.GiGridCellTreeOffsets = type { i32, i32, i32, i32 }
%"class.StructuredBuffer<GiGridNode>" = type { %struct.GiGridNode }
%struct.GiGridNode = type { i32, i32, i32, i32 }
%common_shadercomponents_configuration_collections_worldglobal_collection = type { float, float, float, float, <3 x float>, <3 x float>, <3 x float>, float, float, float, float, float, float, i32, float, float, float, float, float, float, float, float, float, i32, float, float, float, float, float, float, <4 x float>, float, float, float, i32, float, float, i32, i32, float }
%common_shadercomponents_configuration_collections_worldseasonalevent_collection = type { <3 x float>, <3 x float>, <3 x float>, <3 x float>, <3 x float> }
%hostlayout.PerPassConstants = type { [3 x <4 x float>], <4 x float>, <4 x float>, [4 x [4 x <4 x float>]], <4 x float>, [3 x <4 x i32>], [4 x <4 x float>], [5 x <4 x i32>], <4 x float>, [120 x <4 x float>], [4 x <4 x i32>], <4 x float>, [8 x <4 x float>], [8 x <4 x float>], <4 x float>, %struct.TerrainHeightFieldParameters, [5 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], %struct.TerrainColorParameters, [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [4 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [120 x <4 x float>], [4 x <4 x float>], [8 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], %struct.TerrainVirtualTexureParameters, [7 x <4 x float>], [4 x <4 x float>], <4 x float>, [4 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], [8 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], [3 x <4 x float>], [5 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [4 x <4 x float>], <4 x float>, <4 x float>, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, float, <3 x float>, float, <3 x float>, float, <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, float, i32, i32, float, float, float, i32, float, i32, float, float, float, float, i32, float, i32, i32, i32, i32, i32, float, float, i32, i32, i32, float, i32, i32, i32, float, float, float, float, float, float, float, i32, float, float, i32, i32 }
%struct.TerrainHeightFieldParameters = type { <4 x float>, <4 x float>, <4 x float>, <2 x i32>, float, float }
%struct.TerrainColorParameters = type { <4 x float>, <3 x float>, float }
%struct.TerrainVirtualTexureParameters = type { <4 x float>, <2 x i32>, i32, i32, <4 x float>, i32, <3 x float> }
%struct.SamplerState = type { i32 }
%struct.SamplerComparisonState = type { i32 }

define void @ShaderDomain_Ps() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 34, i32 36, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 33, i32 35, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 32, i32 34, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %4 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 31, i32 33, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %5 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 30, i32 32, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %6 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 29, i32 128, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %7 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 28, i32 123, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %8 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 27, i32 121, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %9 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 26, i32 117, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %10 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 25, i32 116, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %11 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 24, i32 114, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %12 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 23, i32 109, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %13 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 22, i32 108, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %14 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 21, i32 107, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %15 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 20, i32 106, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %16 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 19, i32 105, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %17 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 18, i32 100, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %18 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 17, i32 98, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %19 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 16, i32 95, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %20 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 15, i32 91, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %21 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 14, i32 85, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %22 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 13, i32 84, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %23 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 12, i32 82, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %24 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 11, i32 81, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %25 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 10, i32 80, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %26 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 9, i32 78, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %27 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 8, i32 76, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %28 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 7, i32 74, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %29 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 6, i32 73, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %30 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 5, i32 71, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %31 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 4, i32 70, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %32 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 3, i32 69, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %33 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 2, i32 67, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %34 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 66, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %35 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 65, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %36 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 7, i32 9, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %37 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 6, i32 8, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %38 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 5, i32 7, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %39 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 4, i32 5, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %40 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 3, i32 4, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %41 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 2, i32 2, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %42 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %43 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %44 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 2, i32 4, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %45 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 1, i32 3, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %46 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 0, i32 2, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %47 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %48 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %49 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %50 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %51 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %52 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %53 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %54 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %55 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %56 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %57 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %58 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %59 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %60 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %profile42 = fcmp oeq float %60, 0xC045000000000000
  %profile43 = fcmp oeq float %60, 0xC045800000000000
  %profile44 = fcmp oeq float %60, 0xC046000000000000
  %profile45 = fcmp oeq float %60, 0xC046800000000000
  %profile46 = fcmp oeq float %60, 0xC047000000000000
  %profileAny43 = or i1 %profile42, %profile43
  %profileAny44 = or i1 %profileAny43, %profile44
  %profileAny45 = or i1 %profileAny44, %profile45
  %r8Marked = or i1 %profileAny45, %profile46
  %setting_reflection_strength_43 = select i1 %profile43, float 0x3FD0000000000000, float 0x3FF0000000000000
  %setting_reflection_strength_44 = select i1 %profile44, float 0x4000000000000000, float %setting_reflection_strength_43
  %setting_reflection_strength_45 = select i1 %profile45, float 0x3FF0000000000000, float %setting_reflection_strength_44
  %setting_reflection_strength_46 = select i1 %profile46, float 0x3FF0000000000000, float %setting_reflection_strength_45
  %setting_reflection_strength = fadd float %setting_reflection_strength_46, 0.000000e+00
  %setting_roughness_43 = select i1 %profile43, float 0x3FA99999A0000000, float 0x3FA99999A0000000
  %setting_roughness_44 = select i1 %profile44, float 0x3FA99999A0000000, float %setting_roughness_43
  %setting_roughness_45 = select i1 %profile45, float 0x3FA99999A0000000, float %setting_roughness_44
  %setting_roughness_46 = select i1 %profile46, float 0x3FD99999A0000000, float %setting_roughness_45
  %setting_roughness = fadd float %setting_roughness_46, 0.000000e+00
  %setting_face_opacity_43 = select i1 %profile43, float 0x3FB47AE140000000, float 0x3FB47AE140000000
  %setting_face_opacity_44 = select i1 %profile44, float 0x3FB47AE140000000, float %setting_face_opacity_43
  %setting_face_opacity_45 = select i1 %profile45, float 0x3F947AE140000000, float %setting_face_opacity_44
  %setting_face_opacity_46 = select i1 %profile46, float 0x3FB47AE140000000, float %setting_face_opacity_45
  %setting_face_opacity = fadd float %setting_face_opacity_46, 0.000000e+00
  %setting_edge_opacity_43 = select i1 %profile43, float 0x3FE99999A0000000, float 0x3FE99999A0000000
  %setting_edge_opacity_44 = select i1 %profile44, float 0x3FE99999A0000000, float %setting_edge_opacity_43
  %setting_edge_opacity_45 = select i1 %profile45, float 0x3FD6666660000000, float %setting_edge_opacity_44
  %setting_edge_opacity_46 = select i1 %profile46, float 0x3FE99999A0000000, float %setting_edge_opacity_45
  %setting_edge_opacity = fadd float %setting_edge_opacity_46, 0.000000e+00
  %setting_smoothness = fsub float 1.000000e+00, %setting_roughness
  %setting_opacity_range = fsub float %setting_edge_opacity, %setting_face_opacity
  %61 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %62 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %63 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %64 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %65 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %66 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %67 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %glass_r5_dxx = call float @dx.op.unary.f32(i32 83, float %61)  ; DerivCoarseX(value)
  %glass_r5_dyx = call float @dx.op.unary.f32(i32 84, float %61)  ; DerivCoarseY(value)
  %glass_r5_dxy = call float @dx.op.unary.f32(i32 83, float %62)  ; DerivCoarseX(value)
  %glass_r5_dyy = call float @dx.op.unary.f32(i32 84, float %62)  ; DerivCoarseY(value)
  %glass_r5_dxz = call float @dx.op.unary.f32(i32 83, float %63)  ; DerivCoarseX(value)
  %glass_r5_dyz = call float @dx.op.unary.f32(i32 84, float %63)  ; DerivCoarseY(value)
  %glass_r5_crossxa = fmul float %glass_r5_dxy, %glass_r5_dyz
  %glass_r5_crossxb = fmul float %glass_r5_dxz, %glass_r5_dyy
  %glass_r5_crossx = fsub float %glass_r5_crossxa, %glass_r5_crossxb
  %glass_r5_crossya = fmul float %glass_r5_dxz, %glass_r5_dyx
  %glass_r5_crossyb = fmul float %glass_r5_dxx, %glass_r5_dyz
  %glass_r5_crossy = fsub float %glass_r5_crossya, %glass_r5_crossyb
  %glass_r5_crossza = fmul float %glass_r5_dxx, %glass_r5_dyy
  %glass_r5_crosszb = fmul float %glass_r5_dxy, %glass_r5_dyx
  %glass_r5_crossz = fsub float %glass_r5_crossza, %glass_r5_crosszb
  %glass_r5_length2 = call float @dx.op.dot3.f32(i32 55, float %glass_r5_crossx, float %glass_r5_crossy, float %glass_r5_crossz, float %glass_r5_crossx, float %glass_r5_crossy, float %glass_r5_crossz)  ; Dot3(ax,ay,az,bx,by,bz)
  %glass_r5_safe_length2 = call float @dx.op.binary.f32(i32 35, float %glass_r5_length2, float 0x3BC79CA100000000)  ; FMax(a,b)
  %glass_r5_inv_length = call float @dx.op.unary.f32(i32 25, float %glass_r5_safe_length2)  ; Rsqrt(value)
  %glass_r5_raw_nx = fmul float %glass_r5_crossx, %glass_r5_inv_length
  %glass_r5_raw_ny = fmul float %glass_r5_crossy, %glass_r5_inv_length
  %glass_r5_raw_nz = fmul float %glass_r5_crossz, %glass_r5_inv_length
  %68 = alloca [12 x float], align 4
  %69 = alloca [12 x float], align 4
  %70 = alloca [6 x float], align 4
  %71 = alloca [6 x float], align 4
  %72 = alloca [6 x float], align 4
  %73 = alloca [6 x float], align 4
  %74 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 457)  ; CBufferLoadLegacy(handle,regIndex)
  %75 = extractvalue %dx.types.CBufRet.f32 %74, 3
  %76 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 455)  ; CBufferLoadLegacy(handle,regIndex)
  %77 = extractvalue %dx.types.CBufRet.f32 %76, 0
  %78 = extractvalue %dx.types.CBufRet.f32 %76, 1
  %79 = extractvalue %dx.types.CBufRet.f32 %76, 2
  %80 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 454)  ; CBufferLoadLegacy(handle,regIndex)
  %81 = extractvalue %dx.types.CBufRet.f32 %80, 0
  %82 = extractvalue %dx.types.CBufRet.f32 %80, 1
  %83 = extractvalue %dx.types.CBufRet.f32 %80, 2
  %84 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 208)  ; CBufferLoadLegacy(handle,regIndex)
  %85 = extractvalue %dx.types.CBufRet.f32 %84, 2
  %86 = extractvalue %dx.types.CBufRet.f32 %84, 3
  %87 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 459)  ; CBufferLoadLegacy(handle,regIndex)
  %88 = extractvalue %dx.types.CBufRet.f32 %87, 0
  %89 = extractvalue %dx.types.CBufRet.f32 %87, 1
  %90 = extractvalue %dx.types.CBufRet.f32 %87, 2
  %91 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 237)  ; CBufferLoadLegacy(handle,regIndex)
  %92 = extractvalue %dx.types.CBufRet.f32 %91, 0
  %93 = extractvalue %dx.types.CBufRet.f32 %91, 1
  %94 = extractvalue %dx.types.CBufRet.f32 %91, 2
  %95 = extractvalue %dx.types.CBufRet.f32 %91, 3
  %96 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 472)  ; CBufferLoadLegacy(handle,regIndex)
  %97 = extractvalue %dx.types.CBufRet.f32 %96, 2
  %98 = extractvalue %dx.types.CBufRet.f32 %96, 3
  %99 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 236)  ; CBufferLoadLegacy(handle,regIndex)
  %100 = extractvalue %dx.types.CBufRet.f32 %99, 0
  %101 = extractvalue %dx.types.CBufRet.f32 %99, 1
  %102 = extractvalue %dx.types.CBufRet.f32 %99, 2
  %103 = extractvalue %dx.types.CBufRet.f32 %99, 3
  %104 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 463)  ; CBufferLoadLegacy(handle,regIndex)
  %105 = extractvalue %dx.types.CBufRet.i32 %104, 3
  %106 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 400)  ; CBufferLoadLegacy(handle,regIndex)
  %107 = extractvalue %dx.types.CBufRet.f32 %106, 0
  %108 = extractvalue %dx.types.CBufRet.f32 %106, 1
  %109 = extractvalue %dx.types.CBufRet.f32 %106, 2
  %110 = extractvalue %dx.types.CBufRet.f32 %106, 3
  %111 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 217)  ; CBufferLoadLegacy(handle,regIndex)
  %112 = extractvalue %dx.types.CBufRet.f32 %111, 0
  %113 = extractvalue %dx.types.CBufRet.f32 %111, 1
  %114 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 209)  ; CBufferLoadLegacy(handle,regIndex)
  %115 = extractvalue %dx.types.CBufRet.f32 %114, 0
  %116 = extractvalue %dx.types.CBufRet.f32 %114, 1
  %117 = extractvalue %dx.types.CBufRet.f32 %114, 2
  %118 = extractvalue %dx.types.CBufRet.f32 %114, 3
  %119 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 395)  ; CBufferLoadLegacy(handle,regIndex)
  %120 = extractvalue %dx.types.CBufRet.f32 %119, 0
  %121 = extractvalue %dx.types.CBufRet.f32 %119, 1
  %122 = extractvalue %dx.types.CBufRet.f32 %119, 2
  %123 = extractvalue %dx.types.CBufRet.f32 %119, 3
  %124 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 234)  ; CBufferLoadLegacy(handle,regIndex)
  %125 = extractvalue %dx.types.CBufRet.f32 %124, 0
  %126 = extractvalue %dx.types.CBufRet.f32 %124, 1
  %127 = extractvalue %dx.types.CBufRet.f32 %87, 3
  %128 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 479)  ; CBufferLoadLegacy(handle,regIndex)
  %129 = extractvalue %dx.types.CBufRet.f32 %128, 3
  %130 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 3)  ; CBufferLoadLegacy(handle,regIndex)
  %131 = extractvalue %dx.types.CBufRet.f32 %130, 0
  %132 = extractvalue %dx.types.CBufRet.f32 %130, 2
  %133 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 159)  ; CBufferLoadLegacy(handle,regIndex)
  %134 = extractvalue %dx.types.CBufRet.f32 %133, 0
  %135 = extractvalue %dx.types.CBufRet.f32 %133, 2
  %136 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 21)  ; CBufferLoadLegacy(handle,regIndex)
  %137 = extractvalue %dx.types.CBufRet.f32 %136, 0
  %138 = extractvalue %dx.types.CBufRet.f32 %136, 2
  %139 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 25)  ; CBufferLoadLegacy(handle,regIndex)
  %140 = extractvalue %dx.types.CBufRet.f32 %139, 0
  %141 = extractvalue %dx.types.CBufRet.f32 %139, 1
  %142 = extractvalue %dx.types.CBufRet.f32 %139, 2
  %143 = extractvalue %dx.types.CBufRet.f32 %139, 3
  %144 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 26)  ; CBufferLoadLegacy(handle,regIndex)
  %145 = extractvalue %dx.types.CBufRet.f32 %144, 0
  %146 = extractvalue %dx.types.CBufRet.f32 %144, 1
  %147 = extractvalue %dx.types.CBufRet.f32 %144, 2
  %148 = extractvalue %dx.types.CBufRet.f32 %144, 3
  %149 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 27)  ; CBufferLoadLegacy(handle,regIndex)
  %150 = extractvalue %dx.types.CBufRet.f32 %149, 0
  %151 = extractvalue %dx.types.CBufRet.f32 %149, 1
  %152 = extractvalue %dx.types.CBufRet.f32 %149, 2
  %153 = extractvalue %dx.types.CBufRet.f32 %149, 3
  %154 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 4)  ; CBufferLoadLegacy(handle,regIndex)
  %155 = extractvalue %dx.types.CBufRet.f32 %154, 0
  %156 = extractvalue %dx.types.CBufRet.f32 %154, 1
  %157 = fmul fast float %61, 0x3FB99999A0000000
  %158 = fmul fast float %63, 0x3FB99999A0000000
  %159 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 452)  ; CBufferLoadLegacy(handle,regIndex)
  %160 = extractvalue %dx.types.CBufRet.f32 %159, 0
  %161 = extractvalue %dx.types.CBufRet.f32 %159, 2
  %162 = fmul fast float %161, 0x3F999999A0000000
  %163 = fadd fast float %162, %157
  %164 = fadd fast float %162, %158
  %165 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %1, %dx.types.Handle %42, float %163, float %164, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %166 = extractvalue %dx.types.ResRet.f32 %165, 0
  %167 = extractvalue %dx.types.ResRet.f32 %165, 1
  %168 = fmul fast float %166, 2.000000e+00
  %169 = fmul fast float %167, 2.000000e+00
  %170 = fadd fast float %168, -1.000000e+00
  %171 = fadd fast float %169, -1.000000e+00
  %172 = fmul fast float %170, %170
  %173 = fmul fast float %171, %171
  %174 = fsub fast float 1.000000e+00, %173
  %175 = fsub fast float %174, %172
  %176 = call float @dx.op.unary.f32(i32 7, float %175)  ; Saturate(value)
  %177 = call float @dx.op.unary.f32(i32 24, float %176)  ; Sqrt(value)
  %178 = fsub fast float %157, %162
  %179 = fsub fast float %158, %162
  %180 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %2, %dx.types.Handle %42, float %178, float %179, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %181 = extractvalue %dx.types.ResRet.f32 %180, 0
  %182 = extractvalue %dx.types.ResRet.f32 %180, 1
  %183 = fmul fast float %181, 2.000000e+00
  %184 = fmul fast float %182, 2.000000e+00
  %185 = fadd fast float %183, -1.000000e+00
  %186 = fadd fast float %184, -1.000000e+00
  %187 = fmul fast float %185, %185
  %188 = fmul fast float %186, %186
  %189 = fsub fast float 1.000000e+00, %188
  %190 = fsub fast float %189, %187
  %191 = call float @dx.op.unary.f32(i32 7, float %190)  ; Saturate(value)
  %192 = call float @dx.op.unary.f32(i32 24, float %191)  ; Sqrt(value)
  %193 = fadd fast float %185, %170
  %194 = fadd fast float %186, %171
  %195 = fadd fast float %192, %177
  %196 = fmul fast float %61, 0x3FA99999A0000000
  %197 = fmul fast float %63, 0x3FA99999A0000000
  %198 = fsub fast float %196, %162
  %199 = fadd fast float %162, %197
  %200 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %3, %dx.types.Handle %42, float %198, float %199, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %201 = extractvalue %dx.types.ResRet.f32 %200, 0
  %202 = extractvalue %dx.types.ResRet.f32 %200, 1
  %203 = fmul fast float %201, 2.000000e+00
  %204 = fmul fast float %202, 2.000000e+00
  %205 = fadd fast float %203, -1.000000e+00
  %206 = fadd fast float %204, -1.000000e+00
  %207 = fmul fast float %205, %205
  %208 = fmul fast float %206, %206
  %209 = fsub fast float 1.000000e+00, %208
  %210 = fsub fast float %209, %207
  %211 = call float @dx.op.unary.f32(i32 7, float %210)  ; Saturate(value)
  %212 = call float @dx.op.unary.f32(i32 24, float %211)  ; Sqrt(value)
  %213 = fadd fast float %193, %205
  %214 = fadd fast float %194, %206
  %215 = fadd fast float %195, %212
  %216 = fcmp fast oeq float %213, 0.000000e+00
  %217 = fcmp fast oeq float %214, 0.000000e+00
  %218 = fcmp fast oeq float %215, 0.000000e+00
  %219 = and i1 %216, %217
  %220 = and i1 %218, %219
  br i1 %220, label %227, label %221

; <label>:221                                     ; preds = %0
  %222 = call float @dx.op.dot3.f32(i32 55, float %213, float %214, float %215, float %213, float %214, float %215)  ; Dot3(ax,ay,az,bx,by,bz)
  %223 = call float @dx.op.unary.f32(i32 25, float %222)  ; Rsqrt(value)
  %224 = fmul fast float %223, %213
  %225 = fmul fast float %223, %214
  %226 = fmul fast float %223, %215
  br label %227

; <label>:227                                     ; preds = %221, %0
  %228 = phi float [ %224, %221 ], [ 0.000000e+00, %0 ]
  %229 = phi float [ %225, %221 ], [ 0.000000e+00, %0 ]
  %230 = phi float [ %226, %221 ], [ 0.000000e+00, %0 ]
  %231 = fadd fast float %230, -1.000000e+00
  %232 = fmul fast float %228, 2.500000e-01
  %233 = fmul fast float %229, 2.500000e-01
  %234 = fmul fast float %231, 2.500000e-01
  %235 = fadd fast float %234, 1.000000e+00
  %236 = fmul fast float %232, %54
  %237 = call float @dx.op.tertiary.f32(i32 46, float %233, float %51, float %236)  ; FMad(a,b,c)
  %238 = call float @dx.op.tertiary.f32(i32 46, float %235, float %57, float %237)  ; FMad(a,b,c)
  %239 = fmul fast float %232, %55
  %240 = call float @dx.op.tertiary.f32(i32 46, float %233, float %52, float %239)  ; FMad(a,b,c)
  %241 = call float @dx.op.tertiary.f32(i32 46, float %235, float %58, float %240)  ; FMad(a,b,c)
  %242 = fmul fast float %232, %56
  %243 = call float @dx.op.tertiary.f32(i32 46, float %233, float %53, float %242)  ; FMad(a,b,c)
  %244 = call float @dx.op.tertiary.f32(i32 46, float %235, float %59, float %243)  ; FMad(a,b,c)
  %245 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %45, i32 1)  ; CBufferLoadLegacy(handle,regIndex)
  %246 = extractvalue %dx.types.CBufRet.f32 %245, 0
  %247 = extractvalue %dx.types.CBufRet.f32 %245, 1
  %248 = extractvalue %dx.types.CBufRet.f32 %245, 2
  %249 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %45, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %250 = extractvalue %dx.types.CBufRet.f32 %249, 0
  %251 = extractvalue %dx.types.CBufRet.f32 %249, 1
  %252 = extractvalue %dx.types.CBufRet.f32 %249, 2
  %253 = fsub fast float %246, %250
  %254 = fsub fast float %247, %251
  %255 = fsub fast float %248, %252
  %256 = fmul fast float %253, %241
  %257 = fmul fast float %254, %241
  %258 = fmul fast float %255, %241
  %259 = fadd fast float %256, %250
  %260 = fadd fast float %257, %251
  %261 = fadd fast float %258, %252
  %262 = fmul fast float %241, 0x3FC3333300000000
  %263 = fadd fast float %262, 0x3FE99999A0000000
  %264 = fmul fast float %238, 8.750000e-01
  %265 = fmul fast float %241, 8.750000e-01
  %266 = fmul fast float %244, 8.750000e-01
  %267 = fsub fast float %77, %61
  %268 = fsub fast float %78, %62
  %269 = fsub fast float %79, %63
  %270 = call float @dx.op.dot3.f32(i32 55, float %267, float %268, float %269, float %267, float %268, float %269)  ; Dot3(ax,ay,az,bx,by,bz)
  %271 = call float @dx.op.unary.f32(i32 25, float %270)  ; Rsqrt(value)
  %272 = fmul fast float %271, %267
  %273 = fmul fast float %271, %268
  %274 = fmul fast float %271, %269
  %glass_r5_dot = call float @dx.op.dot3.f32(i32 55, float %glass_r5_raw_nx, float %glass_r5_raw_ny, float %glass_r5_raw_nz, float %272, float %273, float %274)  ; Dot3(ax,ay,az,bx,by,bz)
  %glass_r5_back = fcmp olt float %glass_r5_dot, 0.000000e+00
  %glass_r5_face = select i1 %glass_r5_back, float -1.000000e+00, float 1.000000e+00
  %glass_r5_nx = fmul float %glass_r5_raw_nx, %glass_r5_face
  %glass_r5_ny = fmul float %glass_r5_raw_ny, %glass_r5_face
  %glass_r5_nz = fmul float %glass_r5_raw_nz, %glass_r5_face
  %glass_r5_abs_dot = call float @dx.op.unary.f32(i32 6, float %glass_r5_dot)  ; FAbs(value)
  %glass_r5_cos = call float @dx.op.unary.f32(i32 7, float %glass_r5_abs_dot)  ; Saturate(value)
  %glass_r5_grazing = fsub float 1.000000e+00, %glass_r5_cos
  %glass_r5_grazing2 = fmul float %glass_r5_grazing, %glass_r5_grazing
  %glass_r5_grazing4 = fmul float %glass_r5_grazing2, %glass_r5_grazing2
  %glass_r5_grazing5 = fmul float %glass_r5_grazing4, %glass_r5_grazing
  %glass_r5_native_grazing = fmul float %glass_r5_grazing5, 0x3FEEB851E0000000
  %glass_r5_native_fresnel = fadd float %glass_r5_native_grazing, 0x3FA47AE140000000
  %glass_r5_target_grazing = fmul float %glass_r5_grazing5, %setting_opacity_range
  %glass_r5_glass_alpha = fadd float %glass_r5_target_grazing, %setting_face_opacity
  %glass_r5_mirror_half = fcmp olt float %61, 0.000000e+00
  %glass_r5_alpha = fadd float %glass_r5_glass_alpha, 0.000000e+00
  %glass_r5_reflection_scale = fdiv float %glass_r5_alpha, %glass_r5_native_fresnel
  %275 = fmul fast float %160, 0x3F847AE140000000
  %276 = fmul fast float %61, 0x3F947AE140000000
  %277 = fmul fast float %63, 0x3F947AE140000000
  %278 = fadd fast float %275, %276
  %279 = fadd fast float %275, %277
  %280 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %4, %dx.types.Handle %42, float %278, float %279, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %281 = extractvalue %dx.types.ResRet.f32 %280, 0
  %282 = extractvalue %dx.types.ResRet.f32 %280, 1
  %283 = extractvalue %dx.types.ResRet.f32 %280, 2
  %284 = fsub fast float %196, %275
  %285 = fsub fast float %197, %275
  %286 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %4, %dx.types.Handle %42, float %284, float %285, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %287 = extractvalue %dx.types.ResRet.f32 %286, 0
  %288 = extractvalue %dx.types.ResRet.f32 %286, 1
  %289 = extractvalue %dx.types.ResRet.f32 %286, 2
  %290 = fmul fast float %238, 4.000000e+00
  %291 = fmul fast float %241, 4.000000e+00
  %292 = fmul fast float %244, 4.000000e+00
  %293 = fadd fast float %290, %61
  %294 = fadd fast float %291, %62
  %295 = fadd fast float %292, %63
  %296 = fmul fast float %293, 0x3F847AE140000000
  %297 = fmul fast float %294, 0x3F847AE140000000
  %298 = fmul fast float %295, 0x3F847AE140000000
  %299 = call float @dx.op.unary.f32(i32 22, float %296)  ; Frc(value)
  %300 = call float @dx.op.unary.f32(i32 22, float %297)  ; Frc(value)
  %301 = call float @dx.op.unary.f32(i32 22, float %298)  ; Frc(value)
  %302 = fmul fast float %299, 1.024000e+03
  %303 = fmul fast float %300, 1.024000e+03
  %304 = fmul fast float %301, 1.024000e+03
  %305 = call float @dx.op.unary.f32(i32 27, float %302)  ; Round_ni(value)
  %306 = call float @dx.op.unary.f32(i32 27, float %303)  ; Round_ni(value)
  %307 = call float @dx.op.unary.f32(i32 27, float %304)  ; Round_ni(value)
  %308 = fmul fast float %305, 0x3F59E377A0000000
  %309 = fmul fast float %306, 0x3F59E377A0000000
  %310 = fmul fast float %307, 0x3F59E377A0000000
  %311 = fadd fast float %308, 0xC00921FB60000000
  %312 = fadd fast float %309, 0xBFF9E377A0000000
  %313 = fadd fast float %310, 0xC005BF0A80000000
  %314 = fmul fast float %311, %311
  %315 = fmul fast float %312, %312
  %316 = fadd fast float %315, %314
  %317 = fmul fast float %313, %313
  %318 = fadd fast float %316, %317
  %319 = call float @dx.op.unary.f32(i32 24, float %318)  ; Sqrt(value)
  %320 = call float @dx.op.unary.f32(i32 13, float %319)  ; Sin(value)
  %321 = fmul fast float %320, 0x4123B6DA60000000
  %322 = call float @dx.op.unary.f32(i32 22, float %321)  ; Frc(value)
  %323 = fmul fast float %305, 0x3F5B7D1140000000
  %324 = fmul fast float %306, 0x3F5B7D1140000000
  %325 = fmul fast float %307, 0x3F5B7D1140000000
  %326 = fadd fast float %323, 0xC00921FB60000000
  %327 = fadd fast float %324, 0xBFF9E377A0000000
  %328 = fadd fast float %325, 0xC005BF0A80000000
  %329 = fmul fast float %326, %326
  %330 = fmul fast float %327, %327
  %331 = fadd fast float %330, %329
  %332 = fmul fast float %328, %328
  %333 = fadd fast float %331, %332
  %334 = call float @dx.op.unary.f32(i32 24, float %333)  ; Sqrt(value)
  %335 = call float @dx.op.unary.f32(i32 13, float %334)  ; Sin(value)
  %336 = fmul fast float %335, 0x4123B6DA60000000
  %337 = call float @dx.op.unary.f32(i32 22, float %336)  ; Frc(value)
  %338 = fmul fast float %305, 0x3F5D16AAE0000000
  %339 = fmul fast float %306, 0x3F5D16AAE0000000
  %340 = fmul fast float %307, 0x3F5D16AAE0000000
  %341 = fadd fast float %338, 0xC00921FB60000000
  %342 = fadd fast float %339, 0xBFF9E377A0000000
  %343 = fadd fast float %340, 0xC005BF0A80000000
  %344 = fmul fast float %341, %341
  %345 = fmul fast float %342, %342
  %346 = fadd fast float %345, %344
  %347 = fmul fast float %343, %343
  %348 = fadd fast float %346, %347
  %349 = call float @dx.op.unary.f32(i32 24, float %348)  ; Sqrt(value)
  %350 = call float @dx.op.unary.f32(i32 13, float %349)  ; Sin(value)
  %351 = fmul fast float %350, 0x4123B6DA60000000
  %352 = call float @dx.op.unary.f32(i32 22, float %351)  ; Frc(value)
  %353 = fmul fast float %293, 0x3F747AE140000000
  %354 = fmul fast float %294, 0x3F747AE140000000
  %355 = fmul fast float %295, 0x3F747AE140000000
  %356 = call float @dx.op.unary.f32(i32 22, float %353)  ; Frc(value)
  %357 = call float @dx.op.unary.f32(i32 22, float %354)  ; Frc(value)
  %358 = call float @dx.op.unary.f32(i32 22, float %355)  ; Frc(value)
  %359 = fmul fast float %356, 1.024000e+03
  %360 = fmul fast float %357, 1.024000e+03
  %361 = fmul fast float %358, 1.024000e+03
  %362 = call float @dx.op.unary.f32(i32 27, float %359)  ; Round_ni(value)
  %363 = call float @dx.op.unary.f32(i32 27, float %360)  ; Round_ni(value)
  %364 = call float @dx.op.unary.f32(i32 27, float %361)  ; Round_ni(value)
  %365 = fmul fast float %362, 0x3F59E377A0000000
  %366 = fmul fast float %363, 0x3F59E377A0000000
  %367 = fmul fast float %364, 0x3F59E377A0000000
  %368 = fadd fast float %365, 0xC00921FB60000000
  %369 = fadd fast float %366, 0xBFF9E377A0000000
  %370 = fadd fast float %367, 0xC005BF0A80000000
  %371 = fmul fast float %368, %368
  %372 = fmul fast float %369, %369
  %373 = fadd fast float %372, %371
  %374 = fmul fast float %370, %370
  %375 = fadd fast float %373, %374
  %376 = call float @dx.op.unary.f32(i32 24, float %375)  ; Sqrt(value)
  %377 = call float @dx.op.unary.f32(i32 13, float %376)  ; Sin(value)
  %378 = fmul fast float %377, 0x4123B6DA60000000
  %379 = call float @dx.op.unary.f32(i32 22, float %378)  ; Frc(value)
  %380 = fmul fast float %362, 0x3F5B7D1140000000
  %381 = fmul fast float %363, 0x3F5B7D1140000000
  %382 = fmul fast float %364, 0x3F5B7D1140000000
  %383 = fadd fast float %380, 0xC00921FB60000000
  %384 = fadd fast float %381, 0xBFF9E377A0000000
  %385 = fadd fast float %382, 0xC005BF0A80000000
  %386 = fmul fast float %383, %383
  %387 = fmul fast float %384, %384
  %388 = fadd fast float %387, %386
  %389 = fmul fast float %385, %385
  %390 = fadd fast float %388, %389
  %391 = call float @dx.op.unary.f32(i32 24, float %390)  ; Sqrt(value)
  %392 = call float @dx.op.unary.f32(i32 13, float %391)  ; Sin(value)
  %393 = fmul fast float %392, 0x4123B6DA60000000
  %394 = call float @dx.op.unary.f32(i32 22, float %393)  ; Frc(value)
  %395 = fmul fast float %362, 0x3F5D16AAE0000000
  %396 = fmul fast float %363, 0x3F5D16AAE0000000
  %397 = fmul fast float %364, 0x3F5D16AAE0000000
  %398 = fadd fast float %395, 0xC00921FB60000000
  %399 = fadd fast float %396, 0xBFF9E377A0000000
  %400 = fadd fast float %397, 0xC005BF0A80000000
  %401 = fmul fast float %398, %398
  %402 = fmul fast float %399, %399
  %403 = fadd fast float %402, %401
  %404 = fmul fast float %400, %400
  %405 = fadd fast float %403, %404
  %406 = call float @dx.op.unary.f32(i32 24, float %405)  ; Sqrt(value)
  %407 = call float @dx.op.unary.f32(i32 13, float %406)  ; Sin(value)
  %408 = fmul fast float %407, 0x4123B6DA60000000
  %409 = call float @dx.op.unary.f32(i32 22, float %408)  ; Frc(value)
  %410 = fsub fast float %379, %322
  %411 = fsub fast float %394, %337
  %412 = fsub fast float %409, %352
  %413 = fmul fast float %410, 5.000000e-01
  %414 = fmul fast float %411, 5.000000e-01
  %415 = fmul fast float %412, 5.000000e-01
  %416 = fadd fast float %413, %322
  %417 = fadd fast float %414, %337
  %418 = fadd fast float %415, %352
  %419 = fmul fast float %416, 0x3FD3333320000000
  %420 = fadd fast float %419, 0x3FD99999A0000000
  %421 = fsub fast float %287, %281
  %422 = fsub fast float %288, %282
  %423 = fsub fast float %289, %283
  %424 = fmul fast float %420, %421
  %425 = fmul fast float %420, %422
  %426 = fmul fast float %420, %423
  %427 = fadd fast float %424, %281
  %428 = fadd fast float %425, %282
  %429 = fadd fast float %426, %283
  %430 = fsub fast float 1.000000e+00, %427
  %431 = fsub fast float 1.000000e+00, %428
  %432 = fsub fast float 1.000000e+00, %429
  %433 = fmul fast float %432, 2.000000e+00
  %434 = fsub fast float 1.000000e+00, %416
  %435 = fsub fast float 1.000000e+00, %417
  %436 = fsub fast float 1.000000e+00, %418
  %437 = fmul fast float %434, 2.000000e+00
  %438 = fmul fast float %437, %430
  %439 = fmul fast float %435, 2.000000e+00
  %440 = fmul fast float %439, %431
  %441 = fmul fast float %433, %436
  %442 = fsub fast float 1.000000e+00, %438
  %443 = fsub fast float 1.000000e+00, %440
  %444 = fsub fast float 1.000000e+00, %441
  %445 = fmul fast float %429, 2.000000e+00
  %446 = fmul fast float %416, 2.000000e+00
  %447 = fmul fast float %446, %427
  %448 = fmul fast float %417, 2.000000e+00
  %449 = fmul fast float %448, %428
  %450 = fmul fast float %445, %418
  %451 = fcmp fast olt float %427, 5.000000e-01
  %452 = fcmp fast olt float %428, 5.000000e-01
  %453 = fcmp fast olt float %429, 5.000000e-01
  %454 = select i1 %451, float %447, float %442
  %455 = select i1 %452, float %449, float %443
  %456 = select i1 %453, float %450, float %444
  %457 = fsub fast float %454, %427
  %458 = fsub fast float %455, %428
  %459 = fsub fast float %456, %429
  %460 = fmul fast float %457, 2.500000e-01
  %461 = fmul fast float %458, 2.500000e-01
  %462 = fmul fast float %459, 2.500000e-01
  %463 = fadd fast float %460, %427
  %464 = fadd fast float %461, %428
  %465 = fadd fast float %462, %429
  %466 = call float @dx.op.unary.f32(i32 22, float %293)  ; Frc(value)
  %467 = call float @dx.op.unary.f32(i32 22, float %294)  ; Frc(value)
  %468 = call float @dx.op.unary.f32(i32 22, float %295)  ; Frc(value)
  %469 = fmul fast float %466, 1.024000e+03
  %470 = fmul fast float %467, 1.024000e+03
  %471 = fmul fast float %468, 1.024000e+03
  %472 = call float @dx.op.unary.f32(i32 27, float %469)  ; Round_ni(value)
  %473 = call float @dx.op.unary.f32(i32 27, float %470)  ; Round_ni(value)
  %474 = call float @dx.op.unary.f32(i32 27, float %471)  ; Round_ni(value)
  %475 = fmul fast float %472, 0x3F59E377A0000000
  %476 = fmul fast float %473, 0x3F59E377A0000000
  %477 = fmul fast float %474, 0x3F59E377A0000000
  %478 = fadd fast float %475, 0xC00921FB60000000
  %479 = fadd fast float %476, 0xBFF9E377A0000000
  %480 = fadd fast float %477, 0xC005BF0A80000000
  %481 = fmul fast float %478, %478
  %482 = fmul fast float %479, %479
  %483 = fadd fast float %482, %481
  %484 = fmul fast float %480, %480
  %485 = fadd fast float %483, %484
  %486 = call float @dx.op.unary.f32(i32 24, float %485)  ; Sqrt(value)
  %487 = call float @dx.op.unary.f32(i32 13, float %486)  ; Sin(value)
  %488 = fmul fast float %487, 0x4123B6DA60000000
  %489 = call float @dx.op.unary.f32(i32 22, float %488)  ; Frc(value)
  %490 = fmul fast float %472, 0x3F5B7D1140000000
  %491 = fmul fast float %473, 0x3F5B7D1140000000
  %492 = fmul fast float %474, 0x3F5B7D1140000000
  %493 = fadd fast float %490, 0xC00921FB60000000
  %494 = fadd fast float %491, 0xBFF9E377A0000000
  %495 = fadd fast float %492, 0xC005BF0A80000000
  %496 = fmul fast float %493, %493
  %497 = fmul fast float %494, %494
  %498 = fadd fast float %497, %496
  %499 = fmul fast float %495, %495
  %500 = fadd fast float %498, %499
  %501 = call float @dx.op.unary.f32(i32 24, float %500)  ; Sqrt(value)
  %502 = call float @dx.op.unary.f32(i32 13, float %501)  ; Sin(value)
  %503 = fmul fast float %502, 0x4123B6DA60000000
  %504 = call float @dx.op.unary.f32(i32 22, float %503)  ; Frc(value)
  %505 = fmul fast float %472, 0x3F5D16AAE0000000
  %506 = fmul fast float %473, 0x3F5D16AAE0000000
  %507 = fmul fast float %474, 0x3F5D16AAE0000000
  %508 = fadd fast float %505, 0xC00921FB60000000
  %509 = fadd fast float %506, 0xBFF9E377A0000000
  %510 = fadd fast float %507, 0xC005BF0A80000000
  %511 = fmul fast float %508, %508
  %512 = fmul fast float %509, %509
  %513 = fadd fast float %512, %511
  %514 = fmul fast float %510, %510
  %515 = fadd fast float %513, %514
  %516 = call float @dx.op.unary.f32(i32 24, float %515)  ; Sqrt(value)
  %517 = call float @dx.op.unary.f32(i32 13, float %516)  ; Sin(value)
  %518 = fmul fast float %517, 0x4123B6DA60000000
  %519 = call float @dx.op.unary.f32(i32 22, float %518)  ; Frc(value)
  %520 = fsub fast float 1.000000e+00, %463
  %521 = fsub fast float 1.000000e+00, %464
  %522 = fsub fast float 1.000000e+00, %465
  %523 = fmul fast float %520, 2.000000e+00
  %524 = fmul fast float %521, 2.000000e+00
  %525 = fmul fast float %522, 2.000000e+00
  %526 = fsub fast float 1.000000e+00, %489
  %527 = fsub fast float 1.000000e+00, %504
  %528 = fsub fast float 1.000000e+00, %519
  %529 = fmul fast float %523, %526
  %530 = fmul fast float %524, %527
  %531 = fmul fast float %525, %528
  %532 = fsub fast float 1.000000e+00, %529
  %533 = fsub fast float 1.000000e+00, %530
  %534 = fsub fast float 1.000000e+00, %531
  %535 = fmul fast float %463, 2.000000e+00
  %536 = fmul fast float %464, 2.000000e+00
  %537 = fmul fast float %465, 2.000000e+00
  %538 = fmul fast float %535, %489
  %539 = fmul fast float %536, %504
  %540 = fmul fast float %537, %519
  %541 = fcmp fast olt float %463, 5.000000e-01
  %542 = fcmp fast olt float %464, 5.000000e-01
  %543 = fcmp fast olt float %465, 5.000000e-01
  %544 = select i1 %541, float %538, float %532
  %545 = select i1 %542, float %539, float %533
  %546 = select i1 %543, float %540, float %534
  %547 = fsub fast float %544, %463
  %548 = fsub fast float %545, %464
  %549 = fsub fast float %546, %465
  %550 = fmul fast float %547, 0x3FB99999A0000000
  %551 = fmul fast float %548, 0x3FB99999A0000000
  %552 = fmul fast float %549, 0x3FB99999A0000000
  %553 = fadd fast float %550, %463
  %554 = fadd fast float %551, %464
  %555 = fadd fast float %552, %465
  %556 = fmul fast float %272, 2.500000e-01
  %557 = fmul fast float %556, %553
  %558 = fmul fast float %273, 2.500000e-01
  %559 = fmul fast float %558, %554
  %560 = fmul fast float %274, 2.500000e-01
  %561 = fmul fast float %560, %555
  %562 = fadd fast float %557, %264
  %563 = fadd fast float %559, %265
  %564 = fadd fast float %561, %266
  %565 = fsub fast float %61, %77
  %566 = fsub fast float %62, %78
  %567 = fsub fast float %63, %79
  %568 = call float @dx.op.dot3.f32(i32 55, float %565, float %566, float %567, float %272, float %273, float %274)  ; Dot3(ax,ay,az,bx,by,bz)
  %569 = call float @dx.op.unary.f32(i32 6, float %568)  ; FAbs(value)
  %570 = fadd fast float %569, -5.000000e+00
  %571 = fmul fast float %570, 0x3F96C16C20000000
  %572 = call float @dx.op.unary.f32(i32 7, float %571)  ; Saturate(value)
  %573 = fmul fast float %572, %572
  %574 = fmul fast float %573, %572
  %575 = fmul fast float %572, 6.000000e+00
  %576 = fadd fast float %575, -1.500000e+01
  %577 = fmul fast float %576, %572
  %578 = fadd fast float %577, 1.000000e+01
  %579 = fmul fast float %574, %578
  %580 = fmul fast float %579, %579
  %581 = fmul fast float %580, 7.500000e-01
  %582 = fsub fast float 1.000000e+00, %563
  %583 = fmul fast float %581, %562
  %584 = fmul fast float %581, %582
  %585 = fmul fast float %581, %564
  %586 = fsub fast float %562, %583
  %587 = fadd fast float %584, %563
  %588 = fsub fast float %564, %585
  %589 = fcmp fast oeq float %586, 0.000000e+00
  %590 = fcmp fast oeq float %587, 0.000000e+00
  %591 = fcmp fast oeq float %588, 0.000000e+00
  %592 = and i1 %589, %590
  %593 = and i1 %591, %592
  br i1 %593, label %600, label %594

; <label>:594                                     ; preds = %227
  %595 = call float @dx.op.dot3.f32(i32 55, float %586, float %587, float %588, float %586, float %587, float %588)  ; Dot3(ax,ay,az,bx,by,bz)
  %596 = call float @dx.op.unary.f32(i32 25, float %595)  ; Rsqrt(value)
  %597 = fmul fast float %596, %586
  %598 = fmul fast float %596, %587
  %599 = fmul fast float %596, %588
  br label %600

; <label>:600                                     ; preds = %594, %227
  %601 = phi float [ %597, %594 ], [ 0.000000e+00, %227 ]
  %602 = phi float [ %598, %594 ], [ 0.000000e+00, %227 ]
  %603 = phi float [ %599, %594 ], [ 0.000000e+00, %227 ]
  %604 = fmul fast float %241, 0x3FD3333300000000
  %605 = fsub fast float 0x3FD9999980000000, %604
  %606 = fsub fast float 1.000000e+00, %553
  %607 = fmul fast float %606, %605
  %608 = fsub fast float 1.000000e+00, %607
  %609 = fadd fast float %604, 0x3FF99999A0000000
  %610 = fmul fast float %553, %609
  %611 = fcmp fast olt float %263, 5.000000e-01
  %612 = select i1 %611, float %610, float %608
  %613 = fsub fast float %612, %263
  %614 = fmul fast float %613, 2.500000e-01
  %615 = fadd fast float %614, %263
  %616 = fsub fast float -0.000000e+00, %81
  %617 = fsub fast float -0.000000e+00, %82
  %618 = fsub fast float -0.000000e+00, %83
  %619 = call float @dx.op.dot3.f32(i32 55, float %616, float %617, float %618, float %267, float %268, float %269)  ; Dot3(ax,ay,az,bx,by,bz)
  %620 = call float @dx.op.unary.f32(i32 6, float %619)  ; FAbs(value)
  %621 = fadd fast float %620, -2.000000e+02
  %622 = fmul fast float %621, 0x3F42345680000000
  %623 = call float @dx.op.unary.f32(i32 7, float %622)  ; Saturate(value)
  %624 = fmul fast float %623, %623
  %625 = fmul fast float %624, %623
  %626 = fmul fast float %623, 6.000000e+00
  %627 = fadd fast float %626, -1.500000e+01
  %628 = fmul fast float %627, %623
  %629 = fadd fast float %628, 1.000000e+01
  %630 = fmul fast float %625, %629
  %631 = fsub fast float 5.000000e-01, %259
  %632 = fsub fast float 5.000000e-01, %260
  %633 = fsub fast float 5.000000e-01, %261
  %634 = fmul fast float %630, %631
  %635 = fmul fast float %630, %632
  %636 = fmul fast float %630, %633
  %637 = fadd fast float %634, %259
  %638 = fadd fast float %635, %260
  %639 = fadd fast float %636, %261
  %640 = fsub fast float 1.000000e+00, %602
  %641 = fmul fast float %630, %601
  %642 = fmul fast float %630, %640
  %643 = fmul fast float %630, %603
  %644 = fsub fast float %601, %641
  %645 = fadd fast float %642, %602
  %646 = fsub fast float %603, %643
  %647 = fmul fast float %630, %615
  %648 = fsub fast float %615, %647
  %649 = call float @dx.op.dot3.f32(i32 55, float %565, float %566, float %567, float %616, float %617, float %618)  ; Dot3(ax,ay,az,bx,by,bz)
  %650 = call float @dx.op.unary.f32(i32 6, float %649)  ; FAbs(value)
  %651 = fsub fast float %489, %416
  %652 = fsub fast float %504, %417
  %653 = fmul fast float %651, 0x3FC99999A0000000
  %654 = fmul fast float %652, 0x3FC99999A0000000
  %655 = fadd fast float %653, %416
  %656 = fadd fast float %654, %417
  %657 = fmul fast float %655, 2.000000e+00
  %658 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 473)  ; CBufferLoadLegacy(handle,regIndex)
  %659 = extractvalue %dx.types.CBufRet.f32 %658, 0
  %660 = extractvalue %dx.types.CBufRet.f32 %658, 1
  %661 = fmul fast float %85, %47
  %662 = fmul fast float %86, %48
  %663 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %11, %dx.types.Handle %38, float %661, float %662, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %664 = extractvalue %dx.types.ResRet.f32 %663, 0
  %665 = fsub fast float %664, %660
  %666 = fdiv fast float 1.000000e+00, %665
  %667 = fmul fast float %666, %659
  %668 = fadd fast float %657, -1.000000e+00
  %669 = fadd fast float %668, %650
  %670 = fsub fast float %669, %667
  %671 = call float @dx.op.unary.f32(i32 6, float %670)  ; FAbs(value)
  %672 = fadd fast float %671, -5.000000e+00
  %673 = fmul fast float %672, 0xBFC5555560000000
  %674 = call float @dx.op.unary.f32(i32 7, float %673)  ; Saturate(value)
  %675 = call float @dx.op.dot3.f32(i32 55, float %644, float %645, float %646, float %272, float %273, float %274)  ; Dot3(ax,ay,az,bx,by,bz)
  %676 = fmul fast float %379, 0x3FA47AE140000000
  %677 = fadd fast float %676, 0x3FEF5C2900000000
  %678 = fsub fast float %677, %675
  %679 = call float @dx.op.unary.f32(i32 23, float %678)  ; Log(value)
  %680 = fmul fast float %679, 4.000000e+00
  %681 = call float @dx.op.unary.f32(i32 21, float %680)  ; Exp(value)
  %682 = fadd fast float %681, 0xBFE3333340000000
  %683 = fmul fast float %682, 0x4014000020000000
  %684 = call float @dx.op.unary.f32(i32 7, float %683)  ; Saturate(value)
  %685 = fmul fast float %684, 0x3FC99999A0000000
  %686 = fadd fast float %685, %674
  %687 = fmul fast float %656, 0x3FB99999A0000000
  %688 = fsub fast float %662, %687
  %689 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %11, %dx.types.Handle %38, float %661, float %688, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %690 = extractvalue %dx.types.ResRet.f32 %689, 0
  %691 = fsub fast float %690, %660
  %692 = fdiv fast float 1.000000e+00, %691
  %693 = fsub fast float %666, %692
  %694 = fmul fast float %693, %659
  %695 = call float @dx.op.unary.f32(i32 6, float %694)  ; FAbs(value)
  %696 = fmul fast float %671, 5.000000e-01
  %697 = fadd fast float %696, 0xBF847AE140000000
  %698 = fadd fast float %697, %695
  %699 = fmul fast float %698, 1.000000e+02
  %700 = call float @dx.op.unary.f32(i32 7, float %699)  ; Saturate(value)
  %701 = fmul fast float %700, %686
  %702 = fadd fast float %701, %684
  %703 = fsub fast float 0x3F9482FB20000000, %637
  %704 = fsub fast float 0x3FB738DA40000000, %638
  %705 = fsub fast float 0x3FC51BC080000000, %639
  %706 = fmul fast float %702, %703
  %707 = fmul fast float %702, %704
  %708 = fmul fast float %702, %705
  %709 = fadd fast float %706, %637
  %710 = fadd fast float %707, %638
  %711 = fadd fast float %708, %639
  %712 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %45, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %713 = extractvalue %dx.types.CBufRet.f32 %712, 0
  %714 = extractvalue %dx.types.CBufRet.f32 %712, 1
  %715 = extractvalue %dx.types.CBufRet.f32 %712, 2
  %716 = fsub fast float 1.000000e+00, %713
  %717 = fsub fast float 1.000000e+00, %714
  %718 = fsub fast float 1.000000e+00, %715
  %719 = fmul fast float %716, 5.000000e-01
  %720 = fmul fast float %717, 5.000000e-01
  %721 = fmul fast float %718, 5.000000e-01
  %722 = fadd fast float %719, %713
  %723 = fadd fast float %720, %714
  %724 = fadd fast float %721, %715
  %725 = fadd fast float %671, 0xBFD99999A0000000
  %726 = fmul fast float %725, 0xC00AAAAAA0000000
  %727 = call float @dx.op.unary.f32(i32 7, float %726)  ; Saturate(value)
  %728 = fsub fast float %722, %709
  %729 = fsub fast float %723, %710
  %730 = fsub fast float %724, %711
  %731 = fmul fast float %728, %727
  %732 = fmul fast float %729, %727
  %733 = fmul fast float %730, %727
  %734 = fadd fast float %731, %709
  %735 = fadd fast float %732, %710
  %736 = fadd fast float %733, %711
  %737 = fmul fast float %655, 2.500000e-01
  %738 = fadd fast float %650, %737
  %739 = fsub fast float %738, %667
  %740 = call float @dx.op.unary.f32(i32 6, float %739)  ; FAbs(value)
  %741 = fadd fast float %740, 0xBFC99999A0000000
  %742 = fmul fast float %741, -1.000000e+01
  %743 = call float @dx.op.unary.f32(i32 7, float %742)  ; Saturate(value)
  %744 = fsub fast float 1.000000e+00, %734
  %745 = fsub fast float 1.000000e+00, %735
  %746 = fsub fast float 1.000000e+00, %736
  %747 = fmul fast float %744, %743
  %748 = fmul fast float %745, %743
  %749 = fmul fast float %746, %743
  %750 = fadd fast float %747, %734
  %751 = fadd fast float %748, %735
  %752 = fadd fast float %749, %736
  %753 = fmul fast float %702, 2.500000e-01
  %754 = fsub fast float 1.000000e+00, %645
  %755 = fmul fast float %753, %644
  %756 = fmul fast float %753, %754
  %757 = fmul fast float %753, %646
  %758 = fsub fast float %644, %755
  %759 = fadd fast float %756, %645
  %760 = fsub fast float %646, %757
  %761 = fsub fast float 0x3FE99999A0000000, %648
  %762 = fmul fast float %702, %761
  %763 = fadd fast float %762, %648
  %764 = call float @dx.op.unary.f32(i32 6, float %268)  ; FAbs(value)
  %765 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %46, i32 4)  ; CBufferLoadLegacy(handle,regIndex)
  %766 = extractvalue %dx.types.CBufRet.f32 %765, 1
  %767 = fdiv fast float %764, %766
  %768 = call float @dx.op.unary.f32(i32 7, float %767)  ; Saturate(value)
  %769 = fmul fast float %768, %768
  %770 = fmul fast float %768, 2.000000e+00
  %771 = fsub fast float 3.000000e+00, %770
  %772 = fmul fast float %769, %771
  %773 = fmul fast float %772, 4.000000e+01
  %774 = extractvalue %dx.types.CBufRet.f32 %765, 0
  %775 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %46, i32 3)  ; CBufferLoadLegacy(handle,regIndex)
  %776 = extractvalue %dx.types.CBufRet.f32 %775, 3
  %777 = fadd fast float %620, -1.000000e+00
  %778 = fsub fast float %777, %776
  %779 = fadd fast float %778, %773
  %780 = fsub fast float %774, %776
  %781 = fdiv fast float %779, %780
  %782 = call float @dx.op.unary.f32(i32 7, float %781)  ; Saturate(value)
  %783 = fmul fast float %782, %772
  %784 = fsub fast float %783, %782
  %785 = fmul fast float %784, 5.000000e-01
  %786 = fadd fast float %785, %782
  %787 = call float @dx.op.unary.f32(i32 7, float %786)  ; Saturate(value)
  %788 = extractvalue %dx.types.CBufRet.f32 %765, 2
  %789 = fmul fast float %787, %788
  %790 = fmul fast float %789, 2.500000e-01
  %791 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %46, i32 1)  ; CBufferLoadLegacy(handle,regIndex)
  %792 = extractvalue %dx.types.CBufRet.f32 %791, 0
  %793 = extractvalue %dx.types.CBufRet.f32 %791, 1
  %794 = extractvalue %dx.types.CBufRet.f32 %791, 2
  %795 = fmul fast float %790, %792
  %796 = fmul fast float %790, %793
  %797 = fmul fast float %790, %794
  %798 = fadd fast float %750, %795
  %799 = fadd fast float %751, %796
  %800 = fadd fast float %752, %797
  %801 = fmul fast float %789, 7.500000e-01
  %802 = fsub fast float %792, %798
  %803 = fsub fast float %793, %799
  %804 = fsub fast float %794, %800
  %805 = fmul fast float %802, %801
  %806 = fmul fast float %803, %801
  %807 = fmul fast float %804, %801
  %808 = call float @dx.op.dot3.f32(i32 55, float %272, float %273, float %274, float %758, float %759, float %760)  ; Dot3(ax,ay,az,bx,by,bz)
  %809 = fmul fast float %808, 2.000000e+00
  %810 = fmul fast float %809, %758
  %811 = fmul fast float %809, %759
  %812 = fmul fast float %809, %760
  %813 = fsub fast float %272, %810
  %814 = fsub fast float %274, %812
  %815 = fmul fast float %78, 0x3F847AE140000000
  %816 = call float @dx.op.unary.f32(i32 7, float %815)  ; Saturate(value)
  %817 = fmul fast float %816, 6.000000e+00
  %818 = fadd fast float %817, -1.500000e+01
  %819 = fmul fast float %818, %816
  %820 = fadd fast float %819, 1.000000e+01
  %821 = fmul fast float %816, %816
  %822 = fmul fast float %821, 0x3FC99999A0000000
  %823 = fmul fast float %822, %816
  %824 = fmul fast float %823, %820
  %825 = fadd fast float %273, 0xBFB99999A0000000
  %826 = fsub fast float %825, %811
  %827 = fadd fast float %826, %824
  %828 = fadd fast float %77, -3.000000e+02
  %829 = fadd fast float %78, -1.950000e+02
  %830 = fadd fast float %79, -1.440000e+03
  %831 = fmul fast float %828, 0x3F40624DE0000000
  %832 = fmul fast float %830, 0x3F40624DE0000000
  %833 = fsub fast float %831, %813
  %834 = fsub fast float %832, %814
  %835 = fmul fast float %833, 0x3FE8799660000000
  %836 = call float @dx.op.tertiary.f32(i32 46, float %834, float 0x3FE49D6E60000000, float %835)  ; FMad(a,b,c)
  %837 = fmul fast float %833, 0xBFE49D6E60000000
  %838 = call float @dx.op.tertiary.f32(i32 46, float %834, float 0x3FE8799660000000, float %837)  ; FMad(a,b,c)
  %839 = fdiv fast float %838, %836
  %840 = call float @dx.op.unary.f32(i32 17, float %839)  ; Atan(value)
  %841 = fadd fast float %840, 0x400921FB60000000
  %842 = fadd fast float %840, 0xC00921FB60000000
  %843 = fcmp fast olt float %836, 0.000000e+00
  %844 = fcmp fast oeq float %836, 0.000000e+00
  %845 = fcmp fast oge float %838, 0.000000e+00
  %846 = fcmp fast olt float %838, 0.000000e+00
  %847 = and i1 %843, %845
  %848 = select i1 %847, float %841, float %840
  %849 = and i1 %843, %846
  %850 = select i1 %849, float %842, float %848
  %851 = and i1 %844, %846
  %852 = and i1 %844, %845
  %853 = fadd fast float %850, 0x3FF921FB60000000
  %854 = fmul fast float %853, 0x3FC45F3060000000
  %855 = select i1 %851, float 0.000000e+00, float %854
  %856 = select i1 %852, float 5.000000e-01, float %855
  %857 = call float @dx.op.unary.f32(i32 15, float %827)  ; Acos(value)
  %858 = fmul fast float %857, 0x3FD45F3060000000
  %859 = call float @dx.op.unary.f32(i32 83, float %856)  ; DerivCoarseX(value)
  %860 = call float @dx.op.unary.f32(i32 6, float %859)  ; FAbs(value)
  %861 = call float @dx.op.unary.f32(i32 84, float %856)  ; DerivCoarseY(value)
  %862 = call float @dx.op.unary.f32(i32 6, float %861)  ; FAbs(value)
  %863 = fadd fast float %862, %860
  %864 = fcmp fast ogt float %863, 0x3FB99999A0000000
  br i1 %864, label %865, label %867

; <label>:865                                     ; preds = %600
  %866 = call float @dx.op.unary.f32(i32 22, float %856)  ; Frc(value)
  br label %867

; <label>:867                                     ; preds = %865, %600
  %868 = phi float [ %866, %865 ], [ %856, %600 ]
  %869 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %5, %dx.types.Handle %42, float %868, float %858, float undef, float undef, i32 0, i32 0, i32 undef, float %75, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %870 = extractvalue %dx.types.ResRet.f32 %869, 0
  %871 = extractvalue %dx.types.ResRet.f32 %869, 1
  %872 = extractvalue %dx.types.ResRet.f32 %869, 2
  %873 = fmul fast float %565, %565
  %874 = fmul fast float %566, %566
  %875 = fadd fast float %873, %874
  %876 = fmul fast float %567, %567
  %877 = fadd fast float %875, %876
  %878 = call float @dx.op.unary.f32(i32 24, float %877)  ; Sqrt(value)
  %879 = fadd fast float %878, -2.200000e+03
  %880 = fmul fast float %879, 0xBF647AE140000000
  %881 = call float @dx.op.unary.f32(i32 7, float %880)  ; Saturate(value)
  %882 = fmul fast float %828, %828
  %883 = fmul fast float %829, %829
  %884 = fadd fast float %882, %883
  %885 = fmul fast float %830, %830
  %886 = fadd fast float %884, %885
  %887 = call float @dx.op.unary.f32(i32 24, float %886)  ; Sqrt(value)
  %888 = fadd fast float %887, -8.000000e+02
  %889 = fmul fast float %888, 0xBF6B4E81C0000000
  %890 = call float @dx.op.unary.f32(i32 7, float %889)  ; Saturate(value)
  %891 = fmul fast float %759, 2.500000e-01
  %892 = fmul fast float %891, %881
  %893 = fmul fast float %892, %890
  %894 = fadd fast float %870, 0xBFD99999A0000000
  %895 = fmul fast float %894, 0x3FFAAAAAA0000000
  %896 = call float @dx.op.unary.f32(i32 7, float %895)  ; Saturate(value)
  %897 = fmul fast float %896, %896
  %898 = fmul fast float %897, %896
  %899 = fmul fast float %896, 6.000000e+00
  %900 = fadd fast float %899, -1.500000e+01
  %901 = fmul fast float %900, %896
  %902 = fadd fast float %901, 1.000000e+01
  %903 = fmul fast float %898, %902
  %904 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 453)  ; CBufferLoadLegacy(handle,regIndex)
  %905 = extractvalue %dx.types.CBufRet.i32 %904, 3
  %906 = fptoui float %47 to i32
  %907 = fptoui float %48 to i32
  %908 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 181)  ; CBufferLoadLegacy(handle,regIndex)
  %909 = extractvalue %dx.types.CBufRet.f32 %908, 0
  %910 = extractvalue %dx.types.CBufRet.f32 %908, 1
  %911 = extractvalue %dx.types.CBufRet.f32 %908, 2
  %912 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 182)  ; CBufferLoadLegacy(handle,regIndex)
  %913 = extractvalue %dx.types.CBufRet.f32 %912, 0
  %914 = extractvalue %dx.types.CBufRet.f32 %912, 1
  %915 = extractvalue %dx.types.CBufRet.f32 %912, 2
  %916 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 183)  ; CBufferLoadLegacy(handle,regIndex)
  %917 = extractvalue %dx.types.CBufRet.f32 %916, 0
  %918 = extractvalue %dx.types.CBufRet.f32 %916, 1
  %919 = extractvalue %dx.types.CBufRet.f32 %916, 2
  %920 = bitcast float %917 to i32
  %921 = bitcast float %918 to i32
  %922 = bitcast float %919 to i32
  %923 = extractvalue %dx.types.CBufRet.f32 %916, 3
  %924 = bitcast float %923 to i32
  %925 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 185)  ; CBufferLoadLegacy(handle,regIndex)
  %926 = extractvalue %dx.types.CBufRet.f32 %925, 0
  %927 = extractvalue %dx.types.CBufRet.f32 %925, 1
  %928 = extractvalue %dx.types.CBufRet.f32 %925, 2
  %929 = and i32 %905, 65535
  %930 = icmp eq i32 %929, 0
  %931 = icmp eq i32 %924, 0
  %932 = or i1 %930, %931
  br i1 %932, label %1214, label %933

; <label>:933                                     ; preds = %867
  %934 = fcmp fast olt float %61, %913
  %935 = fcmp fast olt float %62, %914
  %936 = fcmp fast olt float %63, %915
  %937 = fcmp fast ole float %909, %61
  %938 = fcmp fast ole float %910, %62
  %939 = fcmp fast ole float %911, %63
  %940 = and i1 %937, %934
  %941 = and i1 %938, %935
  %942 = and i1 %939, %936
  %943 = and i1 %940, %941
  %944 = and i1 %942, %943
  br i1 %944, label %945, label %967

; <label>:945                                     ; preds = %933
  %946 = uitofp i32 %920 to float
  %947 = uitofp i32 %921 to float
  %948 = uitofp i32 %922 to float
  %949 = fsub fast float %61, %909
  %950 = fsub fast float %62, %910
  %951 = fsub fast float %63, %911
  %952 = fmul fast float %946, %949
  %953 = fmul fast float %947, %950
  %954 = fmul fast float %948, %951
  %955 = fsub fast float %913, %909
  %956 = fsub fast float %914, %910
  %957 = fsub fast float %915, %911
  %958 = fdiv fast float %952, %955
  %959 = fdiv fast float %953, %956
  %960 = fdiv fast float %954, %957
  %961 = fptoui float %958 to i32
  %962 = fptoui float %959 to i32
  %963 = fptoui float %960 to i32
  %964 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %20, i32 0, i32 %961, i32 %962, i32 %963, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %965 = extractvalue %dx.types.ResRet.i32 %964, 0
  %966 = extractvalue %dx.types.ResRet.i32 %964, 1
  br label %967

; <label>:967                                     ; preds = %945, %933
  %968 = phi i32 [ %966, %945 ], [ 0, %933 ]
  %969 = phi i32 [ %965, %945 ], [ 0, %933 ]
  %970 = add i32 %969, %968
  %971 = icmp ult i32 %969, %970
  br i1 %971, label %972, label %1185

; <label>:972                                     ; preds = %967
  br label %973

; <label>:973                                     ; preds = %1153, %972
  %974 = phi float [ %1154, %1153 ], [ 0.000000e+00, %972 ]
  %975 = phi float [ %1155, %1153 ], [ 0.000000e+00, %972 ]
  %976 = phi float [ %1156, %1153 ], [ 0.000000e+00, %972 ]
  %977 = phi float [ %1157, %1153 ], [ 0.000000e+00, %972 ]
  %978 = phi float [ %1158, %1153 ], [ 0.000000e+00, %972 ]
  %979 = phi float [ %1159, %1153 ], [ 0.000000e+00, %972 ]
  %980 = phi float [ %1160, %1153 ], [ 0.000000e+00, %972 ]
  %981 = phi float [ %1161, %1153 ], [ 0.000000e+00, %972 ]
  %982 = phi float [ %1162, %1153 ], [ 0.000000e+00, %972 ]
  %983 = phi float [ %1163, %1153 ], [ 0.000000e+00, %972 ]
  %984 = phi float [ %1164, %1153 ], [ 0.000000e+00, %972 ]
  %985 = phi float [ %1165, %1153 ], [ 0.000000e+00, %972 ]
  %986 = phi i32 [ %1166, %1153 ], [ -1, %972 ]
  %987 = phi float [ %1167, %1153 ], [ 1.000000e+00, %972 ]
  %988 = phi i32 [ %1169, %1153 ], [ %969, %972 ]
  %989 = phi float [ %1168, %1153 ], [ 0.000000e+00, %972 ]
  %990 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %18, i32 %988, i32 undef)  ; BufferLoad(srv,index,wot)
  %991 = extractvalue %dx.types.ResRet.i32 %990, 0
  %992 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %991, i32 0)  ; BufferLoad(srv,index,wot)
  %993 = extractvalue %dx.types.ResRet.f32 %992, 0
  %994 = extractvalue %dx.types.ResRet.f32 %992, 1
  %995 = extractvalue %dx.types.ResRet.f32 %992, 2
  %996 = extractvalue %dx.types.ResRet.f32 %992, 3
  %997 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %991, i32 16)  ; BufferLoad(srv,index,wot)
  %998 = extractvalue %dx.types.ResRet.f32 %997, 0
  %999 = extractvalue %dx.types.ResRet.f32 %997, 1
  %1000 = extractvalue %dx.types.ResRet.f32 %997, 2
  %1001 = extractvalue %dx.types.ResRet.f32 %997, 3
  %1002 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %991, i32 32)  ; BufferLoad(srv,index,wot)
  %1003 = extractvalue %dx.types.ResRet.f32 %1002, 0
  %1004 = extractvalue %dx.types.ResRet.f32 %1002, 1
  %1005 = extractvalue %dx.types.ResRet.f32 %1002, 2
  %1006 = extractvalue %dx.types.ResRet.f32 %1002, 3
  %1007 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %9, i32 %991, i32 48)  ; BufferLoad(srv,index,wot)
  %1008 = extractvalue %dx.types.ResRet.i32 %1007, 0
  %1009 = extractvalue %dx.types.ResRet.i32 %1007, 1
  %1010 = extractvalue %dx.types.ResRet.i32 %1007, 2
  %1011 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %9, i32 %991, i32 60)  ; BufferLoad(srv,index,wot)
  %1012 = extractvalue %dx.types.ResRet.i32 %1011, 0
  %1013 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %9, i32 %991, i32 64)  ; BufferLoad(srv,index,wot)
  %1014 = extractvalue %dx.types.ResRet.i32 %1013, 0
  %1015 = extractvalue %dx.types.ResRet.i32 %1013, 1
  %1016 = extractvalue %dx.types.ResRet.i32 %1013, 2
  %1017 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %9, i32 %991, i32 76)  ; BufferLoad(srv,index,wot)
  %1018 = extractvalue %dx.types.ResRet.i32 %1017, 0
  %1019 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %991, i32 80)  ; BufferLoad(srv,index,wot)
  %1020 = extractvalue %dx.types.ResRet.f32 %1019, 0
  %1021 = extractvalue %dx.types.ResRet.f32 %1019, 1
  %1022 = extractvalue %dx.types.ResRet.f32 %1019, 2
  %1023 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %991, i32 96)  ; BufferLoad(srv,index,wot)
  %1024 = extractvalue %dx.types.ResRet.f32 %1023, 0
  %1025 = extractvalue %dx.types.ResRet.f32 %1023, 1
  %1026 = extractvalue %dx.types.ResRet.f32 %1023, 2
  %1027 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %9, i32 %991, i32 108)  ; BufferLoad(srv,index,wot)
  %1028 = extractvalue %dx.types.ResRet.f32 %1027, 0
  %1029 = and i32 %1012, %929
  %1030 = icmp eq i32 %1029, 0
  br i1 %1030, label %1153, label %1031

; <label>:1031                                    ; preds = %973
  %1032 = icmp ult i32 %1018, %986
  %1033 = fsub fast float 1.000000e+00, %989
  %1034 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1033)  ; FMax(a,b)
  %1035 = fcmp fast oeq float %1034, 0.000000e+00
  %1036 = and i1 %1032, %1035
  br i1 %1036, label %1171, label %1037

; <label>:1037                                    ; preds = %1031
  %1038 = fmul fast float %993, %61
  %1039 = call float @dx.op.tertiary.f32(i32 46, float %62, float %994, float %1038)  ; FMad(a,b,c)
  %1040 = call float @dx.op.tertiary.f32(i32 46, float %63, float %995, float %1039)  ; FMad(a,b,c)
  %1041 = fadd fast float %1040, %996
  %1042 = fmul fast float %998, %61
  %1043 = call float @dx.op.tertiary.f32(i32 46, float %62, float %999, float %1042)  ; FMad(a,b,c)
  %1044 = call float @dx.op.tertiary.f32(i32 46, float %63, float %1000, float %1043)  ; FMad(a,b,c)
  %1045 = fadd fast float %1044, %1001
  %1046 = fmul fast float %1003, %61
  %1047 = call float @dx.op.tertiary.f32(i32 46, float %62, float %1004, float %1046)  ; FMad(a,b,c)
  %1048 = call float @dx.op.tertiary.f32(i32 46, float %63, float %1005, float %1047)  ; FMad(a,b,c)
  %1049 = fadd fast float %1048, %1006
  %1050 = call float @dx.op.binary.f32(i32 35, float %1041, float -5.000000e-01)  ; FMax(a,b)
  %1051 = call float @dx.op.binary.f32(i32 35, float %1045, float -5.000000e-01)  ; FMax(a,b)
  %1052 = call float @dx.op.binary.f32(i32 35, float %1049, float -5.000000e-01)  ; FMax(a,b)
  %1053 = call float @dx.op.binary.f32(i32 36, float %1050, float 5.000000e-01)  ; FMin(a,b)
  %1054 = call float @dx.op.binary.f32(i32 36, float %1051, float 5.000000e-01)  ; FMin(a,b)
  %1055 = call float @dx.op.binary.f32(i32 36, float %1052, float 5.000000e-01)  ; FMin(a,b)
  %1056 = fcmp fast olt float %1041, 0.000000e+00
  %1057 = fcmp fast olt float %1045, 0.000000e+00
  %1058 = fcmp fast olt float %1049, 0.000000e+00
  %1059 = select i1 %1056, float %1020, float %1024
  %1060 = select i1 %1057, float %1021, float %1025
  %1061 = select i1 %1058, float %1022, float %1026
  %1062 = fsub fast float %1041, %1053
  %1063 = fsub fast float %1045, %1054
  %1064 = fsub fast float %1049, %1055
  %1065 = call float @dx.op.binary.f32(i32 35, float %1059, float 0x3F50624DE0000000)  ; FMax(a,b)
  %1066 = call float @dx.op.binary.f32(i32 35, float %1060, float 0x3F50624DE0000000)  ; FMax(a,b)
  %1067 = call float @dx.op.binary.f32(i32 35, float %1061, float 0x3F50624DE0000000)  ; FMax(a,b)
  %1068 = fdiv fast float %1062, %1065
  %1069 = fdiv fast float %1063, %1066
  %1070 = fdiv fast float %1064, %1067
  %1071 = call float @dx.op.dot3.f32(i32 55, float %1068, float %1069, float %1070, float %1068, float %1069, float %1070)  ; Dot3(ax,ay,az,bx,by,bz)
  %1072 = fcmp fast olt float %1071, 1.000000e+00
  br i1 %1072, label %1073, label %1153, !dx.controlflow.hints !80

; <label>:1073                                    ; preds = %1037
  %1074 = select i1 %1032, float %1034, float %987
  %1075 = fmul fast float %1074, %1028
  %1076 = call float @dx.op.unary.f32(i32 24, float %1071)  ; Sqrt(value)
  %1077 = fsub fast float 1.000000e+00, %1076
  %1078 = fmul fast float %1075, %1077
  %1079 = fadd fast float %1053, 5.000000e-01
  %1080 = fadd fast float %1054, 5.000000e-01
  %1081 = fadd fast float %1055, 5.000000e-01
  %1082 = uitofp i32 %1014 to float
  %1083 = uitofp i32 %1015 to float
  %1084 = uitofp i32 %1016 to float
  %1085 = fadd fast float %1082, 1.000000e+00
  %1086 = fadd fast float %1083, 1.000000e+00
  %1087 = fadd fast float %1084, 1.000000e+00
  %1088 = fmul fast float %1079, %1085
  %1089 = fmul fast float %1080, %1086
  %1090 = fmul fast float %1081, %1087
  %1091 = call float @dx.op.binary.f32(i32 35, float %1088, float 1.000000e+00)  ; FMax(a,b)
  %1092 = call float @dx.op.binary.f32(i32 35, float %1089, float 1.000000e+00)  ; FMax(a,b)
  %1093 = call float @dx.op.binary.f32(i32 35, float %1090, float 1.000000e+00)  ; FMax(a,b)
  %1094 = call float @dx.op.binary.f32(i32 36, float %1091, float %1082)  ; FMin(a,b)
  %1095 = call float @dx.op.binary.f32(i32 36, float %1092, float %1083)  ; FMin(a,b)
  %1096 = call float @dx.op.binary.f32(i32 36, float %1093, float %1084)  ; FMin(a,b)
  %1097 = uitofp i32 %1008 to float
  %1098 = uitofp i32 %1009 to float
  %1099 = uitofp i32 %1010 to float
  %1100 = fadd fast float %1097, -5.000000e-01
  %1101 = fadd fast float %1100, %1094
  %1102 = fadd fast float %1098, -5.000000e-01
  %1103 = fadd fast float %1102, %1095
  %1104 = fadd fast float %1099, -5.000000e-01
  %1105 = fadd fast float %1104, %1096
  %1106 = fmul fast float %1105, %928
  %1107 = fmul fast float %926, 5.000000e-01
  %1108 = fmul fast float %1107, %1101
  %1109 = fmul fast float %927, 5.000000e-01
  %1110 = fmul fast float %1109, %1103
  %1111 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %19, %dx.types.Handle %37, float %1108, float %1110, float %1106, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1112 = extractvalue %dx.types.ResRet.f32 %1111, 0
  %1113 = extractvalue %dx.types.ResRet.f32 %1111, 1
  %1114 = extractvalue %dx.types.ResRet.f32 %1111, 2
  %1115 = extractvalue %dx.types.ResRet.f32 %1111, 3
  %1116 = fadd fast float %1108, 5.000000e-01
  %1117 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %19, %dx.types.Handle %37, float %1116, float %1110, float %1106, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1118 = extractvalue %dx.types.ResRet.f32 %1117, 0
  %1119 = extractvalue %dx.types.ResRet.f32 %1117, 1
  %1120 = extractvalue %dx.types.ResRet.f32 %1117, 2
  %1121 = extractvalue %dx.types.ResRet.f32 %1117, 3
  %1122 = fadd fast float %1110, 5.000000e-01
  %1123 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %19, %dx.types.Handle %37, float %1108, float %1122, float %1106, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1124 = extractvalue %dx.types.ResRet.f32 %1123, 0
  %1125 = extractvalue %dx.types.ResRet.f32 %1123, 1
  %1126 = extractvalue %dx.types.ResRet.f32 %1123, 2
  %1127 = extractvalue %dx.types.ResRet.f32 %1123, 3
  %1128 = fmul fast float %1112, %1078
  %1129 = fmul fast float %1118, %1078
  %1130 = fmul fast float %1124, %1078
  %1131 = fadd fast float %1128, %977
  %1132 = fadd fast float %1129, %981
  %1133 = fadd fast float %1130, %985
  %1134 = fmul fast float %1113, %1078
  %1135 = fmul fast float %1119, %1078
  %1136 = fmul fast float %1125, %1078
  %1137 = fadd fast float %1134, %976
  %1138 = fadd fast float %1135, %980
  %1139 = fadd fast float %1136, %984
  %1140 = fmul fast float %1114, %1078
  %1141 = fmul fast float %1120, %1078
  %1142 = fmul fast float %1126, %1078
  %1143 = fadd fast float %1140, %975
  %1144 = fadd fast float %1141, %979
  %1145 = fadd fast float %1142, %983
  %1146 = fmul fast float %1115, %1078
  %1147 = fmul fast float %1121, %1078
  %1148 = fmul fast float %1127, %1078
  %1149 = fadd fast float %1146, %974
  %1150 = fadd fast float %1147, %978
  %1151 = fadd fast float %1148, %982
  %1152 = fadd fast float %1078, %989
  br label %1153

; <label>:1153                                    ; preds = %1073, %1037, %973
  %1154 = phi float [ %974, %973 ], [ %1149, %1073 ], [ %974, %1037 ]
  %1155 = phi float [ %975, %973 ], [ %1143, %1073 ], [ %975, %1037 ]
  %1156 = phi float [ %976, %973 ], [ %1137, %1073 ], [ %976, %1037 ]
  %1157 = phi float [ %977, %973 ], [ %1131, %1073 ], [ %977, %1037 ]
  %1158 = phi float [ %978, %973 ], [ %1150, %1073 ], [ %978, %1037 ]
  %1159 = phi float [ %979, %973 ], [ %1144, %1073 ], [ %979, %1037 ]
  %1160 = phi float [ %980, %973 ], [ %1138, %1073 ], [ %980, %1037 ]
  %1161 = phi float [ %981, %973 ], [ %1132, %1073 ], [ %981, %1037 ]
  %1162 = phi float [ %982, %973 ], [ %1151, %1073 ], [ %982, %1037 ]
  %1163 = phi float [ %983, %973 ], [ %1145, %1073 ], [ %983, %1037 ]
  %1164 = phi float [ %984, %973 ], [ %1139, %1073 ], [ %984, %1037 ]
  %1165 = phi float [ %985, %973 ], [ %1133, %1073 ], [ %985, %1037 ]
  %1166 = phi i32 [ %986, %973 ], [ %1018, %1073 ], [ %986, %1037 ]
  %1167 = phi float [ %987, %973 ], [ %1074, %1073 ], [ %987, %1037 ]
  %1168 = phi float [ %989, %973 ], [ %1152, %1073 ], [ %989, %1037 ]
  %1169 = add nuw i32 %988, 1
  %1170 = icmp ult i32 %1169, %970
  br i1 %1170, label %973, label %1171

; <label>:1171                                    ; preds = %1153, %1031
  %1172 = phi float [ %1154, %1153 ], [ %974, %1031 ]
  %1173 = phi float [ %1155, %1153 ], [ %975, %1031 ]
  %1174 = phi float [ %1156, %1153 ], [ %976, %1031 ]
  %1175 = phi float [ %1157, %1153 ], [ %977, %1031 ]
  %1176 = phi float [ %1158, %1153 ], [ %978, %1031 ]
  %1177 = phi float [ %1159, %1153 ], [ %979, %1031 ]
  %1178 = phi float [ %1160, %1153 ], [ %980, %1031 ]
  %1179 = phi float [ %1161, %1153 ], [ %981, %1031 ]
  %1180 = phi float [ %1162, %1153 ], [ %982, %1031 ]
  %1181 = phi float [ %1163, %1153 ], [ %983, %1031 ]
  %1182 = phi float [ %1164, %1153 ], [ %984, %1031 ]
  %1183 = phi float [ %1165, %1153 ], [ %985, %1031 ]
  %1184 = phi float [ %1168, %1153 ], [ %989, %1031 ]
  br label %1185

; <label>:1185                                    ; preds = %1171, %967
  %1186 = phi float [ 0.000000e+00, %967 ], [ %1172, %1171 ]
  %1187 = phi float [ 0.000000e+00, %967 ], [ %1173, %1171 ]
  %1188 = phi float [ 0.000000e+00, %967 ], [ %1174, %1171 ]
  %1189 = phi float [ 0.000000e+00, %967 ], [ %1175, %1171 ]
  %1190 = phi float [ 0.000000e+00, %967 ], [ %1176, %1171 ]
  %1191 = phi float [ 0.000000e+00, %967 ], [ %1177, %1171 ]
  %1192 = phi float [ 0.000000e+00, %967 ], [ %1178, %1171 ]
  %1193 = phi float [ 0.000000e+00, %967 ], [ %1179, %1171 ]
  %1194 = phi float [ 0.000000e+00, %967 ], [ %1180, %1171 ]
  %1195 = phi float [ 0.000000e+00, %967 ], [ %1181, %1171 ]
  %1196 = phi float [ 0.000000e+00, %967 ], [ %1182, %1171 ]
  %1197 = phi float [ 0.000000e+00, %967 ], [ %1183, %1171 ]
  %1198 = phi float [ 0.000000e+00, %967 ], [ %1184, %1171 ]
  %1199 = call float @dx.op.binary.f32(i32 36, float %1198, float 1.000000e+00)  ; FMin(a,b)
  %1200 = call float @dx.op.binary.f32(i32 35, float %1198, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %1201 = fdiv fast float %1199, %1200
  %1202 = fmul fast float %1201, %1189
  %1203 = fmul fast float %1201, %1193
  %1204 = fmul fast float %1201, %1197
  %1205 = fmul fast float %1201, %1188
  %1206 = fmul fast float %1201, %1192
  %1207 = fmul fast float %1201, %1196
  %1208 = fmul fast float %1201, %1187
  %1209 = fmul fast float %1201, %1191
  %1210 = fmul fast float %1201, %1195
  %1211 = fmul fast float %1201, %1186
  %1212 = fmul fast float %1201, %1190
  %1213 = fmul fast float %1201, %1194
  br label %1214

; <label>:1214                                    ; preds = %1185, %867
  %1215 = phi float [ 0.000000e+00, %867 ], [ %1211, %1185 ]
  %1216 = phi float [ 0.000000e+00, %867 ], [ %1208, %1185 ]
  %1217 = phi float [ 0.000000e+00, %867 ], [ %1205, %1185 ]
  %1218 = phi float [ 0.000000e+00, %867 ], [ %1202, %1185 ]
  %1219 = phi float [ 0.000000e+00, %867 ], [ %1212, %1185 ]
  %1220 = phi float [ 0.000000e+00, %867 ], [ %1209, %1185 ]
  %1221 = phi float [ 0.000000e+00, %867 ], [ %1206, %1185 ]
  %1222 = phi float [ 0.000000e+00, %867 ], [ %1203, %1185 ]
  %1223 = phi float [ 0.000000e+00, %867 ], [ %1213, %1185 ]
  %1224 = phi float [ 0.000000e+00, %867 ], [ %1210, %1185 ]
  %1225 = phi float [ 0.000000e+00, %867 ], [ %1207, %1185 ]
  %1226 = phi float [ 0.000000e+00, %867 ], [ %1204, %1185 ]
  %1227 = phi float [ 0.000000e+00, %867 ], [ %1199, %1185 ]
  %1228 = fsub fast float 1.000000e+00, %1227
  %1229 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1228)  ; FMax(a,b)
  %1230 = fcmp fast ogt float %1229, 0.000000e+00
  br i1 %1230, label %1231, label %2723, !dx.controlflow.hints !81

; <label>:1231                                    ; preds = %1214
  %1232 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 409)  ; CBufferLoadLegacy(handle,regIndex)
  %1233 = extractvalue %dx.types.CBufRet.f32 %1232, 0
  %1234 = extractvalue %dx.types.CBufRet.f32 %1232, 1
  %1235 = extractvalue %dx.types.CBufRet.f32 %1232, 2
  %1236 = extractvalue %dx.types.CBufRet.f32 %1232, 3
  %1237 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 410)  ; CBufferLoadLegacy(handle,regIndex)
  %1238 = extractvalue %dx.types.CBufRet.f32 %1237, 0
  %1239 = extractvalue %dx.types.CBufRet.f32 %1237, 1
  %1240 = extractvalue %dx.types.CBufRet.f32 %1237, 2
  %1241 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 411)  ; CBufferLoadLegacy(handle,regIndex)
  %1242 = extractvalue %dx.types.CBufRet.f32 %1241, 3
  %1243 = bitcast float %1242 to i32
  %1244 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 413)  ; CBufferLoadLegacy(handle,regIndex)
  %1245 = extractvalue %dx.types.CBufRet.f32 %1244, 0
  %1246 = extractvalue %dx.types.CBufRet.f32 %1244, 1
  %1247 = extractvalue %dx.types.CBufRet.f32 %1244, 2
  %1248 = extractvalue %dx.types.CBufRet.f32 %1244, 3
  %1249 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 414)  ; CBufferLoadLegacy(handle,regIndex)
  %1250 = extractvalue %dx.types.CBufRet.f32 %1249, 0
  %1251 = extractvalue %dx.types.CBufRet.f32 %1249, 1
  %1252 = extractvalue %dx.types.CBufRet.f32 %1249, 2
  %1253 = extractvalue %dx.types.CBufRet.f32 %1249, 3
  %1254 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 415)  ; CBufferLoadLegacy(handle,regIndex)
  %1255 = extractvalue %dx.types.CBufRet.f32 %1254, 0
  %1256 = extractvalue %dx.types.CBufRet.f32 %1254, 1
  %1257 = extractvalue %dx.types.CBufRet.f32 %1254, 2
  %1258 = extractvalue %dx.types.CBufRet.f32 %1254, 3
  %1259 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 416)  ; CBufferLoadLegacy(handle,regIndex)
  %1260 = extractvalue %dx.types.CBufRet.f32 %1259, 0
  %1261 = extractvalue %dx.types.CBufRet.f32 %1259, 1
  %1262 = bitcast float %1261 to i32
  %1263 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 412)  ; CBufferLoadLegacy(handle,regIndex)
  %1264 = extractvalue %dx.types.CBufRet.f32 %1263, 0
  %1265 = extractvalue %dx.types.CBufRet.f32 %1263, 1
  %1266 = extractvalue %dx.types.CBufRet.f32 %1263, 2
  %1267 = extractvalue %dx.types.CBufRet.f32 %1263, 3
  %1268 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 0
  store float %1245, float* %1268, align 4
  %1269 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 1
  store float %1246, float* %1269, align 4
  %1270 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 2
  store float %1247, float* %1270, align 4
  %1271 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 3
  store float %1248, float* %1271, align 4
  %1272 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 4
  store float %1250, float* %1272, align 4
  %1273 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 5
  store float %1251, float* %1273, align 4
  %1274 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 6
  store float %1252, float* %1274, align 4
  %1275 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 7
  store float %1253, float* %1275, align 4
  %1276 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 8
  store float %1255, float* %1276, align 4
  %1277 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 9
  store float %1256, float* %1277, align 4
  %1278 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 10
  store float %1257, float* %1278, align 4
  %1279 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 11
  store float %1258, float* %1279, align 4
  %1280 = and i32 %1243, %929
  %1281 = icmp eq i32 %1280, 0
  br i1 %1281, label %1561, label %1282

; <label>:1282                                    ; preds = %1231
  %1283 = fsub fast float %61, %1233
  %1284 = fsub fast float %62, %1234
  %1285 = fsub fast float %63, %1235
  %1286 = fdiv fast float %1283, %1236
  %1287 = fdiv fast float %1284, %1236
  %1288 = fdiv fast float %1285, %1236
  %1289 = fcmp fast olt float %1286, %1238
  %1290 = fcmp fast olt float %1287, %1239
  %1291 = fcmp fast olt float %1288, %1240
  %1292 = fcmp fast oge float %1286, 0.000000e+00
  %1293 = fcmp fast oge float %1287, 0.000000e+00
  %1294 = fcmp fast oge float %1288, 0.000000e+00
  %1295 = and i1 %1292, %1289
  %1296 = and i1 %1293, %1290
  %1297 = and i1 %1294, %1291
  %1298 = and i1 %1295, %1296
  %1299 = and i1 %1298, %1297
  br i1 %1299, label %1300, label %1306

; <label>:1300                                    ; preds = %1282
  %1301 = fptoui float %1286 to i32
  %1302 = fptoui float %1287 to i32
  %1303 = fptoui float %1288 to i32
  %1304 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %16, i32 0, i32 %1301, i32 %1302, i32 %1303, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1305 = extractvalue %dx.types.ResRet.i32 %1304, 0
  br label %1306

; <label>:1306                                    ; preds = %1300, %1282
  %1307 = phi i32 [ %1305, %1300 ], [ 65535, %1282 ]
  %1308 = icmp eq i32 %1307, 65535
  br i1 %1308, label %1561, label %1309, !dx.controlflow.hints !82

; <label>:1309                                    ; preds = %1306
  %1310 = fmul fast float %267, %267
  %1311 = fmul fast float %268, %268
  %1312 = fadd fast float %1310, %1311
  %1313 = fmul fast float %269, %269
  %1314 = fadd fast float %1312, %1313
  %1315 = call float @dx.op.unary.f32(i32 24, float %1314)  ; Sqrt(value)
  %1316 = and i32 %1262, 1
  %1317 = icmp eq i32 %1316, 0
  br i1 %1317, label %1388, label %1318

; <label>:1318                                    ; preds = %1309
  %1319 = fcmp fast ogt float %1315, %1245
  %1320 = fcmp fast ogt float %1315, %1246
  %1321 = fcmp fast ogt float %1315, %1247
  %1322 = fcmp fast ogt float %1315, %1248
  %1323 = uitofp i1 %1319 to float
  %1324 = uitofp i1 %1320 to float
  %1325 = uitofp i1 %1321 to float
  %1326 = uitofp i1 %1322 to float
  %1327 = call float @dx.op.dot4.f32(i32 56, float %1323, float %1324, float %1325, float %1326, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1328 = fptosi float %1327 to i32
  %1329 = fcmp fast ogt float %1315, %1250
  %1330 = fcmp fast ogt float %1315, %1251
  %1331 = fcmp fast ogt float %1315, %1252
  %1332 = fcmp fast ogt float %1315, %1253
  %1333 = uitofp i1 %1329 to float
  %1334 = uitofp i1 %1330 to float
  %1335 = uitofp i1 %1331 to float
  %1336 = uitofp i1 %1332 to float
  %1337 = call float @dx.op.dot4.f32(i32 56, float %1333, float %1334, float %1335, float %1336, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1338 = fptosi float %1337 to i32
  %1339 = add nsw i32 %1338, %1328
  %1340 = fcmp fast ogt float %1315, %1255
  %1341 = fcmp fast ogt float %1315, %1256
  %1342 = fcmp fast ogt float %1315, %1257
  %1343 = fcmp fast ogt float %1315, %1258
  %1344 = uitofp i1 %1340 to float
  %1345 = uitofp i1 %1341 to float
  %1346 = uitofp i1 %1342 to float
  %1347 = uitofp i1 %1343 to float
  %1348 = call float @dx.op.dot4.f32(i32 56, float %1344, float %1345, float %1346, float %1347, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1349 = fptosi float %1348 to i32
  %1350 = add nsw i32 %1339, %1349
  %1351 = call i32 @dx.op.binary.i32(i32 38, i32 %1350, i32 9)  ; IMin(a,b)
  %1352 = add nsw i32 %1351, -1
  %1353 = ashr i32 %1351, 2
  %1354 = call i32 @dx.op.binary.i32(i32 38, i32 %1353, i32 2)  ; IMin(a,b)
  %1355 = and i32 %1351, 3
  %1356 = mul i32 %1354, 4
  %1357 = add i32 %1355, %1356
  %1358 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 %1357
  %1359 = load float, float* %1358, align 4, !tbaa !83, !noalias !87
  %1360 = icmp slt i32 %1351, 1
  br i1 %1360, label %1369, label %1361

; <label>:1361                                    ; preds = %1318
  %1362 = ashr i32 %1352, 2
  %1363 = call i32 @dx.op.binary.i32(i32 38, i32 %1362, i32 2)  ; IMin(a,b)
  %1364 = and i32 %1352, 3
  %1365 = mul i32 %1363, 4
  %1366 = add i32 %1364, %1365
  %1367 = getelementptr [12 x float], [12 x float]* %69, i32 0, i32 %1366
  %1368 = load float, float* %1367, align 4, !tbaa !83, !noalias !87
  br label %1369

; <label>:1369                                    ; preds = %1361, %1318
  %1370 = phi float [ %1368, %1361 ], [ 0.000000e+00, %1318 ]
  %1371 = fsub fast float %1315, %1370
  %1372 = fsub fast float %1359, %1370
  %1373 = call float @dx.op.binary.f32(i32 35, float %1372, float 0x3F1A36E2E0000000)  ; FMax(a,b)
  %1374 = fdiv fast float %1371, %1373
  %1375 = call i32 @dx.op.binary.i32(i32 37, i32 %1352, i32 0)  ; IMax(a,b)
  %1376 = and i32 %906, 127
  %1377 = and i32 %907, 127
  %1378 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %8, i32 0, i32 %1376, i32 %1377, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1379 = extractvalue %dx.types.ResRet.f32 %1378, 0
  %1380 = fmul fast float %1374, %1260
  %1381 = call float @dx.op.unary.f32(i32 7, float %1380)  ; Saturate(value)
  %1382 = fmul fast float %1381, 2.000000e+00
  %1383 = fsub fast float 3.000000e+00, %1382
  %1384 = fmul fast float %1381, %1381
  %1385 = fmul fast float %1384, %1383
  %1386 = fcmp fast ogt float %1385, %1379
  %1387 = select i1 %1386, i32 %1351, i32 %1375
  br label %1388

; <label>:1388                                    ; preds = %1369, %1309
  %1389 = phi i32 [ %1387, %1369 ], [ 0, %1309 ]
  %1390 = sub nsw i32 9, %1389
  %1391 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1307, i32 0)  ; BufferLoad(srv,index,wot)
  %1392 = extractvalue %dx.types.ResRet.i32 %1391, 0
  %1393 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1307, i32 4)  ; BufferLoad(srv,index,wot)
  %1394 = extractvalue %dx.types.ResRet.i32 %1393, 0
  %1395 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1307, i32 8)  ; BufferLoad(srv,index,wot)
  %1396 = extractvalue %dx.types.ResRet.i32 %1395, 0
  %1397 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1307, i32 12)  ; BufferLoad(srv,index,wot)
  %1398 = extractvalue %dx.types.ResRet.i32 %1397, 0
  %1399 = call i32 @dx.op.binary.i32(i32 40, i32 %1392, i32 -1)  ; UMin(a,b)
  %1400 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %13, i32 %1394, i32 0)  ; BufferLoad(srv,index,wot)
  %1401 = extractvalue %dx.types.ResRet.f32 %1400, 3
  %1402 = call i32 @dx.op.binary.i32(i32 40, i32 %1390, i32 %1399)  ; UMin(a,b)
  %1403 = extractvalue %dx.types.ResRet.f32 %1400, 2
  %1404 = extractvalue %dx.types.ResRet.f32 %1400, 1
  %1405 = extractvalue %dx.types.ResRet.f32 %1400, 0
  %1406 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1396, i32 4)  ; BufferLoad(srv,index,wot)
  %1407 = extractvalue %dx.types.ResRet.i32 %1406, 0
  %1408 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1396, i32 12)  ; BufferLoad(srv,index,wot)
  %1409 = extractvalue %dx.types.ResRet.i32 %1408, 0
  %1410 = fsub fast float %61, %1405
  %1411 = fsub fast float %62, %1404
  %1412 = fsub fast float %63, %1403
  %1413 = fdiv fast float %1410, %1401
  %1414 = fdiv fast float %1411, %1401
  %1415 = fdiv fast float %1412, %1401
  %1416 = call float @dx.op.unary.f32(i32 7, float %1413)  ; Saturate(value)
  %1417 = call float @dx.op.unary.f32(i32 7, float %1414)  ; Saturate(value)
  %1418 = call float @dx.op.unary.f32(i32 7, float %1415)  ; Saturate(value)
  %1419 = icmp eq i32 %1402, 0
  br i1 %1419, label %1494, label %1420

; <label>:1420                                    ; preds = %1388
  %1421 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1396, i32 8)  ; BufferLoad(srv,index,wot)
  %1422 = extractvalue %dx.types.ResRet.i32 %1421, 0
  %1423 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1396, i32 0)  ; BufferLoad(srv,index,wot)
  %1424 = extractvalue %dx.types.ResRet.i32 %1423, 0
  br label %1425

; <label>:1425                                    ; preds = %1481, %1420
  %1426 = phi i32 [ %1486, %1481 ], [ 0, %1420 ]
  %1427 = phi float [ %1461, %1481 ], [ %1416, %1420 ]
  %1428 = phi float [ %1462, %1481 ], [ %1417, %1420 ]
  %1429 = phi float [ %1463, %1481 ], [ %1418, %1420 ]
  %1430 = phi i32 [ %1460, %1481 ], [ %1409, %1420 ]
  %1431 = phi i32 [ %1483, %1481 ], [ %1422, %1420 ]
  %1432 = phi i32 [ %1458, %1481 ], [ %1407, %1420 ]
  %1433 = phi i32 [ %1485, %1481 ], [ %1424, %1420 ]
  %1434 = fmul fast float %1427, 3.000000e+00
  %1435 = fmul fast float %1428, 3.000000e+00
  %1436 = fmul fast float %1429, 3.000000e+00
  %1437 = call float @dx.op.unary.f32(i32 27, float %1434)  ; Round_ni(value)
  %1438 = call float @dx.op.unary.f32(i32 27, float %1435)  ; Round_ni(value)
  %1439 = call float @dx.op.unary.f32(i32 27, float %1436)  ; Round_ni(value)
  %1440 = fptoui float %1437 to i32
  %1441 = fptoui float %1438 to i32
  %1442 = fptoui float %1439 to i32
  %1443 = mul i32 %1441, 3
  %1444 = add i32 %1443, %1440
  %1445 = mul i32 %1442, 9
  %1446 = add i32 %1444, %1445
  %1447 = and i32 %1446, 31
  %1448 = shl i32 1, %1447
  %1449 = and i32 %1448, %1431
  %1450 = icmp eq i32 %1449, 0
  br i1 %1450, label %1488, label %1451

; <label>:1451                                    ; preds = %1425
  %1452 = add i32 %1448, -1
  %1453 = and i32 %1452, %1431
  %1454 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %1453)  ; Countbits(value)
  %1455 = add i32 %1433, %1396
  %1456 = add i32 %1455, %1454
  %1457 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1456, i32 4)  ; BufferLoad(srv,index,wot)
  %1458 = extractvalue %dx.types.ResRet.i32 %1457, 0
  %1459 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1456, i32 12)  ; BufferLoad(srv,index,wot)
  %1460 = extractvalue %dx.types.ResRet.i32 %1459, 0
  %1461 = call float @dx.op.unary.f32(i32 22, float %1434)  ; Frc(value)
  %1462 = call float @dx.op.unary.f32(i32 22, float %1435)  ; Frc(value)
  %1463 = call float @dx.op.unary.f32(i32 22, float %1436)  ; Frc(value)
  %1464 = fmul fast float %1461, 3.000000e+00
  %1465 = fmul fast float %1462, 3.000000e+00
  %1466 = fmul fast float %1463, 3.000000e+00
  %1467 = call float @dx.op.unary.f32(i32 27, float %1464)  ; Round_ni(value)
  %1468 = call float @dx.op.unary.f32(i32 27, float %1465)  ; Round_ni(value)
  %1469 = call float @dx.op.unary.f32(i32 27, float %1466)  ; Round_ni(value)
  %1470 = fptoui float %1467 to i32
  %1471 = fptoui float %1468 to i32
  %1472 = fptoui float %1469 to i32
  %1473 = mul i32 %1471, 3
  %1474 = add i32 %1473, %1470
  %1475 = mul i32 %1472, 9
  %1476 = add i32 %1474, %1475
  %1477 = and i32 %1476, 31
  %1478 = shl i32 1, %1477
  %1479 = and i32 %1478, %1460
  %1480 = icmp eq i32 %1479, 0
  br i1 %1480, label %1488, label %1481

; <label>:1481                                    ; preds = %1451
  %1482 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1456, i32 8)  ; BufferLoad(srv,index,wot)
  %1483 = extractvalue %dx.types.ResRet.i32 %1482, 0
  %1484 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1456, i32 0)  ; BufferLoad(srv,index,wot)
  %1485 = extractvalue %dx.types.ResRet.i32 %1484, 0
  %1486 = add nuw i32 %1426, 1
  %1487 = icmp ult i32 %1486, %1402
  br i1 %1487, label %1425, label %1488, !llvm.loop !104

; <label>:1488                                    ; preds = %1481, %1451, %1425
  %1489 = phi float [ %1461, %1481 ], [ %1427, %1425 ], [ %1427, %1451 ]
  %1490 = phi float [ %1462, %1481 ], [ %1428, %1425 ], [ %1428, %1451 ]
  %1491 = phi float [ %1463, %1481 ], [ %1429, %1425 ], [ %1429, %1451 ]
  %1492 = phi i32 [ %1460, %1481 ], [ %1430, %1425 ], [ %1430, %1451 ]
  %1493 = phi i32 [ %1458, %1481 ], [ %1432, %1425 ], [ %1432, %1451 ]
  br label %1494

; <label>:1494                                    ; preds = %1488, %1388
  %1495 = phi float [ %1416, %1388 ], [ %1489, %1488 ]
  %1496 = phi float [ %1417, %1388 ], [ %1490, %1488 ]
  %1497 = phi float [ %1418, %1388 ], [ %1491, %1488 ]
  %1498 = phi i32 [ %1409, %1388 ], [ %1492, %1488 ]
  %1499 = phi i32 [ %1407, %1388 ], [ %1493, %1488 ]
  %1500 = fmul fast float %1495, 3.000000e+00
  %1501 = fmul fast float %1496, 3.000000e+00
  %1502 = fmul fast float %1497, 3.000000e+00
  %1503 = call float @dx.op.unary.f32(i32 27, float %1500)  ; Round_ni(value)
  %1504 = call float @dx.op.unary.f32(i32 27, float %1501)  ; Round_ni(value)
  %1505 = call float @dx.op.unary.f32(i32 27, float %1502)  ; Round_ni(value)
  %1506 = fptoui float %1503 to i32
  %1507 = fptoui float %1504 to i32
  %1508 = fptoui float %1505 to i32
  %1509 = mul i32 %1507, 3
  %1510 = add i32 %1509, %1506
  %1511 = mul i32 %1508, 9
  %1512 = add i32 %1510, %1511
  %1513 = and i32 %1512, 31
  %1514 = shl i32 1, %1513
  %1515 = add i32 %1514, -1
  %1516 = and i32 %1515, %1498
  %1517 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %1516)  ; Countbits(value)
  %1518 = add i32 %1499, %1398
  %1519 = add i32 %1518, %1517
  %1520 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %17, i32 %1519, i32 undef)  ; BufferLoad(srv,index,wot)
  %1521 = extractvalue %dx.types.ResRet.i32 %1520, 0
  %1522 = and i32 %1521, 1023
  %1523 = lshr i32 %1521, 10
  %1524 = and i32 %1523, 1023
  %1525 = lshr i32 %1521, 20
  %1526 = and i32 %1525, 1023
  %1527 = uitofp i32 %1522 to float
  %1528 = uitofp i32 %1524 to float
  %1529 = uitofp i32 %1526 to float
  %1530 = call float @dx.op.unary.f32(i32 22, float %1500)  ; Frc(value)
  %1531 = call float @dx.op.unary.f32(i32 22, float %1501)  ; Frc(value)
  %1532 = call float @dx.op.unary.f32(i32 22, float %1502)  ; Frc(value)
  %1533 = fadd fast float %1530, 5.000000e-01
  %1534 = fadd fast float %1533, %1527
  %1535 = fadd fast float %1531, 5.000000e-01
  %1536 = fadd fast float %1535, %1528
  %1537 = fadd fast float %1532, 5.000000e-01
  %1538 = fadd fast float %1537, %1529
  %1539 = fmul fast float %1538, %1266
  %1540 = fmul fast float %1264, 5.000000e-01
  %1541 = fmul fast float %1540, %1534
  %1542 = fmul fast float %1265, 5.000000e-01
  %1543 = fmul fast float %1542, %1536
  %1544 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1541, float %1543, float %1539, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1545 = extractvalue %dx.types.ResRet.f32 %1544, 0
  %1546 = extractvalue %dx.types.ResRet.f32 %1544, 1
  %1547 = extractvalue %dx.types.ResRet.f32 %1544, 2
  %1548 = extractvalue %dx.types.ResRet.f32 %1544, 3
  %1549 = fadd fast float %1541, 5.000000e-01
  %1550 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1549, float %1543, float %1539, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1551 = extractvalue %dx.types.ResRet.f32 %1550, 0
  %1552 = extractvalue %dx.types.ResRet.f32 %1550, 1
  %1553 = extractvalue %dx.types.ResRet.f32 %1550, 2
  %1554 = extractvalue %dx.types.ResRet.f32 %1550, 3
  %1555 = fadd fast float %1543, 5.000000e-01
  %1556 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1541, float %1555, float %1539, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1557 = extractvalue %dx.types.ResRet.f32 %1556, 0
  %1558 = extractvalue %dx.types.ResRet.f32 %1556, 1
  %1559 = extractvalue %dx.types.ResRet.f32 %1556, 2
  %1560 = extractvalue %dx.types.ResRet.f32 %1556, 3
  br label %1561

; <label>:1561                                    ; preds = %1494, %1306, %1231
  %1562 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1548, %1494 ]
  %1563 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1547, %1494 ]
  %1564 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1546, %1494 ]
  %1565 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1545, %1494 ]
  %1566 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1554, %1494 ]
  %1567 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1553, %1494 ]
  %1568 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1552, %1494 ]
  %1569 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1551, %1494 ]
  %1570 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1560, %1494 ]
  %1571 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1559, %1494 ]
  %1572 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1558, %1494 ]
  %1573 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ %1557, %1494 ]
  %1574 = phi float [ 0.000000e+00, %1306 ], [ 0.000000e+00, %1231 ], [ 1.000000e+00, %1494 ]
  %1575 = fsub fast float 1.000000e+00, %1574
  %1576 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1575)  ; FMax(a,b)
  %1577 = fcmp fast ogt float %1576, 0.000000e+00
  %1578 = fcmp fast ogt float %1267, 0.000000e+00
  %1579 = and i1 %1578, %1577
  br i1 %1579, label %1580, label %2640

; <label>:1580                                    ; preds = %1561
  %1581 = fsub fast float %61, %1233
  %1582 = fsub fast float %62, %1234
  %1583 = fsub fast float %63, %1235
  %1584 = fdiv fast float %1581, %1236
  %1585 = fdiv fast float %1582, %1236
  %1586 = fdiv fast float %1583, %1236
  %1587 = call float @dx.op.unary.f32(i32 27, float %1584)  ; Round_ni(value)
  %1588 = call float @dx.op.unary.f32(i32 27, float %1585)  ; Round_ni(value)
  %1589 = call float @dx.op.unary.f32(i32 27, float %1586)  ; Round_ni(value)
  %1590 = fadd fast float %1587, 1.000000e+00
  %1591 = fadd fast float %1588, 1.000000e+00
  %1592 = fadd fast float %1589, 1.000000e+00
  %1593 = fmul fast float %1590, %1236
  %1594 = fmul fast float %1591, %1236
  %1595 = fmul fast float %1592, %1236
  %1596 = fadd fast float %1593, %1233
  %1597 = fadd fast float %1594, %1234
  %1598 = fadd fast float %1595, %1235
  %1599 = fmul fast float %1267, %1236
  %1600 = fadd fast float %1599, %61
  %1601 = fsub fast float %1600, %1596
  %1602 = fadd fast float %1599, %62
  %1603 = fsub fast float %1602, %1597
  %1604 = fadd fast float %1599, %63
  %1605 = fsub fast float %1604, %1598
  %1606 = fdiv fast float %1601, %1599
  %1607 = fdiv fast float %1603, %1599
  %1608 = fdiv fast float %1605, %1599
  %1609 = call float @dx.op.unary.f32(i32 7, float %1606)  ; Saturate(value)
  %1610 = call float @dx.op.unary.f32(i32 7, float %1607)  ; Saturate(value)
  %1611 = call float @dx.op.unary.f32(i32 7, float %1608)  ; Saturate(value)
  %1612 = fcmp fast ogt float %1609, 0.000000e+00
  br i1 %1612, label %1613, label %1944

; <label>:1613                                    ; preds = %1580
  %1614 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 0
  store float %1245, float* %1614, align 4
  %1615 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 1
  store float %1246, float* %1615, align 4
  %1616 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 2
  store float %1247, float* %1616, align 4
  %1617 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 3
  store float %1248, float* %1617, align 4
  %1618 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 4
  store float %1250, float* %1618, align 4
  %1619 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 5
  store float %1251, float* %1619, align 4
  %1620 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 6
  store float %1252, float* %1620, align 4
  %1621 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 7
  store float %1253, float* %1621, align 4
  %1622 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 8
  store float %1255, float* %1622, align 4
  %1623 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 9
  store float %1256, float* %1623, align 4
  %1624 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 10
  store float %1257, float* %1624, align 4
  %1625 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 11
  store float %1258, float* %1625, align 4
  br i1 %1281, label %1901, label %1626

; <label>:1626                                    ; preds = %1613
  %1627 = fdiv fast float %1593, %1236
  %1628 = fcmp fast olt float %1627, %1238
  %1629 = fcmp fast olt float %1585, %1239
  %1630 = fcmp fast olt float %1586, %1240
  %1631 = fcmp fast oge float %1627, 0.000000e+00
  %1632 = fcmp fast oge float %1585, 0.000000e+00
  %1633 = fcmp fast oge float %1586, 0.000000e+00
  %1634 = and i1 %1631, %1628
  %1635 = and i1 %1632, %1629
  %1636 = and i1 %1633, %1630
  %1637 = and i1 %1635, %1634
  %1638 = and i1 %1636, %1637
  br i1 %1638, label %1639, label %1645

; <label>:1639                                    ; preds = %1626
  %1640 = fptoui float %1627 to i32
  %1641 = fptoui float %1585 to i32
  %1642 = fptoui float %1586 to i32
  %1643 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %16, i32 0, i32 %1640, i32 %1641, i32 %1642, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1644 = extractvalue %dx.types.ResRet.i32 %1643, 0
  br label %1645

; <label>:1645                                    ; preds = %1639, %1626
  %1646 = phi i32 [ %1644, %1639 ], [ 65535, %1626 ]
  %1647 = icmp eq i32 %1646, 65535
  br i1 %1647, label %1901, label %1648, !dx.controlflow.hints !82

; <label>:1648                                    ; preds = %1645
  %1649 = fsub fast float %77, %1596
  %1650 = fmul fast float %1649, %1649
  %1651 = fmul fast float %268, %268
  %1652 = fmul fast float %269, %269
  %1653 = fadd fast float %1652, %1651
  %1654 = fadd fast float %1653, %1650
  %1655 = call float @dx.op.unary.f32(i32 24, float %1654)  ; Sqrt(value)
  %1656 = and i32 %1262, 1
  %1657 = icmp eq i32 %1656, 0
  br i1 %1657, label %1728, label %1658

; <label>:1658                                    ; preds = %1648
  %1659 = fcmp fast ogt float %1655, %1245
  %1660 = fcmp fast ogt float %1655, %1246
  %1661 = fcmp fast ogt float %1655, %1247
  %1662 = fcmp fast ogt float %1655, %1248
  %1663 = uitofp i1 %1659 to float
  %1664 = uitofp i1 %1660 to float
  %1665 = uitofp i1 %1661 to float
  %1666 = uitofp i1 %1662 to float
  %1667 = call float @dx.op.dot4.f32(i32 56, float %1663, float %1664, float %1665, float %1666, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1668 = fptosi float %1667 to i32
  %1669 = fcmp fast ogt float %1655, %1250
  %1670 = fcmp fast ogt float %1655, %1251
  %1671 = fcmp fast ogt float %1655, %1252
  %1672 = fcmp fast ogt float %1655, %1253
  %1673 = uitofp i1 %1669 to float
  %1674 = uitofp i1 %1670 to float
  %1675 = uitofp i1 %1671 to float
  %1676 = uitofp i1 %1672 to float
  %1677 = call float @dx.op.dot4.f32(i32 56, float %1673, float %1674, float %1675, float %1676, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1678 = fptosi float %1677 to i32
  %1679 = add nsw i32 %1678, %1668
  %1680 = fcmp fast ogt float %1655, %1255
  %1681 = fcmp fast ogt float %1655, %1256
  %1682 = fcmp fast ogt float %1655, %1257
  %1683 = fcmp fast ogt float %1655, %1258
  %1684 = uitofp i1 %1680 to float
  %1685 = uitofp i1 %1681 to float
  %1686 = uitofp i1 %1682 to float
  %1687 = uitofp i1 %1683 to float
  %1688 = call float @dx.op.dot4.f32(i32 56, float %1684, float %1685, float %1686, float %1687, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1689 = fptosi float %1688 to i32
  %1690 = add nsw i32 %1679, %1689
  %1691 = call i32 @dx.op.binary.i32(i32 38, i32 %1690, i32 9)  ; IMin(a,b)
  %1692 = add nsw i32 %1691, -1
  %1693 = ashr i32 %1691, 2
  %1694 = call i32 @dx.op.binary.i32(i32 38, i32 %1693, i32 2)  ; IMin(a,b)
  %1695 = and i32 %1691, 3
  %1696 = mul i32 %1694, 4
  %1697 = add i32 %1695, %1696
  %1698 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %1697
  %1699 = load float, float* %1698, align 4, !tbaa !83, !noalias !106
  %1700 = icmp slt i32 %1691, 1
  br i1 %1700, label %1709, label %1701

; <label>:1701                                    ; preds = %1658
  %1702 = ashr i32 %1692, 2
  %1703 = call i32 @dx.op.binary.i32(i32 38, i32 %1702, i32 2)  ; IMin(a,b)
  %1704 = and i32 %1692, 3
  %1705 = mul i32 %1703, 4
  %1706 = add i32 %1704, %1705
  %1707 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %1706
  %1708 = load float, float* %1707, align 4, !tbaa !83, !noalias !106
  br label %1709

; <label>:1709                                    ; preds = %1701, %1658
  %1710 = phi float [ %1708, %1701 ], [ 0.000000e+00, %1658 ]
  %1711 = fsub fast float %1655, %1710
  %1712 = fsub fast float %1699, %1710
  %1713 = call float @dx.op.binary.f32(i32 35, float %1712, float 0x3F1A36E2E0000000)  ; FMax(a,b)
  %1714 = fdiv fast float %1711, %1713
  %1715 = call i32 @dx.op.binary.i32(i32 37, i32 %1692, i32 0)  ; IMax(a,b)
  %1716 = and i32 %906, 127
  %1717 = and i32 %907, 127
  %1718 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %8, i32 0, i32 %1716, i32 %1717, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1719 = extractvalue %dx.types.ResRet.f32 %1718, 0
  %1720 = fmul fast float %1714, %1260
  %1721 = call float @dx.op.unary.f32(i32 7, float %1720)  ; Saturate(value)
  %1722 = fmul fast float %1721, 2.000000e+00
  %1723 = fsub fast float 3.000000e+00, %1722
  %1724 = fmul fast float %1721, %1721
  %1725 = fmul fast float %1724, %1723
  %1726 = fcmp fast ogt float %1725, %1719
  %1727 = select i1 %1726, i32 %1691, i32 %1715
  br label %1728

; <label>:1728                                    ; preds = %1709, %1648
  %1729 = phi i32 [ %1727, %1709 ], [ 0, %1648 ]
  %1730 = sub nsw i32 9, %1729
  %1731 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1646, i32 0)  ; BufferLoad(srv,index,wot)
  %1732 = extractvalue %dx.types.ResRet.i32 %1731, 0
  %1733 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1646, i32 4)  ; BufferLoad(srv,index,wot)
  %1734 = extractvalue %dx.types.ResRet.i32 %1733, 0
  %1735 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1646, i32 8)  ; BufferLoad(srv,index,wot)
  %1736 = extractvalue %dx.types.ResRet.i32 %1735, 0
  %1737 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1646, i32 12)  ; BufferLoad(srv,index,wot)
  %1738 = extractvalue %dx.types.ResRet.i32 %1737, 0
  %1739 = call i32 @dx.op.binary.i32(i32 40, i32 %1732, i32 -1)  ; UMin(a,b)
  %1740 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %13, i32 %1734, i32 0)  ; BufferLoad(srv,index,wot)
  %1741 = extractvalue %dx.types.ResRet.f32 %1740, 3
  %1742 = call i32 @dx.op.binary.i32(i32 40, i32 %1730, i32 %1739)  ; UMin(a,b)
  %1743 = extractvalue %dx.types.ResRet.f32 %1740, 2
  %1744 = extractvalue %dx.types.ResRet.f32 %1740, 1
  %1745 = extractvalue %dx.types.ResRet.f32 %1740, 0
  %1746 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1736, i32 4)  ; BufferLoad(srv,index,wot)
  %1747 = extractvalue %dx.types.ResRet.i32 %1746, 0
  %1748 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1736, i32 12)  ; BufferLoad(srv,index,wot)
  %1749 = extractvalue %dx.types.ResRet.i32 %1748, 0
  %1750 = fsub fast float %1596, %1745
  %1751 = fsub fast float %62, %1744
  %1752 = fsub fast float %63, %1743
  %1753 = fdiv fast float %1750, %1741
  %1754 = fdiv fast float %1751, %1741
  %1755 = fdiv fast float %1752, %1741
  %1756 = call float @dx.op.unary.f32(i32 7, float %1753)  ; Saturate(value)
  %1757 = call float @dx.op.unary.f32(i32 7, float %1754)  ; Saturate(value)
  %1758 = call float @dx.op.unary.f32(i32 7, float %1755)  ; Saturate(value)
  %1759 = icmp eq i32 %1742, 0
  br i1 %1759, label %1834, label %1760

; <label>:1760                                    ; preds = %1728
  %1761 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1736, i32 8)  ; BufferLoad(srv,index,wot)
  %1762 = extractvalue %dx.types.ResRet.i32 %1761, 0
  %1763 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1736, i32 0)  ; BufferLoad(srv,index,wot)
  %1764 = extractvalue %dx.types.ResRet.i32 %1763, 0
  br label %1765

; <label>:1765                                    ; preds = %1821, %1760
  %1766 = phi i32 [ %1826, %1821 ], [ 0, %1760 ]
  %1767 = phi float [ %1801, %1821 ], [ %1756, %1760 ]
  %1768 = phi float [ %1802, %1821 ], [ %1757, %1760 ]
  %1769 = phi float [ %1803, %1821 ], [ %1758, %1760 ]
  %1770 = phi i32 [ %1800, %1821 ], [ %1749, %1760 ]
  %1771 = phi i32 [ %1823, %1821 ], [ %1762, %1760 ]
  %1772 = phi i32 [ %1798, %1821 ], [ %1747, %1760 ]
  %1773 = phi i32 [ %1825, %1821 ], [ %1764, %1760 ]
  %1774 = fmul fast float %1767, 3.000000e+00
  %1775 = fmul fast float %1768, 3.000000e+00
  %1776 = fmul fast float %1769, 3.000000e+00
  %1777 = call float @dx.op.unary.f32(i32 27, float %1774)  ; Round_ni(value)
  %1778 = call float @dx.op.unary.f32(i32 27, float %1775)  ; Round_ni(value)
  %1779 = call float @dx.op.unary.f32(i32 27, float %1776)  ; Round_ni(value)
  %1780 = fptoui float %1777 to i32
  %1781 = fptoui float %1778 to i32
  %1782 = fptoui float %1779 to i32
  %1783 = mul i32 %1781, 3
  %1784 = add i32 %1783, %1780
  %1785 = mul i32 %1782, 9
  %1786 = add i32 %1784, %1785
  %1787 = and i32 %1786, 31
  %1788 = shl i32 1, %1787
  %1789 = and i32 %1788, %1771
  %1790 = icmp eq i32 %1789, 0
  br i1 %1790, label %1828, label %1791

; <label>:1791                                    ; preds = %1765
  %1792 = add i32 %1788, -1
  %1793 = and i32 %1792, %1771
  %1794 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %1793)  ; Countbits(value)
  %1795 = add i32 %1773, %1736
  %1796 = add i32 %1795, %1794
  %1797 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1796, i32 4)  ; BufferLoad(srv,index,wot)
  %1798 = extractvalue %dx.types.ResRet.i32 %1797, 0
  %1799 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1796, i32 12)  ; BufferLoad(srv,index,wot)
  %1800 = extractvalue %dx.types.ResRet.i32 %1799, 0
  %1801 = call float @dx.op.unary.f32(i32 22, float %1774)  ; Frc(value)
  %1802 = call float @dx.op.unary.f32(i32 22, float %1775)  ; Frc(value)
  %1803 = call float @dx.op.unary.f32(i32 22, float %1776)  ; Frc(value)
  %1804 = fmul fast float %1801, 3.000000e+00
  %1805 = fmul fast float %1802, 3.000000e+00
  %1806 = fmul fast float %1803, 3.000000e+00
  %1807 = call float @dx.op.unary.f32(i32 27, float %1804)  ; Round_ni(value)
  %1808 = call float @dx.op.unary.f32(i32 27, float %1805)  ; Round_ni(value)
  %1809 = call float @dx.op.unary.f32(i32 27, float %1806)  ; Round_ni(value)
  %1810 = fptoui float %1807 to i32
  %1811 = fptoui float %1808 to i32
  %1812 = fptoui float %1809 to i32
  %1813 = mul i32 %1811, 3
  %1814 = add i32 %1813, %1810
  %1815 = mul i32 %1812, 9
  %1816 = add i32 %1814, %1815
  %1817 = and i32 %1816, 31
  %1818 = shl i32 1, %1817
  %1819 = and i32 %1818, %1800
  %1820 = icmp eq i32 %1819, 0
  br i1 %1820, label %1828, label %1821

; <label>:1821                                    ; preds = %1791
  %1822 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1796, i32 8)  ; BufferLoad(srv,index,wot)
  %1823 = extractvalue %dx.types.ResRet.i32 %1822, 0
  %1824 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %1796, i32 0)  ; BufferLoad(srv,index,wot)
  %1825 = extractvalue %dx.types.ResRet.i32 %1824, 0
  %1826 = add nuw i32 %1766, 1
  %1827 = icmp ult i32 %1826, %1742
  br i1 %1827, label %1765, label %1828, !llvm.loop !104

; <label>:1828                                    ; preds = %1821, %1791, %1765
  %1829 = phi float [ %1801, %1821 ], [ %1767, %1765 ], [ %1767, %1791 ]
  %1830 = phi float [ %1802, %1821 ], [ %1768, %1765 ], [ %1768, %1791 ]
  %1831 = phi float [ %1803, %1821 ], [ %1769, %1765 ], [ %1769, %1791 ]
  %1832 = phi i32 [ %1800, %1821 ], [ %1770, %1765 ], [ %1770, %1791 ]
  %1833 = phi i32 [ %1798, %1821 ], [ %1772, %1765 ], [ %1772, %1791 ]
  br label %1834

; <label>:1834                                    ; preds = %1828, %1728
  %1835 = phi float [ %1756, %1728 ], [ %1829, %1828 ]
  %1836 = phi float [ %1757, %1728 ], [ %1830, %1828 ]
  %1837 = phi float [ %1758, %1728 ], [ %1831, %1828 ]
  %1838 = phi i32 [ %1749, %1728 ], [ %1832, %1828 ]
  %1839 = phi i32 [ %1747, %1728 ], [ %1833, %1828 ]
  %1840 = fmul fast float %1835, 3.000000e+00
  %1841 = fmul fast float %1836, 3.000000e+00
  %1842 = fmul fast float %1837, 3.000000e+00
  %1843 = call float @dx.op.unary.f32(i32 27, float %1840)  ; Round_ni(value)
  %1844 = call float @dx.op.unary.f32(i32 27, float %1841)  ; Round_ni(value)
  %1845 = call float @dx.op.unary.f32(i32 27, float %1842)  ; Round_ni(value)
  %1846 = fptoui float %1843 to i32
  %1847 = fptoui float %1844 to i32
  %1848 = fptoui float %1845 to i32
  %1849 = mul i32 %1847, 3
  %1850 = add i32 %1849, %1846
  %1851 = mul i32 %1848, 9
  %1852 = add i32 %1850, %1851
  %1853 = and i32 %1852, 31
  %1854 = shl i32 1, %1853
  %1855 = add i32 %1854, -1
  %1856 = and i32 %1855, %1838
  %1857 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %1856)  ; Countbits(value)
  %1858 = add i32 %1839, %1738
  %1859 = add i32 %1858, %1857
  %1860 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %17, i32 %1859, i32 undef)  ; BufferLoad(srv,index,wot)
  %1861 = extractvalue %dx.types.ResRet.i32 %1860, 0
  %1862 = and i32 %1861, 1023
  %1863 = lshr i32 %1861, 10
  %1864 = and i32 %1863, 1023
  %1865 = lshr i32 %1861, 20
  %1866 = and i32 %1865, 1023
  %1867 = uitofp i32 %1862 to float
  %1868 = uitofp i32 %1864 to float
  %1869 = uitofp i32 %1866 to float
  %1870 = call float @dx.op.unary.f32(i32 22, float %1840)  ; Frc(value)
  %1871 = call float @dx.op.unary.f32(i32 22, float %1841)  ; Frc(value)
  %1872 = call float @dx.op.unary.f32(i32 22, float %1842)  ; Frc(value)
  %1873 = fadd fast float %1870, 5.000000e-01
  %1874 = fadd fast float %1873, %1867
  %1875 = fadd fast float %1871, 5.000000e-01
  %1876 = fadd fast float %1875, %1868
  %1877 = fadd fast float %1872, 5.000000e-01
  %1878 = fadd fast float %1877, %1869
  %1879 = fmul fast float %1878, %1266
  %1880 = fmul fast float %1264, 5.000000e-01
  %1881 = fmul fast float %1880, %1874
  %1882 = fmul fast float %1265, 5.000000e-01
  %1883 = fmul fast float %1882, %1876
  %1884 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1881, float %1883, float %1879, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1885 = extractvalue %dx.types.ResRet.f32 %1884, 0
  %1886 = extractvalue %dx.types.ResRet.f32 %1884, 1
  %1887 = extractvalue %dx.types.ResRet.f32 %1884, 2
  %1888 = extractvalue %dx.types.ResRet.f32 %1884, 3
  %1889 = fadd fast float %1881, 5.000000e-01
  %1890 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1889, float %1883, float %1879, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1891 = extractvalue %dx.types.ResRet.f32 %1890, 0
  %1892 = extractvalue %dx.types.ResRet.f32 %1890, 1
  %1893 = extractvalue %dx.types.ResRet.f32 %1890, 2
  %1894 = extractvalue %dx.types.ResRet.f32 %1890, 3
  %1895 = fadd fast float %1883, 5.000000e-01
  %1896 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %1881, float %1895, float %1879, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %1897 = extractvalue %dx.types.ResRet.f32 %1896, 0
  %1898 = extractvalue %dx.types.ResRet.f32 %1896, 1
  %1899 = extractvalue %dx.types.ResRet.f32 %1896, 2
  %1900 = extractvalue %dx.types.ResRet.f32 %1896, 3
  br label %1901

; <label>:1901                                    ; preds = %1834, %1645, %1613
  %1902 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1888, %1834 ]
  %1903 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1887, %1834 ]
  %1904 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1886, %1834 ]
  %1905 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1885, %1834 ]
  %1906 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1894, %1834 ]
  %1907 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1893, %1834 ]
  %1908 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1892, %1834 ]
  %1909 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1891, %1834 ]
  %1910 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1900, %1834 ]
  %1911 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1899, %1834 ]
  %1912 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1898, %1834 ]
  %1913 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ %1897, %1834 ]
  %1914 = phi float [ 0.000000e+00, %1645 ], [ 0.000000e+00, %1613 ], [ 1.000000e+00, %1834 ]
  %1915 = call float @dx.op.binary.f32(i32 36, float %1609, float %1576)  ; FMin(a,b)
  %1916 = fmul fast float %1915, %1905
  %1917 = fmul fast float %1915, %1909
  %1918 = fmul fast float %1915, %1913
  %1919 = fadd fast float %1916, %1565
  %1920 = fadd fast float %1917, %1569
  %1921 = fadd fast float %1918, %1573
  %1922 = fmul fast float %1915, %1904
  %1923 = fmul fast float %1915, %1908
  %1924 = fmul fast float %1915, %1912
  %1925 = fadd fast float %1922, %1564
  %1926 = fadd fast float %1923, %1568
  %1927 = fadd fast float %1924, %1572
  %1928 = fmul fast float %1915, %1903
  %1929 = fmul fast float %1915, %1907
  %1930 = fmul fast float %1915, %1911
  %1931 = fadd fast float %1928, %1563
  %1932 = fadd fast float %1929, %1567
  %1933 = fadd fast float %1930, %1571
  %1934 = fmul fast float %1915, %1902
  %1935 = fmul fast float %1915, %1906
  %1936 = fmul fast float %1915, %1910
  %1937 = fadd fast float %1934, %1562
  %1938 = fadd fast float %1935, %1566
  %1939 = fadd fast float %1936, %1570
  %1940 = fmul fast float %1915, %1914
  %1941 = fadd fast float %1940, %1574
  %1942 = fsub fast float 1.000000e+00, %1941
  %1943 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1942)  ; FMax(a,b)
  br label %1944

; <label>:1944                                    ; preds = %1901, %1580
  %1945 = phi float [ %1937, %1901 ], [ %1562, %1580 ]
  %1946 = phi float [ %1931, %1901 ], [ %1563, %1580 ]
  %1947 = phi float [ %1925, %1901 ], [ %1564, %1580 ]
  %1948 = phi float [ %1919, %1901 ], [ %1565, %1580 ]
  %1949 = phi float [ %1938, %1901 ], [ %1566, %1580 ]
  %1950 = phi float [ %1932, %1901 ], [ %1567, %1580 ]
  %1951 = phi float [ %1926, %1901 ], [ %1568, %1580 ]
  %1952 = phi float [ %1920, %1901 ], [ %1569, %1580 ]
  %1953 = phi float [ %1939, %1901 ], [ %1570, %1580 ]
  %1954 = phi float [ %1933, %1901 ], [ %1571, %1580 ]
  %1955 = phi float [ %1927, %1901 ], [ %1572, %1580 ]
  %1956 = phi float [ %1921, %1901 ], [ %1573, %1580 ]
  %1957 = phi float [ %1943, %1901 ], [ %1576, %1580 ]
  %1958 = phi float [ %1941, %1901 ], [ %1574, %1580 ]
  %1959 = fcmp fast ogt float %1957, 0.000000e+00
  %1960 = fcmp fast ogt float %1610, 0.000000e+00
  %1961 = and i1 %1960, %1959
  br i1 %1961, label %1962, label %2293

; <label>:1962                                    ; preds = %1944
  %1963 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 0
  store float %1245, float* %1963, align 4
  %1964 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 1
  store float %1246, float* %1964, align 4
  %1965 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 2
  store float %1247, float* %1965, align 4
  %1966 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 3
  store float %1248, float* %1966, align 4
  %1967 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 4
  store float %1250, float* %1967, align 4
  %1968 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 5
  store float %1251, float* %1968, align 4
  %1969 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 6
  store float %1252, float* %1969, align 4
  %1970 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 7
  store float %1253, float* %1970, align 4
  %1971 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 8
  store float %1255, float* %1971, align 4
  %1972 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 9
  store float %1256, float* %1972, align 4
  %1973 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 10
  store float %1257, float* %1973, align 4
  %1974 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 11
  store float %1258, float* %1974, align 4
  br i1 %1281, label %2250, label %1975

; <label>:1975                                    ; preds = %1962
  %1976 = fdiv fast float %1594, %1236
  %1977 = fcmp fast olt float %1584, %1238
  %1978 = fcmp fast olt float %1976, %1239
  %1979 = fcmp fast olt float %1586, %1240
  %1980 = fcmp fast oge float %1584, 0.000000e+00
  %1981 = fcmp fast oge float %1976, 0.000000e+00
  %1982 = fcmp fast oge float %1586, 0.000000e+00
  %1983 = and i1 %1980, %1977
  %1984 = and i1 %1981, %1978
  %1985 = and i1 %1982, %1979
  %1986 = and i1 %1983, %1984
  %1987 = and i1 %1985, %1986
  br i1 %1987, label %1988, label %1994

; <label>:1988                                    ; preds = %1975
  %1989 = fptoui float %1584 to i32
  %1990 = fptoui float %1976 to i32
  %1991 = fptoui float %1586 to i32
  %1992 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %16, i32 0, i32 %1989, i32 %1990, i32 %1991, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1993 = extractvalue %dx.types.ResRet.i32 %1992, 0
  br label %1994

; <label>:1994                                    ; preds = %1988, %1975
  %1995 = phi i32 [ %1993, %1988 ], [ 65535, %1975 ]
  %1996 = icmp eq i32 %1995, 65535
  br i1 %1996, label %2250, label %1997, !dx.controlflow.hints !82

; <label>:1997                                    ; preds = %1994
  %1998 = fsub fast float %78, %1597
  %1999 = fmul fast float %267, %267
  %2000 = fmul fast float %1998, %1998
  %2001 = fmul fast float %269, %269
  %2002 = fadd fast float %2001, %1999
  %2003 = fadd fast float %2002, %2000
  %2004 = call float @dx.op.unary.f32(i32 24, float %2003)  ; Sqrt(value)
  %2005 = and i32 %1262, 1
  %2006 = icmp eq i32 %2005, 0
  br i1 %2006, label %2077, label %2007

; <label>:2007                                    ; preds = %1997
  %2008 = fcmp fast ogt float %2004, %1245
  %2009 = fcmp fast ogt float %2004, %1246
  %2010 = fcmp fast ogt float %2004, %1247
  %2011 = fcmp fast ogt float %2004, %1248
  %2012 = uitofp i1 %2008 to float
  %2013 = uitofp i1 %2009 to float
  %2014 = uitofp i1 %2010 to float
  %2015 = uitofp i1 %2011 to float
  %2016 = call float @dx.op.dot4.f32(i32 56, float %2012, float %2013, float %2014, float %2015, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2017 = fptosi float %2016 to i32
  %2018 = fcmp fast ogt float %2004, %1250
  %2019 = fcmp fast ogt float %2004, %1251
  %2020 = fcmp fast ogt float %2004, %1252
  %2021 = fcmp fast ogt float %2004, %1253
  %2022 = uitofp i1 %2018 to float
  %2023 = uitofp i1 %2019 to float
  %2024 = uitofp i1 %2020 to float
  %2025 = uitofp i1 %2021 to float
  %2026 = call float @dx.op.dot4.f32(i32 56, float %2022, float %2023, float %2024, float %2025, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2027 = fptosi float %2026 to i32
  %2028 = add nsw i32 %2027, %2017
  %2029 = fcmp fast ogt float %2004, %1255
  %2030 = fcmp fast ogt float %2004, %1256
  %2031 = fcmp fast ogt float %2004, %1257
  %2032 = fcmp fast ogt float %2004, %1258
  %2033 = uitofp i1 %2029 to float
  %2034 = uitofp i1 %2030 to float
  %2035 = uitofp i1 %2031 to float
  %2036 = uitofp i1 %2032 to float
  %2037 = call float @dx.op.dot4.f32(i32 56, float %2033, float %2034, float %2035, float %2036, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2038 = fptosi float %2037 to i32
  %2039 = add nsw i32 %2028, %2038
  %2040 = call i32 @dx.op.binary.i32(i32 38, i32 %2039, i32 9)  ; IMin(a,b)
  %2041 = add nsw i32 %2040, -1
  %2042 = ashr i32 %2040, 2
  %2043 = call i32 @dx.op.binary.i32(i32 38, i32 %2042, i32 2)  ; IMin(a,b)
  %2044 = and i32 %2040, 3
  %2045 = mul i32 %2043, 4
  %2046 = add i32 %2044, %2045
  %2047 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %2046
  %2048 = load float, float* %2047, align 4, !tbaa !83, !noalias !106
  %2049 = icmp slt i32 %2040, 1
  br i1 %2049, label %2058, label %2050

; <label>:2050                                    ; preds = %2007
  %2051 = ashr i32 %2041, 2
  %2052 = call i32 @dx.op.binary.i32(i32 38, i32 %2051, i32 2)  ; IMin(a,b)
  %2053 = and i32 %2041, 3
  %2054 = mul i32 %2052, 4
  %2055 = add i32 %2053, %2054
  %2056 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %2055
  %2057 = load float, float* %2056, align 4, !tbaa !83, !noalias !106
  br label %2058

; <label>:2058                                    ; preds = %2050, %2007
  %2059 = phi float [ %2057, %2050 ], [ 0.000000e+00, %2007 ]
  %2060 = fsub fast float %2004, %2059
  %2061 = fsub fast float %2048, %2059
  %2062 = call float @dx.op.binary.f32(i32 35, float %2061, float 0x3F1A36E2E0000000)  ; FMax(a,b)
  %2063 = fdiv fast float %2060, %2062
  %2064 = call i32 @dx.op.binary.i32(i32 37, i32 %2041, i32 0)  ; IMax(a,b)
  %2065 = and i32 %906, 127
  %2066 = and i32 %907, 127
  %2067 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %8, i32 0, i32 %2065, i32 %2066, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2068 = extractvalue %dx.types.ResRet.f32 %2067, 0
  %2069 = fmul fast float %2063, %1260
  %2070 = call float @dx.op.unary.f32(i32 7, float %2069)  ; Saturate(value)
  %2071 = fmul fast float %2070, 2.000000e+00
  %2072 = fsub fast float 3.000000e+00, %2071
  %2073 = fmul fast float %2070, %2070
  %2074 = fmul fast float %2073, %2072
  %2075 = fcmp fast ogt float %2074, %2068
  %2076 = select i1 %2075, i32 %2040, i32 %2064
  br label %2077

; <label>:2077                                    ; preds = %2058, %1997
  %2078 = phi i32 [ %2076, %2058 ], [ 0, %1997 ]
  %2079 = sub nsw i32 9, %2078
  %2080 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1995, i32 0)  ; BufferLoad(srv,index,wot)
  %2081 = extractvalue %dx.types.ResRet.i32 %2080, 0
  %2082 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1995, i32 4)  ; BufferLoad(srv,index,wot)
  %2083 = extractvalue %dx.types.ResRet.i32 %2082, 0
  %2084 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1995, i32 8)  ; BufferLoad(srv,index,wot)
  %2085 = extractvalue %dx.types.ResRet.i32 %2084, 0
  %2086 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %1995, i32 12)  ; BufferLoad(srv,index,wot)
  %2087 = extractvalue %dx.types.ResRet.i32 %2086, 0
  %2088 = call i32 @dx.op.binary.i32(i32 40, i32 %2081, i32 -1)  ; UMin(a,b)
  %2089 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %13, i32 %2083, i32 0)  ; BufferLoad(srv,index,wot)
  %2090 = extractvalue %dx.types.ResRet.f32 %2089, 3
  %2091 = call i32 @dx.op.binary.i32(i32 40, i32 %2079, i32 %2088)  ; UMin(a,b)
  %2092 = extractvalue %dx.types.ResRet.f32 %2089, 2
  %2093 = extractvalue %dx.types.ResRet.f32 %2089, 1
  %2094 = extractvalue %dx.types.ResRet.f32 %2089, 0
  %2095 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2085, i32 4)  ; BufferLoad(srv,index,wot)
  %2096 = extractvalue %dx.types.ResRet.i32 %2095, 0
  %2097 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2085, i32 12)  ; BufferLoad(srv,index,wot)
  %2098 = extractvalue %dx.types.ResRet.i32 %2097, 0
  %2099 = fsub fast float %61, %2094
  %2100 = fsub fast float %1597, %2093
  %2101 = fsub fast float %63, %2092
  %2102 = fdiv fast float %2099, %2090
  %2103 = fdiv fast float %2100, %2090
  %2104 = fdiv fast float %2101, %2090
  %2105 = call float @dx.op.unary.f32(i32 7, float %2102)  ; Saturate(value)
  %2106 = call float @dx.op.unary.f32(i32 7, float %2103)  ; Saturate(value)
  %2107 = call float @dx.op.unary.f32(i32 7, float %2104)  ; Saturate(value)
  %2108 = icmp eq i32 %2091, 0
  br i1 %2108, label %2183, label %2109

; <label>:2109                                    ; preds = %2077
  %2110 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2085, i32 8)  ; BufferLoad(srv,index,wot)
  %2111 = extractvalue %dx.types.ResRet.i32 %2110, 0
  %2112 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2085, i32 0)  ; BufferLoad(srv,index,wot)
  %2113 = extractvalue %dx.types.ResRet.i32 %2112, 0
  br label %2114

; <label>:2114                                    ; preds = %2170, %2109
  %2115 = phi i32 [ %2175, %2170 ], [ 0, %2109 ]
  %2116 = phi float [ %2150, %2170 ], [ %2105, %2109 ]
  %2117 = phi float [ %2151, %2170 ], [ %2106, %2109 ]
  %2118 = phi float [ %2152, %2170 ], [ %2107, %2109 ]
  %2119 = phi i32 [ %2149, %2170 ], [ %2098, %2109 ]
  %2120 = phi i32 [ %2172, %2170 ], [ %2111, %2109 ]
  %2121 = phi i32 [ %2147, %2170 ], [ %2096, %2109 ]
  %2122 = phi i32 [ %2174, %2170 ], [ %2113, %2109 ]
  %2123 = fmul fast float %2116, 3.000000e+00
  %2124 = fmul fast float %2117, 3.000000e+00
  %2125 = fmul fast float %2118, 3.000000e+00
  %2126 = call float @dx.op.unary.f32(i32 27, float %2123)  ; Round_ni(value)
  %2127 = call float @dx.op.unary.f32(i32 27, float %2124)  ; Round_ni(value)
  %2128 = call float @dx.op.unary.f32(i32 27, float %2125)  ; Round_ni(value)
  %2129 = fptoui float %2126 to i32
  %2130 = fptoui float %2127 to i32
  %2131 = fptoui float %2128 to i32
  %2132 = mul i32 %2130, 3
  %2133 = add i32 %2132, %2129
  %2134 = mul i32 %2131, 9
  %2135 = add i32 %2133, %2134
  %2136 = and i32 %2135, 31
  %2137 = shl i32 1, %2136
  %2138 = and i32 %2137, %2120
  %2139 = icmp eq i32 %2138, 0
  br i1 %2139, label %2177, label %2140

; <label>:2140                                    ; preds = %2114
  %2141 = add i32 %2137, -1
  %2142 = and i32 %2141, %2120
  %2143 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %2142)  ; Countbits(value)
  %2144 = add i32 %2122, %2085
  %2145 = add i32 %2144, %2143
  %2146 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2145, i32 4)  ; BufferLoad(srv,index,wot)
  %2147 = extractvalue %dx.types.ResRet.i32 %2146, 0
  %2148 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2145, i32 12)  ; BufferLoad(srv,index,wot)
  %2149 = extractvalue %dx.types.ResRet.i32 %2148, 0
  %2150 = call float @dx.op.unary.f32(i32 22, float %2123)  ; Frc(value)
  %2151 = call float @dx.op.unary.f32(i32 22, float %2124)  ; Frc(value)
  %2152 = call float @dx.op.unary.f32(i32 22, float %2125)  ; Frc(value)
  %2153 = fmul fast float %2150, 3.000000e+00
  %2154 = fmul fast float %2151, 3.000000e+00
  %2155 = fmul fast float %2152, 3.000000e+00
  %2156 = call float @dx.op.unary.f32(i32 27, float %2153)  ; Round_ni(value)
  %2157 = call float @dx.op.unary.f32(i32 27, float %2154)  ; Round_ni(value)
  %2158 = call float @dx.op.unary.f32(i32 27, float %2155)  ; Round_ni(value)
  %2159 = fptoui float %2156 to i32
  %2160 = fptoui float %2157 to i32
  %2161 = fptoui float %2158 to i32
  %2162 = mul i32 %2160, 3
  %2163 = add i32 %2162, %2159
  %2164 = mul i32 %2161, 9
  %2165 = add i32 %2163, %2164
  %2166 = and i32 %2165, 31
  %2167 = shl i32 1, %2166
  %2168 = and i32 %2167, %2149
  %2169 = icmp eq i32 %2168, 0
  br i1 %2169, label %2177, label %2170

; <label>:2170                                    ; preds = %2140
  %2171 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2145, i32 8)  ; BufferLoad(srv,index,wot)
  %2172 = extractvalue %dx.types.ResRet.i32 %2171, 0
  %2173 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2145, i32 0)  ; BufferLoad(srv,index,wot)
  %2174 = extractvalue %dx.types.ResRet.i32 %2173, 0
  %2175 = add nuw i32 %2115, 1
  %2176 = icmp ult i32 %2175, %2091
  br i1 %2176, label %2114, label %2177, !llvm.loop !104

; <label>:2177                                    ; preds = %2170, %2140, %2114
  %2178 = phi float [ %2150, %2170 ], [ %2116, %2114 ], [ %2116, %2140 ]
  %2179 = phi float [ %2151, %2170 ], [ %2117, %2114 ], [ %2117, %2140 ]
  %2180 = phi float [ %2152, %2170 ], [ %2118, %2114 ], [ %2118, %2140 ]
  %2181 = phi i32 [ %2149, %2170 ], [ %2119, %2114 ], [ %2119, %2140 ]
  %2182 = phi i32 [ %2147, %2170 ], [ %2121, %2114 ], [ %2121, %2140 ]
  br label %2183

; <label>:2183                                    ; preds = %2177, %2077
  %2184 = phi float [ %2105, %2077 ], [ %2178, %2177 ]
  %2185 = phi float [ %2106, %2077 ], [ %2179, %2177 ]
  %2186 = phi float [ %2107, %2077 ], [ %2180, %2177 ]
  %2187 = phi i32 [ %2098, %2077 ], [ %2181, %2177 ]
  %2188 = phi i32 [ %2096, %2077 ], [ %2182, %2177 ]
  %2189 = fmul fast float %2184, 3.000000e+00
  %2190 = fmul fast float %2185, 3.000000e+00
  %2191 = fmul fast float %2186, 3.000000e+00
  %2192 = call float @dx.op.unary.f32(i32 27, float %2189)  ; Round_ni(value)
  %2193 = call float @dx.op.unary.f32(i32 27, float %2190)  ; Round_ni(value)
  %2194 = call float @dx.op.unary.f32(i32 27, float %2191)  ; Round_ni(value)
  %2195 = fptoui float %2192 to i32
  %2196 = fptoui float %2193 to i32
  %2197 = fptoui float %2194 to i32
  %2198 = mul i32 %2196, 3
  %2199 = add i32 %2198, %2195
  %2200 = mul i32 %2197, 9
  %2201 = add i32 %2199, %2200
  %2202 = and i32 %2201, 31
  %2203 = shl i32 1, %2202
  %2204 = add i32 %2203, -1
  %2205 = and i32 %2204, %2187
  %2206 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %2205)  ; Countbits(value)
  %2207 = add i32 %2188, %2087
  %2208 = add i32 %2207, %2206
  %2209 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %17, i32 %2208, i32 undef)  ; BufferLoad(srv,index,wot)
  %2210 = extractvalue %dx.types.ResRet.i32 %2209, 0
  %2211 = and i32 %2210, 1023
  %2212 = lshr i32 %2210, 10
  %2213 = and i32 %2212, 1023
  %2214 = lshr i32 %2210, 20
  %2215 = and i32 %2214, 1023
  %2216 = uitofp i32 %2211 to float
  %2217 = uitofp i32 %2213 to float
  %2218 = uitofp i32 %2215 to float
  %2219 = call float @dx.op.unary.f32(i32 22, float %2189)  ; Frc(value)
  %2220 = call float @dx.op.unary.f32(i32 22, float %2190)  ; Frc(value)
  %2221 = call float @dx.op.unary.f32(i32 22, float %2191)  ; Frc(value)
  %2222 = fadd fast float %2219, 5.000000e-01
  %2223 = fadd fast float %2222, %2216
  %2224 = fadd fast float %2220, 5.000000e-01
  %2225 = fadd fast float %2224, %2217
  %2226 = fadd fast float %2221, 5.000000e-01
  %2227 = fadd fast float %2226, %2218
  %2228 = fmul fast float %2227, %1266
  %2229 = fmul fast float %1264, 5.000000e-01
  %2230 = fmul fast float %2229, %2223
  %2231 = fmul fast float %1265, 5.000000e-01
  %2232 = fmul fast float %2231, %2225
  %2233 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2230, float %2232, float %2228, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2234 = extractvalue %dx.types.ResRet.f32 %2233, 0
  %2235 = extractvalue %dx.types.ResRet.f32 %2233, 1
  %2236 = extractvalue %dx.types.ResRet.f32 %2233, 2
  %2237 = extractvalue %dx.types.ResRet.f32 %2233, 3
  %2238 = fadd fast float %2230, 5.000000e-01
  %2239 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2238, float %2232, float %2228, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2240 = extractvalue %dx.types.ResRet.f32 %2239, 0
  %2241 = extractvalue %dx.types.ResRet.f32 %2239, 1
  %2242 = extractvalue %dx.types.ResRet.f32 %2239, 2
  %2243 = extractvalue %dx.types.ResRet.f32 %2239, 3
  %2244 = fadd fast float %2232, 5.000000e-01
  %2245 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2230, float %2244, float %2228, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2246 = extractvalue %dx.types.ResRet.f32 %2245, 0
  %2247 = extractvalue %dx.types.ResRet.f32 %2245, 1
  %2248 = extractvalue %dx.types.ResRet.f32 %2245, 2
  %2249 = extractvalue %dx.types.ResRet.f32 %2245, 3
  br label %2250

; <label>:2250                                    ; preds = %2183, %1994, %1962
  %2251 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2237, %2183 ]
  %2252 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2236, %2183 ]
  %2253 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2235, %2183 ]
  %2254 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2234, %2183 ]
  %2255 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2243, %2183 ]
  %2256 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2242, %2183 ]
  %2257 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2241, %2183 ]
  %2258 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2240, %2183 ]
  %2259 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2249, %2183 ]
  %2260 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2248, %2183 ]
  %2261 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2247, %2183 ]
  %2262 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ %2246, %2183 ]
  %2263 = phi float [ 0.000000e+00, %1994 ], [ 0.000000e+00, %1962 ], [ 1.000000e+00, %2183 ]
  %2264 = call float @dx.op.binary.f32(i32 36, float %1610, float %1957)  ; FMin(a,b)
  %2265 = fmul fast float %2264, %2254
  %2266 = fmul fast float %2264, %2258
  %2267 = fmul fast float %2264, %2262
  %2268 = fadd fast float %2265, %1948
  %2269 = fadd fast float %2266, %1952
  %2270 = fadd fast float %2267, %1956
  %2271 = fmul fast float %2264, %2253
  %2272 = fmul fast float %2264, %2257
  %2273 = fmul fast float %2264, %2261
  %2274 = fadd fast float %2271, %1947
  %2275 = fadd fast float %2272, %1951
  %2276 = fadd fast float %2273, %1955
  %2277 = fmul fast float %2264, %2252
  %2278 = fmul fast float %2264, %2256
  %2279 = fmul fast float %2264, %2260
  %2280 = fadd fast float %2277, %1946
  %2281 = fadd fast float %2278, %1950
  %2282 = fadd fast float %2279, %1954
  %2283 = fmul fast float %2264, %2251
  %2284 = fmul fast float %2264, %2255
  %2285 = fmul fast float %2264, %2259
  %2286 = fadd fast float %2283, %1945
  %2287 = fadd fast float %2284, %1949
  %2288 = fadd fast float %2285, %1953
  %2289 = fmul fast float %2264, %2263
  %2290 = fadd fast float %2289, %1958
  %2291 = fsub fast float 1.000000e+00, %2290
  %2292 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2291)  ; FMax(a,b)
  br label %2293

; <label>:2293                                    ; preds = %2250, %1944
  %2294 = phi float [ %2286, %2250 ], [ %1945, %1944 ]
  %2295 = phi float [ %2280, %2250 ], [ %1946, %1944 ]
  %2296 = phi float [ %2274, %2250 ], [ %1947, %1944 ]
  %2297 = phi float [ %2268, %2250 ], [ %1948, %1944 ]
  %2298 = phi float [ %2287, %2250 ], [ %1949, %1944 ]
  %2299 = phi float [ %2281, %2250 ], [ %1950, %1944 ]
  %2300 = phi float [ %2275, %2250 ], [ %1951, %1944 ]
  %2301 = phi float [ %2269, %2250 ], [ %1952, %1944 ]
  %2302 = phi float [ %2288, %2250 ], [ %1953, %1944 ]
  %2303 = phi float [ %2282, %2250 ], [ %1954, %1944 ]
  %2304 = phi float [ %2276, %2250 ], [ %1955, %1944 ]
  %2305 = phi float [ %2270, %2250 ], [ %1956, %1944 ]
  %2306 = phi float [ %2292, %2250 ], [ %1957, %1944 ]
  %2307 = phi float [ %2290, %2250 ], [ %1958, %1944 ]
  %2308 = fcmp fast ogt float %2306, 0.000000e+00
  %2309 = fcmp fast ogt float %1611, 0.000000e+00
  %2310 = and i1 %2309, %2308
  br i1 %2310, label %2311, label %2640

; <label>:2311                                    ; preds = %2293
  %2312 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 0
  store float %1245, float* %2312, align 4
  %2313 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 1
  store float %1246, float* %2313, align 4
  %2314 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 2
  store float %1247, float* %2314, align 4
  %2315 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 3
  store float %1248, float* %2315, align 4
  %2316 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 4
  store float %1250, float* %2316, align 4
  %2317 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 5
  store float %1251, float* %2317, align 4
  %2318 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 6
  store float %1252, float* %2318, align 4
  %2319 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 7
  store float %1253, float* %2319, align 4
  %2320 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 8
  store float %1255, float* %2320, align 4
  %2321 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 9
  store float %1256, float* %2321, align 4
  %2322 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 10
  store float %1257, float* %2322, align 4
  %2323 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 11
  store float %1258, float* %2323, align 4
  br i1 %1281, label %2599, label %2324

; <label>:2324                                    ; preds = %2311
  %2325 = fdiv fast float %1595, %1236
  %2326 = fcmp fast olt float %1584, %1238
  %2327 = fcmp fast olt float %1585, %1239
  %2328 = fcmp fast olt float %2325, %1240
  %2329 = fcmp fast oge float %1584, 0.000000e+00
  %2330 = fcmp fast oge float %1585, 0.000000e+00
  %2331 = fcmp fast oge float %2325, 0.000000e+00
  %2332 = and i1 %2329, %2326
  %2333 = and i1 %2330, %2327
  %2334 = and i1 %2331, %2328
  %2335 = and i1 %2332, %2333
  %2336 = and i1 %2335, %2334
  br i1 %2336, label %2337, label %2343

; <label>:2337                                    ; preds = %2324
  %2338 = fptoui float %1584 to i32
  %2339 = fptoui float %1585 to i32
  %2340 = fptoui float %2325 to i32
  %2341 = call %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32 66, %dx.types.Handle %16, i32 0, i32 %2338, i32 %2339, i32 %2340, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2342 = extractvalue %dx.types.ResRet.i32 %2341, 0
  br label %2343

; <label>:2343                                    ; preds = %2337, %2324
  %2344 = phi i32 [ %2342, %2337 ], [ 65535, %2324 ]
  %2345 = icmp eq i32 %2344, 65535
  br i1 %2345, label %2599, label %2346, !dx.controlflow.hints !82

; <label>:2346                                    ; preds = %2343
  %2347 = fsub fast float %79, %1598
  %2348 = fmul fast float %267, %267
  %2349 = fmul fast float %268, %268
  %2350 = fadd fast float %2348, %2349
  %2351 = fmul fast float %2347, %2347
  %2352 = fadd fast float %2350, %2351
  %2353 = call float @dx.op.unary.f32(i32 24, float %2352)  ; Sqrt(value)
  %2354 = and i32 %1262, 1
  %2355 = icmp eq i32 %2354, 0
  br i1 %2355, label %2426, label %2356

; <label>:2356                                    ; preds = %2346
  %2357 = fcmp fast ogt float %2353, %1245
  %2358 = fcmp fast ogt float %2353, %1246
  %2359 = fcmp fast ogt float %2353, %1247
  %2360 = fcmp fast ogt float %2353, %1248
  %2361 = uitofp i1 %2357 to float
  %2362 = uitofp i1 %2358 to float
  %2363 = uitofp i1 %2359 to float
  %2364 = uitofp i1 %2360 to float
  %2365 = call float @dx.op.dot4.f32(i32 56, float %2361, float %2362, float %2363, float %2364, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2366 = fptosi float %2365 to i32
  %2367 = fcmp fast ogt float %2353, %1250
  %2368 = fcmp fast ogt float %2353, %1251
  %2369 = fcmp fast ogt float %2353, %1252
  %2370 = fcmp fast ogt float %2353, %1253
  %2371 = uitofp i1 %2367 to float
  %2372 = uitofp i1 %2368 to float
  %2373 = uitofp i1 %2369 to float
  %2374 = uitofp i1 %2370 to float
  %2375 = call float @dx.op.dot4.f32(i32 56, float %2371, float %2372, float %2373, float %2374, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2376 = fptosi float %2375 to i32
  %2377 = add nsw i32 %2376, %2366
  %2378 = fcmp fast ogt float %2353, %1255
  %2379 = fcmp fast ogt float %2353, %1256
  %2380 = fcmp fast ogt float %2353, %1257
  %2381 = fcmp fast ogt float %2353, %1258
  %2382 = uitofp i1 %2378 to float
  %2383 = uitofp i1 %2379 to float
  %2384 = uitofp i1 %2380 to float
  %2385 = uitofp i1 %2381 to float
  %2386 = call float @dx.op.dot4.f32(i32 56, float %2382, float %2383, float %2384, float %2385, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2387 = fptosi float %2386 to i32
  %2388 = add nsw i32 %2377, %2387
  %2389 = call i32 @dx.op.binary.i32(i32 38, i32 %2388, i32 9)  ; IMin(a,b)
  %2390 = add nsw i32 %2389, -1
  %2391 = ashr i32 %2389, 2
  %2392 = call i32 @dx.op.binary.i32(i32 38, i32 %2391, i32 2)  ; IMin(a,b)
  %2393 = and i32 %2389, 3
  %2394 = mul i32 %2392, 4
  %2395 = add i32 %2393, %2394
  %2396 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %2395
  %2397 = load float, float* %2396, align 4, !tbaa !83, !noalias !106
  %2398 = icmp slt i32 %2389, 1
  br i1 %2398, label %2407, label %2399

; <label>:2399                                    ; preds = %2356
  %2400 = ashr i32 %2390, 2
  %2401 = call i32 @dx.op.binary.i32(i32 38, i32 %2400, i32 2)  ; IMin(a,b)
  %2402 = and i32 %2390, 3
  %2403 = mul i32 %2401, 4
  %2404 = add i32 %2402, %2403
  %2405 = getelementptr [12 x float], [12 x float]* %68, i32 0, i32 %2404
  %2406 = load float, float* %2405, align 4, !tbaa !83, !noalias !106
  br label %2407

; <label>:2407                                    ; preds = %2399, %2356
  %2408 = phi float [ %2406, %2399 ], [ 0.000000e+00, %2356 ]
  %2409 = fsub fast float %2353, %2408
  %2410 = fsub fast float %2397, %2408
  %2411 = call float @dx.op.binary.f32(i32 35, float %2410, float 0x3F1A36E2E0000000)  ; FMax(a,b)
  %2412 = fdiv fast float %2409, %2411
  %2413 = call i32 @dx.op.binary.i32(i32 37, i32 %2390, i32 0)  ; IMax(a,b)
  %2414 = and i32 %906, 127
  %2415 = and i32 %907, 127
  %2416 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %8, i32 0, i32 %2414, i32 %2415, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2417 = extractvalue %dx.types.ResRet.f32 %2416, 0
  %2418 = fmul fast float %2412, %1260
  %2419 = call float @dx.op.unary.f32(i32 7, float %2418)  ; Saturate(value)
  %2420 = fmul fast float %2419, 2.000000e+00
  %2421 = fsub fast float 3.000000e+00, %2420
  %2422 = fmul fast float %2419, %2419
  %2423 = fmul fast float %2422, %2421
  %2424 = fcmp fast ogt float %2423, %2417
  %2425 = select i1 %2424, i32 %2389, i32 %2413
  br label %2426

; <label>:2426                                    ; preds = %2407, %2346
  %2427 = phi i32 [ %2425, %2407 ], [ 0, %2346 ]
  %2428 = sub nsw i32 9, %2427
  %2429 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %2344, i32 0)  ; BufferLoad(srv,index,wot)
  %2430 = extractvalue %dx.types.ResRet.i32 %2429, 0
  %2431 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %2344, i32 4)  ; BufferLoad(srv,index,wot)
  %2432 = extractvalue %dx.types.ResRet.i32 %2431, 0
  %2433 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %2344, i32 8)  ; BufferLoad(srv,index,wot)
  %2434 = extractvalue %dx.types.ResRet.i32 %2433, 0
  %2435 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %7, i32 %2344, i32 12)  ; BufferLoad(srv,index,wot)
  %2436 = extractvalue %dx.types.ResRet.i32 %2435, 0
  %2437 = call i32 @dx.op.binary.i32(i32 40, i32 %2430, i32 -1)  ; UMin(a,b)
  %2438 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %13, i32 %2432, i32 0)  ; BufferLoad(srv,index,wot)
  %2439 = extractvalue %dx.types.ResRet.f32 %2438, 3
  %2440 = call i32 @dx.op.binary.i32(i32 40, i32 %2428, i32 %2437)  ; UMin(a,b)
  %2441 = extractvalue %dx.types.ResRet.f32 %2438, 2
  %2442 = extractvalue %dx.types.ResRet.f32 %2438, 1
  %2443 = extractvalue %dx.types.ResRet.f32 %2438, 0
  %2444 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2434, i32 4)  ; BufferLoad(srv,index,wot)
  %2445 = extractvalue %dx.types.ResRet.i32 %2444, 0
  %2446 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2434, i32 12)  ; BufferLoad(srv,index,wot)
  %2447 = extractvalue %dx.types.ResRet.i32 %2446, 0
  %2448 = fsub fast float %61, %2443
  %2449 = fsub fast float %62, %2442
  %2450 = fsub fast float %1598, %2441
  %2451 = fdiv fast float %2448, %2439
  %2452 = fdiv fast float %2449, %2439
  %2453 = fdiv fast float %2450, %2439
  %2454 = call float @dx.op.unary.f32(i32 7, float %2451)  ; Saturate(value)
  %2455 = call float @dx.op.unary.f32(i32 7, float %2452)  ; Saturate(value)
  %2456 = call float @dx.op.unary.f32(i32 7, float %2453)  ; Saturate(value)
  %2457 = icmp eq i32 %2440, 0
  br i1 %2457, label %2532, label %2458

; <label>:2458                                    ; preds = %2426
  %2459 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2434, i32 8)  ; BufferLoad(srv,index,wot)
  %2460 = extractvalue %dx.types.ResRet.i32 %2459, 0
  %2461 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2434, i32 0)  ; BufferLoad(srv,index,wot)
  %2462 = extractvalue %dx.types.ResRet.i32 %2461, 0
  br label %2463

; <label>:2463                                    ; preds = %2519, %2458
  %2464 = phi i32 [ %2524, %2519 ], [ 0, %2458 ]
  %2465 = phi float [ %2499, %2519 ], [ %2454, %2458 ]
  %2466 = phi float [ %2500, %2519 ], [ %2455, %2458 ]
  %2467 = phi float [ %2501, %2519 ], [ %2456, %2458 ]
  %2468 = phi i32 [ %2498, %2519 ], [ %2447, %2458 ]
  %2469 = phi i32 [ %2521, %2519 ], [ %2460, %2458 ]
  %2470 = phi i32 [ %2496, %2519 ], [ %2445, %2458 ]
  %2471 = phi i32 [ %2523, %2519 ], [ %2462, %2458 ]
  %2472 = fmul fast float %2465, 3.000000e+00
  %2473 = fmul fast float %2466, 3.000000e+00
  %2474 = fmul fast float %2467, 3.000000e+00
  %2475 = call float @dx.op.unary.f32(i32 27, float %2472)  ; Round_ni(value)
  %2476 = call float @dx.op.unary.f32(i32 27, float %2473)  ; Round_ni(value)
  %2477 = call float @dx.op.unary.f32(i32 27, float %2474)  ; Round_ni(value)
  %2478 = fptoui float %2475 to i32
  %2479 = fptoui float %2476 to i32
  %2480 = fptoui float %2477 to i32
  %2481 = mul i32 %2479, 3
  %2482 = add i32 %2481, %2478
  %2483 = mul i32 %2480, 9
  %2484 = add i32 %2482, %2483
  %2485 = and i32 %2484, 31
  %2486 = shl i32 1, %2485
  %2487 = and i32 %2486, %2469
  %2488 = icmp eq i32 %2487, 0
  br i1 %2488, label %2526, label %2489

; <label>:2489                                    ; preds = %2463
  %2490 = add i32 %2486, -1
  %2491 = and i32 %2490, %2469
  %2492 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %2491)  ; Countbits(value)
  %2493 = add i32 %2471, %2434
  %2494 = add i32 %2493, %2492
  %2495 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2494, i32 4)  ; BufferLoad(srv,index,wot)
  %2496 = extractvalue %dx.types.ResRet.i32 %2495, 0
  %2497 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2494, i32 12)  ; BufferLoad(srv,index,wot)
  %2498 = extractvalue %dx.types.ResRet.i32 %2497, 0
  %2499 = call float @dx.op.unary.f32(i32 22, float %2472)  ; Frc(value)
  %2500 = call float @dx.op.unary.f32(i32 22, float %2473)  ; Frc(value)
  %2501 = call float @dx.op.unary.f32(i32 22, float %2474)  ; Frc(value)
  %2502 = fmul fast float %2499, 3.000000e+00
  %2503 = fmul fast float %2500, 3.000000e+00
  %2504 = fmul fast float %2501, 3.000000e+00
  %2505 = call float @dx.op.unary.f32(i32 27, float %2502)  ; Round_ni(value)
  %2506 = call float @dx.op.unary.f32(i32 27, float %2503)  ; Round_ni(value)
  %2507 = call float @dx.op.unary.f32(i32 27, float %2504)  ; Round_ni(value)
  %2508 = fptoui float %2505 to i32
  %2509 = fptoui float %2506 to i32
  %2510 = fptoui float %2507 to i32
  %2511 = mul i32 %2509, 3
  %2512 = add i32 %2511, %2508
  %2513 = mul i32 %2510, 9
  %2514 = add i32 %2512, %2513
  %2515 = and i32 %2514, 31
  %2516 = shl i32 1, %2515
  %2517 = and i32 %2516, %2498
  %2518 = icmp eq i32 %2517, 0
  br i1 %2518, label %2526, label %2519

; <label>:2519                                    ; preds = %2489
  %2520 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2494, i32 8)  ; BufferLoad(srv,index,wot)
  %2521 = extractvalue %dx.types.ResRet.i32 %2520, 0
  %2522 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %6, i32 %2494, i32 0)  ; BufferLoad(srv,index,wot)
  %2523 = extractvalue %dx.types.ResRet.i32 %2522, 0
  %2524 = add nuw i32 %2464, 1
  %2525 = icmp ult i32 %2524, %2440
  br i1 %2525, label %2463, label %2526, !llvm.loop !104

; <label>:2526                                    ; preds = %2519, %2489, %2463
  %2527 = phi float [ %2499, %2519 ], [ %2465, %2463 ], [ %2465, %2489 ]
  %2528 = phi float [ %2500, %2519 ], [ %2466, %2463 ], [ %2466, %2489 ]
  %2529 = phi float [ %2501, %2519 ], [ %2467, %2463 ], [ %2467, %2489 ]
  %2530 = phi i32 [ %2498, %2519 ], [ %2468, %2463 ], [ %2468, %2489 ]
  %2531 = phi i32 [ %2496, %2519 ], [ %2470, %2463 ], [ %2470, %2489 ]
  br label %2532

; <label>:2532                                    ; preds = %2526, %2426
  %2533 = phi float [ %2454, %2426 ], [ %2527, %2526 ]
  %2534 = phi float [ %2455, %2426 ], [ %2528, %2526 ]
  %2535 = phi float [ %2456, %2426 ], [ %2529, %2526 ]
  %2536 = phi i32 [ %2447, %2426 ], [ %2530, %2526 ]
  %2537 = phi i32 [ %2445, %2426 ], [ %2531, %2526 ]
  %2538 = fmul fast float %2533, 3.000000e+00
  %2539 = fmul fast float %2534, 3.000000e+00
  %2540 = fmul fast float %2535, 3.000000e+00
  %2541 = call float @dx.op.unary.f32(i32 27, float %2538)  ; Round_ni(value)
  %2542 = call float @dx.op.unary.f32(i32 27, float %2539)  ; Round_ni(value)
  %2543 = call float @dx.op.unary.f32(i32 27, float %2540)  ; Round_ni(value)
  %2544 = fptoui float %2541 to i32
  %2545 = fptoui float %2542 to i32
  %2546 = fptoui float %2543 to i32
  %2547 = mul i32 %2545, 3
  %2548 = add i32 %2547, %2544
  %2549 = mul i32 %2546, 9
  %2550 = add i32 %2548, %2549
  %2551 = and i32 %2550, 31
  %2552 = shl i32 1, %2551
  %2553 = add i32 %2552, -1
  %2554 = and i32 %2553, %2536
  %2555 = call i32 @dx.op.unaryBits.i32(i32 31, i32 %2554)  ; Countbits(value)
  %2556 = add i32 %2537, %2436
  %2557 = add i32 %2556, %2555
  %2558 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %17, i32 %2557, i32 undef)  ; BufferLoad(srv,index,wot)
  %2559 = extractvalue %dx.types.ResRet.i32 %2558, 0
  %2560 = and i32 %2559, 1023
  %2561 = lshr i32 %2559, 10
  %2562 = and i32 %2561, 1023
  %2563 = lshr i32 %2559, 20
  %2564 = and i32 %2563, 1023
  %2565 = uitofp i32 %2560 to float
  %2566 = uitofp i32 %2562 to float
  %2567 = uitofp i32 %2564 to float
  %2568 = call float @dx.op.unary.f32(i32 22, float %2538)  ; Frc(value)
  %2569 = call float @dx.op.unary.f32(i32 22, float %2539)  ; Frc(value)
  %2570 = call float @dx.op.unary.f32(i32 22, float %2540)  ; Frc(value)
  %2571 = fadd fast float %2568, 5.000000e-01
  %2572 = fadd fast float %2571, %2565
  %2573 = fadd fast float %2569, 5.000000e-01
  %2574 = fadd fast float %2573, %2566
  %2575 = fadd fast float %2570, 5.000000e-01
  %2576 = fadd fast float %2575, %2567
  %2577 = fmul fast float %2576, %1266
  %2578 = fmul fast float %1264, 5.000000e-01
  %2579 = fmul fast float %2578, %2572
  %2580 = fmul fast float %1265, 5.000000e-01
  %2581 = fmul fast float %2580, %2574
  %2582 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2579, float %2581, float %2577, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2583 = extractvalue %dx.types.ResRet.f32 %2582, 0
  %2584 = extractvalue %dx.types.ResRet.f32 %2582, 1
  %2585 = extractvalue %dx.types.ResRet.f32 %2582, 2
  %2586 = extractvalue %dx.types.ResRet.f32 %2582, 3
  %2587 = fadd fast float %2579, 5.000000e-01
  %2588 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2587, float %2581, float %2577, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2589 = extractvalue %dx.types.ResRet.f32 %2588, 0
  %2590 = extractvalue %dx.types.ResRet.f32 %2588, 1
  %2591 = extractvalue %dx.types.ResRet.f32 %2588, 2
  %2592 = extractvalue %dx.types.ResRet.f32 %2588, 3
  %2593 = fadd fast float %2581, 5.000000e-01
  %2594 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %15, %dx.types.Handle %37, float %2579, float %2593, float %2577, float undef, i32 0, i32 0, i32 0, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %2595 = extractvalue %dx.types.ResRet.f32 %2594, 0
  %2596 = extractvalue %dx.types.ResRet.f32 %2594, 1
  %2597 = extractvalue %dx.types.ResRet.f32 %2594, 2
  %2598 = extractvalue %dx.types.ResRet.f32 %2594, 3
  br label %2599

; <label>:2599                                    ; preds = %2532, %2343, %2311
  %2600 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2586, %2532 ]
  %2601 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2585, %2532 ]
  %2602 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2584, %2532 ]
  %2603 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2583, %2532 ]
  %2604 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2592, %2532 ]
  %2605 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2591, %2532 ]
  %2606 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2590, %2532 ]
  %2607 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2589, %2532 ]
  %2608 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2598, %2532 ]
  %2609 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2597, %2532 ]
  %2610 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2596, %2532 ]
  %2611 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ %2595, %2532 ]
  %2612 = phi float [ 0.000000e+00, %2343 ], [ 0.000000e+00, %2311 ], [ 1.000000e+00, %2532 ]
  %2613 = call float @dx.op.binary.f32(i32 36, float %1611, float %2306)  ; FMin(a,b)
  %2614 = fmul fast float %2613, %2603
  %2615 = fmul fast float %2613, %2607
  %2616 = fmul fast float %2613, %2611
  %2617 = fadd fast float %2614, %2297
  %2618 = fadd fast float %2615, %2301
  %2619 = fadd fast float %2616, %2305
  %2620 = fmul fast float %2613, %2602
  %2621 = fmul fast float %2613, %2606
  %2622 = fmul fast float %2613, %2610
  %2623 = fadd fast float %2620, %2296
  %2624 = fadd fast float %2621, %2300
  %2625 = fadd fast float %2622, %2304
  %2626 = fmul fast float %2613, %2601
  %2627 = fmul fast float %2613, %2605
  %2628 = fmul fast float %2613, %2609
  %2629 = fadd fast float %2626, %2295
  %2630 = fadd fast float %2627, %2299
  %2631 = fadd fast float %2628, %2303
  %2632 = fmul fast float %2613, %2600
  %2633 = fmul fast float %2613, %2604
  %2634 = fmul fast float %2613, %2608
  %2635 = fadd fast float %2632, %2294
  %2636 = fadd fast float %2633, %2298
  %2637 = fadd fast float %2634, %2302
  %2638 = fmul fast float %2613, %2612
  %2639 = fadd fast float %2638, %2307
  br label %2640

; <label>:2640                                    ; preds = %2599, %2293, %1561
  %2641 = phi float [ %1562, %1561 ], [ %2635, %2599 ], [ %2294, %2293 ]
  %2642 = phi float [ %1563, %1561 ], [ %2629, %2599 ], [ %2295, %2293 ]
  %2643 = phi float [ %1564, %1561 ], [ %2623, %2599 ], [ %2296, %2293 ]
  %2644 = phi float [ %1565, %1561 ], [ %2617, %2599 ], [ %2297, %2293 ]
  %2645 = phi float [ %1566, %1561 ], [ %2636, %2599 ], [ %2298, %2293 ]
  %2646 = phi float [ %1567, %1561 ], [ %2630, %2599 ], [ %2299, %2293 ]
  %2647 = phi float [ %1568, %1561 ], [ %2624, %2599 ], [ %2300, %2293 ]
  %2648 = phi float [ %1569, %1561 ], [ %2618, %2599 ], [ %2301, %2293 ]
  %2649 = phi float [ %1570, %1561 ], [ %2637, %2599 ], [ %2302, %2293 ]
  %2650 = phi float [ %1571, %1561 ], [ %2631, %2599 ], [ %2303, %2293 ]
  %2651 = phi float [ %1572, %1561 ], [ %2625, %2599 ], [ %2304, %2293 ]
  %2652 = phi float [ %1573, %1561 ], [ %2619, %2599 ], [ %2305, %2293 ]
  %2653 = phi float [ %1574, %1561 ], [ %2639, %2599 ], [ %2307, %2293 ]
  %2654 = fmul fast float %2644, %1229
  %2655 = fmul fast float %2648, %1229
  %2656 = fmul fast float %2652, %1229
  %2657 = fadd fast float %2654, %1218
  %2658 = fadd fast float %2655, %1222
  %2659 = fadd fast float %2656, %1226
  %2660 = fmul fast float %2643, %1229
  %2661 = fmul fast float %2647, %1229
  %2662 = fmul fast float %2651, %1229
  %2663 = fadd fast float %2660, %1217
  %2664 = fadd fast float %2661, %1221
  %2665 = fadd fast float %2662, %1225
  %2666 = fmul fast float %2642, %1229
  %2667 = fmul fast float %2646, %1229
  %2668 = fmul fast float %2650, %1229
  %2669 = fadd fast float %2666, %1216
  %2670 = fadd fast float %2667, %1220
  %2671 = fadd fast float %2668, %1224
  %2672 = fmul fast float %2641, %1229
  %2673 = fmul fast float %2645, %1229
  %2674 = fmul fast float %2649, %1229
  %2675 = fadd fast float %2672, %1215
  %2676 = fadd fast float %2673, %1219
  %2677 = fadd fast float %2674, %1223
  %2678 = fmul fast float %2653, %1229
  %2679 = fsub fast float %1228, %2678
  %2680 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2679)  ; FMax(a,b)
  %2681 = fcmp fast ogt float %2680, 0.000000e+00
  br i1 %2681, label %2682, label %2723, !dx.controlflow.hints !117

; <label>:2682                                    ; preds = %2640
  %2683 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %10, i32 0, i32 0)  ; BufferLoad(srv,index,wot)
  %2684 = extractvalue %dx.types.ResRet.f32 %2683, 0
  %2685 = extractvalue %dx.types.ResRet.f32 %2683, 1
  %2686 = extractvalue %dx.types.ResRet.f32 %2683, 2
  %2687 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %10, i32 0, i32 16)  ; BufferLoad(srv,index,wot)
  %2688 = extractvalue %dx.types.ResRet.f32 %2687, 0
  %2689 = extractvalue %dx.types.ResRet.f32 %2687, 1
  %2690 = extractvalue %dx.types.ResRet.f32 %2687, 2
  %2691 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %10, i32 0, i32 32)  ; BufferLoad(srv,index,wot)
  %2692 = extractvalue %dx.types.ResRet.f32 %2691, 0
  %2693 = extractvalue %dx.types.ResRet.f32 %2691, 1
  %2694 = extractvalue %dx.types.ResRet.f32 %2691, 2
  %2695 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %10, i32 0, i32 48)  ; BufferLoad(srv,index,wot)
  %2696 = extractvalue %dx.types.ResRet.f32 %2695, 0
  %2697 = extractvalue %dx.types.ResRet.f32 %2695, 1
  %2698 = extractvalue %dx.types.ResRet.f32 %2695, 2
  %2699 = fmul fast float %2684, %2680
  %2700 = fmul fast float %2685, %2680
  %2701 = fmul fast float %2686, %2680
  %2702 = fadd fast float %2699, %2657
  %2703 = fadd fast float %2700, %2658
  %2704 = fadd fast float %2701, %2659
  %2705 = fmul fast float %2688, %2680
  %2706 = fmul fast float %2689, %2680
  %2707 = fmul fast float %2690, %2680
  %2708 = fadd fast float %2705, %2663
  %2709 = fadd fast float %2706, %2664
  %2710 = fadd fast float %2707, %2665
  %2711 = fmul fast float %2692, %2680
  %2712 = fmul fast float %2693, %2680
  %2713 = fmul fast float %2694, %2680
  %2714 = fadd fast float %2711, %2669
  %2715 = fadd fast float %2712, %2670
  %2716 = fadd fast float %2713, %2671
  %2717 = fmul fast float %2696, %2680
  %2718 = fmul fast float %2697, %2680
  %2719 = fmul fast float %2698, %2680
  %2720 = fadd fast float %2717, %2675
  %2721 = fadd fast float %2718, %2676
  %2722 = fadd fast float %2719, %2677
  br label %2723

; <label>:2723                                    ; preds = %2682, %2640, %1214
  %2724 = phi float [ %2720, %2682 ], [ %1215, %1214 ], [ %2675, %2640 ]
  %2725 = phi float [ %2714, %2682 ], [ %1216, %1214 ], [ %2669, %2640 ]
  %2726 = phi float [ %2708, %2682 ], [ %1217, %1214 ], [ %2663, %2640 ]
  %2727 = phi float [ %2702, %2682 ], [ %1218, %1214 ], [ %2657, %2640 ]
  %2728 = phi float [ %2721, %2682 ], [ %1219, %1214 ], [ %2676, %2640 ]
  %2729 = phi float [ %2715, %2682 ], [ %1220, %1214 ], [ %2670, %2640 ]
  %2730 = phi float [ %2709, %2682 ], [ %1221, %1214 ], [ %2664, %2640 ]
  %2731 = phi float [ %2703, %2682 ], [ %1222, %1214 ], [ %2658, %2640 ]
  %2732 = phi float [ %2722, %2682 ], [ %1223, %1214 ], [ %2677, %2640 ]
  %2733 = phi float [ %2716, %2682 ], [ %1224, %1214 ], [ %2671, %2640 ]
  %2734 = phi float [ %2710, %2682 ], [ %1225, %1214 ], [ %2665, %2640 ]
  %2735 = phi float [ %2704, %2682 ], [ %1226, %1214 ], [ %2659, %2640 ]
  %2736 = call float @dx.op.dot3.f32(i32 55, float %758, float %759, float %760, float %758, float %759, float %760)  ; Dot3(ax,ay,az,bx,by,bz)
  %2737 = call float @dx.op.unary.f32(i32 25, float %2736)  ; Rsqrt(value)
  %2738 = fmul fast float %2737, %758
  %2739 = fmul fast float %2737, %759
  %2740 = fmul fast float %2737, %760
  %2741 = fmul fast float %903, 0x3FC331E1E0000000
  %2742 = fmul fast float %903, 0x3FC0A84FE0000000
  %2743 = fmul fast float %903, 0x3FB2806880000000
  %2744 = fadd fast float %2741, %870
  %2745 = fmul fast float %2744, %893
  %2746 = fadd fast float %805, %798
  %2747 = fadd fast float %2746, %2745
  %2748 = fadd fast float %2742, %871
  %2749 = fmul fast float %2748, %893
  %2750 = fadd fast float %806, %799
  %2751 = fadd fast float %2750, %2749
  %2752 = fadd fast float %2743, %872
  %2753 = fmul fast float %2752, %893
  %2754 = fadd fast float %807, %800
  %2755 = fadd fast float %2754, %2753
  %2756 = call float @dx.op.unary.f32(i32 7, float %2747)  ; Saturate(value)
  %2757 = call float @dx.op.unary.f32(i32 7, float %2751)  ; Saturate(value)
  %2758 = call float @dx.op.unary.f32(i32 7, float %2755)  ; Saturate(value)
  %2759 = fmul fast float %2726, 5.000000e-01
  %2760 = fmul fast float %2725, 5.000000e-01
  %2761 = fmul fast float %2724, 5.000000e-01
  %2762 = fmul fast float %2759, %2759
  %2763 = fmul fast float %2760, %2760
  %2764 = fmul fast float %2761, %2761
  %2765 = fadd fast float %2763, %2764
  %2766 = fadd fast float %2765, %2762
  %2767 = call float @dx.op.unary.f32(i32 24, float %2766)  ; Sqrt(value)
  %2768 = fcmp fast olt float %2727, 0x3E7AD7F2A0000000
  %2769 = fcmp fast olt float %2767, 0x3E7AD7F2A0000000
  %2770 = or i1 %2768, %2769
  br i1 %2770, label %2771, label %2773

; <label>:2771                                    ; preds = %2723
  %2772 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2727)  ; FMax(a,b)
  br label %2796

; <label>:2773                                    ; preds = %2723
  %2774 = fdiv fast float %2767, %2727
  %2775 = fdiv fast float %2759, %2767
  %2776 = fdiv fast float %2760, %2767
  %2777 = fdiv fast float %2761, %2767
  %2778 = call float @dx.op.dot3.f32(i32 55, float %2775, float %2776, float %2777, float %2738, float %2739, float %2740)  ; Dot3(ax,ay,az,bx,by,bz)
  %2779 = fadd fast float %2778, 1.000000e+00
  %2780 = fmul fast float %2779, 5.000000e-01
  %2781 = fmul fast float %2774, 2.000000e+00
  %2782 = fadd fast float %2781, 1.000000e+00
  %2783 = fsub fast float 1.000000e+00, %2774
  %2784 = fadd fast float %2774, 1.000000e+00
  %2785 = fdiv fast float %2783, %2784
  %2786 = fsub fast float 1.000000e+00, %2785
  %2787 = fadd fast float %2781, 2.000000e+00
  %2788 = fmul fast float %2786, %2787
  %2789 = call float @dx.op.unary.f32(i32 6, float %2780)  ; FAbs(value)
  %2790 = call float @dx.op.unary.f32(i32 23, float %2789)  ; Log(value)
  %2791 = fmul fast float %2790, %2782
  %2792 = call float @dx.op.unary.f32(i32 21, float %2791)  ; Exp(value)
  %2793 = fmul fast float %2788, %2792
  %2794 = fadd fast float %2793, %2785
  %2795 = fmul fast float %2794, %2727
  br label %2796

; <label>:2796                                    ; preds = %2773, %2771
  %2797 = phi float [ %2772, %2771 ], [ %2795, %2773 ]
  %2798 = fmul fast float %2730, 5.000000e-01
  %2799 = fmul fast float %2729, 5.000000e-01
  %2800 = fmul fast float %2728, 5.000000e-01
  %2801 = fmul fast float %2798, %2798
  %2802 = fmul fast float %2799, %2799
  %2803 = fmul fast float %2800, %2800
  %2804 = fadd fast float %2802, %2803
  %2805 = fadd fast float %2804, %2801
  %2806 = call float @dx.op.unary.f32(i32 24, float %2805)  ; Sqrt(value)
  %2807 = fcmp fast olt float %2731, 0x3E7AD7F2A0000000
  %2808 = fcmp fast olt float %2806, 0x3E7AD7F2A0000000
  %2809 = or i1 %2807, %2808
  br i1 %2809, label %2810, label %2812

; <label>:2810                                    ; preds = %2796
  %2811 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2731)  ; FMax(a,b)
  br label %2835

; <label>:2812                                    ; preds = %2796
  %2813 = fdiv fast float %2806, %2731
  %2814 = fdiv fast float %2798, %2806
  %2815 = fdiv fast float %2799, %2806
  %2816 = fdiv fast float %2800, %2806
  %2817 = call float @dx.op.dot3.f32(i32 55, float %2814, float %2815, float %2816, float %2738, float %2739, float %2740)  ; Dot3(ax,ay,az,bx,by,bz)
  %2818 = fadd fast float %2817, 1.000000e+00
  %2819 = fmul fast float %2818, 5.000000e-01
  %2820 = fmul fast float %2813, 2.000000e+00
  %2821 = fadd fast float %2820, 1.000000e+00
  %2822 = fsub fast float 1.000000e+00, %2813
  %2823 = fadd fast float %2813, 1.000000e+00
  %2824 = fdiv fast float %2822, %2823
  %2825 = fsub fast float 1.000000e+00, %2824
  %2826 = fadd fast float %2820, 2.000000e+00
  %2827 = fmul fast float %2825, %2826
  %2828 = call float @dx.op.unary.f32(i32 6, float %2819)  ; FAbs(value)
  %2829 = call float @dx.op.unary.f32(i32 23, float %2828)  ; Log(value)
  %2830 = fmul fast float %2829, %2821
  %2831 = call float @dx.op.unary.f32(i32 21, float %2830)  ; Exp(value)
  %2832 = fmul fast float %2827, %2831
  %2833 = fadd fast float %2832, %2824
  %2834 = fmul fast float %2833, %2731
  br label %2835

; <label>:2835                                    ; preds = %2812, %2810
  %2836 = phi float [ %2811, %2810 ], [ %2834, %2812 ]
  %2837 = fmul fast float %2734, 5.000000e-01
  %2838 = fmul fast float %2733, 5.000000e-01
  %2839 = fmul fast float %2732, 5.000000e-01
  %2840 = fmul fast float %2837, %2837
  %2841 = fmul fast float %2838, %2838
  %2842 = fmul fast float %2839, %2839
  %2843 = fadd fast float %2841, %2842
  %2844 = fadd fast float %2843, %2840
  %2845 = call float @dx.op.unary.f32(i32 24, float %2844)  ; Sqrt(value)
  %2846 = fcmp fast olt float %2735, 0x3E7AD7F2A0000000
  %2847 = fcmp fast olt float %2845, 0x3E7AD7F2A0000000
  %2848 = or i1 %2846, %2847
  br i1 %2848, label %2849, label %2851

; <label>:2849                                    ; preds = %2835
  %2850 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2735)  ; FMax(a,b)
  br label %2874

; <label>:2851                                    ; preds = %2835
  %2852 = fdiv fast float %2845, %2735
  %2853 = fdiv fast float %2837, %2845
  %2854 = fdiv fast float %2838, %2845
  %2855 = fdiv fast float %2839, %2845
  %2856 = call float @dx.op.dot3.f32(i32 55, float %2853, float %2854, float %2855, float %2738, float %2739, float %2740)  ; Dot3(ax,ay,az,bx,by,bz)
  %2857 = fadd fast float %2856, 1.000000e+00
  %2858 = fmul fast float %2857, 5.000000e-01
  %2859 = fmul fast float %2852, 2.000000e+00
  %2860 = fadd fast float %2859, 1.000000e+00
  %2861 = fsub fast float 1.000000e+00, %2852
  %2862 = fadd fast float %2852, 1.000000e+00
  %2863 = fdiv fast float %2861, %2862
  %2864 = fsub fast float 1.000000e+00, %2863
  %2865 = fadd fast float %2859, 2.000000e+00
  %2866 = fmul fast float %2864, %2865
  %2867 = call float @dx.op.unary.f32(i32 6, float %2858)  ; FAbs(value)
  %2868 = call float @dx.op.unary.f32(i32 23, float %2867)  ; Log(value)
  %2869 = fmul fast float %2868, %2860
  %2870 = call float @dx.op.unary.f32(i32 21, float %2869)  ; Exp(value)
  %2871 = fmul fast float %2866, %2870
  %2872 = fadd fast float %2871, %2863
  %2873 = fmul fast float %2872, %2735
  br label %2874

; <label>:2874                                    ; preds = %2851, %2849
  %2875 = phi float [ %2850, %2849 ], [ %2873, %2851 ]
  %r8Native2876 = call float @dx.op.unary.f32(i32 7, float %763)  ; Saturate(value)
  %r8Glass2876 = fadd float %setting_smoothness, 0.000000e+00
  %2876 = select i1 %r8Marked, float %r8Glass2876, float %r8Native2876
  %2877 = call float @dx.op.dot3.f32(i32 55, float %2738, float %2739, float %2740, float %2738, float %2739, float %2740)  ; Dot3(ax,ay,az,bx,by,bz)
  %2878 = call float @dx.op.unary.f32(i32 25, float %2877)  ; Rsqrt(value)
  %r8Native2879 = fmul fast float %2878, %2738
  %r8Glass2879 = fadd float %glass_r5_nx, 0.000000e+00
  %2879 = select i1 %r8Marked, float %r8Glass2879, float %r8Native2879
  %r8Native2880 = fmul fast float %2878, %2739
  %r8Glass2880 = fadd float %glass_r5_ny, 0.000000e+00
  %2880 = select i1 %r8Marked, float %r8Glass2880, float %r8Native2880
  %r8Native2881 = fmul fast float %2878, %2740
  %r8Glass2881 = fadd float %glass_r5_nz, 0.000000e+00
  %2881 = select i1 %r8Marked, float %r8Glass2881, float %r8Native2881
  %2882 = fsub fast float 1.000000e+00, %2876
  %2883 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 30)  ; CBufferLoadLegacy(handle,regIndex)
  %2884 = extractvalue %dx.types.CBufRet.i32 %2883, 3
  %2885 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 22)  ; CBufferLoadLegacy(handle,regIndex)
  %2886 = extractvalue %dx.types.CBufRet.i32 %2885, 0
  %2887 = icmp eq i32 %2886, 0
  br i1 %2887, label %2937, label %2888

; <label>:2888                                    ; preds = %2874
  %2889 = extractvalue %dx.types.CBufRet.i32 %2885, 1
  %2890 = icmp ult i32 %2889, %2886
  br i1 %2890, label %2891, label %2937

; <label>:2891                                    ; preds = %2888
  br label %2892

; <label>:2892                                    ; preds = %2931, %2891
  %2893 = phi i32 [ %2932, %2931 ], [ %2889, %2891 ]
  %2894 = shl i32 %2893, 2
  %2895 = add i32 %2894, 5
  %2896 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %2895)  ; CBufferLoadLegacy(handle,regIndex)
  %2897 = extractvalue %dx.types.CBufRet.f32 %2896, 0
  %2898 = extractvalue %dx.types.CBufRet.f32 %2896, 1
  %2899 = extractvalue %dx.types.CBufRet.f32 %2896, 2
  %2900 = extractvalue %dx.types.CBufRet.f32 %2896, 3
  %2901 = add i32 %2894, 6
  %2902 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %2901)  ; CBufferLoadLegacy(handle,regIndex)
  %2903 = extractvalue %dx.types.CBufRet.f32 %2902, 0
  %2904 = extractvalue %dx.types.CBufRet.f32 %2902, 1
  %2905 = extractvalue %dx.types.CBufRet.f32 %2902, 2
  %2906 = extractvalue %dx.types.CBufRet.f32 %2902, 3
  %2907 = add i32 %2894, 7
  %2908 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %2907)  ; CBufferLoadLegacy(handle,regIndex)
  %2909 = extractvalue %dx.types.CBufRet.f32 %2908, 0
  %2910 = extractvalue %dx.types.CBufRet.f32 %2908, 1
  %2911 = extractvalue %dx.types.CBufRet.f32 %2908, 2
  %2912 = extractvalue %dx.types.CBufRet.f32 %2908, 3
  %2913 = fmul fast float %2897, %565
  %2914 = call float @dx.op.tertiary.f32(i32 46, float %566, float %2898, float %2913)  ; FMad(a,b,c)
  %2915 = call float @dx.op.tertiary.f32(i32 46, float %567, float %2899, float %2914)  ; FMad(a,b,c)
  %2916 = fadd fast float %2915, %2900
  %2917 = fmul fast float %2903, %565
  %2918 = call float @dx.op.tertiary.f32(i32 46, float %566, float %2904, float %2917)  ; FMad(a,b,c)
  %2919 = call float @dx.op.tertiary.f32(i32 46, float %567, float %2905, float %2918)  ; FMad(a,b,c)
  %2920 = fadd fast float %2919, %2906
  %2921 = fmul fast float %2909, %565
  %2922 = call float @dx.op.tertiary.f32(i32 46, float %566, float %2910, float %2921)  ; FMad(a,b,c)
  %2923 = call float @dx.op.tertiary.f32(i32 46, float %567, float %2911, float %2922)  ; FMad(a,b,c)
  %2924 = fadd fast float %2923, %2912
  %2925 = call float @dx.op.binary.f32(i32 36, float %2916, float %2920)  ; FMin(a,b)
  %2926 = call float @dx.op.binary.f32(i32 36, float %2925, float %2924)  ; FMin(a,b)
  %2927 = call float @dx.op.binary.f32(i32 35, float %2916, float %2920)  ; FMax(a,b)
  %2928 = fsub fast float 1.000000e+00, %2927
  %2929 = call float @dx.op.binary.f32(i32 36, float %2926, float %2928)  ; FMin(a,b)
  %2930 = fcmp fast ogt float %2929, 0x3EF0001000000000
  br i1 %2930, label %2934, label %2931

; <label>:2931                                    ; preds = %2892
  %2932 = add nuw i32 %2893, 1
  %2933 = icmp ult i32 %2932, %2886
  br i1 %2933, label %2892, label %2934

; <label>:2934                                    ; preds = %2931, %2892
  %2935 = phi i1 [ false, %2931 ], [ true, %2892 ]
  %2936 = phi i32 [ %2932, %2931 ], [ %2893, %2892 ]
  br label %2937

; <label>:2937                                    ; preds = %2934, %2888, %2874
  %2938 = phi i1 [ false, %2874 ], [ false, %2888 ], [ %2935, %2934 ]
  %2939 = phi i32 [ 0, %2874 ], [ %2889, %2888 ], [ %2936, %2934 ]
  %2940 = phi float [ 0.000000e+00, %2874 ], [ 0.000000e+00, %2888 ], [ %2916, %2934 ]
  %2941 = phi float [ 0.000000e+00, %2874 ], [ 0.000000e+00, %2888 ], [ %2920, %2934 ]
  %2942 = phi float [ 0.000000e+00, %2874 ], [ 0.000000e+00, %2888 ], [ %2924, %2934 ]
  br i1 %2938, label %2943, label %3064

; <label>:2943                                    ; preds = %2937
  %2944 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 23)  ; CBufferLoadLegacy(handle,regIndex)
  %2945 = extractvalue %dx.types.CBufRet.i32 %2944, 1
  %2946 = extractvalue %dx.types.CBufRet.i32 %2944, 3
  %2947 = uitofp i32 %2939 to float
  %2948 = add i32 %2945, -1
  %2949 = lshr i32 %2948, 1
  %2950 = fmul fast float %2940, %131
  %2951 = fmul fast float %2941, %131
  %2952 = fadd fast float %2950, -5.000000e-01
  %2953 = fadd fast float %2951, -5.000000e-01
  %2954 = call float @dx.op.unary.f32(i32 22, float %2952)  ; Frc(value)
  %2955 = call float @dx.op.unary.f32(i32 22, float %2953)  ; Frc(value)
  %2956 = fsub fast float 1.000000e+00, %2954
  %2957 = fsub fast float 1.000000e+00, %2955
  %2958 = fmul fast float %2957, %2956
  %2959 = fmul fast float %2957, %2954
  %2960 = fmul fast float %2956, %2955
  %2961 = fmul fast float %2955, %2954
  %2962 = call float @dx.op.unary.f32(i32 27, float %2952)  ; Round_ni(value)
  %2963 = fptosi float %2962 to i32
  %2964 = sub i32 %2963, %2949
  %2965 = sitofp i32 %2964 to float
  %2966 = fmul fast float %2965, %132
  %2967 = fadd fast float %2966, %132
  %2968 = fmul fast float %132, 2.000000e+00
  %2969 = icmp eq i32 %2945, 0
  br i1 %2969, label %3058, label %2970

; <label>:2970                                    ; preds = %2943
  %2971 = call float @dx.op.unary.f32(i32 27, float %2953)  ; Round_ni(value)
  %2972 = fptosi float %2971 to i32
  %2973 = sub i32 %2972, %2949
  %2974 = sitofp i32 %2973 to float
  %2975 = fmul fast float %2974, %132
  %2976 = fadd fast float %2975, %132
  %2977 = extractvalue %dx.types.CBufRet.i32 %2944, 2
  br label %2978

; <label>:2978                                    ; preds = %3051, %2970
  %2979 = phi float [ %3052, %3051 ], [ %2976, %2970 ]
  %2980 = phi float [ %3047, %3051 ], [ 0.000000e+00, %2970 ]
  %2981 = phi i32 [ %3054, %3051 ], [ %2977, %2970 ]
  %2982 = phi i32 [ %3055, %3051 ], [ 0, %2970 ]
  br label %2983

; <label>:2983                                    ; preds = %2983, %2978
  %2984 = phi float [ %3047, %2983 ], [ %2980, %2978 ]
  %2985 = phi float [ %3048, %2983 ], [ %2967, %2978 ]
  %2986 = phi i32 [ %3049, %2983 ], [ 0, %2978 ]
  %2987 = add i32 %2986, %2981
  %2988 = add i32 %2987, %2946
  %2989 = add i32 %2987, 35
  %2990 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %2989)  ; CBufferLoadLegacy(handle,regIndex)
  %2991 = extractvalue %dx.types.CBufRet.f32 %2990, 0
  %2992 = fmul fast float %2991, %2961
  %2993 = extractvalue %dx.types.CBufRet.f32 %2990, 1
  %2994 = fmul fast float %2993, %2960
  %2995 = fadd fast float %2994, %2992
  %2996 = extractvalue %dx.types.CBufRet.f32 %2990, 2
  %2997 = fmul fast float %2996, %2959
  %2998 = fadd fast float %2995, %2997
  %2999 = extractvalue %dx.types.CBufRet.f32 %2990, 3
  %3000 = fmul fast float %2999, %2958
  %3001 = fadd fast float %2998, %3000
  %3002 = add i32 %2987, 36
  %3003 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3002)  ; CBufferLoadLegacy(handle,regIndex)
  %3004 = extractvalue %dx.types.CBufRet.f32 %3003, 0
  %3005 = fmul fast float %3004, %2961
  %3006 = extractvalue %dx.types.CBufRet.f32 %3003, 1
  %3007 = fmul fast float %3006, %2960
  %3008 = fadd fast float %3007, %3005
  %3009 = extractvalue %dx.types.CBufRet.f32 %3003, 2
  %3010 = fmul fast float %3009, %2959
  %3011 = fadd fast float %3008, %3010
  %3012 = extractvalue %dx.types.CBufRet.f32 %3003, 3
  %3013 = fmul fast float %3012, %2958
  %3014 = fadd fast float %3011, %3013
  %3015 = add i32 %2988, 35
  %3016 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3015)  ; CBufferLoadLegacy(handle,regIndex)
  %3017 = extractvalue %dx.types.CBufRet.f32 %3016, 0
  %3018 = fmul fast float %3017, %2961
  %3019 = extractvalue %dx.types.CBufRet.f32 %3016, 1
  %3020 = fmul fast float %3019, %2960
  %3021 = fadd fast float %3020, %3018
  %3022 = extractvalue %dx.types.CBufRet.f32 %3016, 2
  %3023 = fmul fast float %3022, %2959
  %3024 = fadd fast float %3021, %3023
  %3025 = extractvalue %dx.types.CBufRet.f32 %3016, 3
  %3026 = fmul fast float %3025, %2958
  %3027 = fadd fast float %3024, %3026
  %3028 = add i32 %2988, 36
  %3029 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3028)  ; CBufferLoadLegacy(handle,regIndex)
  %3030 = extractvalue %dx.types.CBufRet.f32 %3029, 0
  %3031 = fmul fast float %3030, %2961
  %3032 = extractvalue %dx.types.CBufRet.f32 %3029, 1
  %3033 = fmul fast float %3032, %2960
  %3034 = fadd fast float %3033, %3031
  %3035 = extractvalue %dx.types.CBufRet.f32 %3029, 2
  %3036 = fmul fast float %3035, %2959
  %3037 = fadd fast float %3034, %3036
  %3038 = extractvalue %dx.types.CBufRet.f32 %3029, 3
  %3039 = fmul fast float %3038, %2958
  %3040 = fadd fast float %3037, %3039
  %3041 = call %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32 74, %dx.types.Handle %27, %dx.types.Handle %36, float %2985, float %2979, float %2947, float undef, i32 0, i32 0, i32 0, float %2942)  ; TextureGatherCmp(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,channel,compareValue)
  %3042 = extractvalue %dx.types.ResRet.f32 %3041, 0
  %3043 = extractvalue %dx.types.ResRet.f32 %3041, 1
  %3044 = extractvalue %dx.types.ResRet.f32 %3041, 2
  %3045 = extractvalue %dx.types.ResRet.f32 %3041, 3
  %3046 = call float @dx.op.dot4.f32(i32 56, float %3045, float %3044, float %3042, float %3043, float %3001, float %3014, float %3027, float %3040)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %3047 = fadd fast float %3046, %2984
  %3048 = fadd fast float %2985, %2968
  %3049 = add i32 %2986, 2
  %3050 = icmp ult i32 %3049, %2945
  br i1 %3050, label %2983, label %3051

; <label>:3051                                    ; preds = %2983
  %3052 = fadd fast float %2979, %2968
  %3053 = shl i32 %2946, 1
  %3054 = add i32 %2981, %3053
  %3055 = add i32 %2982, 2
  %3056 = icmp ult i32 %3055, %2945
  br i1 %3056, label %2978, label %3057

; <label>:3057                                    ; preds = %3051
  br label %3058

; <label>:3058                                    ; preds = %3057, %2943
  %3059 = phi float [ 0.000000e+00, %2943 ], [ %3047, %3057 ]
  %3060 = call float @dx.op.unary.f32(i32 7, float %3059)  ; Saturate(value)
  %3061 = extractvalue %dx.types.CBufRet.i32 %2944, 0
  %3062 = icmp uge i32 %2939, %3061
  %3063 = zext i1 %3062 to i32
  br label %3064

; <label>:3064                                    ; preds = %3058, %2937
  %3065 = phi float [ %3060, %3058 ], [ 1.000000e+00, %2937 ]
  %3066 = phi i32 [ %3063, %3058 ], [ 1, %2937 ]
  %3067 = icmp eq i32 %3066, 0
  br i1 %3067, label %3208, label %3068

; <label>:3068                                    ; preds = %3064
  %3069 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 24)  ; CBufferLoadLegacy(handle,regIndex)
  %3070 = extractvalue %dx.types.CBufRet.i32 %3069, 0
  %3071 = icmp eq i32 %3070, 0
  br i1 %3071, label %3208, label %3072

; <label>:3072                                    ; preds = %3068
  %3073 = extractvalue %dx.types.CBufRet.i32 %3069, 1
  %3074 = extractvalue %dx.types.CBufRet.i32 %3069, 3
  %3075 = fmul fast float %140, %565
  %3076 = call float @dx.op.tertiary.f32(i32 46, float %566, float %141, float %3075)  ; FMad(a,b,c)
  %3077 = call float @dx.op.tertiary.f32(i32 46, float %567, float %142, float %3076)  ; FMad(a,b,c)
  %3078 = fadd fast float %3077, %143
  %3079 = fmul fast float %145, %565
  %3080 = call float @dx.op.tertiary.f32(i32 46, float %566, float %146, float %3079)  ; FMad(a,b,c)
  %3081 = call float @dx.op.tertiary.f32(i32 46, float %567, float %147, float %3080)  ; FMad(a,b,c)
  %3082 = fadd fast float %3081, %148
  %3083 = fmul fast float %150, %565
  %3084 = call float @dx.op.tertiary.f32(i32 46, float %566, float %151, float %3083)  ; FMad(a,b,c)
  %3085 = call float @dx.op.tertiary.f32(i32 46, float %567, float %152, float %3084)  ; FMad(a,b,c)
  %3086 = fadd fast float %3085, %153
  %3087 = call float @dx.op.binary.f32(i32 36, float %3078, float %3082)  ; FMin(a,b)
  %3088 = call float @dx.op.binary.f32(i32 36, float %3087, float %3086)  ; FMin(a,b)
  %3089 = call float @dx.op.binary.f32(i32 35, float %3078, float %3082)  ; FMax(a,b)
  %3090 = fsub fast float 1.000000e+00, %3089
  %3091 = call float @dx.op.binary.f32(i32 36, float %3088, float %3090)  ; FMin(a,b)
  %3092 = fcmp fast ogt float %3091, 0.000000e+00
  br i1 %3092, label %3093, label %3208

; <label>:3093                                    ; preds = %3072
  %3094 = add i32 %3073, -1
  %3095 = lshr i32 %3094, 1
  %3096 = fmul fast float %3078, %137
  %3097 = fmul fast float %3082, %137
  %3098 = fadd fast float %3096, -5.000000e-01
  %3099 = fadd fast float %3097, -5.000000e-01
  %3100 = call float @dx.op.unary.f32(i32 22, float %3098)  ; Frc(value)
  %3101 = call float @dx.op.unary.f32(i32 22, float %3099)  ; Frc(value)
  %3102 = fsub fast float 1.000000e+00, %3100
  %3103 = fsub fast float 1.000000e+00, %3101
  %3104 = fmul fast float %3103, %3102
  %3105 = fmul fast float %3103, %3100
  %3106 = fmul fast float %3102, %3101
  %3107 = fmul fast float %3101, %3100
  %3108 = call float @dx.op.unary.f32(i32 27, float %3098)  ; Round_ni(value)
  %3109 = fptosi float %3108 to i32
  %3110 = sub i32 %3109, %3095
  %3111 = sitofp i32 %3110 to float
  %3112 = fmul fast float %3111, %138
  %3113 = fadd fast float %3112, %138
  %3114 = fmul fast float %138, 2.000000e+00
  %3115 = icmp eq i32 %3073, 0
  br i1 %3115, label %3204, label %3116

; <label>:3116                                    ; preds = %3093
  %3117 = call float @dx.op.unary.f32(i32 27, float %3099)  ; Round_ni(value)
  %3118 = fptosi float %3117 to i32
  %3119 = sub i32 %3118, %3095
  %3120 = sitofp i32 %3119 to float
  %3121 = fmul fast float %3120, %138
  %3122 = fadd fast float %3121, %138
  %3123 = extractvalue %dx.types.CBufRet.i32 %3069, 2
  br label %3124

; <label>:3124                                    ; preds = %3197, %3116
  %3125 = phi float [ %3198, %3197 ], [ %3122, %3116 ]
  %3126 = phi float [ %3193, %3197 ], [ 0.000000e+00, %3116 ]
  %3127 = phi i32 [ %3200, %3197 ], [ %3123, %3116 ]
  %3128 = phi i32 [ %3201, %3197 ], [ 0, %3116 ]
  br label %3129

; <label>:3129                                    ; preds = %3129, %3124
  %3130 = phi float [ %3193, %3129 ], [ %3126, %3124 ]
  %3131 = phi float [ %3194, %3129 ], [ %3113, %3124 ]
  %3132 = phi i32 [ %3195, %3129 ], [ 0, %3124 ]
  %3133 = add i32 %3132, %3127
  %3134 = add i32 %3133, %3074
  %3135 = add i32 %3133, 35
  %3136 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3135)  ; CBufferLoadLegacy(handle,regIndex)
  %3137 = extractvalue %dx.types.CBufRet.f32 %3136, 0
  %3138 = fmul fast float %3137, %3107
  %3139 = extractvalue %dx.types.CBufRet.f32 %3136, 1
  %3140 = fmul fast float %3139, %3106
  %3141 = fadd fast float %3140, %3138
  %3142 = extractvalue %dx.types.CBufRet.f32 %3136, 2
  %3143 = fmul fast float %3142, %3105
  %3144 = fadd fast float %3141, %3143
  %3145 = extractvalue %dx.types.CBufRet.f32 %3136, 3
  %3146 = fmul fast float %3145, %3104
  %3147 = fadd fast float %3144, %3146
  %3148 = add i32 %3133, 36
  %3149 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3148)  ; CBufferLoadLegacy(handle,regIndex)
  %3150 = extractvalue %dx.types.CBufRet.f32 %3149, 0
  %3151 = fmul fast float %3150, %3107
  %3152 = extractvalue %dx.types.CBufRet.f32 %3149, 1
  %3153 = fmul fast float %3152, %3106
  %3154 = fadd fast float %3153, %3151
  %3155 = extractvalue %dx.types.CBufRet.f32 %3149, 2
  %3156 = fmul fast float %3155, %3105
  %3157 = fadd fast float %3154, %3156
  %3158 = extractvalue %dx.types.CBufRet.f32 %3149, 3
  %3159 = fmul fast float %3158, %3104
  %3160 = fadd fast float %3157, %3159
  %3161 = add i32 %3134, 35
  %3162 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3161)  ; CBufferLoadLegacy(handle,regIndex)
  %3163 = extractvalue %dx.types.CBufRet.f32 %3162, 0
  %3164 = fmul fast float %3163, %3107
  %3165 = extractvalue %dx.types.CBufRet.f32 %3162, 1
  %3166 = fmul fast float %3165, %3106
  %3167 = fadd fast float %3166, %3164
  %3168 = extractvalue %dx.types.CBufRet.f32 %3162, 2
  %3169 = fmul fast float %3168, %3105
  %3170 = fadd fast float %3167, %3169
  %3171 = extractvalue %dx.types.CBufRet.f32 %3162, 3
  %3172 = fmul fast float %3171, %3104
  %3173 = fadd fast float %3170, %3172
  %3174 = add i32 %3134, 36
  %3175 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3174)  ; CBufferLoadLegacy(handle,regIndex)
  %3176 = extractvalue %dx.types.CBufRet.f32 %3175, 0
  %3177 = fmul fast float %3176, %3107
  %3178 = extractvalue %dx.types.CBufRet.f32 %3175, 1
  %3179 = fmul fast float %3178, %3106
  %3180 = fadd fast float %3179, %3177
  %3181 = extractvalue %dx.types.CBufRet.f32 %3175, 2
  %3182 = fmul fast float %3181, %3105
  %3183 = fadd fast float %3180, %3182
  %3184 = extractvalue %dx.types.CBufRet.f32 %3175, 3
  %3185 = fmul fast float %3184, %3104
  %3186 = fadd fast float %3183, %3185
  %3187 = call %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32 74, %dx.types.Handle %35, %dx.types.Handle %36, float %3131, float %3125, float undef, float undef, i32 0, i32 0, i32 0, float %3086)  ; TextureGatherCmp(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,channel,compareValue)
  %3188 = extractvalue %dx.types.ResRet.f32 %3187, 0
  %3189 = extractvalue %dx.types.ResRet.f32 %3187, 1
  %3190 = extractvalue %dx.types.ResRet.f32 %3187, 2
  %3191 = extractvalue %dx.types.ResRet.f32 %3187, 3
  %3192 = call float @dx.op.dot4.f32(i32 56, float %3191, float %3190, float %3188, float %3189, float %3147, float %3160, float %3173, float %3186)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %3193 = fadd fast float %3192, %3130
  %3194 = fadd fast float %3131, %3114
  %3195 = add i32 %3132, 2
  %3196 = icmp ult i32 %3195, %3073
  br i1 %3196, label %3129, label %3197

; <label>:3197                                    ; preds = %3129
  %3198 = fadd fast float %3125, %3114
  %3199 = shl i32 %3074, 1
  %3200 = add i32 %3127, %3199
  %3201 = add i32 %3128, 2
  %3202 = icmp ult i32 %3201, %3073
  br i1 %3202, label %3124, label %3203

; <label>:3203                                    ; preds = %3197
  br label %3204

; <label>:3204                                    ; preds = %3203, %3093
  %3205 = phi float [ 0.000000e+00, %3093 ], [ %3193, %3203 ]
  %3206 = call float @dx.op.unary.f32(i32 7, float %3205)  ; Saturate(value)
  %3207 = call float @dx.op.binary.f32(i32 36, float %3065, float %3206)  ; FMin(a,b)
  br label %3208

; <label>:3208                                    ; preds = %3204, %3072, %3068, %3064
  %3209 = phi float [ %3207, %3204 ], [ %3065, %3072 ], [ %3065, %3068 ], [ %3065, %3064 ]
  %3210 = icmp eq i32 %105, 1
  br i1 %3210, label %3211, label %3260

; <label>:3211                                    ; preds = %3208
  %3212 = fmul fast float %88, %62
  %3213 = fmul fast float %90, %62
  %3214 = fmul fast float %110, %3212
  %3215 = fmul fast float %110, %3213
  %3216 = fsub fast float %565, %3214
  %3217 = fsub fast float %567, %3215
  %3218 = fmul fast float %3216, %109
  %3219 = fmul fast float %3217, %109
  %3220 = fadd fast float %3218, %107
  %3221 = fadd fast float %3219, %108
  %3222 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %14, %dx.types.Handle %43, float %3220, float %3221, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3223 = extractvalue %dx.types.ResRet.f32 %3222, 0
  %3224 = fadd fast float %3223, %112
  %3225 = call float @dx.op.unary.f32(i32 7, float %3224)  ; Saturate(value)
  %3226 = call float @dx.op.unary.f32(i32 23, float %3225)  ; Log(value)
  %3227 = fmul fast float %3226, %113
  %3228 = call float @dx.op.unary.f32(i32 21, float %3227)  ; Exp(value)
  %3229 = fcmp fast olt float %112, 1.000000e+00
  br i1 %3229, label %3230, label %3247

; <label>:3230                                    ; preds = %3211
  %3231 = fmul fast float %123, %3212
  %3232 = fmul fast float %123, %3213
  %3233 = fsub fast float %565, %3231
  %3234 = fsub fast float %567, %3232
  %3235 = fmul fast float %3233, %122
  %3236 = fmul fast float %3234, %122
  %3237 = fadd fast float %3235, %120
  %3238 = fadd fast float %3236, %121
  %3239 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %12, %dx.types.Handle %43, float %3237, float %3238, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3240 = extractvalue %dx.types.ResRet.f32 %3239, 0
  %3241 = fadd fast float %3240, %125
  %3242 = call float @dx.op.unary.f32(i32 7, float %3241)  ; Saturate(value)
  %3243 = call float @dx.op.unary.f32(i32 23, float %3242)  ; Log(value)
  %3244 = fmul fast float %3243, %126
  %3245 = call float @dx.op.unary.f32(i32 21, float %3244)  ; Exp(value)
  %3246 = fmul fast float %3245, %3228
  br label %3247

; <label>:3247                                    ; preds = %3230, %3211
  %3248 = phi float [ %3246, %3230 ], [ %3228, %3211 ]
  %3249 = fmul fast float %878, %116
  %3250 = fadd fast float %3249, %115
  %3251 = call float @dx.op.unary.f32(i32 7, float %3250)  ; Saturate(value)
  %3252 = fmul fast float %118, %62
  %3253 = fadd fast float %3252, %117
  %3254 = call float @dx.op.unary.f32(i32 7, float %3253)  ; Saturate(value)
  %3255 = call float @dx.op.binary.f32(i32 35, float %3251, float %3254)  ; FMax(a,b)
  %3256 = fsub fast float 1.000000e+00, %3248
  %3257 = fmul fast float %3255, %3255
  %3258 = fmul fast float %3257, %3256
  %3259 = fadd fast float %3258, %3248
  br label %3278

; <label>:3260                                    ; preds = %3208
  %3261 = icmp eq i32 %105, 2
  br i1 %3261, label %3262, label %3278

; <label>:3262                                    ; preds = %3260
  %3263 = call float @dx.op.unary.f32(i32 6, float %89)  ; FAbs(value)
  %3264 = fcmp fast olt float %3263, 0x3EB0C6F7A0000000
  %3265 = select i1 %3264, float 0x3EB0C6F7A0000000, float %89
  %3266 = fsub fast float %113, %62
  %3267 = fdiv fast float %3266, %3265
  %3268 = fmul fast float %3267, %88
  %3269 = fmul fast float %3267, %90
  %3270 = fadd fast float %107, %61
  %3271 = fadd fast float %3270, %3268
  %3272 = fadd fast float %108, %63
  %3273 = fadd fast float %3272, %3269
  %3274 = fmul fast float %3271, %109
  %3275 = fmul fast float %3273, %109
  %3276 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %14, %dx.types.Handle %43, float %3274, float %3275, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3277 = extractvalue %dx.types.ResRet.f32 %3276, 0
  br label %3278

; <label>:3278                                    ; preds = %3262, %3260, %3247
  %3279 = phi float [ %3259, %3247 ], [ %3277, %3262 ], [ 1.000000e+00, %3260 ]
  %3280 = fmul fast float %3279, %3209
  %3281 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %272, float %273, float %274)  ; Dot3(ax,ay,az,bx,by,bz)
  %3282 = call float @dx.op.unary.f32(i32 7, float %3281)  ; Saturate(value)
  %3283 = fmul fast float %2882, %2882
  %3284 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %24, %dx.types.Handle %40, float %3282, float %3283, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3285 = extractvalue %dx.types.ResRet.f32 %3284, 0
  %3286 = extractvalue %dx.types.ResRet.f32 %3284, 1
  %3287 = extractvalue %dx.types.ResRet.f32 %3284, 2
  %3288 = fsub fast float %3285, %3286
  %3289 = fmul fast float %3288, 0x3FA47AE140000000
  %3290 = fadd fast float %3289, %3286
  %3291 = fmul fast float %3282, %2879
  %3292 = fmul fast float %3282, %2880
  %3293 = fmul fast float %3282, %2881
  %3294 = fsub fast float %272, %3291
  %3295 = fsub fast float %273, %3292
  %3296 = fsub fast float %274, %3293
  %3297 = call float @dx.op.dot3.f32(i32 55, float %3294, float %3295, float %3296, float %3294, float %3295, float %3296)  ; Dot3(ax,ay,az,bx,by,bz)
  %3298 = call float @dx.op.unary.f32(i32 25, float %3297)  ; Rsqrt(value)
  %3299 = fmul fast float %3298, %3294
  %3300 = fmul fast float %3298, %3295
  %3301 = fmul fast float %3298, %3296
  %3302 = fmul fast float %3301, %2880
  %3303 = fmul fast float %3300, %2881
  %3304 = fsub fast float %3302, %3303
  %3305 = fmul fast float %3299, %2881
  %3306 = fmul fast float %3301, %2879
  %3307 = fsub fast float %3305, %3306
  %3308 = fmul fast float %3300, %2879
  %3309 = fmul fast float %3299, %2880
  %3310 = fsub fast float %3308, %3309
  %3311 = call float @dx.op.binary.f32(i32 35, float %2882, float 0x3FA6E5B7E0000000)  ; FMax(a,b)
  %3312 = call float @dx.op.unary.f32(i32 7, float %3282)  ; Saturate(value)
  %3313 = fsub fast float 1.000000e+00, %3312
  %3314 = call float @dx.op.unary.f32(i32 24, float %3313)  ; Sqrt(value)
  %3315 = fmul fast float %3311, 9.843750e-01
  %3316 = fmul fast float %3314, 9.843750e-01
  %3317 = fadd fast float %3315, 7.812500e-03
  %3318 = fadd fast float %3316, 7.812500e-03
  %3319 = call float @dx.op.unary.f32(i32 7, float %3317)  ; Saturate(value)
  %3320 = call float @dx.op.unary.f32(i32 7, float %3318)  ; Saturate(value)
  %3321 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %22, %dx.types.Handle %40, float %3319, float %3320, float 1.000000e+00, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3322 = extractvalue %dx.types.ResRet.f32 %3321, 0
  %3323 = extractvalue %dx.types.ResRet.f32 %3321, 1
  %3324 = extractvalue %dx.types.ResRet.f32 %3321, 2
  %3325 = extractvalue %dx.types.ResRet.f32 %3321, 3
  %3326 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %22, %dx.types.Handle %40, float %3319, float %3320, float 0.000000e+00, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3327 = extractvalue %dx.types.ResRet.f32 %3326, 0
  %3328 = extractvalue %dx.types.ResRet.f32 %3326, 1
  %3329 = extractvalue %dx.types.ResRet.f32 %3326, 2
  %3330 = extractvalue %dx.types.ResRet.f32 %3326, 3
  %3331 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 155)  ; CBufferLoadLegacy(handle,regIndex)
  %3332 = extractvalue %dx.types.CBufRet.i32 %3331, 0
  %3333 = extractvalue %dx.types.CBufRet.i32 %3331, 1
  %3334 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 156)  ; CBufferLoadLegacy(handle,regIndex)
  %3335 = extractvalue %dx.types.CBufRet.i32 %3334, 0
  %3336 = extractvalue %dx.types.CBufRet.i32 %3334, 2
  %3337 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 157)  ; CBufferLoadLegacy(handle,regIndex)
  %3338 = extractvalue %dx.types.CBufRet.i32 %3337, 0
  %3339 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 31)  ; CBufferLoadLegacy(handle,regIndex)
  %3340 = extractvalue %dx.types.CBufRet.i32 %3339, 0
  %3341 = extractvalue %dx.types.CBufRet.i32 %3339, 1
  %3342 = sub i32 0, %3341
  %3343 = icmp eq i32 %3340, %3342
  br i1 %3343, label %3387, label %3344

; <label>:3344                                    ; preds = %3278
  %3345 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 29)  ; CBufferLoadLegacy(handle,regIndex)
  %3346 = extractvalue %dx.types.CBufRet.i32 %3345, 0
  %3347 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 32)  ; CBufferLoadLegacy(handle,regIndex)
  %3348 = extractvalue %dx.types.CBufRet.i32 %3347, 0
  %3349 = extractvalue %dx.types.CBufRet.i32 %3347, 1
  %3350 = extractvalue %dx.types.CBufRet.i32 %3347, 2
  %3351 = extractvalue %dx.types.CBufRet.i32 %3347, 3
  %3352 = bitcast i32 %3348 to float
  %3353 = bitcast i32 %3349 to float
  %3354 = bitcast i32 %3350 to float
  %3355 = bitcast i32 %3351 to float
  %3356 = fmul fast float %3352, %47
  %3357 = fmul fast float %3353, %48
  %3358 = fadd fast float %3356, %3354
  %3359 = fadd fast float %3357, %3355
  %3360 = fptoui float %3358 to i32
  %3361 = fptoui float %3359 to i32
  %3362 = extractvalue %dx.types.CBufRet.i32 %3339, 2
  %3363 = extractvalue %dx.types.CBufRet.i32 %3339, 3
  %3364 = extractvalue %dx.types.CBufRet.i32 %3345, 2
  %3365 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 33)  ; CBufferLoadLegacy(handle,regIndex)
  %3366 = extractvalue %dx.types.CBufRet.i32 %3365, 0
  %3367 = extractvalue %dx.types.CBufRet.i32 %3365, 1
  %3368 = extractvalue %dx.types.CBufRet.i32 %3365, 2
  %3369 = extractvalue %dx.types.CBufRet.i32 %3365, 3
  %3370 = mul i32 %3361, %3346
  %3371 = add i32 %3370, %3360
  %3372 = mul i32 %3371, %3362
  %3373 = fsub fast float %49, %156
  %3374 = fdiv fast float 1.000000e+00, %3373
  %3375 = bitcast i32 %3366 to float
  %3376 = fmul fast float %3374, %155
  %3377 = fmul fast float %3376, %3375
  %3378 = bitcast i32 %3367 to float
  %3379 = fadd fast float %3377, %3378
  %3380 = call i32 @dx.op.legacyF32ToF16(i32 130, float %3379)  ; LegacyF32ToF16(value)
  %3381 = and i32 %3369, 31
  %3382 = lshr i32 %3380, %3381
  %3383 = and i32 %3368, 31
  %3384 = shl i32 1, %3383
  %3385 = add i32 %3384, -1
  %3386 = and i32 %3385, %3382
  br label %3387

; <label>:3387                                    ; preds = %3344, %3278
  %3388 = phi i32 [ %3363, %3344 ], [ 0, %3278 ]
  %3389 = phi i32 [ %3364, %3344 ], [ 0, %3278 ]
  %3390 = phi i32 [ %3372, %3344 ], [ 0, %3278 ]
  %3391 = phi i32 [ %3386, %3344 ], [ 0, %3278 ]
  %3392 = icmp eq i32 %3340, 0
  br i1 %3392, label %6576, label %3393

; <label>:3393                                    ; preds = %3387
  %3394 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %21, i32 %3391, i32 0)  ; BufferLoad(srv,index,wot)
  %3395 = extractvalue %dx.types.ResRet.i32 %3394, 0
  %3396 = and i32 %3395, 65535
  %3397 = lshr i32 %3395, 16
  %3398 = lshr i32 %3396, 5
  %3399 = lshr i32 %3395, 21
  %3400 = icmp ugt i32 %3398, %3399
  br i1 %3400, label %6576, label %3401

; <label>:3401                                    ; preds = %3393
  br label %3402

; <label>:3402                                    ; preds = %6543, %3401
  %3403 = phi float [ %6544, %6543 ], [ 0.000000e+00, %3401 ]
  %3404 = phi float [ %6545, %6543 ], [ 0.000000e+00, %3401 ]
  %3405 = phi float [ %6546, %6543 ], [ 0.000000e+00, %3401 ]
  %3406 = phi float [ %6570, %6543 ], [ 0.000000e+00, %3401 ]
  %3407 = phi float [ %6571, %6543 ], [ 0.000000e+00, %3401 ]
  %3408 = phi float [ %6572, %6543 ], [ 0.000000e+00, %3401 ]
  %3409 = phi i32 [ %6573, %6543 ], [ %3398, %3401 ]
  %3410 = add i32 %3409, %3390
  %3411 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %29, i32 %3410, i32 0)  ; BufferLoad(srv,index,wot)
  %3412 = extractvalue %dx.types.ResRet.i32 %3411, 0
  %3413 = shl i32 %3409, 5
  %3414 = sub nsw i32 %3396, %3413
  %3415 = call i32 @dx.op.binary.i32(i32 37, i32 %3414, i32 0)  ; IMax(a,b)
  %3416 = call i32 @dx.op.binary.i32(i32 38, i32 %3415, i32 31)  ; IMin(a,b)
  %3417 = add nuw nsw i32 %3413, 32
  %3418 = icmp uge i32 %3396, %3417
  %3419 = icmp ult i32 %3397, %3413
  %3420 = or i1 %3419, %3418
  br i1 %3420, label %3429, label %3421

; <label>:3421                                    ; preds = %3402
  %3422 = sub nsw i32 %3397, %3413
  %3423 = call i32 @dx.op.binary.i32(i32 37, i32 %3422, i32 0)  ; IMax(a,b)
  %3424 = call i32 @dx.op.binary.i32(i32 38, i32 %3423, i32 31)  ; IMin(a,b)
  %3425 = sub i32 1, %3416
  %3426 = add i32 %3425, %3424
  %3427 = call i32 @dx.op.binary.i32(i32 37, i32 %3426, i32 0)  ; IMax(a,b)
  %3428 = call i32 @dx.op.binary.i32(i32 38, i32 %3427, i32 32)  ; IMin(a,b)
  br label %3429

; <label>:3429                                    ; preds = %3421, %3402
  %3430 = phi i32 [ %3428, %3421 ], [ 0, %3402 ]
  %3431 = icmp eq i32 %3430, 32
  br i1 %3431, label %3438, label %3432

; <label>:3432                                    ; preds = %3429
  %3433 = and i32 %3430, 31
  %3434 = shl i32 1, %3433
  %3435 = add i32 %3434, -1
  %3436 = and i32 %3416, 31
  %3437 = shl i32 %3435, %3436
  br label %3438

; <label>:3438                                    ; preds = %3432, %3429
  %3439 = phi i32 [ %3437, %3432 ], [ -1, %3429 ]
  %3440 = and i32 %3439, %3412
  %3441 = icmp eq i32 %3440, 0
  br i1 %3441, label %6543, label %3442

; <label>:3442                                    ; preds = %3438
  br label %3443

; <label>:3443                                    ; preds = %3515, %3442
  %3444 = phi float [ %3516, %3515 ], [ %3403, %3442 ]
  %3445 = phi float [ %3517, %3515 ], [ %3404, %3442 ]
  %3446 = phi float [ %3518, %3515 ], [ %3405, %3442 ]
  %3447 = phi float [ %3519, %3515 ], [ %3406, %3442 ]
  %3448 = phi float [ %3520, %3515 ], [ %3407, %3442 ]
  %3449 = phi float [ %3521, %3515 ], [ %3408, %3442 ]
  %3450 = phi i32 [ %3454, %3515 ], [ %3440, %3442 ]
  %3451 = call i32 @dx.op.unaryBits.i32(i32 32, i32 %3450)  ; FirstbitLo(value)
  %3452 = and i32 %3451, 31
  %3453 = shl i32 1, %3452
  %3454 = xor i32 %3453, %3450
  %3455 = add i32 %3451, %3413
  %3456 = add i32 %3455, %3332
  %3457 = shl i32 %3456, 2
  %3458 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %3457, i32 undef)  ; BufferLoad(srv,index,wot)
  %3459 = extractvalue %dx.types.ResRet.i32 %3458, 0
  %3460 = lshr i32 %3459, 19
  %3461 = and i32 %3460, 7
  %3462 = mul i32 %3455, 28
  %3463 = add i32 %3462, %3335
  %3464 = shl i32 %3463, 2
  %3465 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3464, i32 undef)  ; BufferLoad(srv,index,wot)
  %3466 = extractvalue %dx.types.ResRet.f32 %3465, 0
  %3467 = extractvalue %dx.types.ResRet.f32 %3465, 1
  %3468 = extractvalue %dx.types.ResRet.f32 %3465, 2
  %3469 = add i32 %3464, 12
  %3470 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3469, i32 undef)  ; BufferLoad(srv,index,wot)
  %3471 = extractvalue %dx.types.ResRet.f32 %3470, 0
  %3472 = add i32 %3464, 16
  %3473 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3472, i32 undef)  ; BufferLoad(srv,index,wot)
  %3474 = extractvalue %dx.types.ResRet.f32 %3473, 0
  %3475 = extractvalue %dx.types.ResRet.f32 %3473, 1
  %3476 = extractvalue %dx.types.ResRet.f32 %3473, 2
  %3477 = add i32 %3464, 28
  %3478 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3477, i32 undef)  ; BufferLoad(srv,index,wot)
  %3479 = extractvalue %dx.types.ResRet.f32 %3478, 0
  %3480 = add i32 %3464, 36
  %3481 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3480, i32 undef)  ; BufferLoad(srv,index,wot)
  %3482 = extractvalue %dx.types.ResRet.f32 %3481, 0
  %3483 = add i32 %3464, 40
  %3484 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3483, i32 undef)  ; BufferLoad(srv,index,wot)
  %3485 = extractvalue %dx.types.ResRet.f32 %3484, 0
  %3486 = add i32 %3464, 44
  %3487 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %3486, i32 undef)  ; BufferLoad(srv,index,wot)
  %3488 = extractvalue %dx.types.ResRet.i32 %3487, 0
  %3489 = add i32 %3464, 48
  %3490 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3489, i32 undef)  ; BufferLoad(srv,index,wot)
  %3491 = extractvalue %dx.types.ResRet.f32 %3490, 0
  %3492 = extractvalue %dx.types.ResRet.f32 %3490, 1
  %3493 = extractvalue %dx.types.ResRet.f32 %3490, 2
  %3494 = add i32 %3464, 60
  %3495 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3494, i32 undef)  ; BufferLoad(srv,index,wot)
  %3496 = extractvalue %dx.types.ResRet.f32 %3495, 0
  %3497 = add i32 %3464, 64
  %3498 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3497, i32 undef)  ; BufferLoad(srv,index,wot)
  %3499 = extractvalue %dx.types.ResRet.f32 %3498, 0
  %3500 = extractvalue %dx.types.ResRet.f32 %3498, 1
  %3501 = extractvalue %dx.types.ResRet.f32 %3498, 2
  %3502 = add i32 %3464, 76
  %3503 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3502, i32 undef)  ; BufferLoad(srv,index,wot)
  %3504 = extractvalue %dx.types.ResRet.f32 %3503, 0
  %3505 = add i32 %3464, 80
  %3506 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3505, i32 undef)  ; BufferLoad(srv,index,wot)
  %3507 = extractvalue %dx.types.ResRet.f32 %3506, 0
  %3508 = extractvalue %dx.types.ResRet.f32 %3506, 1
  %3509 = extractvalue %dx.types.ResRet.f32 %3506, 2
  %3510 = add i32 %3464, 96
  %3511 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3510, i32 undef)  ; BufferLoad(srv,index,wot)
  %3512 = extractvalue %dx.types.ResRet.f32 %3511, 0
  %3513 = extractvalue %dx.types.ResRet.f32 %3511, 1
  %3514 = extractvalue %dx.types.ResRet.f32 %3511, 2
  switch i32 %3461, label %3515 [
    i32 0, label %3523
    i32 1, label %4087
  ]

; <label>:3515                                    ; preds = %6528, %4080, %4059, %3443
  %3516 = phi float [ %3444, %3443 ], [ %6539, %6528 ], [ %4077, %4059 ], [ %4084, %4080 ]
  %3517 = phi float [ %3445, %3443 ], [ %6540, %6528 ], [ %4078, %4059 ], [ %4085, %4080 ]
  %3518 = phi float [ %3446, %3443 ], [ %6541, %6528 ], [ %4079, %4059 ], [ %4086, %4080 ]
  %3519 = phi float [ %3447, %3443 ], [ %6533, %6528 ], [ %4071, %4059 ], [ %4081, %4080 ]
  %3520 = phi float [ %3448, %3443 ], [ %6534, %6528 ], [ %4072, %4059 ], [ %4082, %4080 ]
  %3521 = phi float [ %3449, %3443 ], [ %6535, %6528 ], [ %4073, %4059 ], [ %4083, %4080 ]
  %3522 = icmp eq i32 %3450, %3453
  br i1 %3522, label %6542, label %3443

; <label>:3523                                    ; preds = %3443
  %3524 = fsub fast float %3466, %565
  %3525 = fsub fast float %3467, %566
  %3526 = fsub fast float %3468, %567
  %3527 = call float @dx.op.dot3.f32(i32 55, float %3524, float %3525, float %3526, float %3524, float %3525, float %3526)  ; Dot3(ax,ay,az,bx,by,bz)
  %3528 = call float @dx.op.unary.f32(i32 25, float %3527)  ; Rsqrt(value)
  %3529 = fmul fast float %3528, %3524
  %3530 = fmul fast float %3528, %3525
  %3531 = fmul fast float %3528, %3526
  %3532 = fadd fast float %3527, %3479
  %3533 = call float @dx.op.binary.f32(i32 35, float 0x3F1A36E2E0000000, float %3532)  ; FMax(a,b)
  %3534 = fdiv fast float 1.000000e+00, %3533
  %3535 = fmul fast float %3527, %3471
  %3536 = fmul fast float %3535, %3535
  %3537 = fsub fast float 1.000000e+00, %3536
  %3538 = call float @dx.op.unary.f32(i32 7, float %3537)  ; Saturate(value)
  %3539 = call float @dx.op.dot3.f32(i32 55, float %3491, float %3492, float %3493, float %3529, float %3530, float %3531)  ; Dot3(ax,ay,az,bx,by,bz)
  %3540 = fmul fast float %3539, %3482
  %3541 = fadd fast float %3540, %3485
  %3542 = call float @dx.op.unary.f32(i32 7, float %3541)  ; Saturate(value)
  %3543 = fmul float %3538, %3542
  %3544 = fmul float %3543, %3543
  %3545 = fmul fast float %3544, %3534
  %3546 = fcmp fast ogt float %3545, 0.000000e+00
  %3547 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %3529, float %3530, float %3531)  ; Dot3(ax,ay,az,bx,by,bz)
  %3548 = call float @dx.op.unary.f32(i32 7, float %3547)  ; Saturate(value)
  %3549 = fmul fast float %3545, %3548
  %3550 = fcmp fast ogt float %3549, 0.000000e+00
  br i1 %3550, label %3551, label %3656

; <label>:3551                                    ; preds = %3523
  %3552 = fadd fast float %3529, %272
  %3553 = fadd fast float %3530, %273
  %3554 = fadd fast float %3531, %274
  %3555 = call float @dx.op.dot3.f32(i32 55, float %3552, float %3553, float %3554, float %3552, float %3553, float %3554)  ; Dot3(ax,ay,az,bx,by,bz)
  %3556 = call float @dx.op.unary.f32(i32 25, float %3555)  ; Rsqrt(value)
  %3557 = fmul fast float %3556, %3552
  %3558 = fmul fast float %3556, %3553
  %3559 = fmul fast float %3556, %3554
  %3560 = call float @dx.op.unary.f32(i32 6, float %3281)  ; FAbs(value)
  %3561 = call float @dx.op.binary.f32(i32 35, float %3560, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %3562 = call float @dx.op.unary.f32(i32 7, float %3561)  ; Saturate(value)
  %3563 = call float @dx.op.dot3.f32(i32 55, float %3529, float %3530, float %3531, float %3557, float %3558, float %3559)  ; Dot3(ax,ay,az,bx,by,bz)
  %3564 = call float @dx.op.unary.f32(i32 7, float %3563)  ; Saturate(value)
  %3565 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %3557, float %3558, float %3559)  ; Dot3(ax,ay,az,bx,by,bz)
  %3566 = call float @dx.op.unary.f32(i32 7, float %3565)  ; Saturate(value)
  %3567 = call float @dx.op.unary.f32(i32 6, float %3565)  ; FAbs(value)
  %3568 = call float @dx.op.binary.f32(i32 35, float %3567, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %3569 = call float @dx.op.unary.f32(i32 7, float %3568)  ; Saturate(value)
  %3570 = fsub fast float 1.000000e+00, %3564
  %3571 = fmul fast float %3570, %3570
  %3572 = fmul fast float %3571, %3571
  %3573 = fmul fast float %3572, %3570
  %3574 = fmul fast float %3573, 0x3FEEB851E0000000
  %3575 = fadd fast float %3574, 0x3FA47AE140000000
  %3576 = call float @dx.op.binary.f32(i32 35, float %3283, float 0x3F60624DE0000000)  ; FMax(a,b)
  %3577 = fmul fast float %3576, %3576
  %3578 = fmul fast float %3577, %3562
  %3579 = fsub fast float %3562, %3578
  %3580 = fmul fast float %3579, %3562
  %3581 = fadd fast float %3580, %3577
  %3582 = call float @dx.op.unary.f32(i32 24, float %3581)  ; Sqrt(value)
  %3583 = fmul fast float %3582, %3548
  %3584 = fmul fast float %3577, %3548
  %3585 = fsub fast float %3548, %3584
  %3586 = fmul fast float %3585, %3548
  %3587 = fadd fast float %3586, %3577
  %3588 = call float @dx.op.unary.f32(i32 24, float %3587)  ; Sqrt(value)
  %3589 = fmul fast float %3588, %3562
  %3590 = fadd fast float %3589, %3583
  %3591 = fdiv fast float 5.000000e-01, %3590
  %3592 = fmul fast float %3577, %3566
  %3593 = fsub fast float %3592, %3566
  %3594 = fmul fast float %3593, %3566
  %3595 = fadd fast float %3594, 1.000000e+00
  %3596 = fmul fast float %3595, %3595
  %3597 = fdiv fast float 1.000000e+00, %3596
  %3598 = fdiv fast float 2.000000e+00, %3577
  %3599 = fadd fast float %3598, -1.000000e+00
  %3600 = call float @dx.op.unary.f32(i32 23, float %3599)  ; Log(value)
  %3601 = fmul fast float %3600, 0x3FAC71C720000000
  %3602 = call float @dx.op.unary.f32(i32 7, float %3601)  ; Saturate(value)
  %3603 = fadd fast float %3573, %3564
  %3604 = fsub fast float 1.000000e+00, %3548
  %3605 = fmul fast float %3604, %3604
  %3606 = fmul fast float %3605, %3605
  %3607 = fmul fast float %3606, %3604
  %3608 = fsub fast float 1.000000e+00, %3607
  %3609 = fsub fast float 1.000000e+00, %3562
  %3610 = fmul fast float %3609, %3609
  %3611 = fmul fast float %3610, %3610
  %3612 = fmul fast float %3611, %3609
  %3613 = fsub fast float 1.000000e+00, %3612
  %3614 = fmul fast float %3613, %3608
  %3615 = fmul fast float %3602, 0x40019999A0000000
  %3616 = fadd fast float %3615, -5.000000e-01
  %3617 = call float @dx.op.unary.f32(i32 7, float %3616)  ; Saturate(value)
  %3618 = fsub fast float %3614, %3603
  %3619 = fmul fast float %3617, %3618
  %3620 = fadd fast float %3619, %3603
  %3621 = fmul fast float %3602, %3602
  %3622 = fmul fast float %3621, 3.450000e+01
  %3623 = fmul fast float %3602, 5.900000e+01
  %3624 = fsub fast float 2.450000e+01, %3623
  %3625 = fadd fast float %3624, %3622
  %3626 = fmul fast float %3625, %3564
  %3627 = fmul fast float %3602, 0x40524CCCC0000000
  %3628 = fadd fast float %3627, 0xC035333340000000
  %3629 = call float @dx.op.binary.f32(i32 35, float %3628, float 0x4021CCCCC0000000)  ; FMax(a,b)
  %3630 = call float @dx.op.unary.f32(i32 24, float %3569)  ; Sqrt(value)
  %3631 = fmul fast float %3629, %3630
  %3632 = fsub fast float -0.000000e+00, %3631
  %3633 = call float @dx.op.unary.f32(i32 21, float %3632)  ; Exp(value)
  %3634 = fmul fast float %3626, %3633
  %3635 = fadd fast float %3620, %3634
  %3636 = call float @dx.op.binary.f32(i32 35, float %3635, float 0.000000e+00)  ; FMax(a,b)
  %3637 = and i32 %3459, 32
  %3638 = icmp ne i32 %3637, 0
  %3639 = select i1 %3638, float 1.000000e+00, float 0.000000e+00
  %3640 = fmul fast float %3549, %3639
  %3641 = and i32 %3459, 64
  %3642 = icmp ne i32 %3641, 0
  %3643 = select i1 %3642, float 1.000000e+00, float 0.000000e+00
  %3644 = fmul fast float %3640, %3636
  %3645 = fmul fast float %3644, %3474
  %3646 = fmul fast float %3644, %3475
  %3647 = fmul fast float %3644, %3476
  %3648 = fmul fast float %3549, %3643
  %3649 = fmul fast float %3648, %3577
  %3650 = fmul fast float %3649, %3591
  %3651 = fmul fast float %3650, %3597
  %3652 = fmul fast float %3651, %3575
  %3653 = fmul fast float %3652, %3474
  %3654 = fmul fast float %3652, %3475
  %3655 = fmul fast float %3652, %3476
  br label %3656

; <label>:3656                                    ; preds = %3551, %3523
  %3657 = phi float [ %3645, %3551 ], [ 0.000000e+00, %3523 ]
  %3658 = phi float [ %3646, %3551 ], [ 0.000000e+00, %3523 ]
  %3659 = phi float [ %3647, %3551 ], [ 0.000000e+00, %3523 ]
  %3660 = phi float [ %3653, %3551 ], [ 0.000000e+00, %3523 ]
  %3661 = phi float [ %3654, %3551 ], [ 0.000000e+00, %3523 ]
  %3662 = phi float [ %3655, %3551 ], [ 0.000000e+00, %3523 ]
  %3663 = and i32 %3459, 256
  %3664 = icmp ne i32 %3663, 0
  %3665 = and i1 %3664, %3546
  br i1 %3665, label %3666, label %4080

; <label>:3666                                    ; preds = %3656
  %3667 = mul i32 %3488, 52
  %3668 = add i32 %3667, %3336
  %3669 = shl i32 %3668, 2
  %3670 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3669, i32 undef)  ; BufferLoad(srv,index,wot)
  %3671 = extractvalue %dx.types.ResRet.f32 %3670, 0
  %3672 = extractvalue %dx.types.ResRet.f32 %3670, 1
  %3673 = extractvalue %dx.types.ResRet.f32 %3670, 2
  %3674 = extractvalue %dx.types.ResRet.f32 %3670, 3
  %3675 = add i32 %3669, 16
  %3676 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3675, i32 undef)  ; BufferLoad(srv,index,wot)
  %3677 = extractvalue %dx.types.ResRet.f32 %3676, 0
  %3678 = extractvalue %dx.types.ResRet.f32 %3676, 1
  %3679 = extractvalue %dx.types.ResRet.f32 %3676, 2
  %3680 = extractvalue %dx.types.ResRet.f32 %3676, 3
  %3681 = add i32 %3669, 32
  %3682 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3681, i32 undef)  ; BufferLoad(srv,index,wot)
  %3683 = extractvalue %dx.types.ResRet.f32 %3682, 0
  %3684 = extractvalue %dx.types.ResRet.f32 %3682, 1
  %3685 = extractvalue %dx.types.ResRet.f32 %3682, 2
  %3686 = extractvalue %dx.types.ResRet.f32 %3682, 3
  %3687 = add i32 %3669, 48
  %3688 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3687, i32 undef)  ; BufferLoad(srv,index,wot)
  %3689 = extractvalue %dx.types.ResRet.f32 %3688, 0
  %3690 = extractvalue %dx.types.ResRet.f32 %3688, 1
  %3691 = extractvalue %dx.types.ResRet.f32 %3688, 2
  %3692 = extractvalue %dx.types.ResRet.f32 %3688, 3
  %3693 = add i32 %3669, 76
  %3694 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3693, i32 undef)  ; BufferLoad(srv,index,wot)
  %3695 = extractvalue %dx.types.ResRet.f32 %3694, 0
  %3696 = add i32 %3669, 80
  %3697 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3696, i32 undef)  ; BufferLoad(srv,index,wot)
  %3698 = extractvalue %dx.types.ResRet.f32 %3697, 0
  %3699 = add i32 %3669, 84
  %3700 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3699, i32 undef)  ; BufferLoad(srv,index,wot)
  %3701 = extractvalue %dx.types.ResRet.f32 %3700, 0
  %3702 = add i32 %3669, 96
  %3703 = add i32 %3669, 192
  %3704 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3703, i32 undef)  ; BufferLoad(srv,index,wot)
  %3705 = extractvalue %dx.types.ResRet.f32 %3704, 2
  %3706 = extractvalue %dx.types.ResRet.f32 %3704, 3
  %3707 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3702, i32 undef)  ; BufferLoad(srv,index,wot)
  %3708 = extractvalue %dx.types.ResRet.f32 %3707, 0
  %3709 = extractvalue %dx.types.ResRet.f32 %3707, 1
  %3710 = add i32 %3669, 112
  %3711 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3710, i32 undef)  ; BufferLoad(srv,index,wot)
  %3712 = extractvalue %dx.types.ResRet.f32 %3711, 0
  %3713 = extractvalue %dx.types.ResRet.f32 %3711, 1
  %3714 = extractvalue %dx.types.ResRet.f32 %3711, 2
  %3715 = extractvalue %dx.types.ResRet.f32 %3711, 3
  %3716 = add i32 %3669, 128
  %3717 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3716, i32 undef)  ; BufferLoad(srv,index,wot)
  %3718 = extractvalue %dx.types.ResRet.f32 %3717, 0
  %3719 = extractvalue %dx.types.ResRet.f32 %3717, 1
  %3720 = add i32 %3669, 144
  %3721 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3720, i32 undef)  ; BufferLoad(srv,index,wot)
  %3722 = extractvalue %dx.types.ResRet.f32 %3721, 0
  %3723 = extractvalue %dx.types.ResRet.f32 %3721, 1
  %3724 = add i32 %3669, 160
  %3725 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3724, i32 undef)  ; BufferLoad(srv,index,wot)
  %3726 = extractvalue %dx.types.ResRet.f32 %3725, 0
  %3727 = extractvalue %dx.types.ResRet.f32 %3725, 1
  %3728 = add i32 %3669, 176
  %3729 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %3728, i32 undef)  ; BufferLoad(srv,index,wot)
  %3730 = extractvalue %dx.types.ResRet.f32 %3729, 0
  %3731 = extractvalue %dx.types.ResRet.f32 %3729, 1
  %3732 = and i32 %3459, 16
  %3733 = icmp ne i32 %3732, 0
  %3734 = and i1 %3733, %3550
  br i1 %3734, label %3735, label %3774

; <label>:3735                                    ; preds = %3666
  %3736 = add i32 %3669, 68
  %3737 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %3736, i32 undef)  ; BufferLoad(srv,index,wot)
  %3738 = extractvalue %dx.types.ResRet.i32 %3737, 0
  %3739 = and i32 %3738, 65535
  %3740 = uitofp i32 %3739 to float
  %3741 = fsub fast float -0.000000e+00, %3529
  %3742 = fsub fast float -0.000000e+00, %3530
  %3743 = fsub fast float -0.000000e+00, %3531
  %3744 = fmul fast float %3507, %3741
  %3745 = call float @dx.op.tertiary.f32(i32 46, float %3508, float %3742, float %3744)  ; FMad(a,b,c)
  %3746 = call float @dx.op.tertiary.f32(i32 46, float %3509, float %3743, float %3745)  ; FMad(a,b,c)
  %3747 = fmul fast float %3499, %3741
  %3748 = call float @dx.op.tertiary.f32(i32 46, float %3500, float %3742, float %3747)  ; FMad(a,b,c)
  %3749 = call float @dx.op.tertiary.f32(i32 46, float %3501, float %3743, float %3748)  ; FMad(a,b,c)
  %3750 = fmul fast float %3491, %3741
  %3751 = call float @dx.op.tertiary.f32(i32 46, float %3492, float %3742, float %3750)  ; FMad(a,b,c)
  %3752 = call float @dx.op.tertiary.f32(i32 46, float %3493, float %3743, float %3751)  ; FMad(a,b,c)
  %3753 = fmul fast float %3752, 5.000000e-01
  %3754 = fadd fast float %3753, 5.000000e-01
  %3755 = fdiv fast float %3749, %3746
  %3756 = call float @dx.op.unary.f32(i32 17, float %3755)  ; Atan(value)
  %3757 = fadd fast float %3756, 0x400921FB60000000
  %3758 = fadd fast float %3756, 0xC00921FB60000000
  %3759 = fcmp fast olt float %3746, 0.000000e+00
  %3760 = fcmp fast oeq float %3746, 0.000000e+00
  %3761 = fcmp fast oge float %3749, 0.000000e+00
  %3762 = fcmp fast olt float %3749, 0.000000e+00
  %3763 = and i1 %3759, %3761
  %3764 = select i1 %3763, float %3757, float %3756
  %3765 = and i1 %3759, %3762
  %3766 = select i1 %3765, float %3758, float %3764
  %3767 = and i1 %3760, %3762
  %3768 = and i1 %3760, %3761
  %3769 = fmul fast float %3766, 0x3FC45F3060000000
  %3770 = select i1 %3767, float -2.500000e-01, float %3769
  %3771 = select i1 %3768, float 2.500000e-01, float %3770
  %3772 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %33, %dx.types.Handle %41, float %3771, float %3754, float %3740, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %3773 = extractvalue %dx.types.ResRet.f32 %3772, 0
  br label %3774

; <label>:3774                                    ; preds = %3735, %3666
  %3775 = phi float [ %3773, %3735 ], [ 1.000000e+00, %3666 ]
  %3776 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 30)  ; CBufferLoadLegacy(handle,regIndex)
  %3777 = extractvalue %dx.types.CBufRet.i32 %3776, 0
  %3778 = extractvalue %dx.types.CBufRet.i32 %3776, 1
  %3779 = extractvalue %dx.types.CBufRet.i32 %3776, 2
  %3780 = and i32 %3459, 6144
  %3781 = icmp ne i32 %3780, 0
  %3782 = and i1 %3781, %3550
  br i1 %3782, label %3783, label %4006

; <label>:3783                                    ; preds = %3774
  %3784 = fmul fast float %3698, %3539
  %3785 = fadd fast float %3784, %3701
  %3786 = call float @dx.op.unary.f32(i32 7, float %3785)  ; Saturate(value)
  %3787 = fmul fast float %3786, %3786
  %3788 = fcmp fast ogt float %3787, 0.000000e+00
  br i1 %3788, label %3789, label %4006

; <label>:3789                                    ; preds = %3783
  %3790 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 0
  %3791 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 0
  store float %3708, float* %3790, align 4
  store float %3709, float* %3791, align 4
  %3792 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 1
  %3793 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 1
  store float %3712, float* %3792, align 4
  store float %3713, float* %3793, align 4
  %3794 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 2
  %3795 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 2
  store float %3718, float* %3794, align 4
  store float %3719, float* %3795, align 4
  %3796 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 3
  %3797 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 3
  store float %3722, float* %3796, align 4
  store float %3723, float* %3797, align 4
  %3798 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 4
  %3799 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 4
  store float %3726, float* %3798, align 4
  store float %3727, float* %3799, align 4
  %3800 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 5
  %3801 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 5
  store float %3730, float* %3800, align 4
  store float %3731, float* %3801, align 4
  %3802 = icmp eq i32 %3780, 4096
  br i1 %3802, label %3803, label %3847

; <label>:3803                                    ; preds = %3789
  %3804 = call float @dx.op.unary.f32(i32 6, float %3524)  ; FAbs(value)
  %3805 = call float @dx.op.unary.f32(i32 6, float %3525)  ; FAbs(value)
  %3806 = call float @dx.op.unary.f32(i32 6, float %3526)  ; FAbs(value)
  %3807 = call float @dx.op.binary.f32(i32 35, float %3804, float %3805)  ; FMax(a,b)
  %3808 = call float @dx.op.binary.f32(i32 35, float %3807, float %3806)  ; FMax(a,b)
  %3809 = fcmp fast oge float %3806, %3805
  %3810 = fcmp fast oge float %3806, %3804
  %3811 = and i1 %3810, %3809
  br i1 %3811, label %3812, label %3818

; <label>:3812                                    ; preds = %3803
  %3813 = fsub fast float -0.000000e+00, %3524
  %3814 = fcmp fast olt float %3526, 0.000000e+00
  %3815 = select i1 %3814, float %3813, float %3524
  %3816 = fsub fast float -0.000000e+00, %3525
  %3817 = select i1 %3814, float 5.000000e+00, float 4.000000e+00
  br label %3830

; <label>:3818                                    ; preds = %3803
  %3819 = fcmp fast ult float %3805, %3804
  %3820 = fsub fast float -0.000000e+00, %3526
  br i1 %3819, label %3825, label %3821

; <label>:3821                                    ; preds = %3818
  %3822 = fcmp fast olt float %3525, 0.000000e+00
  %3823 = select i1 %3822, float %3820, float %3526
  %3824 = select i1 %3822, float 3.000000e+00, float 2.000000e+00
  br label %3830

; <label>:3825                                    ; preds = %3818
  %3826 = fcmp fast olt float %3524, 0.000000e+00
  %3827 = select i1 %3826, float %3526, float %3820
  %3828 = fsub fast float -0.000000e+00, %3525
  %3829 = select i1 %3826, float 1.000000e+00, float 0.000000e+00
  br label %3830

; <label>:3830                                    ; preds = %3825, %3821, %3812
  %3831 = phi float [ %3815, %3812 ], [ %3524, %3821 ], [ %3827, %3825 ]
  %3832 = phi float [ %3816, %3812 ], [ %3823, %3821 ], [ %3828, %3825 ]
  %3833 = phi float [ %3817, %3812 ], [ %3824, %3821 ], [ %3829, %3825 ]
  %3834 = fsub fast float -0.000000e+00, %3831
  %3835 = fdiv fast float %3834, %3808
  %3836 = fsub fast float -0.000000e+00, %3832
  %3837 = fdiv fast float %3836, %3808
  %3838 = fmul fast float %3808, %3685
  %3839 = fsub fast float %3686, %3838
  %3840 = fdiv fast float %3839, %3808
  %3841 = fsub fast float 1.000000e+00, %3840
  %3842 = fptoui float %3833 to i32
  %3843 = getelementptr [6 x float], [6 x float]* %70, i32 0, i32 %3842
  %3844 = load float, float* %3843, align 4
  %3845 = getelementptr [6 x float], [6 x float]* %71, i32 0, i32 %3842
  %3846 = load float, float* %3845, align 4
  br label %3874

; <label>:3847                                    ; preds = %3789
  %3848 = fmul fast float %3671, %565
  %3849 = call float @dx.op.tertiary.f32(i32 46, float %566, float %3672, float %3848)  ; FMad(a,b,c)
  %3850 = call float @dx.op.tertiary.f32(i32 46, float %567, float %3673, float %3849)  ; FMad(a,b,c)
  %3851 = fadd fast float %3850, %3674
  %3852 = fmul fast float %3677, %565
  %3853 = call float @dx.op.tertiary.f32(i32 46, float %566, float %3678, float %3852)  ; FMad(a,b,c)
  %3854 = call float @dx.op.tertiary.f32(i32 46, float %567, float %3679, float %3853)  ; FMad(a,b,c)
  %3855 = fadd fast float %3854, %3680
  %3856 = fmul fast float %3683, %565
  %3857 = call float @dx.op.tertiary.f32(i32 46, float %566, float %3684, float %3856)  ; FMad(a,b,c)
  %3858 = call float @dx.op.tertiary.f32(i32 46, float %567, float %3685, float %3857)  ; FMad(a,b,c)
  %3859 = fadd fast float %3858, %3686
  %3860 = fmul fast float %3689, %565
  %3861 = call float @dx.op.tertiary.f32(i32 46, float %566, float %3690, float %3860)  ; FMad(a,b,c)
  %3862 = call float @dx.op.tertiary.f32(i32 46, float %567, float %3691, float %3861)  ; FMad(a,b,c)
  %3863 = fadd fast float %3862, %3692
  %3864 = fdiv fast float 1.000000e+00, %3863
  %3865 = fmul fast float %3864, %3851
  %3866 = fmul fast float %3855, %3864
  %3867 = fsub fast float -0.000000e+00, %3866
  %3868 = fmul fast float %3864, %3859
  %3869 = fsub fast float 1.000000e+00, %3868
  %3870 = call float @dx.op.unary.f32(i32 6, float %3867)  ; FAbs(value)
  %3871 = call float @dx.op.unary.f32(i32 6, float %3865)  ; FAbs(value)
  %3872 = call float @dx.op.binary.f32(i32 35, float %3871, float %3870)  ; FMax(a,b)
  %3873 = call float @dx.op.binary.f32(i32 35, float %3872, float %3869)  ; FMax(a,b)
  br label %3874

; <label>:3874                                    ; preds = %3847, %3830
  %3875 = phi float [ %3846, %3830 ], [ %3709, %3847 ]
  %3876 = phi float [ %3844, %3830 ], [ %3708, %3847 ]
  %3877 = phi float [ %3841, %3830 ], [ %3873, %3847 ]
  %3878 = phi float [ %3835, %3830 ], [ %3865, %3847 ]
  %3879 = phi float [ %3837, %3830 ], [ %3867, %3847 ]
  %3880 = phi float [ %3840, %3830 ], [ %3868, %3847 ]
  %3881 = fcmp fast ole float %3877, 1.000000e+00
  %3882 = fmul fast float %3878, %3705
  %3883 = fmul fast float %3879, %3706
  %3884 = fadd fast float %3882, %3876
  %3885 = fadd fast float %3883, %3875
  %3886 = fcmp fast oge float %3876, 0.000000e+00
  %3887 = and i1 %3886, %3881
  %3888 = add i32 %3777, -1
  %3889 = lshr i32 %3888, 1
  %3890 = fmul fast float %3884, %134
  %3891 = fmul fast float %3885, %134
  %3892 = fadd fast float %3890, -5.000000e-01
  %3893 = fadd fast float %3891, -5.000000e-01
  %3894 = call float @dx.op.unary.f32(i32 22, float %3892)  ; Frc(value)
  %3895 = call float @dx.op.unary.f32(i32 22, float %3893)  ; Frc(value)
  %3896 = fsub fast float 1.000000e+00, %3894
  %3897 = fsub fast float 1.000000e+00, %3895
  %3898 = fmul fast float %3897, %3896
  %3899 = fmul fast float %3897, %3894
  %3900 = fmul fast float %3896, %3895
  %3901 = fmul fast float %3895, %3894
  %3902 = call float @dx.op.unary.f32(i32 27, float %3892)  ; Round_ni(value)
  %3903 = fptosi float %3902 to i32
  %3904 = sub i32 %3903, %3889
  %3905 = sitofp i32 %3904 to float
  %3906 = fmul fast float %3905, %135
  %3907 = fadd fast float %3906, %135
  %3908 = fmul fast float %135, 2.000000e+00
  %3909 = icmp eq i32 %3777, 0
  br i1 %3909, label %3997, label %3910

; <label>:3910                                    ; preds = %3874
  %3911 = call float @dx.op.unary.f32(i32 27, float %3893)  ; Round_ni(value)
  %3912 = fptosi float %3911 to i32
  %3913 = sub i32 %3912, %3889
  %3914 = sitofp i32 %3913 to float
  %3915 = fmul fast float %3914, %135
  %3916 = fadd fast float %3915, %135
  br label %3917

; <label>:3917                                    ; preds = %3990, %3910
  %3918 = phi float [ %3991, %3990 ], [ %3916, %3910 ]
  %3919 = phi float [ %3986, %3990 ], [ 0.000000e+00, %3910 ]
  %3920 = phi i32 [ %3993, %3990 ], [ %3778, %3910 ]
  %3921 = phi i32 [ %3994, %3990 ], [ 0, %3910 ]
  br label %3922

; <label>:3922                                    ; preds = %3922, %3917
  %3923 = phi float [ %3986, %3922 ], [ %3919, %3917 ]
  %3924 = phi float [ %3987, %3922 ], [ %3907, %3917 ]
  %3925 = phi i32 [ %3988, %3922 ], [ 0, %3917 ]
  %3926 = add i32 %3925, %3920
  %3927 = add i32 %3926, %3779
  %3928 = add i32 %3926, 35
  %3929 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3928)  ; CBufferLoadLegacy(handle,regIndex)
  %3930 = extractvalue %dx.types.CBufRet.f32 %3929, 0
  %3931 = fmul fast float %3930, %3901
  %3932 = extractvalue %dx.types.CBufRet.f32 %3929, 1
  %3933 = fmul fast float %3932, %3900
  %3934 = fadd fast float %3933, %3931
  %3935 = extractvalue %dx.types.CBufRet.f32 %3929, 2
  %3936 = fmul fast float %3935, %3899
  %3937 = fadd fast float %3934, %3936
  %3938 = extractvalue %dx.types.CBufRet.f32 %3929, 3
  %3939 = fmul fast float %3938, %3898
  %3940 = fadd fast float %3937, %3939
  %3941 = add i32 %3926, 36
  %3942 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3941)  ; CBufferLoadLegacy(handle,regIndex)
  %3943 = extractvalue %dx.types.CBufRet.f32 %3942, 0
  %3944 = fmul fast float %3943, %3901
  %3945 = extractvalue %dx.types.CBufRet.f32 %3942, 1
  %3946 = fmul fast float %3945, %3900
  %3947 = fadd fast float %3946, %3944
  %3948 = extractvalue %dx.types.CBufRet.f32 %3942, 2
  %3949 = fmul fast float %3948, %3899
  %3950 = fadd fast float %3947, %3949
  %3951 = extractvalue %dx.types.CBufRet.f32 %3942, 3
  %3952 = fmul fast float %3951, %3898
  %3953 = fadd fast float %3950, %3952
  %3954 = add i32 %3927, 35
  %3955 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3954)  ; CBufferLoadLegacy(handle,regIndex)
  %3956 = extractvalue %dx.types.CBufRet.f32 %3955, 0
  %3957 = fmul fast float %3956, %3901
  %3958 = extractvalue %dx.types.CBufRet.f32 %3955, 1
  %3959 = fmul fast float %3958, %3900
  %3960 = fadd fast float %3959, %3957
  %3961 = extractvalue %dx.types.CBufRet.f32 %3955, 2
  %3962 = fmul fast float %3961, %3899
  %3963 = fadd fast float %3960, %3962
  %3964 = extractvalue %dx.types.CBufRet.f32 %3955, 3
  %3965 = fmul fast float %3964, %3898
  %3966 = fadd fast float %3963, %3965
  %3967 = add i32 %3927, 36
  %3968 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %3967)  ; CBufferLoadLegacy(handle,regIndex)
  %3969 = extractvalue %dx.types.CBufRet.f32 %3968, 0
  %3970 = fmul fast float %3969, %3901
  %3971 = extractvalue %dx.types.CBufRet.f32 %3968, 1
  %3972 = fmul fast float %3971, %3900
  %3973 = fadd fast float %3972, %3970
  %3974 = extractvalue %dx.types.CBufRet.f32 %3968, 2
  %3975 = fmul fast float %3974, %3899
  %3976 = fadd fast float %3973, %3975
  %3977 = extractvalue %dx.types.CBufRet.f32 %3968, 3
  %3978 = fmul fast float %3977, %3898
  %3979 = fadd fast float %3976, %3978
  %3980 = call %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32 74, %dx.types.Handle %30, %dx.types.Handle %36, float %3924, float %3918, float undef, float undef, i32 0, i32 0, i32 0, float %3880)  ; TextureGatherCmp(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,channel,compareValue)
  %3981 = extractvalue %dx.types.ResRet.f32 %3980, 0
  %3982 = extractvalue %dx.types.ResRet.f32 %3980, 1
  %3983 = extractvalue %dx.types.ResRet.f32 %3980, 2
  %3984 = extractvalue %dx.types.ResRet.f32 %3980, 3
  %3985 = call float @dx.op.dot4.f32(i32 56, float %3984, float %3983, float %3981, float %3982, float %3940, float %3953, float %3966, float %3979)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %3986 = fadd fast float %3985, %3923
  %3987 = fadd fast float %3924, %3908
  %3988 = add i32 %3925, 2
  %3989 = icmp ult i32 %3988, %3777
  br i1 %3989, label %3922, label %3990

; <label>:3990                                    ; preds = %3922
  %3991 = fadd fast float %3918, %3908
  %3992 = shl i32 %3779, 1
  %3993 = add i32 %3920, %3992
  %3994 = add i32 %3921, 2
  %3995 = icmp ult i32 %3994, %3777
  br i1 %3995, label %3917, label %3996

; <label>:3996                                    ; preds = %3990
  br label %3997

; <label>:3997                                    ; preds = %3996, %3874
  %3998 = phi float [ 0.000000e+00, %3874 ], [ %3986, %3996 ]
  %3999 = call float @dx.op.unary.f32(i32 7, float %3998)  ; Saturate(value)
  %4000 = fadd fast float %3999, -1.000000e+00
  %4001 = select i1 %3887, float %4000, float 0.000000e+00
  %4002 = fmul fast float %3787, %3695
  %4003 = fmul fast float %4002, %4001
  %4004 = fadd fast float %4003, 1.000000e+00
  %4005 = fmul fast float %4004, %3775
  br label %4006

; <label>:4006                                    ; preds = %3997, %3783, %3774
  %4007 = phi float [ %4005, %3997 ], [ %3775, %3783 ], [ %3775, %3774 ]
  %4008 = and i32 %3459, 1536
  %4009 = icmp eq i32 %4008, 0
  br i1 %4009, label %4059, label %4010

; <label>:4010                                    ; preds = %4006
  %4011 = fmul fast float %3671, %565
  %4012 = call float @dx.op.tertiary.f32(i32 46, float %3672, float %566, float %4011)  ; FMad(a,b,c)
  %4013 = call float @dx.op.tertiary.f32(i32 46, float %3673, float %567, float %4012)  ; FMad(a,b,c)
  %4014 = fadd fast float %4013, %3674
  %4015 = fmul fast float %3677, %565
  %4016 = call float @dx.op.tertiary.f32(i32 46, float %3678, float %566, float %4015)  ; FMad(a,b,c)
  %4017 = call float @dx.op.tertiary.f32(i32 46, float %3679, float %567, float %4016)  ; FMad(a,b,c)
  %4018 = fadd fast float %4017, %3680
  %4019 = fmul fast float %3683, %565
  %4020 = call float @dx.op.tertiary.f32(i32 46, float %3684, float %566, float %4019)  ; FMad(a,b,c)
  %4021 = call float @dx.op.tertiary.f32(i32 46, float %3685, float %567, float %4020)  ; FMad(a,b,c)
  %4022 = fadd fast float %4021, %3686
  %4023 = fmul fast float %3689, %565
  %4024 = call float @dx.op.tertiary.f32(i32 46, float %3690, float %566, float %4023)  ; FMad(a,b,c)
  %4025 = call float @dx.op.tertiary.f32(i32 46, float %3691, float %567, float %4024)  ; FMad(a,b,c)
  %4026 = fadd fast float %4025, %3692
  %4027 = call float @dx.op.unary.f32(i32 6, float %4014)  ; FAbs(value)
  %4028 = call float @dx.op.unary.f32(i32 6, float %4018)  ; FAbs(value)
  %4029 = call float @dx.op.unary.f32(i32 6, float %4022)  ; FAbs(value)
  %4030 = fcmp fast ogt float %4027, %4026
  %4031 = fcmp fast ogt float %4028, %4026
  %4032 = fcmp fast ogt float %4029, %4026
  %4033 = or i1 %4030, %4031
  %4034 = or i1 %4033, %4032
  %4035 = select i1 %4034, float 0.000000e+00, float 1.000000e+00
  %4036 = and i32 %3459, 128
  %4037 = icmp eq i32 %4036, 0
  br i1 %4037, label %4059, label %4038

; <label>:4038                                    ; preds = %4010
  %4039 = fdiv fast float %4014, %4026
  %4040 = fdiv fast float %4018, %4026
  %4041 = fmul fast float %4039, 5.000000e-01
  %4042 = fmul fast float %4040, 5.000000e-01
  %4043 = fadd fast float %4041, 5.000000e-01
  %4044 = fsub fast float 5.000000e-01, %4042
  %4045 = fmul fast float %4043, %3714
  %4046 = fmul fast float %4044, %3715
  %4047 = fadd fast float %4045, %3712
  %4048 = fadd fast float %4046, %3713
  %4049 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %23, %dx.types.Handle %40, float %4047, float %4048, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %4050 = extractvalue %dx.types.ResRet.f32 %4049, 0
  %4051 = extractvalue %dx.types.ResRet.f32 %4049, 1
  %4052 = extractvalue %dx.types.ResRet.f32 %4049, 2
  %4053 = fmul fast float %4050, %3657
  %4054 = fmul fast float %4051, %3658
  %4055 = fmul fast float %4052, %3659
  %4056 = fmul fast float %4050, %3660
  %4057 = fmul fast float %4051, %3661
  %4058 = fmul fast float %4052, %3662
  br label %4059

; <label>:4059                                    ; preds = %4038, %4010, %4006
  %4060 = phi float [ %4053, %4038 ], [ %3657, %4010 ], [ %3657, %4006 ]
  %4061 = phi float [ %4054, %4038 ], [ %3658, %4010 ], [ %3658, %4006 ]
  %4062 = phi float [ %4055, %4038 ], [ %3659, %4010 ], [ %3659, %4006 ]
  %4063 = phi float [ %4056, %4038 ], [ %3660, %4010 ], [ %3660, %4006 ]
  %4064 = phi float [ %4057, %4038 ], [ %3661, %4010 ], [ %3661, %4006 ]
  %4065 = phi float [ %4058, %4038 ], [ %3662, %4010 ], [ %3662, %4006 ]
  %4066 = phi float [ %4035, %4038 ], [ %4035, %4010 ], [ 1.000000e+00, %4006 ]
  %4067 = fmul fast float %4066, %4007
  %4068 = fmul fast float %4067, %4060
  %4069 = fmul fast float %4067, %4061
  %4070 = fmul fast float %4067, %4062
  %4071 = fadd fast float %4068, %3447
  %4072 = fadd fast float %4069, %3448
  %4073 = fadd fast float %4070, %3449
  %4074 = fmul fast float %4067, %4063
  %4075 = fmul fast float %4067, %4064
  %4076 = fmul fast float %4067, %4065
  %4077 = fadd fast float %4074, %3444
  %4078 = fadd fast float %4075, %3445
  %4079 = fadd fast float %4076, %3446
  br label %3515

; <label>:4080                                    ; preds = %3656
  %4081 = fadd fast float %3657, %3447
  %4082 = fadd fast float %3658, %3448
  %4083 = fadd fast float %3659, %3449
  %4084 = fadd fast float %3660, %3444
  %4085 = fadd fast float %3661, %3445
  %4086 = fadd fast float %3662, %3446
  br label %3515

; <label>:4087                                    ; preds = %3443
  %4088 = fsub fast float %3466, %565
  %4089 = fsub fast float %3467, %566
  %4090 = fsub fast float %3468, %567
  %4091 = call float @dx.op.dot3.f32(i32 55, float %4088, float %4089, float %4090, float %4088, float %4089, float %4090)  ; Dot3(ax,ay,az,bx,by,bz)
  %4092 = call float @dx.op.unary.f32(i32 25, float %4091)  ; Rsqrt(value)
  %4093 = fmul fast float %4092, %4088
  %4094 = fmul fast float %4092, %4089
  %4095 = fmul fast float %4092, %4090
  %4096 = lshr i32 %3459, 14
  %4097 = and i32 %4096, 7
  %4098 = icmp eq i32 %4097, 0
  br i1 %4098, label %4099, label %4316

; <label>:4099                                    ; preds = %4087
  %4100 = fsub fast float -0.000000e+00, %272
  %4101 = fsub fast float -0.000000e+00, %273
  %4102 = fsub fast float -0.000000e+00, %274
  %4103 = call float @dx.op.dot3.f32(i32 55, float %4100, float %4101, float %4102, float %2879, float %2880, float %2881)  ; Dot3(ax,ay,az,bx,by,bz)
  %4104 = fmul fast float %4103, 2.000000e+00
  %4105 = fmul fast float %4104, %2879
  %4106 = fmul fast float %4104, %2880
  %4107 = fmul fast float %4104, %2881
  %4108 = fsub fast float %4100, %4105
  %4109 = fsub fast float %4101, %4106
  %4110 = fsub fast float %4102, %4107
  %4111 = call float @dx.op.unary.f32(i32 24, float %4091)  ; Sqrt(value)
  %4112 = fdiv fast float %4088, %4111
  %4113 = fdiv fast float %4089, %4111
  %4114 = fdiv fast float %4090, %4111
  %4115 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %4112, float %4113, float %4114)  ; Dot3(ax,ay,az,bx,by,bz)
  %4116 = fmul fast float %3496, %3496
  %4117 = fadd fast float %4091, %3479
  %4118 = call float @dx.op.binary.f32(i32 35, float %4116, float %4117)  ; FMax(a,b)
  %4119 = fdiv fast float %4116, %4118
  %4120 = fmul fast float %4091, %3471
  %4121 = fmul fast float %4120, %4120
  %4122 = fsub fast float 1.000000e+00, %4121
  %4123 = call float @dx.op.unary.f32(i32 7, float %4122)  ; Saturate(value)
  %4124 = fmul fast float %4119, 0x3FE61933C0000000
  %4125 = fsub fast float 0x3FE1E88A00000000, %4124
  %4126 = fmul fast float %4119, 0x4024F72B80000000
  %4127 = fsub fast float 0x40324246A0000000, %4126
  %4128 = fmul fast float %4127, %4119
  %4129 = fadd fast float %4128, 0xC0276BFDA0000000
  %4130 = fmul fast float %4129, %4119
  %4131 = fadd fast float %4130, 0x4013FDD020000000
  %4132 = fmul fast float %4115, 5.000000e-01
  %4133 = fadd fast float %4132, 5.000000e-01
  %4134 = call float @dx.op.unary.f32(i32 23, float %4133)  ; Log(value)
  %4135 = fmul fast float %4131, %4134
  %4136 = call float @dx.op.unary.f32(i32 21, float %4135)  ; Exp(value)
  %4137 = fmul fast float %4125, %4115
  %4138 = fsub fast float %4133, %4136
  %4139 = fmul fast float %4137, %4138
  %4140 = fadd fast float %4139, %4136
  %4141 = call float @dx.op.unary.f32(i32 7, float %4115)  ; Saturate(value)
  %4142 = call float @dx.op.binary.f32(i32 35, float %4141, float %4140)  ; FMax(a,b)
  %4143 = fmul fast float %4119, 0x400921FB60000000
  %4144 = fmul fast float %4123, %4123
  %4145 = fmul fast float %4144, %4143
  %4146 = fmul fast float %4145, %4142
  %4147 = fcmp ogt float %4146, 0.000000e+00
  br i1 %4147, label %4148, label %4308

; <label>:4148                                    ; preds = %4099
  %4149 = fsub fast float %4091, %4116
  %4150 = fcmp fast olt float %4149, 0.000000e+00
  %4151 = fmul fast float %4091, 0x3FEFF7CEE0000000
  %4152 = select i1 %4150, float %4151, float %4116
  %4153 = fsub fast float %4091, %4152
  %4154 = call float @dx.op.unary.f32(i32 24, float %4153)  ; Sqrt(value)
  %4155 = fdiv fast float 1.000000e+00, %4111
  %4156 = fmul fast float %4155, %4154
  %4157 = call float @dx.op.dot3.f32(i32 55, float %4112, float %4113, float %4114, float %4108, float %4109, float %4110)  ; Dot3(ax,ay,az,bx,by,bz)
  %4158 = fcmp fast olt float %4157, %4156
  br i1 %4158, label %4159, label %4188

; <label>:4159                                    ; preds = %4148
  %4160 = fmul fast float %4157, %4112
  %4161 = fmul fast float %4157, %4113
  %4162 = fmul fast float %4157, %4114
  %4163 = fsub fast float %4108, %4160
  %4164 = fsub fast float %4109, %4161
  %4165 = fsub fast float %4110, %4162
  %4166 = fmul fast float %4155, %3496
  %4167 = fmul fast float %4156, %4112
  %4168 = fmul fast float %4156, %4113
  %4169 = fmul fast float %4156, %4114
  %4170 = fmul fast float %4163, %4163
  %4171 = fmul fast float %4164, %4164
  %4172 = fadd fast float %4170, %4171
  %4173 = fmul fast float %4165, %4165
  %4174 = fadd fast float %4172, %4173
  %4175 = call float @dx.op.unary.f32(i32 24, float %4174)  ; Sqrt(value)
  %4176 = fdiv fast float %4166, %4175
  %4177 = fmul fast float %4176, %4163
  %4178 = fmul fast float %4176, %4164
  %4179 = fmul fast float %4176, %4165
  %4180 = fadd fast float %4177, %4167
  %4181 = fadd fast float %4178, %4168
  %4182 = fadd fast float %4179, %4169
  %4183 = call float @dx.op.dot3.f32(i32 55, float %4180, float %4181, float %4182, float %4180, float %4181, float %4182)  ; Dot3(ax,ay,az,bx,by,bz)
  %4184 = call float @dx.op.unary.f32(i32 25, float %4183)  ; Rsqrt(value)
  %4185 = fmul fast float %4180, %4184
  %4186 = fmul fast float %4181, %4184
  %4187 = fmul fast float %4182, %4184
  br label %4188

; <label>:4188                                    ; preds = %4159, %4148
  %4189 = phi float [ %4185, %4159 ], [ %4108, %4148 ]
  %4190 = phi float [ %4186, %4159 ], [ %4109, %4148 ]
  %4191 = phi float [ %4187, %4159 ], [ %4110, %4148 ]
  %4192 = fmul fast float %3496, 5.000000e-01
  %4193 = fmul fast float %4192, %4155
  %4194 = fmul fast float %3311, %3311
  %4195 = fadd fast float %4193, %4194
  %4196 = call float @dx.op.unary.f32(i32 7, float %4195)  ; Saturate(value)
  %4197 = fdiv fast float %4194, %4196
  %4198 = fadd fast float %4189, %272
  %4199 = fadd fast float %4190, %273
  %4200 = fadd fast float %4191, %274
  %4201 = call float @dx.op.dot3.f32(i32 55, float %4198, float %4199, float %4200, float %4198, float %4199, float %4200)  ; Dot3(ax,ay,az,bx,by,bz)
  %4202 = call float @dx.op.unary.f32(i32 25, float %4201)  ; Rsqrt(value)
  %4203 = fmul fast float %4202, %4198
  %4204 = fmul fast float %4202, %4199
  %4205 = fmul fast float %4202, %4200
  %4206 = call float @dx.op.unary.f32(i32 6, float %3281)  ; FAbs(value)
  %4207 = call float @dx.op.binary.f32(i32 35, float %4206, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %4208 = call float @dx.op.unary.f32(i32 7, float %4207)  ; Saturate(value)
  %4209 = call float @dx.op.dot3.f32(i32 55, float %4189, float %4190, float %4191, float %4203, float %4204, float %4205)  ; Dot3(ax,ay,az,bx,by,bz)
  %4210 = call float @dx.op.unary.f32(i32 7, float %4209)  ; Saturate(value)
  %4211 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %4203, float %4204, float %4205)  ; Dot3(ax,ay,az,bx,by,bz)
  %4212 = call float @dx.op.unary.f32(i32 7, float %4211)  ; Saturate(value)
  %4213 = call float @dx.op.unary.f32(i32 6, float %4211)  ; FAbs(value)
  %4214 = call float @dx.op.binary.f32(i32 35, float %4213, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %4215 = call float @dx.op.unary.f32(i32 7, float %4214)  ; Saturate(value)
  %4216 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %4189, float %4190, float %4191)  ; Dot3(ax,ay,az,bx,by,bz)
  %4217 = call float @dx.op.unary.f32(i32 7, float %4216)  ; Saturate(value)
  %4218 = fsub fast float 1.000000e+00, %4210
  %4219 = fmul fast float %4218, %4218
  %4220 = fmul fast float %4219, %4219
  %4221 = fmul fast float %4220, %4218
  %4222 = fmul fast float %4221, 0x3FEEB851E0000000
  %4223 = fadd fast float %4222, 0x3FA47AE140000000
  %4224 = call float @dx.op.binary.f32(i32 35, float %4194, float 0x3F60624DE0000000)  ; FMax(a,b)
  %4225 = fmul fast float %4224, %4224
  %4226 = fmul fast float %4225, %4208
  %4227 = fsub fast float %4208, %4226
  %4228 = fmul fast float %4227, %4208
  %4229 = fadd fast float %4228, %4225
  %4230 = call float @dx.op.unary.f32(i32 24, float %4229)  ; Sqrt(value)
  %4231 = fmul fast float %4230, %4217
  %4232 = fmul fast float %4225, %4217
  %4233 = fsub fast float %4217, %4232
  %4234 = fmul fast float %4233, %4217
  %4235 = fadd fast float %4234, %4225
  %4236 = call float @dx.op.unary.f32(i32 24, float %4235)  ; Sqrt(value)
  %4237 = fmul fast float %4236, %4208
  %4238 = fadd fast float %4237, %4231
  %4239 = fdiv fast float 5.000000e-01, %4238
  %4240 = fmul fast float %4225, %4212
  %4241 = fsub fast float %4240, %4212
  %4242 = fmul fast float %4241, %4212
  %4243 = fadd fast float %4242, 1.000000e+00
  %4244 = fmul fast float %4243, %4243
  %4245 = fdiv fast float 1.000000e+00, %4244
  %4246 = fdiv fast float 2.000000e+00, %4225
  %4247 = fadd fast float %4246, -1.000000e+00
  %4248 = call float @dx.op.unary.f32(i32 23, float %4247)  ; Log(value)
  %4249 = fmul fast float %4248, 0x3FAC71C720000000
  %4250 = call float @dx.op.unary.f32(i32 7, float %4249)  ; Saturate(value)
  %4251 = fadd fast float %4221, %4210
  %4252 = fsub fast float 1.000000e+00, %4217
  %4253 = fmul fast float %4252, %4252
  %4254 = fmul fast float %4253, %4253
  %4255 = fmul fast float %4254, %4252
  %4256 = fsub fast float 1.000000e+00, %4255
  %4257 = fsub fast float 1.000000e+00, %4208
  %4258 = fmul fast float %4257, %4257
  %4259 = fmul fast float %4258, %4258
  %4260 = fmul fast float %4259, %4257
  %4261 = fsub fast float 1.000000e+00, %4260
  %4262 = fmul fast float %4256, %4261
  %4263 = fmul fast float %4250, 0x40019999A0000000
  %4264 = fadd fast float %4263, -5.000000e-01
  %4265 = call float @dx.op.unary.f32(i32 7, float %4264)  ; Saturate(value)
  %4266 = fsub fast float %4262, %4251
  %4267 = fmul fast float %4265, %4266
  %4268 = fadd fast float %4267, %4251
  %4269 = fmul fast float %4250, %4250
  %4270 = fmul fast float %4269, 3.450000e+01
  %4271 = fmul fast float %4250, 5.900000e+01
  %4272 = fsub fast float 2.450000e+01, %4271
  %4273 = fadd fast float %4272, %4270
  %4274 = fmul fast float %4273, %4210
  %4275 = fmul fast float %4250, 0x40524CCCC0000000
  %4276 = fadd fast float %4275, 0xC035333340000000
  %4277 = call float @dx.op.binary.f32(i32 35, float %4276, float 0x4021CCCCC0000000)  ; FMax(a,b)
  %4278 = call float @dx.op.unary.f32(i32 24, float %4215)  ; Sqrt(value)
  %4279 = fmul fast float %4277, %4278
  %4280 = fsub fast float -0.000000e+00, %4279
  %4281 = call float @dx.op.unary.f32(i32 21, float %4280)  ; Exp(value)
  %4282 = fmul fast float %4274, %4281
  %4283 = fadd fast float %4268, %4282
  %4284 = call float @dx.op.binary.f32(i32 35, float %4283, float 0.000000e+00)  ; FMax(a,b)
  %4285 = fmul fast float %4284, %4146
  %4286 = and i32 %3459, 32
  %4287 = icmp ne i32 %4286, 0
  %4288 = fmul fast float %4285, %3474
  %4289 = fmul fast float %4285, %3475
  %4290 = fmul fast float %4285, %3476
  %4291 = select i1 %4287, float %4288, float 0.000000e+00
  %4292 = select i1 %4287, float %4289, float 0.000000e+00
  %4293 = select i1 %4287, float %4290, float 0.000000e+00
  %4294 = and i32 %3459, 64
  %4295 = icmp ne i32 %4294, 0
  %4296 = fmul fast float %4197, %4197
  %4297 = fmul fast float %4296, %4146
  %4298 = fmul fast float %4297, %4225
  %4299 = fmul fast float %4298, %4239
  %4300 = fmul fast float %4299, %4245
  %4301 = fmul fast float %4300, %4223
  %4302 = fmul fast float %4301, %3474
  %4303 = fmul fast float %4301, %3475
  %4304 = fmul fast float %4301, %3476
  %4305 = select i1 %4295, float %4302, float 0.000000e+00
  %4306 = select i1 %4295, float %4303, float 0.000000e+00
  %4307 = select i1 %4295, float %4304, float 0.000000e+00
  br label %4308

; <label>:4308                                    ; preds = %4188, %4099
  %4309 = phi float [ %4291, %4188 ], [ 0.000000e+00, %4099 ]
  %4310 = phi float [ %4292, %4188 ], [ 0.000000e+00, %4099 ]
  %4311 = phi float [ %4293, %4188 ], [ 0.000000e+00, %4099 ]
  %4312 = phi float [ %4305, %4188 ], [ 0.000000e+00, %4099 ]
  %4313 = phi float [ %4306, %4188 ], [ 0.000000e+00, %4099 ]
  %4314 = phi float [ %4307, %4188 ], [ 0.000000e+00, %4099 ]
  %4315 = zext i1 %4147 to i32
  br label %6175

; <label>:4316                                    ; preds = %4087
  %4317 = icmp eq i32 %4097, 3
  br i1 %4317, label %4318, label %5101

; <label>:4318                                    ; preds = %4316
  %4319 = fmul fast float %4091, %3471
  %4320 = fmul fast float %4319, %4319
  %4321 = fsub fast float 1.000000e+00, %4320
  %4322 = call float @dx.op.unary.f32(i32 7, float %4321)  ; Saturate(value)
  %4323 = fsub fast float %3512, %565
  %4324 = fsub fast float %3513, %566
  %4325 = fsub fast float %3514, %567
  %4326 = call float @dx.op.dot3.f32(i32 55, float %4323, float %4324, float %4325, float %4323, float %4324, float %4325)  ; Dot3(ax,ay,az,bx,by,bz)
  %4327 = call float @dx.op.unary.f32(i32 25, float %4326)  ; Rsqrt(value)
  %4328 = fmul fast float %4327, %4323
  %4329 = fmul fast float %4327, %4324
  %4330 = fmul fast float %4327, %4325
  %4331 = call float @dx.op.dot3.f32(i32 55, float %3491, float %3492, float %3493, float %4328, float %4329, float %4330)  ; Dot3(ax,ay,az,bx,by,bz)
  %4332 = fmul fast float %4331, %3482
  %4333 = fadd fast float %4332, %3485
  %4334 = call float @dx.op.unary.f32(i32 7, float %4333)  ; Saturate(value)
  %4335 = fmul float %4322, %4334
  %4336 = fmul float %4335, %4335
  %4337 = fcmp fast ogt float %4336, 0.000000e+00
  br i1 %4337, label %4338, label %5093

; <label>:4338                                    ; preds = %4318
  %4339 = fmul fast float %3507, %3496
  %4340 = fmul fast float %3508, %3496
  %4341 = fmul fast float %3509, %3496
  %4342 = fmul fast float %3499, %3496
  %4343 = fmul fast float %3500, %3496
  %4344 = fmul fast float %3501, %3496
  %4345 = fsub fast float %4088, %4339
  %4346 = fsub fast float %4089, %4340
  %4347 = fsub fast float %4090, %4341
  %4348 = fsub fast float %4345, %4342
  %4349 = fsub fast float %4346, %4343
  %4350 = fsub fast float %4347, %4344
  %4351 = fadd fast float %4339, %4088
  %4352 = fadd fast float %4340, %4089
  %4353 = fadd fast float %4341, %4090
  %4354 = fsub fast float %4351, %4342
  %4355 = fsub fast float %4352, %4343
  %4356 = fsub fast float %4353, %4344
  %4357 = fadd fast float %4351, %4342
  %4358 = fadd fast float %4352, %4343
  %4359 = fadd fast float %4353, %4344
  %4360 = fmul fast float %4348, %3299
  %4361 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %3300, float %4360)  ; FMad(a,b,c)
  %4362 = call float @dx.op.tertiary.f32(i32 46, float %4350, float %3301, float %4361)  ; FMad(a,b,c)
  %4363 = fmul fast float %4348, %3304
  %4364 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %3307, float %4363)  ; FMad(a,b,c)
  %4365 = call float @dx.op.tertiary.f32(i32 46, float %4350, float %3310, float %4364)  ; FMad(a,b,c)
  %4366 = fmul fast float %4348, %2879
  %4367 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %2880, float %4366)  ; FMad(a,b,c)
  %4368 = call float @dx.op.tertiary.f32(i32 46, float %4350, float %2881, float %4367)  ; FMad(a,b,c)
  %4369 = fmul fast float %4354, %3299
  %4370 = call float @dx.op.tertiary.f32(i32 46, float %4355, float %3300, float %4369)  ; FMad(a,b,c)
  %4371 = call float @dx.op.tertiary.f32(i32 46, float %4356, float %3301, float %4370)  ; FMad(a,b,c)
  %4372 = fmul fast float %4354, %3304
  %4373 = call float @dx.op.tertiary.f32(i32 46, float %4355, float %3307, float %4372)  ; FMad(a,b,c)
  %4374 = call float @dx.op.tertiary.f32(i32 46, float %4356, float %3310, float %4373)  ; FMad(a,b,c)
  %4375 = fmul fast float %4354, %2879
  %4376 = call float @dx.op.tertiary.f32(i32 46, float %4355, float %2880, float %4375)  ; FMad(a,b,c)
  %4377 = call float @dx.op.tertiary.f32(i32 46, float %4356, float %2881, float %4376)  ; FMad(a,b,c)
  %4378 = fmul fast float %4357, %3299
  %4379 = call float @dx.op.tertiary.f32(i32 46, float %4358, float %3300, float %4378)  ; FMad(a,b,c)
  %4380 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %3301, float %4379)  ; FMad(a,b,c)
  %4381 = fmul fast float %4357, %3304
  %4382 = call float @dx.op.tertiary.f32(i32 46, float %4358, float %3307, float %4381)  ; FMad(a,b,c)
  %4383 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %3310, float %4382)  ; FMad(a,b,c)
  %4384 = fmul fast float %4357, %2879
  %4385 = call float @dx.op.tertiary.f32(i32 46, float %4358, float %2880, float %4384)  ; FMad(a,b,c)
  %4386 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %2881, float %4385)  ; FMad(a,b,c)
  %4387 = fadd fast float %4380, %4362
  %4388 = fadd fast float %4383, %4365
  %4389 = fadd fast float %4386, %4368
  %4390 = fmul fast float %4387, 5.000000e-01
  %4391 = fmul fast float %4388, 5.000000e-01
  %4392 = fmul fast float %4389, 5.000000e-01
  %4393 = fsub fast float %4371, %4380
  %4394 = fsub fast float %4374, %4383
  %4395 = fsub fast float %4377, %4386
  %4396 = fmul fast float %4393, 5.000000e-01
  %4397 = fmul fast float %4394, 5.000000e-01
  %4398 = fmul fast float %4395, 5.000000e-01
  %4399 = fsub fast float %4371, %4362
  %4400 = fsub fast float %4374, %4365
  %4401 = fsub fast float %4377, %4368
  %4402 = fmul fast float %4399, 5.000000e-01
  %4403 = fmul fast float %4400, 5.000000e-01
  %4404 = fmul fast float %4401, 5.000000e-01
  %4405 = fmul fast float %4390, %3322
  %4406 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %4392, float %4405)  ; FMad(a,b,c)
  %4407 = fmul fast float %4390, %3323
  %4408 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %4392, float %4407)  ; FMad(a,b,c)
  %4409 = fmul fast float %4396, %3322
  %4410 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %4398, float %4409)  ; FMad(a,b,c)
  %4411 = fmul fast float %4396, %3323
  %4412 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %4398, float %4411)  ; FMad(a,b,c)
  %4413 = fmul fast float %4402, %3322
  %4414 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %4404, float %4413)  ; FMad(a,b,c)
  %4415 = fmul fast float %4402, %3323
  %4416 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %4404, float %4415)  ; FMad(a,b,c)
  %4417 = fmul fast float %4416, %4397
  %4418 = fmul fast float %4412, %4403
  %4419 = fsub fast float %4417, %4418
  %4420 = fmul fast float %4414, %4412
  %4421 = fmul fast float %4416, %4410
  %4422 = fsub fast float %4420, %4421
  %4423 = fmul fast float %4410, %4403
  %4424 = fmul fast float %4414, %4397
  %4425 = fsub fast float %4423, %4424
  %4426 = call float @dx.op.dot3.f32(i32 55, float %4419, float %4422, float %4425, float %4406, float %4391, float %4408)  ; Dot3(ax,ay,az,bx,by,bz)
  %4427 = fcmp fast olt float %4426, 0x3EE4F8B580000000
  br i1 %4427, label %4736, label %4428

; <label>:4428                                    ; preds = %4338
  %4429 = call float @dx.op.dot3.f32(i32 55, float %4410, float %4397, float %4412, float %4410, float %4397, float %4412)  ; Dot3(ax,ay,az,bx,by,bz)
  %4430 = call float @dx.op.dot3.f32(i32 55, float %4414, float %4403, float %4416, float %4414, float %4403, float %4416)  ; Dot3(ax,ay,az,bx,by,bz)
  %4431 = call float @dx.op.dot3.f32(i32 55, float %4410, float %4397, float %4412, float %4414, float %4403, float %4416)  ; Dot3(ax,ay,az,bx,by,bz)
  %4432 = call float @dx.op.unary.f32(i32 6, float %4431)  ; FAbs(value)
  %4433 = fmul fast float %4430, %4429
  %4434 = call float @dx.op.unary.f32(i32 24, float %4433)  ; Sqrt(value)
  %4435 = fdiv fast float %4432, %4434
  %4436 = fcmp fast ogt float %4435, 0x3F4A36E2E0000000
  br i1 %4436, label %4437, label %4509

; <label>:4437                                    ; preds = %4428
  %4438 = fadd fast float %4430, %4429
  %4439 = fmul fast float %4431, %4431
  %4440 = fsub fast float %4433, %4439
  %4441 = call float @dx.op.unary.f32(i32 24, float %4440)  ; Sqrt(value)
  %4442 = fmul fast float %4441, 2.000000e+00
  %4443 = fsub fast float %4438, %4442
  %4444 = call float @dx.op.unary.f32(i32 24, float %4443)  ; Sqrt(value)
  %4445 = fadd fast float %4442, %4438
  %4446 = call float @dx.op.unary.f32(i32 24, float %4445)  ; Sqrt(value)
  %4447 = fadd fast float %4446, %4444
  %4448 = fmul fast float %4447, 5.000000e-01
  %4449 = fmul fast float %4448, %4448
  %4450 = fsub fast float %4444, %4446
  %4451 = fmul fast float %4450, 5.000000e-01
  %4452 = fmul fast float %4451, %4451
  %4453 = fcmp fast ogt float %4429, %4430
  br i1 %4453, label %4454, label %4472

; <label>:4454                                    ; preds = %4437
  %4455 = fmul fast float %4431, %4410
  %4456 = fmul fast float %4431, %4397
  %4457 = fmul fast float %4431, %4412
  %4458 = fsub fast float %4449, %4429
  %4459 = fmul fast float %4458, %4414
  %4460 = fmul fast float %4458, %4403
  %4461 = fmul fast float %4458, %4416
  %4462 = fadd fast float %4459, %4455
  %4463 = fadd fast float %4460, %4456
  %4464 = fadd fast float %4461, %4457
  %4465 = fsub fast float %4452, %4429
  %4466 = fmul fast float %4465, %4414
  %4467 = fmul fast float %4465, %4403
  %4468 = fmul fast float %4465, %4416
  %4469 = fadd fast float %4466, %4455
  %4470 = fadd fast float %4467, %4456
  %4471 = fadd fast float %4468, %4457
  br label %4490

; <label>:4472                                    ; preds = %4437
  %4473 = fmul fast float %4431, %4414
  %4474 = fmul fast float %4431, %4403
  %4475 = fmul fast float %4431, %4416
  %4476 = fsub fast float %4449, %4430
  %4477 = fmul fast float %4476, %4410
  %4478 = fmul fast float %4476, %4397
  %4479 = fmul fast float %4476, %4412
  %4480 = fadd fast float %4477, %4473
  %4481 = fadd fast float %4478, %4474
  %4482 = fadd fast float %4479, %4475
  %4483 = fsub fast float %4452, %4430
  %4484 = fmul fast float %4483, %4410
  %4485 = fmul fast float %4483, %4397
  %4486 = fmul fast float %4483, %4412
  %4487 = fadd fast float %4484, %4473
  %4488 = fadd fast float %4485, %4474
  %4489 = fadd fast float %4486, %4475
  br label %4490

; <label>:4490                                    ; preds = %4472, %4454
  %4491 = phi float [ %4462, %4454 ], [ %4480, %4472 ]
  %4492 = phi float [ %4463, %4454 ], [ %4481, %4472 ]
  %4493 = phi float [ %4464, %4454 ], [ %4482, %4472 ]
  %4494 = phi float [ %4469, %4454 ], [ %4487, %4472 ]
  %4495 = phi float [ %4470, %4454 ], [ %4488, %4472 ]
  %4496 = phi float [ %4471, %4454 ], [ %4489, %4472 ]
  %4497 = fdiv fast float 1.000000e+00, %4449
  %4498 = fdiv fast float 1.000000e+00, %4452
  %4499 = call float @dx.op.dot3.f32(i32 55, float %4491, float %4492, float %4493, float %4491, float %4492, float %4493)  ; Dot3(ax,ay,az,bx,by,bz)
  %4500 = call float @dx.op.unary.f32(i32 25, float %4499)  ; Rsqrt(value)
  %4501 = fmul fast float %4500, %4491
  %4502 = fmul fast float %4500, %4492
  %4503 = fmul fast float %4500, %4493
  %4504 = call float @dx.op.dot3.f32(i32 55, float %4494, float %4495, float %4496, float %4494, float %4495, float %4496)  ; Dot3(ax,ay,az,bx,by,bz)
  %4505 = call float @dx.op.unary.f32(i32 25, float %4504)  ; Rsqrt(value)
  %4506 = fmul fast float %4505, %4494
  %4507 = fmul fast float %4505, %4495
  %4508 = fmul fast float %4505, %4496
  br label %4520

; <label>:4509                                    ; preds = %4428
  %4510 = fdiv fast float 1.000000e+00, %4429
  %4511 = fdiv fast float 1.000000e+00, %4430
  %4512 = call float @dx.op.unary.f32(i32 24, float %4510)  ; Sqrt(value)
  %4513 = fmul fast float %4512, %4410
  %4514 = fmul fast float %4512, %4397
  %4515 = fmul fast float %4512, %4412
  %4516 = call float @dx.op.unary.f32(i32 24, float %4511)  ; Sqrt(value)
  %4517 = fmul fast float %4516, %4414
  %4518 = fmul fast float %4516, %4403
  %4519 = fmul fast float %4516, %4416
  br label %4520

; <label>:4520                                    ; preds = %4509, %4490
  %4521 = phi float [ %4501, %4490 ], [ %4513, %4509 ]
  %4522 = phi float [ %4502, %4490 ], [ %4514, %4509 ]
  %4523 = phi float [ %4503, %4490 ], [ %4515, %4509 ]
  %4524 = phi float [ %4506, %4490 ], [ %4517, %4509 ]
  %4525 = phi float [ %4507, %4490 ], [ %4518, %4509 ]
  %4526 = phi float [ %4508, %4490 ], [ %4519, %4509 ]
  %4527 = phi float [ %4497, %4490 ], [ %4510, %4509 ]
  %4528 = phi float [ %4498, %4490 ], [ %4511, %4509 ]
  %4529 = fmul fast float %4526, %4522
  %4530 = fmul fast float %4525, %4523
  %4531 = fsub fast float %4529, %4530
  %4532 = fmul fast float %4524, %4523
  %4533 = fmul fast float %4526, %4521
  %4534 = fsub fast float %4532, %4533
  %4535 = fmul fast float %4525, %4521
  %4536 = fmul fast float %4524, %4522
  %4537 = fsub fast float %4535, %4536
  %4538 = call float @dx.op.dot3.f32(i32 55, float %4406, float %4391, float %4408, float %4531, float %4534, float %4537)  ; Dot3(ax,ay,az,bx,by,bz)
  %4539 = fcmp fast olt float %4538, 0.000000e+00
  %4540 = fsub fast float -0.000000e+00, %4531
  %4541 = fsub fast float -0.000000e+00, %4534
  %4542 = fsub fast float -0.000000e+00, %4537
  %4543 = select i1 %4539, float %4540, float %4531
  %4544 = select i1 %4539, float %4541, float %4534
  %4545 = select i1 %4539, float %4542, float %4537
  %4546 = call float @dx.op.dot3.f32(i32 55, float %4543, float %4544, float %4545, float %4406, float %4391, float %4408)  ; Dot3(ax,ay,az,bx,by,bz)
  %4547 = call float @dx.op.dot3.f32(i32 55, float %4521, float %4522, float %4523, float %4406, float %4391, float %4408)  ; Dot3(ax,ay,az,bx,by,bz)
  %4548 = fdiv fast float %4547, %4546
  %4549 = call float @dx.op.dot3.f32(i32 55, float %4524, float %4525, float %4526, float %4406, float %4391, float %4408)  ; Dot3(ax,ay,az,bx,by,bz)
  %4550 = fdiv fast float %4549, %4546
  %4551 = fmul fast float %4546, %4546
  %4552 = fmul fast float %4551, %4527
  %4553 = fmul fast float %4551, %4528
  %4554 = fmul fast float %4552, %4553
  %4555 = fmul fast float %4548, %4548
  %4556 = fadd fast float %4555, 1.000000e+00
  %4557 = fmul fast float %4550, %4550
  %4558 = fadd fast float %4557, %4556
  %4559 = fmul fast float %4558, %4554
  %4560 = fsub fast float %4559, %4552
  %4561 = fsub fast float %4560, %4553
  %4562 = fmul fast float %4556, %4552
  %4563 = fsub fast float 1.000000e+00, %4562
  %4564 = fadd fast float %4557, 1.000000e+00
  %4565 = fmul fast float %4564, %4553
  %4566 = fsub fast float %4563, %4565
  %4567 = call float @dx.op.unary.f32(i32 6, float %4554)  ; FAbs(value)
  %4568 = call float @dx.op.unary.f32(i32 6, float %4561)  ; FAbs(value)
  %4569 = call float @dx.op.unary.f32(i32 6, float %4566)  ; FAbs(value)
  %4570 = call float @dx.op.binary.f32(i32 35, float %4567, float %4568)  ; FMax(a,b)
  %4571 = call float @dx.op.binary.f32(i32 35, float %4570, float %4569)  ; FMax(a,b)
  %4572 = call float @dx.op.binary.f32(i32 35, float %4571, float 1.000000e+00)  ; FMax(a,b)
  %4573 = fcmp fast ult float %4572, 0x42A05EF3A0000000
  br i1 %4573, label %4579, label %4574

; <label>:4574                                    ; preds = %4520
  %4575 = fdiv fast float %4554, %4572
  %4576 = fdiv fast float %4561, %4572
  %4577 = fdiv fast float %4566, %4572
  %4578 = fdiv fast float 1.000000e+00, %4572
  br label %4579

; <label>:4579                                    ; preds = %4574, %4520
  %4580 = phi float [ %4575, %4574 ], [ %4554, %4520 ]
  %4581 = phi float [ %4576, %4574 ], [ %4561, %4520 ]
  %4582 = phi float [ %4577, %4574 ], [ %4566, %4520 ]
  %4583 = phi float [ %4578, %4574 ], [ 1.000000e+00, %4520 ]
  %4584 = fmul fast float %4581, 0x3FD5555560000000
  %4585 = fmul fast float %4582, 0x3FD5555560000000
  %4586 = fmul fast float %4585, %4585
  %4587 = fsub fast float %4584, %4586
  %4588 = fmul fast float %4585, %4584
  %4589 = fsub fast float %4580, %4588
  %4590 = fsub fast float -0.000000e+00, %4584
  %4591 = call float @dx.op.dot2.f32(i32 54, float %4585, float %4590, float %4580, float %4584)  ; Dot2(ax,ay,bx,by)
  %4592 = fmul fast float %4587, 4.000000e+00
  %4593 = fsub fast float -0.000000e+00, %4589
  %4594 = call float @dx.op.dot2.f32(i32 54, float %4592, float %4593, float %4591, float %4589)  ; Dot2(ax,ay,bx,by)
  %4595 = call float @dx.op.binary.f32(i32 35, float %4594, float 0.000000e+00)  ; FMax(a,b)
  %4596 = call float @dx.op.binary.f32(i32 36, float %4595, float 0x47EFFFFFE0000000)  ; FMin(a,b)
  %4597 = fmul fast float %4582, 0xBFE5555560000000
  %4598 = fmul fast float %4597, %4587
  %4599 = fadd fast float %4598, %4589
  %4600 = fsub fast float -0.000000e+00, %4599
  %4601 = call float @dx.op.unary.f32(i32 24, float %4596)  ; Sqrt(value)
  %4602 = fdiv fast float %4601, %4600
  %4603 = call float @dx.op.unary.f32(i32 17, float %4602)  ; Atan(value)
  %4604 = fadd fast float %4603, 0x400921FB60000000
  %4605 = fadd fast float %4603, 0xC00921FB60000000
  %4606 = fcmp ogt float %4599, -0.000000e+00
  %4607 = fcmp oeq float %4599, -0.000000e+00
  %4608 = fcmp fast oge float %4601, 0.000000e+00
  %4609 = fcmp fast olt float %4601, 0.000000e+00
  %4610 = and i1 %4606, %4608
  %4611 = select i1 %4610, float %4604, float %4603
  %4612 = and i1 %4606, %4609
  %4613 = select i1 %4612, float %4605, float %4611
  %4614 = and i1 %4607, %4609
  %4615 = and i1 %4607, %4608
  %4616 = fmul fast float %4613, 0x3FD5555560000000
  %4617 = select i1 %4614, float 0xBFE0C15240000000, float %4616
  %4618 = select i1 %4615, float 0x3FE0C15240000000, float %4617
  %4619 = fsub fast float -0.000000e+00, %4587
  %4620 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4619)  ; FMax(a,b)
  %4621 = call float @dx.op.unary.f32(i32 24, float %4620)  ; Sqrt(value)
  %4622 = fmul fast float %4621, 2.000000e+00
  %4623 = call float @dx.op.unary.f32(i32 12, float %4618)  ; Cos(value)
  %4624 = fadd fast float %4618, 0x4000C15240000000
  %4625 = call float @dx.op.unary.f32(i32 12, float %4624)  ; Cos(value)
  %4626 = fadd fast float %4625, %4623
  %4627 = fmul fast float %4622, %4626
  %4628 = fmul fast float %4582, 0x3FE5555560000000
  %4629 = fcmp fast ogt float %4627, %4628
  %4630 = select i1 %4629, float %4623, float %4625
  %4631 = fmul float %4622, %4630
  %4632 = fsub fast float %4631, %4585
  %4633 = fmul fast float %4589, %4580
  %4634 = fmul fast float %4581, 0x3FE5555560000000
  %4635 = fmul fast float %4591, %4634
  %4636 = fsub fast float %4635, %4633
  %4637 = fsub fast float -0.000000e+00, %4636
  %4638 = fmul fast float %4601, %4580
  %4639 = fdiv fast float %4638, %4637
  %4640 = call float @dx.op.unary.f32(i32 17, float %4639)  ; Atan(value)
  %4641 = fadd fast float %4640, 0x400921FB60000000
  %4642 = fadd fast float %4640, 0xC00921FB60000000
  %4643 = fcmp ogt float %4636, -0.000000e+00
  %4644 = fcmp oeq float %4636, -0.000000e+00
  %4645 = fcmp fast oge float %4638, 0.000000e+00
  %4646 = fcmp fast olt float %4638, 0.000000e+00
  %4647 = and i1 %4643, %4645
  %4648 = select i1 %4647, float %4641, float %4640
  %4649 = and i1 %4643, %4646
  %4650 = select i1 %4649, float %4642, float %4648
  %4651 = and i1 %4644, %4646
  %4652 = and i1 %4644, %4645
  %4653 = fmul fast float %4650, 0x3FD5555560000000
  %4654 = select i1 %4651, float 0xBFE0C15240000000, float %4653
  %4655 = select i1 %4652, float 0x3FE0C15240000000, float %4654
  %4656 = fsub fast float -0.000000e+00, %4591
  %4657 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4656)  ; FMax(a,b)
  %4658 = call float @dx.op.unary.f32(i32 24, float %4657)  ; Sqrt(value)
  %4659 = fmul fast float %4658, 2.000000e+00
  %4660 = call float @dx.op.unary.f32(i32 12, float %4655)  ; Cos(value)
  %4661 = fadd fast float %4655, 0x4000C15240000000
  %4662 = call float @dx.op.unary.f32(i32 12, float %4661)  ; Cos(value)
  %4663 = fadd fast float %4662, %4660
  %4664 = fmul fast float %4659, %4663
  %4665 = fcmp fast olt float %4664, %4634
  %4666 = select i1 %4665, float %4660, float %4662
  %4667 = fmul float %4659, %4666
  %4668 = fsub fast float -0.000000e+00, %4580
  %4669 = fadd fast float %4667, %4584
  %4670 = fmul fast float %4632, %4669
  %4671 = fsub fast float -0.000000e+00, %4670
  %4672 = fmul fast float %4583, %4668
  %4673 = fsub fast float %4671, %4672
  %4674 = fmul fast float %4673, %4584
  %4675 = fmul fast float %4585, %4668
  %4676 = fmul fast float %4675, %4632
  %4677 = fsub fast float %4674, %4676
  %4678 = fmul fast float %4673, %4585
  %4679 = fmul fast float %4583, %4584
  %4680 = fmul fast float %4679, %4669
  %4681 = fsub fast float %4680, %4678
  %4682 = fdiv fast float %4668, %4669
  %4683 = fdiv fast float %4677, %4681
  %4684 = fdiv fast float %4632, %4583
  %4685 = fcmp fast olt float %4682, %4684
  %4686 = fcmp fast olt float %4682, %4683
  %4687 = and i1 %4686, %4685
  br i1 %4687, label %4694, label %4688

; <label>:4688                                    ; preds = %4579
  %4689 = fcmp fast olt float %4684, %4683
  %4690 = fcmp fast olt float %4684, %4682
  %4691 = and i1 %4690, %4689
  %4692 = select i1 %4691, float %4684, float %4683
  %4693 = select i1 %4691, float %4683, float %4684
  br label %4694

; <label>:4694                                    ; preds = %4688, %4579
  %4695 = phi float [ %4683, %4579 ], [ %4682, %4688 ]
  %4696 = phi float [ %4682, %4579 ], [ %4692, %4688 ]
  %4697 = phi float [ %4684, %4579 ], [ %4693, %4688 ]
  %4698 = fmul fast float %4552, %4548
  %4699 = fsub fast float %4552, %4696
  %4700 = fdiv fast float %4698, %4699
  %4701 = fmul fast float %4550, %4553
  %4702 = fsub fast float %4553, %4696
  %4703 = fdiv fast float %4701, %4702
  %4704 = fmul fast float %4700, %4521
  %4705 = call float @dx.op.tertiary.f32(i32 46, float %4703, float %4524, float %4704)  ; FMad(a,b,c)
  %4706 = fadd fast float %4705, %4543
  %4707 = fmul fast float %4700, %4522
  %4708 = call float @dx.op.tertiary.f32(i32 46, float %4703, float %4525, float %4707)  ; FMad(a,b,c)
  %4709 = fadd fast float %4708, %4544
  %4710 = fmul fast float %4700, %4523
  %4711 = call float @dx.op.tertiary.f32(i32 46, float %4703, float %4526, float %4710)  ; FMad(a,b,c)
  %4712 = fadd fast float %4711, %4545
  %4713 = call float @dx.op.dot3.f32(i32 55, float %4706, float %4709, float %4712, float %4706, float %4709, float %4712)  ; Dot3(ax,ay,az,bx,by,bz)
  %4714 = call float @dx.op.unary.f32(i32 25, float %4713)  ; Rsqrt(value)
  %4715 = fsub fast float -0.000000e+00, %4696
  %4716 = fdiv fast float %4715, %4697
  %4717 = call float @dx.op.unary.f32(i32 24, float %4716)  ; Sqrt(value)
  %4718 = fdiv fast float %4715, %4695
  %4719 = call float @dx.op.unary.f32(i32 24, float %4718)  ; Sqrt(value)
  %4720 = fmul fast float %4719, %4717
  %4721 = fmul fast float %4717, %4717
  %4722 = fadd fast float %4721, 1.000000e+00
  %4723 = fmul fast float %4719, %4719
  %4724 = fadd fast float %4723, 1.000000e+00
  %4725 = fmul fast float %4724, %4722
  %4726 = call float @dx.op.unary.f32(i32 25, float %4725)  ; Rsqrt(value)
  %4727 = fmul fast float %4720, %4726
  %4728 = fmul fast float %4712, 0x3FDFC00000000000
  %4729 = fmul fast float %4728, %4714
  %4730 = fmul fast float %4727, 9.921875e-01
  %4731 = fadd fast float %4729, 5.000000e-01
  %4732 = fadd fast float %4730, 3.906250e-03
  %4733 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %24, %dx.types.Handle %40, float %4731, float %4732, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %4734 = extractvalue %dx.types.ResRet.f32 %4733, 3
  %4735 = fmul fast float %4734, %4727
  br label %4736

; <label>:4736                                    ; preds = %4694, %4338
  %4737 = phi float [ %4735, %4694 ], [ 0.000000e+00, %4338 ]
  %4738 = fmul fast float %4390, %3327
  %4739 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %4392, float %4738)  ; FMad(a,b,c)
  %4740 = fmul fast float %4390, %3328
  %4741 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %4392, float %4740)  ; FMad(a,b,c)
  %4742 = fmul fast float %4396, %3327
  %4743 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %4398, float %4742)  ; FMad(a,b,c)
  %4744 = fmul fast float %4396, %3328
  %4745 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %4398, float %4744)  ; FMad(a,b,c)
  %4746 = fmul fast float %4402, %3327
  %4747 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %4404, float %4746)  ; FMad(a,b,c)
  %4748 = fmul fast float %4402, %3328
  %4749 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %4404, float %4748)  ; FMad(a,b,c)
  %4750 = fmul fast float %4749, %4397
  %4751 = fmul fast float %4745, %4403
  %4752 = fsub fast float %4750, %4751
  %4753 = fmul fast float %4747, %4745
  %4754 = fmul fast float %4749, %4743
  %4755 = fsub fast float %4753, %4754
  %4756 = fmul fast float %4743, %4403
  %4757 = fmul fast float %4747, %4397
  %4758 = fsub fast float %4756, %4757
  %4759 = call float @dx.op.dot3.f32(i32 55, float %4752, float %4755, float %4758, float %4739, float %4391, float %4741)  ; Dot3(ax,ay,az,bx,by,bz)
  %4760 = fcmp fast olt float %4759, 0x3EE4F8B580000000
  br i1 %4760, label %5069, label %4761

; <label>:4761                                    ; preds = %4736
  %4762 = call float @dx.op.dot3.f32(i32 55, float %4743, float %4397, float %4745, float %4743, float %4397, float %4745)  ; Dot3(ax,ay,az,bx,by,bz)
  %4763 = call float @dx.op.dot3.f32(i32 55, float %4747, float %4403, float %4749, float %4747, float %4403, float %4749)  ; Dot3(ax,ay,az,bx,by,bz)
  %4764 = call float @dx.op.dot3.f32(i32 55, float %4743, float %4397, float %4745, float %4747, float %4403, float %4749)  ; Dot3(ax,ay,az,bx,by,bz)
  %4765 = call float @dx.op.unary.f32(i32 6, float %4764)  ; FAbs(value)
  %4766 = fmul fast float %4763, %4762
  %4767 = call float @dx.op.unary.f32(i32 24, float %4766)  ; Sqrt(value)
  %4768 = fdiv fast float %4765, %4767
  %4769 = fcmp fast ogt float %4768, 0x3F4A36E2E0000000
  br i1 %4769, label %4770, label %4842

; <label>:4770                                    ; preds = %4761
  %4771 = fadd fast float %4763, %4762
  %4772 = fmul fast float %4764, %4764
  %4773 = fsub fast float %4766, %4772
  %4774 = call float @dx.op.unary.f32(i32 24, float %4773)  ; Sqrt(value)
  %4775 = fmul fast float %4774, 2.000000e+00
  %4776 = fsub fast float %4771, %4775
  %4777 = call float @dx.op.unary.f32(i32 24, float %4776)  ; Sqrt(value)
  %4778 = fadd fast float %4775, %4771
  %4779 = call float @dx.op.unary.f32(i32 24, float %4778)  ; Sqrt(value)
  %4780 = fadd fast float %4779, %4777
  %4781 = fmul fast float %4780, 5.000000e-01
  %4782 = fmul fast float %4781, %4781
  %4783 = fsub fast float %4777, %4779
  %4784 = fmul fast float %4783, 5.000000e-01
  %4785 = fmul fast float %4784, %4784
  %4786 = fcmp fast ogt float %4762, %4763
  br i1 %4786, label %4787, label %4805

; <label>:4787                                    ; preds = %4770
  %4788 = fmul fast float %4764, %4743
  %4789 = fmul fast float %4764, %4397
  %4790 = fmul fast float %4764, %4745
  %4791 = fsub fast float %4782, %4762
  %4792 = fmul fast float %4791, %4747
  %4793 = fmul fast float %4791, %4403
  %4794 = fmul fast float %4791, %4749
  %4795 = fadd fast float %4792, %4788
  %4796 = fadd fast float %4793, %4789
  %4797 = fadd fast float %4794, %4790
  %4798 = fsub fast float %4785, %4762
  %4799 = fmul fast float %4798, %4747
  %4800 = fmul fast float %4798, %4403
  %4801 = fmul fast float %4798, %4749
  %4802 = fadd fast float %4799, %4788
  %4803 = fadd fast float %4800, %4789
  %4804 = fadd fast float %4801, %4790
  br label %4823

; <label>:4805                                    ; preds = %4770
  %4806 = fmul fast float %4764, %4747
  %4807 = fmul fast float %4764, %4403
  %4808 = fmul fast float %4764, %4749
  %4809 = fsub fast float %4782, %4763
  %4810 = fmul fast float %4809, %4743
  %4811 = fmul fast float %4809, %4397
  %4812 = fmul fast float %4809, %4745
  %4813 = fadd fast float %4810, %4806
  %4814 = fadd fast float %4811, %4807
  %4815 = fadd fast float %4812, %4808
  %4816 = fsub fast float %4785, %4763
  %4817 = fmul fast float %4816, %4743
  %4818 = fmul fast float %4816, %4397
  %4819 = fmul fast float %4816, %4745
  %4820 = fadd fast float %4817, %4806
  %4821 = fadd fast float %4818, %4807
  %4822 = fadd fast float %4819, %4808
  br label %4823

; <label>:4823                                    ; preds = %4805, %4787
  %4824 = phi float [ %4795, %4787 ], [ %4813, %4805 ]
  %4825 = phi float [ %4796, %4787 ], [ %4814, %4805 ]
  %4826 = phi float [ %4797, %4787 ], [ %4815, %4805 ]
  %4827 = phi float [ %4802, %4787 ], [ %4820, %4805 ]
  %4828 = phi float [ %4803, %4787 ], [ %4821, %4805 ]
  %4829 = phi float [ %4804, %4787 ], [ %4822, %4805 ]
  %4830 = fdiv fast float 1.000000e+00, %4782
  %4831 = fdiv fast float 1.000000e+00, %4785
  %4832 = call float @dx.op.dot3.f32(i32 55, float %4824, float %4825, float %4826, float %4824, float %4825, float %4826)  ; Dot3(ax,ay,az,bx,by,bz)
  %4833 = call float @dx.op.unary.f32(i32 25, float %4832)  ; Rsqrt(value)
  %4834 = fmul fast float %4833, %4824
  %4835 = fmul fast float %4833, %4825
  %4836 = fmul fast float %4833, %4826
  %4837 = call float @dx.op.dot3.f32(i32 55, float %4827, float %4828, float %4829, float %4827, float %4828, float %4829)  ; Dot3(ax,ay,az,bx,by,bz)
  %4838 = call float @dx.op.unary.f32(i32 25, float %4837)  ; Rsqrt(value)
  %4839 = fmul fast float %4838, %4827
  %4840 = fmul fast float %4838, %4828
  %4841 = fmul fast float %4838, %4829
  br label %4853

; <label>:4842                                    ; preds = %4761
  %4843 = fdiv fast float 1.000000e+00, %4762
  %4844 = fdiv fast float 1.000000e+00, %4763
  %4845 = call float @dx.op.unary.f32(i32 24, float %4843)  ; Sqrt(value)
  %4846 = fmul fast float %4845, %4743
  %4847 = fmul fast float %4845, %4397
  %4848 = fmul fast float %4845, %4745
  %4849 = call float @dx.op.unary.f32(i32 24, float %4844)  ; Sqrt(value)
  %4850 = fmul fast float %4849, %4747
  %4851 = fmul fast float %4849, %4403
  %4852 = fmul fast float %4849, %4749
  br label %4853

; <label>:4853                                    ; preds = %4842, %4823
  %4854 = phi float [ %4834, %4823 ], [ %4846, %4842 ]
  %4855 = phi float [ %4835, %4823 ], [ %4847, %4842 ]
  %4856 = phi float [ %4836, %4823 ], [ %4848, %4842 ]
  %4857 = phi float [ %4839, %4823 ], [ %4850, %4842 ]
  %4858 = phi float [ %4840, %4823 ], [ %4851, %4842 ]
  %4859 = phi float [ %4841, %4823 ], [ %4852, %4842 ]
  %4860 = phi float [ %4830, %4823 ], [ %4843, %4842 ]
  %4861 = phi float [ %4831, %4823 ], [ %4844, %4842 ]
  %4862 = fmul fast float %4859, %4855
  %4863 = fmul fast float %4858, %4856
  %4864 = fsub fast float %4862, %4863
  %4865 = fmul fast float %4857, %4856
  %4866 = fmul fast float %4859, %4854
  %4867 = fsub fast float %4865, %4866
  %4868 = fmul fast float %4858, %4854
  %4869 = fmul fast float %4857, %4855
  %4870 = fsub fast float %4868, %4869
  %4871 = call float @dx.op.dot3.f32(i32 55, float %4739, float %4391, float %4741, float %4864, float %4867, float %4870)  ; Dot3(ax,ay,az,bx,by,bz)
  %4872 = fcmp fast olt float %4871, 0.000000e+00
  %4873 = fsub fast float -0.000000e+00, %4864
  %4874 = fsub fast float -0.000000e+00, %4867
  %4875 = fsub fast float -0.000000e+00, %4870
  %4876 = select i1 %4872, float %4873, float %4864
  %4877 = select i1 %4872, float %4874, float %4867
  %4878 = select i1 %4872, float %4875, float %4870
  %4879 = call float @dx.op.dot3.f32(i32 55, float %4876, float %4877, float %4878, float %4739, float %4391, float %4741)  ; Dot3(ax,ay,az,bx,by,bz)
  %4880 = call float @dx.op.dot3.f32(i32 55, float %4854, float %4855, float %4856, float %4739, float %4391, float %4741)  ; Dot3(ax,ay,az,bx,by,bz)
  %4881 = fdiv fast float %4880, %4879
  %4882 = call float @dx.op.dot3.f32(i32 55, float %4857, float %4858, float %4859, float %4739, float %4391, float %4741)  ; Dot3(ax,ay,az,bx,by,bz)
  %4883 = fdiv fast float %4882, %4879
  %4884 = fmul fast float %4879, %4879
  %4885 = fmul fast float %4884, %4860
  %4886 = fmul fast float %4884, %4861
  %4887 = fmul fast float %4885, %4886
  %4888 = fmul fast float %4881, %4881
  %4889 = fadd fast float %4888, 1.000000e+00
  %4890 = fmul fast float %4883, %4883
  %4891 = fadd fast float %4890, %4889
  %4892 = fmul fast float %4891, %4887
  %4893 = fsub fast float %4892, %4885
  %4894 = fsub fast float %4893, %4886
  %4895 = fmul fast float %4889, %4885
  %4896 = fsub fast float 1.000000e+00, %4895
  %4897 = fadd fast float %4890, 1.000000e+00
  %4898 = fmul fast float %4897, %4886
  %4899 = fsub fast float %4896, %4898
  %4900 = call float @dx.op.unary.f32(i32 6, float %4887)  ; FAbs(value)
  %4901 = call float @dx.op.unary.f32(i32 6, float %4894)  ; FAbs(value)
  %4902 = call float @dx.op.unary.f32(i32 6, float %4899)  ; FAbs(value)
  %4903 = call float @dx.op.binary.f32(i32 35, float %4900, float %4901)  ; FMax(a,b)
  %4904 = call float @dx.op.binary.f32(i32 35, float %4903, float %4902)  ; FMax(a,b)
  %4905 = call float @dx.op.binary.f32(i32 35, float %4904, float 1.000000e+00)  ; FMax(a,b)
  %4906 = fcmp fast ult float %4905, 0x42A05EF3A0000000
  br i1 %4906, label %4912, label %4907

; <label>:4907                                    ; preds = %4853
  %4908 = fdiv fast float %4887, %4905
  %4909 = fdiv fast float %4894, %4905
  %4910 = fdiv fast float %4899, %4905
  %4911 = fdiv fast float 1.000000e+00, %4905
  br label %4912

; <label>:4912                                    ; preds = %4907, %4853
  %4913 = phi float [ %4908, %4907 ], [ %4887, %4853 ]
  %4914 = phi float [ %4909, %4907 ], [ %4894, %4853 ]
  %4915 = phi float [ %4910, %4907 ], [ %4899, %4853 ]
  %4916 = phi float [ %4911, %4907 ], [ 1.000000e+00, %4853 ]
  %4917 = fmul fast float %4914, 0x3FD5555560000000
  %4918 = fmul fast float %4915, 0x3FD5555560000000
  %4919 = fmul fast float %4918, %4918
  %4920 = fsub fast float %4917, %4919
  %4921 = fmul fast float %4918, %4917
  %4922 = fsub fast float %4913, %4921
  %4923 = fsub fast float -0.000000e+00, %4917
  %4924 = call float @dx.op.dot2.f32(i32 54, float %4918, float %4923, float %4913, float %4917)  ; Dot2(ax,ay,bx,by)
  %4925 = fmul fast float %4920, 4.000000e+00
  %4926 = fsub fast float -0.000000e+00, %4922
  %4927 = call float @dx.op.dot2.f32(i32 54, float %4925, float %4926, float %4924, float %4922)  ; Dot2(ax,ay,bx,by)
  %4928 = call float @dx.op.binary.f32(i32 35, float %4927, float 0.000000e+00)  ; FMax(a,b)
  %4929 = call float @dx.op.binary.f32(i32 36, float %4928, float 0x47EFFFFFE0000000)  ; FMin(a,b)
  %4930 = fmul fast float %4915, 0xBFE5555560000000
  %4931 = fmul fast float %4930, %4920
  %4932 = fadd fast float %4931, %4922
  %4933 = fsub fast float -0.000000e+00, %4932
  %4934 = call float @dx.op.unary.f32(i32 24, float %4929)  ; Sqrt(value)
  %4935 = fdiv fast float %4934, %4933
  %4936 = call float @dx.op.unary.f32(i32 17, float %4935)  ; Atan(value)
  %4937 = fadd fast float %4936, 0x400921FB60000000
  %4938 = fadd fast float %4936, 0xC00921FB60000000
  %4939 = fcmp ogt float %4932, -0.000000e+00
  %4940 = fcmp oeq float %4932, -0.000000e+00
  %4941 = fcmp fast oge float %4934, 0.000000e+00
  %4942 = fcmp fast olt float %4934, 0.000000e+00
  %4943 = and i1 %4939, %4941
  %4944 = select i1 %4943, float %4937, float %4936
  %4945 = and i1 %4939, %4942
  %4946 = select i1 %4945, float %4938, float %4944
  %4947 = and i1 %4940, %4942
  %4948 = and i1 %4940, %4941
  %4949 = fmul fast float %4946, 0x3FD5555560000000
  %4950 = select i1 %4947, float 0xBFE0C15240000000, float %4949
  %4951 = select i1 %4948, float 0x3FE0C15240000000, float %4950
  %4952 = fsub fast float -0.000000e+00, %4920
  %4953 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4952)  ; FMax(a,b)
  %4954 = call float @dx.op.unary.f32(i32 24, float %4953)  ; Sqrt(value)
  %4955 = fmul fast float %4954, 2.000000e+00
  %4956 = call float @dx.op.unary.f32(i32 12, float %4951)  ; Cos(value)
  %4957 = fadd fast float %4951, 0x4000C15240000000
  %4958 = call float @dx.op.unary.f32(i32 12, float %4957)  ; Cos(value)
  %4959 = fadd fast float %4958, %4956
  %4960 = fmul fast float %4955, %4959
  %4961 = fmul fast float %4915, 0x3FE5555560000000
  %4962 = fcmp fast ogt float %4960, %4961
  %4963 = select i1 %4962, float %4956, float %4958
  %4964 = fmul float %4955, %4963
  %4965 = fsub fast float %4964, %4918
  %4966 = fmul fast float %4922, %4913
  %4967 = fmul fast float %4914, 0x3FE5555560000000
  %4968 = fmul fast float %4924, %4967
  %4969 = fsub fast float %4968, %4966
  %4970 = fsub fast float -0.000000e+00, %4969
  %4971 = fmul fast float %4934, %4913
  %4972 = fdiv fast float %4971, %4970
  %4973 = call float @dx.op.unary.f32(i32 17, float %4972)  ; Atan(value)
  %4974 = fadd fast float %4973, 0x400921FB60000000
  %4975 = fadd fast float %4973, 0xC00921FB60000000
  %4976 = fcmp ogt float %4969, -0.000000e+00
  %4977 = fcmp oeq float %4969, -0.000000e+00
  %4978 = fcmp fast oge float %4971, 0.000000e+00
  %4979 = fcmp fast olt float %4971, 0.000000e+00
  %4980 = and i1 %4976, %4978
  %4981 = select i1 %4980, float %4974, float %4973
  %4982 = and i1 %4976, %4979
  %4983 = select i1 %4982, float %4975, float %4981
  %4984 = and i1 %4977, %4979
  %4985 = and i1 %4977, %4978
  %4986 = fmul fast float %4983, 0x3FD5555560000000
  %4987 = select i1 %4984, float 0xBFE0C15240000000, float %4986
  %4988 = select i1 %4985, float 0x3FE0C15240000000, float %4987
  %4989 = fsub fast float -0.000000e+00, %4924
  %4990 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4989)  ; FMax(a,b)
  %4991 = call float @dx.op.unary.f32(i32 24, float %4990)  ; Sqrt(value)
  %4992 = fmul fast float %4991, 2.000000e+00
  %4993 = call float @dx.op.unary.f32(i32 12, float %4988)  ; Cos(value)
  %4994 = fadd fast float %4988, 0x4000C15240000000
  %4995 = call float @dx.op.unary.f32(i32 12, float %4994)  ; Cos(value)
  %4996 = fadd fast float %4995, %4993
  %4997 = fmul fast float %4992, %4996
  %4998 = fcmp fast olt float %4997, %4967
  %4999 = select i1 %4998, float %4993, float %4995
  %5000 = fmul float %4992, %4999
  %5001 = fsub fast float -0.000000e+00, %4913
  %5002 = fadd fast float %5000, %4917
  %5003 = fmul fast float %4965, %5002
  %5004 = fsub fast float -0.000000e+00, %5003
  %5005 = fmul fast float %4916, %5001
  %5006 = fsub fast float %5004, %5005
  %5007 = fmul fast float %5006, %4917
  %5008 = fmul fast float %4918, %5001
  %5009 = fmul fast float %5008, %4965
  %5010 = fsub fast float %5007, %5009
  %5011 = fmul fast float %5006, %4918
  %5012 = fmul fast float %4916, %4917
  %5013 = fmul fast float %5012, %5002
  %5014 = fsub fast float %5013, %5011
  %5015 = fdiv fast float %5001, %5002
  %5016 = fdiv fast float %5010, %5014
  %5017 = fdiv fast float %4965, %4916
  %5018 = fcmp fast olt float %5015, %5017
  %5019 = fcmp fast olt float %5015, %5016
  %5020 = and i1 %5019, %5018
  br i1 %5020, label %5027, label %5021

; <label>:5021                                    ; preds = %4912
  %5022 = fcmp fast olt float %5017, %5016
  %5023 = fcmp fast olt float %5017, %5015
  %5024 = and i1 %5023, %5022
  %5025 = select i1 %5024, float %5017, float %5016
  %5026 = select i1 %5024, float %5016, float %5017
  br label %5027

; <label>:5027                                    ; preds = %5021, %4912
  %5028 = phi float [ %5016, %4912 ], [ %5015, %5021 ]
  %5029 = phi float [ %5015, %4912 ], [ %5025, %5021 ]
  %5030 = phi float [ %5017, %4912 ], [ %5026, %5021 ]
  %5031 = fmul fast float %4885, %4881
  %5032 = fsub fast float %4885, %5029
  %5033 = fdiv fast float %5031, %5032
  %5034 = fmul fast float %4883, %4886
  %5035 = fsub fast float %4886, %5029
  %5036 = fdiv fast float %5034, %5035
  %5037 = fmul fast float %5033, %4854
  %5038 = call float @dx.op.tertiary.f32(i32 46, float %5036, float %4857, float %5037)  ; FMad(a,b,c)
  %5039 = fadd fast float %5038, %4876
  %5040 = fmul fast float %5033, %4855
  %5041 = call float @dx.op.tertiary.f32(i32 46, float %5036, float %4858, float %5040)  ; FMad(a,b,c)
  %5042 = fadd fast float %5041, %4877
  %5043 = fmul fast float %5033, %4856
  %5044 = call float @dx.op.tertiary.f32(i32 46, float %5036, float %4859, float %5043)  ; FMad(a,b,c)
  %5045 = fadd fast float %5044, %4878
  %5046 = call float @dx.op.dot3.f32(i32 55, float %5039, float %5042, float %5045, float %5039, float %5042, float %5045)  ; Dot3(ax,ay,az,bx,by,bz)
  %5047 = call float @dx.op.unary.f32(i32 25, float %5046)  ; Rsqrt(value)
  %5048 = fsub fast float -0.000000e+00, %5029
  %5049 = fdiv fast float %5048, %5030
  %5050 = call float @dx.op.unary.f32(i32 24, float %5049)  ; Sqrt(value)
  %5051 = fdiv fast float %5048, %5028
  %5052 = call float @dx.op.unary.f32(i32 24, float %5051)  ; Sqrt(value)
  %5053 = fmul fast float %5052, %5050
  %5054 = fmul fast float %5050, %5050
  %5055 = fadd fast float %5054, 1.000000e+00
  %5056 = fmul fast float %5052, %5052
  %5057 = fadd fast float %5056, 1.000000e+00
  %5058 = fmul fast float %5057, %5055
  %5059 = call float @dx.op.unary.f32(i32 25, float %5058)  ; Rsqrt(value)
  %5060 = fmul fast float %5053, %5059
  %5061 = fmul fast float %5045, 0x3FDFC00000000000
  %5062 = fmul fast float %5061, %5047
  %5063 = fmul fast float %5060, 9.921875e-01
  %5064 = fadd fast float %5062, 5.000000e-01
  %5065 = fadd fast float %5063, 3.906250e-03
  %5066 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %24, %dx.types.Handle %40, float %5064, float %5065, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %5067 = extractvalue %dx.types.ResRet.f32 %5066, 3
  %5068 = fmul fast float %5067, %5060
  br label %5069

; <label>:5069                                    ; preds = %5027, %4736
  %5070 = phi float [ %5068, %5027 ], [ 0.000000e+00, %4736 ]
  %5071 = and i32 %3459, 32
  %5072 = icmp eq i32 %5071, 0
  br i1 %5072, label %5077, label %5073

; <label>:5073                                    ; preds = %5069
  %5074 = fmul fast float %3287, 0x400921FB60000000
  %5075 = fmul fast float %5074, %4336
  %5076 = fmul fast float %5075, %4737
  br label %5077

; <label>:5077                                    ; preds = %5073, %5069
  %5078 = phi float [ %5076, %5073 ], [ 0.000000e+00, %5069 ]
  %5079 = and i32 %3459, 64
  %5080 = icmp eq i32 %5079, 0
  br i1 %5080, label %5085, label %5081

; <label>:5081                                    ; preds = %5077
  %5082 = fmul fast float %3290, 0x400921FB60000000
  %5083 = fmul fast float %5082, %4336
  %5084 = fmul fast float %5083, %5070
  br label %5085

; <label>:5085                                    ; preds = %5081, %5077
  %5086 = phi float [ %5084, %5081 ], [ 0.000000e+00, %5077 ]
  %5087 = fmul fast float %5078, %3474
  %5088 = fmul fast float %5078, %3475
  %5089 = fmul fast float %5078, %3476
  %5090 = fmul fast float %5086, %3474
  %5091 = fmul fast float %5086, %3475
  %5092 = fmul fast float %5086, %3476
  br label %5093

; <label>:5093                                    ; preds = %5085, %4318
  %5094 = phi float [ %5087, %5085 ], [ 0.000000e+00, %4318 ]
  %5095 = phi float [ %5088, %5085 ], [ 0.000000e+00, %4318 ]
  %5096 = phi float [ %5089, %5085 ], [ 0.000000e+00, %4318 ]
  %5097 = phi float [ %5090, %5085 ], [ 0.000000e+00, %4318 ]
  %5098 = phi float [ %5091, %5085 ], [ 0.000000e+00, %4318 ]
  %5099 = phi float [ %5092, %5085 ], [ 0.000000e+00, %4318 ]
  %5100 = zext i1 %4337 to i32
  br label %6175

; <label>:5101                                    ; preds = %4316
  %5102 = icmp eq i32 %4097, 1
  br i1 %5102, label %5103, label %5663

; <label>:5103                                    ; preds = %5101
  %5104 = fmul fast float %3504, 5.000000e-01
  %5105 = fmul fast float %5104, %3507
  %5106 = fmul fast float %5104, %3508
  %5107 = fmul fast float %5104, %3509
  %5108 = fsub fast float %3466, %5105
  %5109 = fsub fast float %3467, %5106
  %5110 = fsub fast float %3468, %5107
  %5111 = fmul fast float %3507, %3504
  %5112 = fmul fast float %3508, %3504
  %5113 = fmul fast float %3509, %3504
  %5114 = fsub fast float %565, %5108
  %5115 = fsub fast float %566, %5109
  %5116 = fsub fast float %567, %5110
  %5117 = call float @dx.op.dot3.f32(i32 55, float %5114, float %5115, float %5116, float %5111, float %5112, float %5113)  ; Dot3(ax,ay,az,bx,by,bz)
  %5118 = call float @dx.op.dot3.f32(i32 55, float %5111, float %5112, float %5113, float %5111, float %5112, float %5113)  ; Dot3(ax,ay,az,bx,by,bz)
  %5119 = fdiv fast float %5117, %5118
  %5120 = call float @dx.op.unary.f32(i32 7, float %5119)  ; Saturate(value)
  %5121 = fmul fast float %5120, %5111
  %5122 = fmul fast float %5120, %5112
  %5123 = fmul fast float %5120, %5113
  %5124 = fsub fast float %5108, %565
  %5125 = fadd fast float %5121, %5124
  %5126 = fsub fast float %5109, %566
  %5127 = fadd fast float %5122, %5126
  %5128 = fsub fast float %5110, %567
  %5129 = fadd fast float %5123, %5128
  %5130 = call float @dx.op.dot3.f32(i32 55, float %5125, float %5127, float %5129, float %5125, float %5127, float %5129)  ; Dot3(ax,ay,az,bx,by,bz)
  %5131 = call float @dx.op.unary.f32(i32 25, float %5130)  ; Rsqrt(value)
  %5132 = fmul fast float %5125, %5131
  %5133 = fmul fast float %5127, %5131
  %5134 = fmul fast float %5129, %5131
  %5135 = call float @dx.op.dot3.f32(i32 55, float %5132, float %5133, float %5134, float %2879, float %2880, float %2881)  ; Dot3(ax,ay,az,bx,by,bz)
  %5136 = fcmp fast ogt float %5135, 0.000000e+00
  %5137 = fmul fast float %4091, %3471
  %5138 = fmul fast float %5137, %5137
  %5139 = fsub fast float 1.000000e+00, %5138
  %5140 = call float @dx.op.unary.f32(i32 7, float %5139)  ; Saturate(value)
  %5141 = fmul fast float %5140, %5140
  %5142 = fcmp fast ogt float %5141, 0.000000e+00
  %5143 = and i1 %5136, %5142
  br i1 %5143, label %5144, label %5655

; <label>:5144                                    ; preds = %5103
  %5145 = fmul fast float %5119, %5111
  %5146 = fmul fast float %5119, %5112
  %5147 = fmul fast float %5119, %5113
  %5148 = fadd fast float %5145, %5124
  %5149 = fadd fast float %5146, %5126
  %5150 = fadd fast float %5147, %5128
  %5151 = call float @dx.op.dot3.f32(i32 55, float %5148, float %5149, float %5150, float %5148, float %5149, float %5150)  ; Dot3(ax,ay,az,bx,by,bz)
  %5152 = call float @dx.op.unary.f32(i32 25, float %5151)  ; Rsqrt(value)
  %5153 = fmul fast float %5148, %5152
  %5154 = fsub fast float -0.000000e+00, %5153
  %5155 = fmul fast float %5149, %5152
  %5156 = fsub fast float -0.000000e+00, %5155
  %5157 = fmul fast float %5150, %5152
  %5158 = fsub fast float -0.000000e+00, %5157
  %5159 = fmul fast float %3508, %5158
  %5160 = fmul fast float %3509, %5156
  %5161 = fsub fast float %5159, %5160
  %5162 = fmul fast float %3509, %5154
  %5163 = fmul fast float %3507, %5158
  %5164 = fsub fast float %5162, %5163
  %5165 = fmul fast float %3507, %5156
  %5166 = fmul fast float %3508, %5154
  %5167 = fsub fast float %5165, %5166
  %5168 = fmul fast float %3496, 5.000000e-01
  %5169 = fmul fast float %5161, %5168
  %5170 = fmul fast float %5164, %5168
  %5171 = fmul fast float %5167, %5168
  %5172 = fsub fast float %4088, %5105
  %5173 = fsub fast float %4089, %5106
  %5174 = fsub fast float %4090, %5107
  %5175 = fsub fast float %5172, %5169
  %5176 = fsub fast float %5173, %5170
  %5177 = fsub fast float %5174, %5171
  %5178 = fadd fast float %5105, %4088
  %5179 = fadd fast float %5106, %4089
  %5180 = fadd fast float %5107, %4090
  %5181 = fsub fast float %5178, %5169
  %5182 = fsub fast float %5179, %5170
  %5183 = fsub fast float %5180, %5171
  %5184 = fadd fast float %5169, %5178
  %5185 = fadd fast float %5170, %5179
  %5186 = fadd fast float %5171, %5180
  %5187 = fadd fast float %5169, %5172
  %5188 = fadd fast float %5170, %5173
  %5189 = fadd fast float %5171, %5174
  %5190 = fmul fast float %5175, %3299
  %5191 = call float @dx.op.tertiary.f32(i32 46, float %5176, float %3300, float %5190)  ; FMad(a,b,c)
  %5192 = call float @dx.op.tertiary.f32(i32 46, float %5177, float %3301, float %5191)  ; FMad(a,b,c)
  %5193 = fmul fast float %5175, %3304
  %5194 = call float @dx.op.tertiary.f32(i32 46, float %5176, float %3307, float %5193)  ; FMad(a,b,c)
  %5195 = call float @dx.op.tertiary.f32(i32 46, float %5177, float %3310, float %5194)  ; FMad(a,b,c)
  %5196 = fmul fast float %5175, %2879
  %5197 = call float @dx.op.tertiary.f32(i32 46, float %5176, float %2880, float %5196)  ; FMad(a,b,c)
  %5198 = call float @dx.op.tertiary.f32(i32 46, float %5177, float %2881, float %5197)  ; FMad(a,b,c)
  %5199 = fmul fast float %5181, %3299
  %5200 = call float @dx.op.tertiary.f32(i32 46, float %5182, float %3300, float %5199)  ; FMad(a,b,c)
  %5201 = call float @dx.op.tertiary.f32(i32 46, float %5183, float %3301, float %5200)  ; FMad(a,b,c)
  %5202 = fmul fast float %5181, %3304
  %5203 = call float @dx.op.tertiary.f32(i32 46, float %5182, float %3307, float %5202)  ; FMad(a,b,c)
  %5204 = call float @dx.op.tertiary.f32(i32 46, float %5183, float %3310, float %5203)  ; FMad(a,b,c)
  %5205 = fmul fast float %5181, %2879
  %5206 = call float @dx.op.tertiary.f32(i32 46, float %5182, float %2880, float %5205)  ; FMad(a,b,c)
  %5207 = call float @dx.op.tertiary.f32(i32 46, float %5183, float %2881, float %5206)  ; FMad(a,b,c)
  %5208 = fmul fast float %5184, %3299
  %5209 = call float @dx.op.tertiary.f32(i32 46, float %5185, float %3300, float %5208)  ; FMad(a,b,c)
  %5210 = call float @dx.op.tertiary.f32(i32 46, float %5186, float %3301, float %5209)  ; FMad(a,b,c)
  %5211 = fmul fast float %5184, %3304
  %5212 = call float @dx.op.tertiary.f32(i32 46, float %5185, float %3307, float %5211)  ; FMad(a,b,c)
  %5213 = call float @dx.op.tertiary.f32(i32 46, float %5186, float %3310, float %5212)  ; FMad(a,b,c)
  %5214 = fmul fast float %5184, %2879
  %5215 = call float @dx.op.tertiary.f32(i32 46, float %5185, float %2880, float %5214)  ; FMad(a,b,c)
  %5216 = call float @dx.op.tertiary.f32(i32 46, float %5186, float %2881, float %5215)  ; FMad(a,b,c)
  %5217 = fmul fast float %5187, %3299
  %5218 = call float @dx.op.tertiary.f32(i32 46, float %5188, float %3300, float %5217)  ; FMad(a,b,c)
  %5219 = call float @dx.op.tertiary.f32(i32 46, float %5189, float %3301, float %5218)  ; FMad(a,b,c)
  %5220 = fmul fast float %5187, %3304
  %5221 = call float @dx.op.tertiary.f32(i32 46, float %5188, float %3307, float %5220)  ; FMad(a,b,c)
  %5222 = call float @dx.op.tertiary.f32(i32 46, float %5189, float %3310, float %5221)  ; FMad(a,b,c)
  %5223 = fmul fast float %5187, %2879
  %5224 = call float @dx.op.tertiary.f32(i32 46, float %5188, float %2880, float %5223)  ; FMad(a,b,c)
  %5225 = call float @dx.op.tertiary.f32(i32 46, float %5189, float %2881, float %5224)  ; FMad(a,b,c)
  %5226 = fmul fast float %5192, %3322
  %5227 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5198, float %5226)  ; FMad(a,b,c)
  %5228 = fmul fast float %5192, %3323
  %5229 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5198, float %5228)  ; FMad(a,b,c)
  %5230 = fmul fast float %5201, %3322
  %5231 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5207, float %5230)  ; FMad(a,b,c)
  %5232 = fmul fast float %5201, %3323
  %5233 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5207, float %5232)  ; FMad(a,b,c)
  %5234 = fmul fast float %5210, %3322
  %5235 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5216, float %5234)  ; FMad(a,b,c)
  %5236 = fmul fast float %5210, %3323
  %5237 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5216, float %5236)  ; FMad(a,b,c)
  %5238 = fmul fast float %5219, %3322
  %5239 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5225, float %5238)  ; FMad(a,b,c)
  %5240 = fmul fast float %5219, %3323
  %5241 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5225, float %5240)  ; FMad(a,b,c)
  %5242 = fsub fast float %5239, %5227
  %5243 = fsub fast float %5222, %5195
  %5244 = fsub fast float %5241, %5229
  %5245 = fsub fast float %5231, %5227
  %5246 = fsub fast float %5204, %5195
  %5247 = fsub fast float %5233, %5229
  %5248 = fmul fast float %5244, %5246
  %5249 = fmul fast float %5247, %5243
  %5250 = fsub fast float %5248, %5249
  %5251 = fmul fast float %5242, %5247
  %5252 = fmul fast float %5244, %5245
  %5253 = fsub fast float %5251, %5252
  %5254 = fmul fast float %5245, %5243
  %5255 = fmul fast float %5242, %5246
  %5256 = fsub fast float %5254, %5255
  %5257 = call float @dx.op.dot3.f32(i32 55, float %5227, float %5195, float %5229, float %5250, float %5253, float %5256)  ; Dot3(ax,ay,az,bx,by,bz)
  %5258 = fcmp fast olt float %5257, 0.000000e+00
  br i1 %5258, label %5417, label %5259

; <label>:5259                                    ; preds = %5144
  %5260 = call float @dx.op.dot3.f32(i32 55, float %5227, float %5195, float %5229, float %5227, float %5195, float %5229)  ; Dot3(ax,ay,az,bx,by,bz)
  %5261 = call float @dx.op.unary.f32(i32 25, float %5260)  ; Rsqrt(value)
  %5262 = fmul fast float %5261, %5227
  %5263 = fmul fast float %5261, %5195
  %5264 = fmul fast float %5261, %5229
  %5265 = call float @dx.op.dot3.f32(i32 55, float %5231, float %5204, float %5233, float %5231, float %5204, float %5233)  ; Dot3(ax,ay,az,bx,by,bz)
  %5266 = call float @dx.op.unary.f32(i32 25, float %5265)  ; Rsqrt(value)
  %5267 = fmul fast float %5266, %5231
  %5268 = fmul fast float %5266, %5204
  %5269 = fmul fast float %5266, %5233
  %5270 = call float @dx.op.dot3.f32(i32 55, float %5235, float %5213, float %5237, float %5235, float %5213, float %5237)  ; Dot3(ax,ay,az,bx,by,bz)
  %5271 = call float @dx.op.unary.f32(i32 25, float %5270)  ; Rsqrt(value)
  %5272 = fmul fast float %5271, %5235
  %5273 = fmul fast float %5271, %5213
  %5274 = fmul fast float %5271, %5237
  %5275 = call float @dx.op.dot3.f32(i32 55, float %5239, float %5222, float %5241, float %5239, float %5222, float %5241)  ; Dot3(ax,ay,az,bx,by,bz)
  %5276 = call float @dx.op.unary.f32(i32 25, float %5275)  ; Rsqrt(value)
  %5277 = fmul fast float %5276, %5239
  %5278 = fmul fast float %5276, %5222
  %5279 = fmul fast float %5276, %5241
  %5280 = call float @dx.op.dot3.f32(i32 55, float %5262, float %5263, float %5264, float %5267, float %5268, float %5269)  ; Dot3(ax,ay,az,bx,by,bz)
  %5281 = call float @dx.op.unary.f32(i32 6, float %5280)  ; FAbs(value)
  %5282 = fmul fast float %5281, 0x3F8DBCFA00000000
  %5283 = fadd fast float %5282, 0x3FDFC6E900000000
  %5284 = fmul fast float %5283, %5281
  %5285 = fadd fast float %5284, 0x3FEB573B80000000
  %5286 = fadd fast float %5281, 0x4010A58D80000000
  %5287 = fmul fast float %5286, %5281
  %5288 = fadd fast float %5287, 0x400B573B80000000
  %5289 = fdiv fast float %5285, %5288
  %5290 = fcmp fast ogt float %5280, 0.000000e+00
  br i1 %5290, label %5298, label %5291

; <label>:5291                                    ; preds = %5259
  %5292 = fmul fast float %5280, %5280
  %5293 = fsub fast float 1.000000e+00, %5292
  %5294 = call float @dx.op.binary.f32(i32 35, float %5293, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5295 = call float @dx.op.unary.f32(i32 25, float %5294)  ; Rsqrt(value)
  %5296 = fmul fast float %5295, 5.000000e-01
  %5297 = fsub fast float %5296, %5289
  br label %5298

; <label>:5298                                    ; preds = %5291, %5259
  %5299 = phi float [ %5297, %5291 ], [ %5289, %5259 ]
  %5300 = fmul fast float %5269, %5263
  %5301 = fmul fast float %5268, %5264
  %5302 = fsub fast float %5300, %5301
  %5303 = fmul fast float %5267, %5264
  %5304 = fmul fast float %5269, %5262
  %5305 = fsub fast float %5303, %5304
  %5306 = fmul fast float %5268, %5262
  %5307 = fmul fast float %5267, %5263
  %5308 = fsub fast float %5306, %5307
  %5309 = fmul fast float %5299, %5302
  %5310 = fmul fast float %5299, %5305
  %5311 = fmul fast float %5299, %5308
  %5312 = call float @dx.op.dot3.f32(i32 55, float %5267, float %5268, float %5269, float %5272, float %5273, float %5274)  ; Dot3(ax,ay,az,bx,by,bz)
  %5313 = call float @dx.op.unary.f32(i32 6, float %5312)  ; FAbs(value)
  %5314 = fmul fast float %5313, 0x3F8DBCFA00000000
  %5315 = fadd fast float %5314, 0x3FDFC6E900000000
  %5316 = fmul fast float %5315, %5313
  %5317 = fadd fast float %5316, 0x3FEB573B80000000
  %5318 = fadd fast float %5313, 0x4010A58D80000000
  %5319 = fmul fast float %5318, %5313
  %5320 = fadd fast float %5319, 0x400B573B80000000
  %5321 = fdiv fast float %5317, %5320
  %5322 = fcmp fast ogt float %5312, 0.000000e+00
  br i1 %5322, label %5330, label %5323

; <label>:5323                                    ; preds = %5298
  %5324 = fmul fast float %5312, %5312
  %5325 = fsub fast float 1.000000e+00, %5324
  %5326 = call float @dx.op.binary.f32(i32 35, float %5325, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5327 = call float @dx.op.unary.f32(i32 25, float %5326)  ; Rsqrt(value)
  %5328 = fmul fast float %5327, 5.000000e-01
  %5329 = fsub fast float %5328, %5321
  br label %5330

; <label>:5330                                    ; preds = %5323, %5298
  %5331 = phi float [ %5329, %5323 ], [ %5321, %5298 ]
  %5332 = fmul fast float %5274, %5268
  %5333 = fmul fast float %5273, %5269
  %5334 = fsub fast float %5332, %5333
  %5335 = fmul fast float %5272, %5269
  %5336 = fmul fast float %5274, %5267
  %5337 = fsub fast float %5335, %5336
  %5338 = fmul fast float %5273, %5267
  %5339 = fmul fast float %5272, %5268
  %5340 = fsub fast float %5338, %5339
  %5341 = fmul fast float %5331, %5334
  %5342 = fmul fast float %5331, %5337
  %5343 = fmul fast float %5331, %5340
  %5344 = fadd fast float %5341, %5309
  %5345 = fadd fast float %5342, %5310
  %5346 = fadd fast float %5343, %5311
  %5347 = call float @dx.op.dot3.f32(i32 55, float %5272, float %5273, float %5274, float %5277, float %5278, float %5279)  ; Dot3(ax,ay,az,bx,by,bz)
  %5348 = call float @dx.op.unary.f32(i32 6, float %5347)  ; FAbs(value)
  %5349 = fmul fast float %5348, 0x3F8DBCFA00000000
  %5350 = fadd fast float %5349, 0x3FDFC6E900000000
  %5351 = fmul fast float %5350, %5348
  %5352 = fadd fast float %5351, 0x3FEB573B80000000
  %5353 = fadd fast float %5348, 0x4010A58D80000000
  %5354 = fmul fast float %5353, %5348
  %5355 = fadd fast float %5354, 0x400B573B80000000
  %5356 = fdiv fast float %5352, %5355
  %5357 = fcmp fast ogt float %5347, 0.000000e+00
  br i1 %5357, label %5365, label %5358

; <label>:5358                                    ; preds = %5330
  %5359 = fmul fast float %5347, %5347
  %5360 = fsub fast float 1.000000e+00, %5359
  %5361 = call float @dx.op.binary.f32(i32 35, float %5360, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5362 = call float @dx.op.unary.f32(i32 25, float %5361)  ; Rsqrt(value)
  %5363 = fmul fast float %5362, 5.000000e-01
  %5364 = fsub fast float %5363, %5356
  br label %5365

; <label>:5365                                    ; preds = %5358, %5330
  %5366 = phi float [ %5364, %5358 ], [ %5356, %5330 ]
  %5367 = fmul fast float %5279, %5273
  %5368 = fmul fast float %5278, %5274
  %5369 = fsub fast float %5367, %5368
  %5370 = fmul fast float %5277, %5274
  %5371 = fmul fast float %5279, %5272
  %5372 = fsub fast float %5370, %5371
  %5373 = fmul fast float %5278, %5272
  %5374 = fmul fast float %5277, %5273
  %5375 = fsub fast float %5373, %5374
  %5376 = fmul fast float %5366, %5369
  %5377 = fmul fast float %5366, %5372
  %5378 = fmul fast float %5366, %5375
  %5379 = fadd fast float %5344, %5376
  %5380 = fadd fast float %5345, %5377
  %5381 = fadd fast float %5346, %5378
  %5382 = call float @dx.op.dot3.f32(i32 55, float %5277, float %5278, float %5279, float %5262, float %5263, float %5264)  ; Dot3(ax,ay,az,bx,by,bz)
  %5383 = call float @dx.op.unary.f32(i32 6, float %5382)  ; FAbs(value)
  %5384 = fmul fast float %5383, 0x3F8DBCFA00000000
  %5385 = fadd fast float %5384, 0x3FDFC6E900000000
  %5386 = fmul fast float %5385, %5383
  %5387 = fadd fast float %5386, 0x3FEB573B80000000
  %5388 = fadd fast float %5383, 0x4010A58D80000000
  %5389 = fmul fast float %5388, %5383
  %5390 = fadd fast float %5389, 0x400B573B80000000
  %5391 = fdiv fast float %5387, %5390
  %5392 = fcmp fast ogt float %5382, 0.000000e+00
  br i1 %5392, label %5400, label %5393

; <label>:5393                                    ; preds = %5365
  %5394 = fmul fast float %5382, %5382
  %5395 = fsub fast float 1.000000e+00, %5394
  %5396 = call float @dx.op.binary.f32(i32 35, float %5395, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5397 = call float @dx.op.unary.f32(i32 25, float %5396)  ; Rsqrt(value)
  %5398 = fmul fast float %5397, 5.000000e-01
  %5399 = fsub fast float %5398, %5391
  br label %5400

; <label>:5400                                    ; preds = %5393, %5365
  %5401 = phi float [ %5399, %5393 ], [ %5391, %5365 ]
  %5402 = fmul fast float %5278, %5264
  %5403 = fmul fast float %5279, %5263
  %5404 = fsub fast float %5402, %5403
  %5405 = fmul fast float %5279, %5262
  %5406 = fmul fast float %5277, %5264
  %5407 = fsub fast float %5405, %5406
  %5408 = fmul fast float %5277, %5263
  %5409 = fmul fast float %5278, %5262
  %5410 = fsub fast float %5408, %5409
  %5411 = fmul fast float %5401, %5404
  %5412 = fmul fast float %5401, %5407
  %5413 = fmul fast float %5401, %5410
  %5414 = fadd fast float %5379, %5411
  %5415 = fadd fast float %5380, %5412
  %5416 = fadd fast float %5381, %5413
  br label %5417

; <label>:5417                                    ; preds = %5400, %5144
  %5418 = phi float [ %5414, %5400 ], [ 0.000000e+00, %5144 ]
  %5419 = phi float [ %5415, %5400 ], [ 0.000000e+00, %5144 ]
  %5420 = phi float [ %5416, %5400 ], [ 0.000000e+00, %5144 ]
  %5421 = fmul fast float %5418, %5418
  %5422 = fmul fast float %5419, %5419
  %5423 = fadd fast float %5422, %5421
  %5424 = fmul fast float %5420, %5420
  %5425 = fadd fast float %5423, %5424
  %5426 = call float @dx.op.unary.f32(i32 24, float %5425)  ; Sqrt(value)
  %5427 = fmul fast float %5426, %5426
  %5428 = fadd fast float %5427, %5420
  %5429 = fadd fast float %5426, 1.000000e+00
  %5430 = fdiv fast float %5428, %5429
  %5431 = call float @dx.op.binary.f32(i32 35, float %5430, float 0.000000e+00)  ; FMax(a,b)
  %5432 = fmul fast float %5192, %3327
  %5433 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5198, float %5432)  ; FMad(a,b,c)
  %5434 = fmul fast float %5192, %3328
  %5435 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5198, float %5434)  ; FMad(a,b,c)
  %5436 = fmul fast float %5201, %3327
  %5437 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5207, float %5436)  ; FMad(a,b,c)
  %5438 = fmul fast float %5201, %3328
  %5439 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5207, float %5438)  ; FMad(a,b,c)
  %5440 = fmul fast float %5210, %3327
  %5441 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5216, float %5440)  ; FMad(a,b,c)
  %5442 = fmul fast float %5210, %3328
  %5443 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5216, float %5442)  ; FMad(a,b,c)
  %5444 = fmul fast float %5219, %3327
  %5445 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5225, float %5444)  ; FMad(a,b,c)
  %5446 = fmul fast float %5219, %3328
  %5447 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5225, float %5446)  ; FMad(a,b,c)
  %5448 = fsub fast float %5445, %5433
  %5449 = fsub fast float %5447, %5435
  %5450 = fsub fast float %5437, %5433
  %5451 = fsub fast float %5439, %5435
  %5452 = fmul fast float %5449, %5246
  %5453 = fmul fast float %5451, %5243
  %5454 = fsub fast float %5452, %5453
  %5455 = fmul fast float %5448, %5451
  %5456 = fmul fast float %5449, %5450
  %5457 = fsub fast float %5455, %5456
  %5458 = fmul fast float %5450, %5243
  %5459 = fmul fast float %5448, %5246
  %5460 = fsub fast float %5458, %5459
  %5461 = call float @dx.op.dot3.f32(i32 55, float %5433, float %5195, float %5435, float %5454, float %5457, float %5460)  ; Dot3(ax,ay,az,bx,by,bz)
  %5462 = fcmp fast olt float %5461, 0.000000e+00
  br i1 %5462, label %5621, label %5463

; <label>:5463                                    ; preds = %5417
  %5464 = call float @dx.op.dot3.f32(i32 55, float %5433, float %5195, float %5435, float %5433, float %5195, float %5435)  ; Dot3(ax,ay,az,bx,by,bz)
  %5465 = call float @dx.op.unary.f32(i32 25, float %5464)  ; Rsqrt(value)
  %5466 = fmul fast float %5465, %5433
  %5467 = fmul fast float %5465, %5195
  %5468 = fmul fast float %5465, %5435
  %5469 = call float @dx.op.dot3.f32(i32 55, float %5437, float %5204, float %5439, float %5437, float %5204, float %5439)  ; Dot3(ax,ay,az,bx,by,bz)
  %5470 = call float @dx.op.unary.f32(i32 25, float %5469)  ; Rsqrt(value)
  %5471 = fmul fast float %5470, %5437
  %5472 = fmul fast float %5470, %5204
  %5473 = fmul fast float %5470, %5439
  %5474 = call float @dx.op.dot3.f32(i32 55, float %5441, float %5213, float %5443, float %5441, float %5213, float %5443)  ; Dot3(ax,ay,az,bx,by,bz)
  %5475 = call float @dx.op.unary.f32(i32 25, float %5474)  ; Rsqrt(value)
  %5476 = fmul fast float %5475, %5441
  %5477 = fmul fast float %5475, %5213
  %5478 = fmul fast float %5475, %5443
  %5479 = call float @dx.op.dot3.f32(i32 55, float %5445, float %5222, float %5447, float %5445, float %5222, float %5447)  ; Dot3(ax,ay,az,bx,by,bz)
  %5480 = call float @dx.op.unary.f32(i32 25, float %5479)  ; Rsqrt(value)
  %5481 = fmul fast float %5480, %5445
  %5482 = fmul fast float %5480, %5222
  %5483 = fmul fast float %5480, %5447
  %5484 = call float @dx.op.dot3.f32(i32 55, float %5466, float %5467, float %5468, float %5471, float %5472, float %5473)  ; Dot3(ax,ay,az,bx,by,bz)
  %5485 = call float @dx.op.unary.f32(i32 6, float %5484)  ; FAbs(value)
  %5486 = fmul fast float %5485, 0x3F8DBCFA00000000
  %5487 = fadd fast float %5486, 0x3FDFC6E900000000
  %5488 = fmul fast float %5487, %5485
  %5489 = fadd fast float %5488, 0x3FEB573B80000000
  %5490 = fadd fast float %5485, 0x4010A58D80000000
  %5491 = fmul fast float %5490, %5485
  %5492 = fadd fast float %5491, 0x400B573B80000000
  %5493 = fdiv fast float %5489, %5492
  %5494 = fcmp fast ogt float %5484, 0.000000e+00
  br i1 %5494, label %5502, label %5495

; <label>:5495                                    ; preds = %5463
  %5496 = fmul fast float %5484, %5484
  %5497 = fsub fast float 1.000000e+00, %5496
  %5498 = call float @dx.op.binary.f32(i32 35, float %5497, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5499 = call float @dx.op.unary.f32(i32 25, float %5498)  ; Rsqrt(value)
  %5500 = fmul fast float %5499, 5.000000e-01
  %5501 = fsub fast float %5500, %5493
  br label %5502

; <label>:5502                                    ; preds = %5495, %5463
  %5503 = phi float [ %5501, %5495 ], [ %5493, %5463 ]
  %5504 = fmul fast float %5473, %5467
  %5505 = fmul fast float %5472, %5468
  %5506 = fsub fast float %5504, %5505
  %5507 = fmul fast float %5471, %5468
  %5508 = fmul fast float %5473, %5466
  %5509 = fsub fast float %5507, %5508
  %5510 = fmul fast float %5472, %5466
  %5511 = fmul fast float %5471, %5467
  %5512 = fsub fast float %5510, %5511
  %5513 = fmul fast float %5503, %5506
  %5514 = fmul fast float %5503, %5509
  %5515 = fmul fast float %5503, %5512
  %5516 = call float @dx.op.dot3.f32(i32 55, float %5471, float %5472, float %5473, float %5476, float %5477, float %5478)  ; Dot3(ax,ay,az,bx,by,bz)
  %5517 = call float @dx.op.unary.f32(i32 6, float %5516)  ; FAbs(value)
  %5518 = fmul fast float %5517, 0x3F8DBCFA00000000
  %5519 = fadd fast float %5518, 0x3FDFC6E900000000
  %5520 = fmul fast float %5519, %5517
  %5521 = fadd fast float %5520, 0x3FEB573B80000000
  %5522 = fadd fast float %5517, 0x4010A58D80000000
  %5523 = fmul fast float %5522, %5517
  %5524 = fadd fast float %5523, 0x400B573B80000000
  %5525 = fdiv fast float %5521, %5524
  %5526 = fcmp fast ogt float %5516, 0.000000e+00
  br i1 %5526, label %5534, label %5527

; <label>:5527                                    ; preds = %5502
  %5528 = fmul fast float %5516, %5516
  %5529 = fsub fast float 1.000000e+00, %5528
  %5530 = call float @dx.op.binary.f32(i32 35, float %5529, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5531 = call float @dx.op.unary.f32(i32 25, float %5530)  ; Rsqrt(value)
  %5532 = fmul fast float %5531, 5.000000e-01
  %5533 = fsub fast float %5532, %5525
  br label %5534

; <label>:5534                                    ; preds = %5527, %5502
  %5535 = phi float [ %5533, %5527 ], [ %5525, %5502 ]
  %5536 = fmul fast float %5478, %5472
  %5537 = fmul fast float %5477, %5473
  %5538 = fsub fast float %5536, %5537
  %5539 = fmul fast float %5476, %5473
  %5540 = fmul fast float %5478, %5471
  %5541 = fsub fast float %5539, %5540
  %5542 = fmul fast float %5477, %5471
  %5543 = fmul fast float %5476, %5472
  %5544 = fsub fast float %5542, %5543
  %5545 = fmul fast float %5535, %5538
  %5546 = fmul fast float %5535, %5541
  %5547 = fmul fast float %5535, %5544
  %5548 = fadd fast float %5545, %5513
  %5549 = fadd fast float %5546, %5514
  %5550 = fadd fast float %5547, %5515
  %5551 = call float @dx.op.dot3.f32(i32 55, float %5476, float %5477, float %5478, float %5481, float %5482, float %5483)  ; Dot3(ax,ay,az,bx,by,bz)
  %5552 = call float @dx.op.unary.f32(i32 6, float %5551)  ; FAbs(value)
  %5553 = fmul fast float %5552, 0x3F8DBCFA00000000
  %5554 = fadd fast float %5553, 0x3FDFC6E900000000
  %5555 = fmul fast float %5554, %5552
  %5556 = fadd fast float %5555, 0x3FEB573B80000000
  %5557 = fadd fast float %5552, 0x4010A58D80000000
  %5558 = fmul fast float %5557, %5552
  %5559 = fadd fast float %5558, 0x400B573B80000000
  %5560 = fdiv fast float %5556, %5559
  %5561 = fcmp fast ogt float %5551, 0.000000e+00
  br i1 %5561, label %5569, label %5562

; <label>:5562                                    ; preds = %5534
  %5563 = fmul fast float %5551, %5551
  %5564 = fsub fast float 1.000000e+00, %5563
  %5565 = call float @dx.op.binary.f32(i32 35, float %5564, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5566 = call float @dx.op.unary.f32(i32 25, float %5565)  ; Rsqrt(value)
  %5567 = fmul fast float %5566, 5.000000e-01
  %5568 = fsub fast float %5567, %5560
  br label %5569

; <label>:5569                                    ; preds = %5562, %5534
  %5570 = phi float [ %5568, %5562 ], [ %5560, %5534 ]
  %5571 = fmul fast float %5483, %5477
  %5572 = fmul fast float %5482, %5478
  %5573 = fsub fast float %5571, %5572
  %5574 = fmul fast float %5481, %5478
  %5575 = fmul fast float %5483, %5476
  %5576 = fsub fast float %5574, %5575
  %5577 = fmul fast float %5482, %5476
  %5578 = fmul fast float %5481, %5477
  %5579 = fsub fast float %5577, %5578
  %5580 = fmul fast float %5570, %5573
  %5581 = fmul fast float %5570, %5576
  %5582 = fmul fast float %5570, %5579
  %5583 = fadd fast float %5548, %5580
  %5584 = fadd fast float %5549, %5581
  %5585 = fadd fast float %5550, %5582
  %5586 = call float @dx.op.dot3.f32(i32 55, float %5481, float %5482, float %5483, float %5466, float %5467, float %5468)  ; Dot3(ax,ay,az,bx,by,bz)
  %5587 = call float @dx.op.unary.f32(i32 6, float %5586)  ; FAbs(value)
  %5588 = fmul fast float %5587, 0x3F8DBCFA00000000
  %5589 = fadd fast float %5588, 0x3FDFC6E900000000
  %5590 = fmul fast float %5589, %5587
  %5591 = fadd fast float %5590, 0x3FEB573B80000000
  %5592 = fadd fast float %5587, 0x4010A58D80000000
  %5593 = fmul fast float %5592, %5587
  %5594 = fadd fast float %5593, 0x400B573B80000000
  %5595 = fdiv fast float %5591, %5594
  %5596 = fcmp fast ogt float %5586, 0.000000e+00
  br i1 %5596, label %5604, label %5597

; <label>:5597                                    ; preds = %5569
  %5598 = fmul fast float %5586, %5586
  %5599 = fsub fast float 1.000000e+00, %5598
  %5600 = call float @dx.op.binary.f32(i32 35, float %5599, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5601 = call float @dx.op.unary.f32(i32 25, float %5600)  ; Rsqrt(value)
  %5602 = fmul fast float %5601, 5.000000e-01
  %5603 = fsub fast float %5602, %5595
  br label %5604

; <label>:5604                                    ; preds = %5597, %5569
  %5605 = phi float [ %5603, %5597 ], [ %5595, %5569 ]
  %5606 = fmul fast float %5482, %5468
  %5607 = fmul fast float %5483, %5467
  %5608 = fsub fast float %5606, %5607
  %5609 = fmul fast float %5483, %5466
  %5610 = fmul fast float %5481, %5468
  %5611 = fsub fast float %5609, %5610
  %5612 = fmul fast float %5481, %5467
  %5613 = fmul fast float %5482, %5466
  %5614 = fsub fast float %5612, %5613
  %5615 = fmul fast float %5605, %5608
  %5616 = fmul fast float %5605, %5611
  %5617 = fmul fast float %5605, %5614
  %5618 = fadd fast float %5583, %5615
  %5619 = fadd fast float %5584, %5616
  %5620 = fadd fast float %5585, %5617
  br label %5621

; <label>:5621                                    ; preds = %5604, %5417
  %5622 = phi float [ %5618, %5604 ], [ 0.000000e+00, %5417 ]
  %5623 = phi float [ %5619, %5604 ], [ 0.000000e+00, %5417 ]
  %5624 = phi float [ %5620, %5604 ], [ 0.000000e+00, %5417 ]
  %5625 = fmul fast float %5622, %5622
  %5626 = fmul fast float %5623, %5623
  %5627 = fadd fast float %5626, %5625
  %5628 = fmul fast float %5624, %5624
  %5629 = fadd fast float %5627, %5628
  %5630 = call float @dx.op.unary.f32(i32 24, float %5629)  ; Sqrt(value)
  %5631 = fmul fast float %5630, %5630
  %5632 = fadd fast float %5631, %5624
  %5633 = fadd fast float %5630, 1.000000e+00
  %5634 = fdiv fast float %5632, %5633
  %5635 = call float @dx.op.binary.f32(i32 35, float %5634, float 0.000000e+00)  ; FMax(a,b)
  %5636 = fmul fast float %5141, 0x400921FB60000000
  %5637 = and i32 %3459, 32
  %5638 = icmp ne i32 %5637, 0
  %5639 = select i1 %5638, float 1.000000e+00, float 0.000000e+00
  %5640 = fmul fast float %5639, %3287
  %5641 = fmul fast float %5640, %5636
  %5642 = fmul fast float %5431, %5641
  %5643 = fmul fast float %5642, %3474
  %5644 = fmul fast float %5642, %3475
  %5645 = fmul fast float %5642, %3476
  %5646 = and i32 %3459, 64
  %5647 = icmp ne i32 %5646, 0
  %5648 = select i1 %5647, float 1.000000e+00, float 0.000000e+00
  %5649 = fmul fast float %5648, %3290
  %5650 = fmul fast float %5649, %5636
  %5651 = fmul fast float %5650, %5635
  %5652 = fmul fast float %5651, %3474
  %5653 = fmul fast float %5651, %3475
  %5654 = fmul fast float %5651, %3476
  br label %5655

; <label>:5655                                    ; preds = %5621, %5103
  %5656 = phi float [ %5643, %5621 ], [ 0.000000e+00, %5103 ]
  %5657 = phi float [ %5644, %5621 ], [ 0.000000e+00, %5103 ]
  %5658 = phi float [ %5645, %5621 ], [ 0.000000e+00, %5103 ]
  %5659 = phi float [ %5652, %5621 ], [ 0.000000e+00, %5103 ]
  %5660 = phi float [ %5653, %5621 ], [ 0.000000e+00, %5103 ]
  %5661 = phi float [ %5654, %5621 ], [ 0.000000e+00, %5103 ]
  %5662 = zext i1 %5143 to i32
  br label %6175

; <label>:5663                                    ; preds = %5101
  %5664 = icmp eq i32 %4097, 4
  br i1 %5664, label %5665, label %6175

; <label>:5665                                    ; preds = %5663
  %5666 = fmul fast float %4091, %3471
  %5667 = fmul fast float %5666, %5666
  %5668 = fsub fast float 1.000000e+00, %5667
  %5669 = call float @dx.op.unary.f32(i32 7, float %5668)  ; Saturate(value)
  %5670 = fmul fast float %5669, %5669
  %5671 = fcmp fast ogt float %5670, 0.000000e+00
  br i1 %5671, label %5672, label %6167

; <label>:5672                                    ; preds = %5665
  %5673 = fmul fast float %3496, 5.000000e-01
  %5674 = fmul fast float %3504, 5.000000e-01
  %5675 = fmul fast float %3507, %5673
  %5676 = fmul fast float %3508, %5673
  %5677 = fmul fast float %3509, %5673
  %5678 = fmul fast float %5674, %3499
  %5679 = fmul fast float %5674, %3500
  %5680 = fmul fast float %5674, %3501
  %5681 = fsub fast float %4088, %5675
  %5682 = fsub fast float %4089, %5676
  %5683 = fsub fast float %4090, %5677
  %5684 = fsub fast float %5681, %5678
  %5685 = fsub fast float %5682, %5679
  %5686 = fsub fast float %5683, %5680
  %5687 = fadd fast float %5675, %4088
  %5688 = fadd fast float %5676, %4089
  %5689 = fadd fast float %5677, %4090
  %5690 = fsub fast float %5687, %5678
  %5691 = fsub fast float %5688, %5679
  %5692 = fsub fast float %5689, %5680
  %5693 = fadd fast float %5687, %5678
  %5694 = fadd fast float %5688, %5679
  %5695 = fadd fast float %5689, %5680
  %5696 = fadd fast float %5681, %5678
  %5697 = fadd fast float %5682, %5679
  %5698 = fadd fast float %5683, %5680
  %5699 = fmul fast float %5684, %3299
  %5700 = call float @dx.op.tertiary.f32(i32 46, float %5685, float %3300, float %5699)  ; FMad(a,b,c)
  %5701 = call float @dx.op.tertiary.f32(i32 46, float %5686, float %3301, float %5700)  ; FMad(a,b,c)
  %5702 = fmul fast float %5684, %3304
  %5703 = call float @dx.op.tertiary.f32(i32 46, float %5685, float %3307, float %5702)  ; FMad(a,b,c)
  %5704 = call float @dx.op.tertiary.f32(i32 46, float %5686, float %3310, float %5703)  ; FMad(a,b,c)
  %5705 = fmul fast float %5684, %2879
  %5706 = call float @dx.op.tertiary.f32(i32 46, float %5685, float %2880, float %5705)  ; FMad(a,b,c)
  %5707 = call float @dx.op.tertiary.f32(i32 46, float %5686, float %2881, float %5706)  ; FMad(a,b,c)
  %5708 = fmul fast float %5690, %3299
  %5709 = call float @dx.op.tertiary.f32(i32 46, float %5691, float %3300, float %5708)  ; FMad(a,b,c)
  %5710 = call float @dx.op.tertiary.f32(i32 46, float %5692, float %3301, float %5709)  ; FMad(a,b,c)
  %5711 = fmul fast float %5690, %3304
  %5712 = call float @dx.op.tertiary.f32(i32 46, float %5691, float %3307, float %5711)  ; FMad(a,b,c)
  %5713 = call float @dx.op.tertiary.f32(i32 46, float %5692, float %3310, float %5712)  ; FMad(a,b,c)
  %5714 = fmul fast float %5690, %2879
  %5715 = call float @dx.op.tertiary.f32(i32 46, float %5691, float %2880, float %5714)  ; FMad(a,b,c)
  %5716 = call float @dx.op.tertiary.f32(i32 46, float %5692, float %2881, float %5715)  ; FMad(a,b,c)
  %5717 = fmul fast float %5693, %3299
  %5718 = call float @dx.op.tertiary.f32(i32 46, float %5694, float %3300, float %5717)  ; FMad(a,b,c)
  %5719 = call float @dx.op.tertiary.f32(i32 46, float %5695, float %3301, float %5718)  ; FMad(a,b,c)
  %5720 = fmul fast float %5693, %3304
  %5721 = call float @dx.op.tertiary.f32(i32 46, float %5694, float %3307, float %5720)  ; FMad(a,b,c)
  %5722 = call float @dx.op.tertiary.f32(i32 46, float %5695, float %3310, float %5721)  ; FMad(a,b,c)
  %5723 = fmul fast float %5693, %2879
  %5724 = call float @dx.op.tertiary.f32(i32 46, float %5694, float %2880, float %5723)  ; FMad(a,b,c)
  %5725 = call float @dx.op.tertiary.f32(i32 46, float %5695, float %2881, float %5724)  ; FMad(a,b,c)
  %5726 = fmul fast float %5696, %3299
  %5727 = call float @dx.op.tertiary.f32(i32 46, float %5697, float %3300, float %5726)  ; FMad(a,b,c)
  %5728 = call float @dx.op.tertiary.f32(i32 46, float %5698, float %3301, float %5727)  ; FMad(a,b,c)
  %5729 = fmul fast float %5696, %3304
  %5730 = call float @dx.op.tertiary.f32(i32 46, float %5697, float %3307, float %5729)  ; FMad(a,b,c)
  %5731 = call float @dx.op.tertiary.f32(i32 46, float %5698, float %3310, float %5730)  ; FMad(a,b,c)
  %5732 = fmul fast float %5696, %2879
  %5733 = call float @dx.op.tertiary.f32(i32 46, float %5697, float %2880, float %5732)  ; FMad(a,b,c)
  %5734 = call float @dx.op.tertiary.f32(i32 46, float %5698, float %2881, float %5733)  ; FMad(a,b,c)
  %5735 = fmul fast float %5701, %3322
  %5736 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5707, float %5735)  ; FMad(a,b,c)
  %5737 = fmul fast float %5701, %3323
  %5738 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5707, float %5737)  ; FMad(a,b,c)
  %5739 = fmul fast float %5710, %3322
  %5740 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5716, float %5739)  ; FMad(a,b,c)
  %5741 = fmul fast float %5710, %3323
  %5742 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5716, float %5741)  ; FMad(a,b,c)
  %5743 = fmul fast float %5719, %3322
  %5744 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5725, float %5743)  ; FMad(a,b,c)
  %5745 = fmul fast float %5719, %3323
  %5746 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5725, float %5745)  ; FMad(a,b,c)
  %5747 = fmul fast float %5728, %3322
  %5748 = call float @dx.op.tertiary.f32(i32 46, float %3324, float %5734, float %5747)  ; FMad(a,b,c)
  %5749 = fmul fast float %5728, %3323
  %5750 = call float @dx.op.tertiary.f32(i32 46, float %3325, float %5734, float %5749)  ; FMad(a,b,c)
  %5751 = fsub fast float %5748, %5736
  %5752 = fsub fast float %5731, %5704
  %5753 = fsub fast float %5750, %5738
  %5754 = fsub fast float %5740, %5736
  %5755 = fsub fast float %5713, %5704
  %5756 = fsub fast float %5742, %5738
  %5757 = fmul fast float %5753, %5755
  %5758 = fmul fast float %5756, %5752
  %5759 = fsub fast float %5757, %5758
  %5760 = fmul fast float %5751, %5756
  %5761 = fmul fast float %5753, %5754
  %5762 = fsub fast float %5760, %5761
  %5763 = fmul fast float %5754, %5752
  %5764 = fmul fast float %5751, %5755
  %5765 = fsub fast float %5763, %5764
  %5766 = call float @dx.op.dot3.f32(i32 55, float %5736, float %5704, float %5738, float %5759, float %5762, float %5765)  ; Dot3(ax,ay,az,bx,by,bz)
  %5767 = fcmp fast olt float %5766, 0.000000e+00
  br i1 %5767, label %5926, label %5768

; <label>:5768                                    ; preds = %5672
  %5769 = call float @dx.op.dot3.f32(i32 55, float %5736, float %5704, float %5738, float %5736, float %5704, float %5738)  ; Dot3(ax,ay,az,bx,by,bz)
  %5770 = call float @dx.op.unary.f32(i32 25, float %5769)  ; Rsqrt(value)
  %5771 = fmul fast float %5770, %5736
  %5772 = fmul fast float %5770, %5704
  %5773 = fmul fast float %5770, %5738
  %5774 = call float @dx.op.dot3.f32(i32 55, float %5740, float %5713, float %5742, float %5740, float %5713, float %5742)  ; Dot3(ax,ay,az,bx,by,bz)
  %5775 = call float @dx.op.unary.f32(i32 25, float %5774)  ; Rsqrt(value)
  %5776 = fmul fast float %5775, %5740
  %5777 = fmul fast float %5775, %5713
  %5778 = fmul fast float %5775, %5742
  %5779 = call float @dx.op.dot3.f32(i32 55, float %5744, float %5722, float %5746, float %5744, float %5722, float %5746)  ; Dot3(ax,ay,az,bx,by,bz)
  %5780 = call float @dx.op.unary.f32(i32 25, float %5779)  ; Rsqrt(value)
  %5781 = fmul fast float %5780, %5744
  %5782 = fmul fast float %5780, %5722
  %5783 = fmul fast float %5780, %5746
  %5784 = call float @dx.op.dot3.f32(i32 55, float %5748, float %5731, float %5750, float %5748, float %5731, float %5750)  ; Dot3(ax,ay,az,bx,by,bz)
  %5785 = call float @dx.op.unary.f32(i32 25, float %5784)  ; Rsqrt(value)
  %5786 = fmul fast float %5785, %5748
  %5787 = fmul fast float %5785, %5731
  %5788 = fmul fast float %5785, %5750
  %5789 = call float @dx.op.dot3.f32(i32 55, float %5771, float %5772, float %5773, float %5776, float %5777, float %5778)  ; Dot3(ax,ay,az,bx,by,bz)
  %5790 = call float @dx.op.unary.f32(i32 6, float %5789)  ; FAbs(value)
  %5791 = fmul fast float %5790, 0x3F8DBCFA00000000
  %5792 = fadd fast float %5791, 0x3FDFC6E900000000
  %5793 = fmul fast float %5792, %5790
  %5794 = fadd fast float %5793, 0x3FEB573B80000000
  %5795 = fadd fast float %5790, 0x4010A58D80000000
  %5796 = fmul fast float %5795, %5790
  %5797 = fadd fast float %5796, 0x400B573B80000000
  %5798 = fdiv fast float %5794, %5797
  %5799 = fcmp fast ogt float %5789, 0.000000e+00
  br i1 %5799, label %5807, label %5800

; <label>:5800                                    ; preds = %5768
  %5801 = fmul fast float %5789, %5789
  %5802 = fsub fast float 1.000000e+00, %5801
  %5803 = call float @dx.op.binary.f32(i32 35, float %5802, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5804 = call float @dx.op.unary.f32(i32 25, float %5803)  ; Rsqrt(value)
  %5805 = fmul fast float %5804, 5.000000e-01
  %5806 = fsub fast float %5805, %5798
  br label %5807

; <label>:5807                                    ; preds = %5800, %5768
  %5808 = phi float [ %5806, %5800 ], [ %5798, %5768 ]
  %5809 = fmul fast float %5778, %5772
  %5810 = fmul fast float %5777, %5773
  %5811 = fsub fast float %5809, %5810
  %5812 = fmul fast float %5776, %5773
  %5813 = fmul fast float %5778, %5771
  %5814 = fsub fast float %5812, %5813
  %5815 = fmul fast float %5777, %5771
  %5816 = fmul fast float %5776, %5772
  %5817 = fsub fast float %5815, %5816
  %5818 = fmul fast float %5808, %5811
  %5819 = fmul fast float %5808, %5814
  %5820 = fmul fast float %5808, %5817
  %5821 = call float @dx.op.dot3.f32(i32 55, float %5776, float %5777, float %5778, float %5781, float %5782, float %5783)  ; Dot3(ax,ay,az,bx,by,bz)
  %5822 = call float @dx.op.unary.f32(i32 6, float %5821)  ; FAbs(value)
  %5823 = fmul fast float %5822, 0x3F8DBCFA00000000
  %5824 = fadd fast float %5823, 0x3FDFC6E900000000
  %5825 = fmul fast float %5824, %5822
  %5826 = fadd fast float %5825, 0x3FEB573B80000000
  %5827 = fadd fast float %5822, 0x4010A58D80000000
  %5828 = fmul fast float %5827, %5822
  %5829 = fadd fast float %5828, 0x400B573B80000000
  %5830 = fdiv fast float %5826, %5829
  %5831 = fcmp fast ogt float %5821, 0.000000e+00
  br i1 %5831, label %5839, label %5832

; <label>:5832                                    ; preds = %5807
  %5833 = fmul fast float %5821, %5821
  %5834 = fsub fast float 1.000000e+00, %5833
  %5835 = call float @dx.op.binary.f32(i32 35, float %5834, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5836 = call float @dx.op.unary.f32(i32 25, float %5835)  ; Rsqrt(value)
  %5837 = fmul fast float %5836, 5.000000e-01
  %5838 = fsub fast float %5837, %5830
  br label %5839

; <label>:5839                                    ; preds = %5832, %5807
  %5840 = phi float [ %5838, %5832 ], [ %5830, %5807 ]
  %5841 = fmul fast float %5783, %5777
  %5842 = fmul fast float %5782, %5778
  %5843 = fsub fast float %5841, %5842
  %5844 = fmul fast float %5781, %5778
  %5845 = fmul fast float %5783, %5776
  %5846 = fsub fast float %5844, %5845
  %5847 = fmul fast float %5782, %5776
  %5848 = fmul fast float %5781, %5777
  %5849 = fsub fast float %5847, %5848
  %5850 = fmul fast float %5840, %5843
  %5851 = fmul fast float %5840, %5846
  %5852 = fmul fast float %5840, %5849
  %5853 = fadd fast float %5850, %5818
  %5854 = fadd fast float %5851, %5819
  %5855 = fadd fast float %5852, %5820
  %5856 = call float @dx.op.dot3.f32(i32 55, float %5781, float %5782, float %5783, float %5786, float %5787, float %5788)  ; Dot3(ax,ay,az,bx,by,bz)
  %5857 = call float @dx.op.unary.f32(i32 6, float %5856)  ; FAbs(value)
  %5858 = fmul fast float %5857, 0x3F8DBCFA00000000
  %5859 = fadd fast float %5858, 0x3FDFC6E900000000
  %5860 = fmul fast float %5859, %5857
  %5861 = fadd fast float %5860, 0x3FEB573B80000000
  %5862 = fadd fast float %5857, 0x4010A58D80000000
  %5863 = fmul fast float %5862, %5857
  %5864 = fadd fast float %5863, 0x400B573B80000000
  %5865 = fdiv fast float %5861, %5864
  %5866 = fcmp fast ogt float %5856, 0.000000e+00
  br i1 %5866, label %5874, label %5867

; <label>:5867                                    ; preds = %5839
  %5868 = fmul fast float %5856, %5856
  %5869 = fsub fast float 1.000000e+00, %5868
  %5870 = call float @dx.op.binary.f32(i32 35, float %5869, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5871 = call float @dx.op.unary.f32(i32 25, float %5870)  ; Rsqrt(value)
  %5872 = fmul fast float %5871, 5.000000e-01
  %5873 = fsub fast float %5872, %5865
  br label %5874

; <label>:5874                                    ; preds = %5867, %5839
  %5875 = phi float [ %5873, %5867 ], [ %5865, %5839 ]
  %5876 = fmul fast float %5788, %5782
  %5877 = fmul fast float %5787, %5783
  %5878 = fsub fast float %5876, %5877
  %5879 = fmul fast float %5786, %5783
  %5880 = fmul fast float %5788, %5781
  %5881 = fsub fast float %5879, %5880
  %5882 = fmul fast float %5787, %5781
  %5883 = fmul fast float %5786, %5782
  %5884 = fsub fast float %5882, %5883
  %5885 = fmul fast float %5875, %5878
  %5886 = fmul fast float %5875, %5881
  %5887 = fmul fast float %5875, %5884
  %5888 = fadd fast float %5853, %5885
  %5889 = fadd fast float %5854, %5886
  %5890 = fadd fast float %5855, %5887
  %5891 = call float @dx.op.dot3.f32(i32 55, float %5786, float %5787, float %5788, float %5771, float %5772, float %5773)  ; Dot3(ax,ay,az,bx,by,bz)
  %5892 = call float @dx.op.unary.f32(i32 6, float %5891)  ; FAbs(value)
  %5893 = fmul fast float %5892, 0x3F8DBCFA00000000
  %5894 = fadd fast float %5893, 0x3FDFC6E900000000
  %5895 = fmul fast float %5894, %5892
  %5896 = fadd fast float %5895, 0x3FEB573B80000000
  %5897 = fadd fast float %5892, 0x4010A58D80000000
  %5898 = fmul fast float %5897, %5892
  %5899 = fadd fast float %5898, 0x400B573B80000000
  %5900 = fdiv fast float %5896, %5899
  %5901 = fcmp fast ogt float %5891, 0.000000e+00
  br i1 %5901, label %5909, label %5902

; <label>:5902                                    ; preds = %5874
  %5903 = fmul fast float %5891, %5891
  %5904 = fsub fast float 1.000000e+00, %5903
  %5905 = call float @dx.op.binary.f32(i32 35, float %5904, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %5906 = call float @dx.op.unary.f32(i32 25, float %5905)  ; Rsqrt(value)
  %5907 = fmul fast float %5906, 5.000000e-01
  %5908 = fsub fast float %5907, %5900
  br label %5909

; <label>:5909                                    ; preds = %5902, %5874
  %5910 = phi float [ %5908, %5902 ], [ %5900, %5874 ]
  %5911 = fmul fast float %5787, %5773
  %5912 = fmul fast float %5788, %5772
  %5913 = fsub fast float %5911, %5912
  %5914 = fmul fast float %5788, %5771
  %5915 = fmul fast float %5786, %5773
  %5916 = fsub fast float %5914, %5915
  %5917 = fmul fast float %5786, %5772
  %5918 = fmul fast float %5787, %5771
  %5919 = fsub fast float %5917, %5918
  %5920 = fmul fast float %5910, %5913
  %5921 = fmul fast float %5910, %5916
  %5922 = fmul fast float %5910, %5919
  %5923 = fadd fast float %5888, %5920
  %5924 = fadd fast float %5889, %5921
  %5925 = fadd fast float %5890, %5922
  br label %5926

; <label>:5926                                    ; preds = %5909, %5672
  %5927 = phi float [ %5923, %5909 ], [ 0.000000e+00, %5672 ]
  %5928 = phi float [ %5924, %5909 ], [ 0.000000e+00, %5672 ]
  %5929 = phi float [ %5925, %5909 ], [ 0.000000e+00, %5672 ]
  %5930 = fmul fast float %5927, %5927
  %5931 = fmul fast float %5928, %5928
  %5932 = fadd fast float %5931, %5930
  %5933 = fmul fast float %5929, %5929
  %5934 = fadd fast float %5932, %5933
  %5935 = call float @dx.op.unary.f32(i32 24, float %5934)  ; Sqrt(value)
  %5936 = fmul fast float %5935, %5935
  %5937 = fadd fast float %5936, %5929
  %5938 = fadd fast float %5935, 1.000000e+00
  %5939 = fdiv fast float %5937, %5938
  %5940 = call float @dx.op.binary.f32(i32 35, float %5939, float 0.000000e+00)  ; FMax(a,b)
  %5941 = fmul fast float %5701, %3327
  %5942 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5707, float %5941)  ; FMad(a,b,c)
  %5943 = fmul fast float %5701, %3328
  %5944 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5707, float %5943)  ; FMad(a,b,c)
  %5945 = fmul fast float %5710, %3327
  %5946 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5716, float %5945)  ; FMad(a,b,c)
  %5947 = fmul fast float %5710, %3328
  %5948 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5716, float %5947)  ; FMad(a,b,c)
  %5949 = fmul fast float %5719, %3327
  %5950 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5725, float %5949)  ; FMad(a,b,c)
  %5951 = fmul fast float %5719, %3328
  %5952 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5725, float %5951)  ; FMad(a,b,c)
  %5953 = fmul fast float %5728, %3327
  %5954 = call float @dx.op.tertiary.f32(i32 46, float %3329, float %5734, float %5953)  ; FMad(a,b,c)
  %5955 = fmul fast float %5728, %3328
  %5956 = call float @dx.op.tertiary.f32(i32 46, float %3330, float %5734, float %5955)  ; FMad(a,b,c)
  %5957 = fsub fast float %5954, %5942
  %5958 = fsub fast float %5956, %5944
  %5959 = fsub fast float %5946, %5942
  %5960 = fsub fast float %5948, %5944
  %5961 = fmul fast float %5958, %5755
  %5962 = fmul fast float %5960, %5752
  %5963 = fsub fast float %5961, %5962
  %5964 = fmul fast float %5957, %5960
  %5965 = fmul fast float %5958, %5959
  %5966 = fsub fast float %5964, %5965
  %5967 = fmul fast float %5959, %5752
  %5968 = fmul fast float %5957, %5755
  %5969 = fsub fast float %5967, %5968
  %5970 = call float @dx.op.dot3.f32(i32 55, float %5942, float %5704, float %5944, float %5963, float %5966, float %5969)  ; Dot3(ax,ay,az,bx,by,bz)
  %5971 = fcmp fast olt float %5970, 0.000000e+00
  br i1 %5971, label %6130, label %5972

; <label>:5972                                    ; preds = %5926
  %5973 = call float @dx.op.dot3.f32(i32 55, float %5942, float %5704, float %5944, float %5942, float %5704, float %5944)  ; Dot3(ax,ay,az,bx,by,bz)
  %5974 = call float @dx.op.unary.f32(i32 25, float %5973)  ; Rsqrt(value)
  %5975 = fmul fast float %5974, %5942
  %5976 = fmul fast float %5974, %5704
  %5977 = fmul fast float %5974, %5944
  %5978 = call float @dx.op.dot3.f32(i32 55, float %5946, float %5713, float %5948, float %5946, float %5713, float %5948)  ; Dot3(ax,ay,az,bx,by,bz)
  %5979 = call float @dx.op.unary.f32(i32 25, float %5978)  ; Rsqrt(value)
  %5980 = fmul fast float %5979, %5946
  %5981 = fmul fast float %5979, %5713
  %5982 = fmul fast float %5979, %5948
  %5983 = call float @dx.op.dot3.f32(i32 55, float %5950, float %5722, float %5952, float %5950, float %5722, float %5952)  ; Dot3(ax,ay,az,bx,by,bz)
  %5984 = call float @dx.op.unary.f32(i32 25, float %5983)  ; Rsqrt(value)
  %5985 = fmul fast float %5984, %5950
  %5986 = fmul fast float %5984, %5722
  %5987 = fmul fast float %5984, %5952
  %5988 = call float @dx.op.dot3.f32(i32 55, float %5954, float %5731, float %5956, float %5954, float %5731, float %5956)  ; Dot3(ax,ay,az,bx,by,bz)
  %5989 = call float @dx.op.unary.f32(i32 25, float %5988)  ; Rsqrt(value)
  %5990 = fmul fast float %5989, %5954
  %5991 = fmul fast float %5989, %5731
  %5992 = fmul fast float %5989, %5956
  %5993 = call float @dx.op.dot3.f32(i32 55, float %5975, float %5976, float %5977, float %5980, float %5981, float %5982)  ; Dot3(ax,ay,az,bx,by,bz)
  %5994 = call float @dx.op.unary.f32(i32 6, float %5993)  ; FAbs(value)
  %5995 = fmul fast float %5994, 0x3F8DBCFA00000000
  %5996 = fadd fast float %5995, 0x3FDFC6E900000000
  %5997 = fmul fast float %5996, %5994
  %5998 = fadd fast float %5997, 0x3FEB573B80000000
  %5999 = fadd fast float %5994, 0x4010A58D80000000
  %6000 = fmul fast float %5999, %5994
  %6001 = fadd fast float %6000, 0x400B573B80000000
  %6002 = fdiv fast float %5998, %6001
  %6003 = fcmp fast ogt float %5993, 0.000000e+00
  br i1 %6003, label %6011, label %6004

; <label>:6004                                    ; preds = %5972
  %6005 = fmul fast float %5993, %5993
  %6006 = fsub fast float 1.000000e+00, %6005
  %6007 = call float @dx.op.binary.f32(i32 35, float %6006, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6008 = call float @dx.op.unary.f32(i32 25, float %6007)  ; Rsqrt(value)
  %6009 = fmul fast float %6008, 5.000000e-01
  %6010 = fsub fast float %6009, %6002
  br label %6011

; <label>:6011                                    ; preds = %6004, %5972
  %6012 = phi float [ %6010, %6004 ], [ %6002, %5972 ]
  %6013 = fmul fast float %5982, %5976
  %6014 = fmul fast float %5981, %5977
  %6015 = fsub fast float %6013, %6014
  %6016 = fmul fast float %5980, %5977
  %6017 = fmul fast float %5982, %5975
  %6018 = fsub fast float %6016, %6017
  %6019 = fmul fast float %5981, %5975
  %6020 = fmul fast float %5980, %5976
  %6021 = fsub fast float %6019, %6020
  %6022 = fmul fast float %6012, %6015
  %6023 = fmul fast float %6012, %6018
  %6024 = fmul fast float %6012, %6021
  %6025 = call float @dx.op.dot3.f32(i32 55, float %5980, float %5981, float %5982, float %5985, float %5986, float %5987)  ; Dot3(ax,ay,az,bx,by,bz)
  %6026 = call float @dx.op.unary.f32(i32 6, float %6025)  ; FAbs(value)
  %6027 = fmul fast float %6026, 0x3F8DBCFA00000000
  %6028 = fadd fast float %6027, 0x3FDFC6E900000000
  %6029 = fmul fast float %6028, %6026
  %6030 = fadd fast float %6029, 0x3FEB573B80000000
  %6031 = fadd fast float %6026, 0x4010A58D80000000
  %6032 = fmul fast float %6031, %6026
  %6033 = fadd fast float %6032, 0x400B573B80000000
  %6034 = fdiv fast float %6030, %6033
  %6035 = fcmp fast ogt float %6025, 0.000000e+00
  br i1 %6035, label %6043, label %6036

; <label>:6036                                    ; preds = %6011
  %6037 = fmul fast float %6025, %6025
  %6038 = fsub fast float 1.000000e+00, %6037
  %6039 = call float @dx.op.binary.f32(i32 35, float %6038, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6040 = call float @dx.op.unary.f32(i32 25, float %6039)  ; Rsqrt(value)
  %6041 = fmul fast float %6040, 5.000000e-01
  %6042 = fsub fast float %6041, %6034
  br label %6043

; <label>:6043                                    ; preds = %6036, %6011
  %6044 = phi float [ %6042, %6036 ], [ %6034, %6011 ]
  %6045 = fmul fast float %5987, %5981
  %6046 = fmul fast float %5986, %5982
  %6047 = fsub fast float %6045, %6046
  %6048 = fmul fast float %5985, %5982
  %6049 = fmul fast float %5987, %5980
  %6050 = fsub fast float %6048, %6049
  %6051 = fmul fast float %5986, %5980
  %6052 = fmul fast float %5985, %5981
  %6053 = fsub fast float %6051, %6052
  %6054 = fmul fast float %6044, %6047
  %6055 = fmul fast float %6044, %6050
  %6056 = fmul fast float %6044, %6053
  %6057 = fadd fast float %6054, %6022
  %6058 = fadd fast float %6055, %6023
  %6059 = fadd fast float %6056, %6024
  %6060 = call float @dx.op.dot3.f32(i32 55, float %5985, float %5986, float %5987, float %5990, float %5991, float %5992)  ; Dot3(ax,ay,az,bx,by,bz)
  %6061 = call float @dx.op.unary.f32(i32 6, float %6060)  ; FAbs(value)
  %6062 = fmul fast float %6061, 0x3F8DBCFA00000000
  %6063 = fadd fast float %6062, 0x3FDFC6E900000000
  %6064 = fmul fast float %6063, %6061
  %6065 = fadd fast float %6064, 0x3FEB573B80000000
  %6066 = fadd fast float %6061, 0x4010A58D80000000
  %6067 = fmul fast float %6066, %6061
  %6068 = fadd fast float %6067, 0x400B573B80000000
  %6069 = fdiv fast float %6065, %6068
  %6070 = fcmp fast ogt float %6060, 0.000000e+00
  br i1 %6070, label %6078, label %6071

; <label>:6071                                    ; preds = %6043
  %6072 = fmul fast float %6060, %6060
  %6073 = fsub fast float 1.000000e+00, %6072
  %6074 = call float @dx.op.binary.f32(i32 35, float %6073, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6075 = call float @dx.op.unary.f32(i32 25, float %6074)  ; Rsqrt(value)
  %6076 = fmul fast float %6075, 5.000000e-01
  %6077 = fsub fast float %6076, %6069
  br label %6078

; <label>:6078                                    ; preds = %6071, %6043
  %6079 = phi float [ %6077, %6071 ], [ %6069, %6043 ]
  %6080 = fmul fast float %5992, %5986
  %6081 = fmul fast float %5991, %5987
  %6082 = fsub fast float %6080, %6081
  %6083 = fmul fast float %5990, %5987
  %6084 = fmul fast float %5992, %5985
  %6085 = fsub fast float %6083, %6084
  %6086 = fmul fast float %5991, %5985
  %6087 = fmul fast float %5990, %5986
  %6088 = fsub fast float %6086, %6087
  %6089 = fmul fast float %6079, %6082
  %6090 = fmul fast float %6079, %6085
  %6091 = fmul fast float %6079, %6088
  %6092 = fadd fast float %6057, %6089
  %6093 = fadd fast float %6058, %6090
  %6094 = fadd fast float %6059, %6091
  %6095 = call float @dx.op.dot3.f32(i32 55, float %5990, float %5991, float %5992, float %5975, float %5976, float %5977)  ; Dot3(ax,ay,az,bx,by,bz)
  %6096 = call float @dx.op.unary.f32(i32 6, float %6095)  ; FAbs(value)
  %6097 = fmul fast float %6096, 0x3F8DBCFA00000000
  %6098 = fadd fast float %6097, 0x3FDFC6E900000000
  %6099 = fmul fast float %6098, %6096
  %6100 = fadd fast float %6099, 0x3FEB573B80000000
  %6101 = fadd fast float %6096, 0x4010A58D80000000
  %6102 = fmul fast float %6101, %6096
  %6103 = fadd fast float %6102, 0x400B573B80000000
  %6104 = fdiv fast float %6100, %6103
  %6105 = fcmp fast ogt float %6095, 0.000000e+00
  br i1 %6105, label %6113, label %6106

; <label>:6106                                    ; preds = %6078
  %6107 = fmul fast float %6095, %6095
  %6108 = fsub fast float 1.000000e+00, %6107
  %6109 = call float @dx.op.binary.f32(i32 35, float %6108, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6110 = call float @dx.op.unary.f32(i32 25, float %6109)  ; Rsqrt(value)
  %6111 = fmul fast float %6110, 5.000000e-01
  %6112 = fsub fast float %6111, %6104
  br label %6113

; <label>:6113                                    ; preds = %6106, %6078
  %6114 = phi float [ %6112, %6106 ], [ %6104, %6078 ]
  %6115 = fmul fast float %5991, %5977
  %6116 = fmul fast float %5992, %5976
  %6117 = fsub fast float %6115, %6116
  %6118 = fmul fast float %5992, %5975
  %6119 = fmul fast float %5990, %5977
  %6120 = fsub fast float %6118, %6119
  %6121 = fmul fast float %5990, %5976
  %6122 = fmul fast float %5991, %5975
  %6123 = fsub fast float %6121, %6122
  %6124 = fmul fast float %6114, %6117
  %6125 = fmul fast float %6114, %6120
  %6126 = fmul fast float %6114, %6123
  %6127 = fadd fast float %6092, %6124
  %6128 = fadd fast float %6093, %6125
  %6129 = fadd fast float %6094, %6126
  br label %6130

; <label>:6130                                    ; preds = %6113, %5926
  %6131 = phi float [ %6127, %6113 ], [ 0.000000e+00, %5926 ]
  %6132 = phi float [ %6128, %6113 ], [ 0.000000e+00, %5926 ]
  %6133 = phi float [ %6129, %6113 ], [ 0.000000e+00, %5926 ]
  %6134 = fmul fast float %6131, %6131
  %6135 = fmul fast float %6132, %6132
  %6136 = fadd fast float %6135, %6134
  %6137 = fmul fast float %6133, %6133
  %6138 = fadd fast float %6136, %6137
  %6139 = call float @dx.op.unary.f32(i32 24, float %6138)  ; Sqrt(value)
  %6140 = fmul fast float %6139, %6139
  %6141 = fadd fast float %6140, %6133
  %6142 = fadd fast float %6139, 1.000000e+00
  %6143 = fdiv fast float %6141, %6142
  %6144 = call float @dx.op.binary.f32(i32 35, float %6143, float 0.000000e+00)  ; FMax(a,b)
  %6145 = and i32 %3459, 32
  %6146 = icmp eq i32 %6145, 0
  br i1 %6146, label %6151, label %6147

; <label>:6147                                    ; preds = %6130
  %6148 = fmul fast float %3287, 0x400921FB60000000
  %6149 = fmul fast float %6148, %5670
  %6150 = fmul fast float %6149, %5940
  br label %6151

; <label>:6151                                    ; preds = %6147, %6130
  %6152 = phi float [ %6150, %6147 ], [ 0.000000e+00, %6130 ]
  %6153 = and i32 %3459, 64
  %6154 = icmp eq i32 %6153, 0
  br i1 %6154, label %6159, label %6155

; <label>:6155                                    ; preds = %6151
  %6156 = fmul fast float %3290, 0x400921FB60000000
  %6157 = fmul fast float %6156, %5670
  %6158 = fmul fast float %6157, %6144
  br label %6159

; <label>:6159                                    ; preds = %6155, %6151
  %6160 = phi float [ %6158, %6155 ], [ 0.000000e+00, %6151 ]
  %6161 = fmul fast float %6152, %3474
  %6162 = fmul fast float %6152, %3475
  %6163 = fmul fast float %6152, %3476
  %6164 = fmul fast float %6160, %3474
  %6165 = fmul fast float %6160, %3475
  %6166 = fmul fast float %6160, %3476
  br label %6167

; <label>:6167                                    ; preds = %6159, %5665
  %6168 = phi float [ %6161, %6159 ], [ 0.000000e+00, %5665 ]
  %6169 = phi float [ %6162, %6159 ], [ 0.000000e+00, %5665 ]
  %6170 = phi float [ %6163, %6159 ], [ 0.000000e+00, %5665 ]
  %6171 = phi float [ %6164, %6159 ], [ 0.000000e+00, %5665 ]
  %6172 = phi float [ %6165, %6159 ], [ 0.000000e+00, %5665 ]
  %6173 = phi float [ %6166, %6159 ], [ 0.000000e+00, %5665 ]
  %6174 = zext i1 %5671 to i32
  br label %6175

; <label>:6175                                    ; preds = %6167, %5663, %5655, %5093, %4308
  %6176 = phi float [ %4112, %4308 ], [ %4093, %5093 ], [ %4093, %5655 ], [ %4093, %6167 ], [ %4093, %5663 ]
  %6177 = phi float [ %4113, %4308 ], [ %4094, %5093 ], [ %4094, %5655 ], [ %4094, %6167 ], [ %4094, %5663 ]
  %6178 = phi float [ %4114, %4308 ], [ %4095, %5093 ], [ %4095, %5655 ], [ %4095, %6167 ], [ %4095, %5663 ]
  %6179 = phi float [ %4309, %4308 ], [ %5094, %5093 ], [ %5656, %5655 ], [ %6168, %6167 ], [ 0.000000e+00, %5663 ]
  %6180 = phi float [ %4310, %4308 ], [ %5095, %5093 ], [ %5657, %5655 ], [ %6169, %6167 ], [ 0.000000e+00, %5663 ]
  %6181 = phi float [ %4311, %4308 ], [ %5096, %5093 ], [ %5658, %5655 ], [ %6170, %6167 ], [ 0.000000e+00, %5663 ]
  %6182 = phi float [ %4312, %4308 ], [ %5097, %5093 ], [ %5659, %5655 ], [ %6171, %6167 ], [ 0.000000e+00, %5663 ]
  %6183 = phi float [ %4313, %4308 ], [ %5098, %5093 ], [ %5660, %5655 ], [ %6172, %6167 ], [ 0.000000e+00, %5663 ]
  %6184 = phi float [ %4314, %4308 ], [ %5099, %5093 ], [ %5661, %5655 ], [ %6173, %6167 ], [ 0.000000e+00, %5663 ]
  %6185 = phi i32 [ %4315, %4308 ], [ %5100, %5093 ], [ %5662, %5655 ], [ %6174, %6167 ], [ 0, %5663 ]
  %6186 = and i32 %3459, 256
  %6187 = icmp eq i32 %6186, 0
  br i1 %6187, label %6528, label %6188

; <label>:6188                                    ; preds = %6175
  %6189 = mul i32 %3488, 52
  %6190 = add i32 %6189, %3336
  %6191 = shl i32 %6190, 2
  %6192 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6191, i32 undef)  ; BufferLoad(srv,index,wot)
  %6193 = extractvalue %dx.types.ResRet.f32 %6192, 0
  %6194 = extractvalue %dx.types.ResRet.f32 %6192, 1
  %6195 = extractvalue %dx.types.ResRet.f32 %6192, 2
  %6196 = extractvalue %dx.types.ResRet.f32 %6192, 3
  %6197 = add i32 %6191, 16
  %6198 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6197, i32 undef)  ; BufferLoad(srv,index,wot)
  %6199 = extractvalue %dx.types.ResRet.f32 %6198, 0
  %6200 = extractvalue %dx.types.ResRet.f32 %6198, 1
  %6201 = extractvalue %dx.types.ResRet.f32 %6198, 2
  %6202 = extractvalue %dx.types.ResRet.f32 %6198, 3
  %6203 = add i32 %6191, 32
  %6204 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6203, i32 undef)  ; BufferLoad(srv,index,wot)
  %6205 = extractvalue %dx.types.ResRet.f32 %6204, 0
  %6206 = extractvalue %dx.types.ResRet.f32 %6204, 1
  %6207 = extractvalue %dx.types.ResRet.f32 %6204, 2
  %6208 = extractvalue %dx.types.ResRet.f32 %6204, 3
  %6209 = add i32 %6191, 48
  %6210 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6209, i32 undef)  ; BufferLoad(srv,index,wot)
  %6211 = extractvalue %dx.types.ResRet.f32 %6210, 0
  %6212 = extractvalue %dx.types.ResRet.f32 %6210, 1
  %6213 = extractvalue %dx.types.ResRet.f32 %6210, 2
  %6214 = extractvalue %dx.types.ResRet.f32 %6210, 3
  %6215 = add i32 %6191, 68
  %6216 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %6215, i32 undef)  ; BufferLoad(srv,index,wot)
  %6217 = add i32 %6191, 76
  %6218 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6217, i32 undef)  ; BufferLoad(srv,index,wot)
  %6219 = extractvalue %dx.types.ResRet.f32 %6218, 0
  %6220 = add i32 %6191, 80
  %6221 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6220, i32 undef)  ; BufferLoad(srv,index,wot)
  %6222 = extractvalue %dx.types.ResRet.f32 %6221, 0
  %6223 = add i32 %6191, 84
  %6224 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6223, i32 undef)  ; BufferLoad(srv,index,wot)
  %6225 = extractvalue %dx.types.ResRet.f32 %6224, 0
  %6226 = add i32 %6191, 96
  %6227 = add i32 %6191, 192
  %6228 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6227, i32 undef)  ; BufferLoad(srv,index,wot)
  %6229 = extractvalue %dx.types.ResRet.f32 %6228, 2
  %6230 = extractvalue %dx.types.ResRet.f32 %6228, 3
  %6231 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6226, i32 undef)  ; BufferLoad(srv,index,wot)
  %6232 = extractvalue %dx.types.ResRet.f32 %6231, 0
  %6233 = extractvalue %dx.types.ResRet.f32 %6231, 1
  %6234 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 0
  %6235 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 0
  store float %6232, float* %6234, align 4
  store float %6233, float* %6235, align 4
  %6236 = add i32 %6191, 112
  %6237 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6236, i32 undef)  ; BufferLoad(srv,index,wot)
  %6238 = extractvalue %dx.types.ResRet.f32 %6237, 0
  %6239 = extractvalue %dx.types.ResRet.f32 %6237, 1
  %6240 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 1
  %6241 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 1
  store float %6238, float* %6240, align 4
  store float %6239, float* %6241, align 4
  %6242 = add i32 %6191, 128
  %6243 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6242, i32 undef)  ; BufferLoad(srv,index,wot)
  %6244 = extractvalue %dx.types.ResRet.f32 %6243, 0
  %6245 = extractvalue %dx.types.ResRet.f32 %6243, 1
  %6246 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 2
  %6247 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 2
  store float %6244, float* %6246, align 4
  store float %6245, float* %6247, align 4
  %6248 = add i32 %6191, 144
  %6249 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6248, i32 undef)  ; BufferLoad(srv,index,wot)
  %6250 = extractvalue %dx.types.ResRet.f32 %6249, 0
  %6251 = extractvalue %dx.types.ResRet.f32 %6249, 1
  %6252 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 3
  %6253 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 3
  store float %6250, float* %6252, align 4
  store float %6251, float* %6253, align 4
  %6254 = add i32 %6191, 160
  %6255 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6254, i32 undef)  ; BufferLoad(srv,index,wot)
  %6256 = extractvalue %dx.types.ResRet.f32 %6255, 0
  %6257 = extractvalue %dx.types.ResRet.f32 %6255, 1
  %6258 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 4
  %6259 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 4
  store float %6256, float* %6258, align 4
  store float %6257, float* %6259, align 4
  %6260 = add i32 %6191, 176
  %6261 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6260, i32 undef)  ; BufferLoad(srv,index,wot)
  %6262 = extractvalue %dx.types.ResRet.f32 %6261, 0
  %6263 = extractvalue %dx.types.ResRet.f32 %6261, 1
  %6264 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 5
  %6265 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 5
  store float %6262, float* %6264, align 4
  store float %6263, float* %6265, align 4
  %6266 = icmp ne i32 %6185, 0
  %6267 = and i32 %3459, 16
  %6268 = icmp ne i32 %6267, 0
  %6269 = and i1 %6268, %6266
  br i1 %6269, label %6270, label %6307

; <label>:6270                                    ; preds = %6188
  %6271 = extractvalue %dx.types.ResRet.i32 %6216, 0
  %6272 = and i32 %6271, 65535
  %6273 = uitofp i32 %6272 to float
  %6274 = fsub fast float -0.000000e+00, %6176
  %6275 = fsub fast float -0.000000e+00, %6177
  %6276 = fsub fast float -0.000000e+00, %6178
  %6277 = fmul fast float %3507, %6274
  %6278 = call float @dx.op.tertiary.f32(i32 46, float %3508, float %6275, float %6277)  ; FMad(a,b,c)
  %6279 = call float @dx.op.tertiary.f32(i32 46, float %3509, float %6276, float %6278)  ; FMad(a,b,c)
  %6280 = fmul fast float %3499, %6274
  %6281 = call float @dx.op.tertiary.f32(i32 46, float %3500, float %6275, float %6280)  ; FMad(a,b,c)
  %6282 = call float @dx.op.tertiary.f32(i32 46, float %3501, float %6276, float %6281)  ; FMad(a,b,c)
  %6283 = fmul fast float %3491, %6274
  %6284 = call float @dx.op.tertiary.f32(i32 46, float %3492, float %6275, float %6283)  ; FMad(a,b,c)
  %6285 = call float @dx.op.tertiary.f32(i32 46, float %3493, float %6276, float %6284)  ; FMad(a,b,c)
  %6286 = fmul fast float %6285, 5.000000e-01
  %6287 = fadd fast float %6286, 5.000000e-01
  %6288 = fdiv fast float %6282, %6279
  %6289 = call float @dx.op.unary.f32(i32 17, float %6288)  ; Atan(value)
  %6290 = fadd fast float %6289, 0x400921FB60000000
  %6291 = fadd fast float %6289, 0xC00921FB60000000
  %6292 = fcmp fast olt float %6279, 0.000000e+00
  %6293 = fcmp fast oeq float %6279, 0.000000e+00
  %6294 = fcmp fast oge float %6282, 0.000000e+00
  %6295 = fcmp fast olt float %6282, 0.000000e+00
  %6296 = and i1 %6292, %6294
  %6297 = select i1 %6296, float %6290, float %6289
  %6298 = and i1 %6292, %6295
  %6299 = select i1 %6298, float %6291, float %6297
  %6300 = and i1 %6293, %6295
  %6301 = and i1 %6293, %6294
  %6302 = fmul fast float %6299, 0x3FC45F3060000000
  %6303 = select i1 %6300, float -2.500000e-01, float %6302
  %6304 = select i1 %6301, float 2.500000e-01, float %6303
  %6305 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %33, %dx.types.Handle %41, float %6304, float %6287, float %6273, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %6306 = extractvalue %dx.types.ResRet.f32 %6305, 0
  br label %6307

; <label>:6307                                    ; preds = %6270, %6188
  %6308 = phi float [ %6306, %6270 ], [ 1.000000e+00, %6188 ]
  %6309 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %44, i32 30)  ; CBufferLoadLegacy(handle,regIndex)
  %6310 = extractvalue %dx.types.CBufRet.i32 %6309, 0
  %6311 = extractvalue %dx.types.CBufRet.i32 %6309, 1
  %6312 = extractvalue %dx.types.CBufRet.i32 %6309, 2
  %6313 = and i32 %3459, 6144
  %6314 = icmp ne i32 %6313, 0
  %6315 = and i1 %6314, %6266
  br i1 %6315, label %6316, label %6528

; <label>:6316                                    ; preds = %6307
  %6317 = call float @dx.op.dot3.f32(i32 55, float %3491, float %3492, float %3493, float %6176, float %6177, float %6178)  ; Dot3(ax,ay,az,bx,by,bz)
  %6318 = fmul fast float %6317, %6222
  %6319 = fadd fast float %6318, %6225
  %6320 = call float @dx.op.unary.f32(i32 7, float %6319)  ; Saturate(value)
  %6321 = fmul fast float %6320, %6320
  %6322 = fcmp fast ogt float %6321, 0.000000e+00
  br i1 %6322, label %6323, label %6528

; <label>:6323                                    ; preds = %6316
  %6324 = icmp eq i32 %6313, 4096
  br i1 %6324, label %6325, label %6369

; <label>:6325                                    ; preds = %6323
  %6326 = call float @dx.op.unary.f32(i32 6, float %4088)  ; FAbs(value)
  %6327 = call float @dx.op.unary.f32(i32 6, float %4089)  ; FAbs(value)
  %6328 = call float @dx.op.unary.f32(i32 6, float %4090)  ; FAbs(value)
  %6329 = call float @dx.op.binary.f32(i32 35, float %6326, float %6327)  ; FMax(a,b)
  %6330 = call float @dx.op.binary.f32(i32 35, float %6329, float %6328)  ; FMax(a,b)
  %6331 = fcmp fast oge float %6328, %6327
  %6332 = fcmp fast oge float %6328, %6326
  %6333 = and i1 %6332, %6331
  br i1 %6333, label %6334, label %6340

; <label>:6334                                    ; preds = %6325
  %6335 = fsub fast float -0.000000e+00, %4088
  %6336 = fcmp fast olt float %4090, 0.000000e+00
  %6337 = select i1 %6336, float %6335, float %4088
  %6338 = fsub fast float -0.000000e+00, %4089
  %6339 = select i1 %6336, float 5.000000e+00, float 4.000000e+00
  br label %6352

; <label>:6340                                    ; preds = %6325
  %6341 = fcmp fast ult float %6327, %6326
  %6342 = fsub fast float -0.000000e+00, %4090
  br i1 %6341, label %6347, label %6343

; <label>:6343                                    ; preds = %6340
  %6344 = fcmp fast olt float %4089, 0.000000e+00
  %6345 = select i1 %6344, float %6342, float %4090
  %6346 = select i1 %6344, float 3.000000e+00, float 2.000000e+00
  br label %6352

; <label>:6347                                    ; preds = %6340
  %6348 = fcmp fast olt float %4088, 0.000000e+00
  %6349 = select i1 %6348, float %4090, float %6342
  %6350 = fsub fast float -0.000000e+00, %4089
  %6351 = select i1 %6348, float 1.000000e+00, float 0.000000e+00
  br label %6352

; <label>:6352                                    ; preds = %6347, %6343, %6334
  %6353 = phi float [ %6337, %6334 ], [ %4088, %6343 ], [ %6349, %6347 ]
  %6354 = phi float [ %6338, %6334 ], [ %6345, %6343 ], [ %6350, %6347 ]
  %6355 = phi float [ %6339, %6334 ], [ %6346, %6343 ], [ %6351, %6347 ]
  %6356 = fsub fast float -0.000000e+00, %6353
  %6357 = fdiv fast float %6356, %6330
  %6358 = fsub fast float -0.000000e+00, %6354
  %6359 = fdiv fast float %6358, %6330
  %6360 = fmul fast float %6330, %6207
  %6361 = fsub fast float %6208, %6360
  %6362 = fdiv fast float %6361, %6330
  %6363 = fsub fast float 1.000000e+00, %6362
  %6364 = fptoui float %6355 to i32
  %6365 = getelementptr [6 x float], [6 x float]* %72, i32 0, i32 %6364
  %6366 = load float, float* %6365, align 4
  %6367 = getelementptr [6 x float], [6 x float]* %73, i32 0, i32 %6364
  %6368 = load float, float* %6367, align 4
  br label %6396

; <label>:6369                                    ; preds = %6323
  %6370 = fmul fast float %6193, %565
  %6371 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6194, float %6370)  ; FMad(a,b,c)
  %6372 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6195, float %6371)  ; FMad(a,b,c)
  %6373 = fadd fast float %6372, %6196
  %6374 = fmul fast float %6199, %565
  %6375 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6200, float %6374)  ; FMad(a,b,c)
  %6376 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6201, float %6375)  ; FMad(a,b,c)
  %6377 = fadd fast float %6376, %6202
  %6378 = fmul fast float %6205, %565
  %6379 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6206, float %6378)  ; FMad(a,b,c)
  %6380 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6207, float %6379)  ; FMad(a,b,c)
  %6381 = fadd fast float %6380, %6208
  %6382 = fmul fast float %6211, %565
  %6383 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6212, float %6382)  ; FMad(a,b,c)
  %6384 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6213, float %6383)  ; FMad(a,b,c)
  %6385 = fadd fast float %6384, %6214
  %6386 = fdiv fast float 1.000000e+00, %6385
  %6387 = fmul fast float %6386, %6373
  %6388 = fmul fast float %6377, %6386
  %6389 = fsub fast float -0.000000e+00, %6388
  %6390 = fmul fast float %6386, %6381
  %6391 = fsub fast float 1.000000e+00, %6390
  %6392 = call float @dx.op.unary.f32(i32 6, float %6389)  ; FAbs(value)
  %6393 = call float @dx.op.unary.f32(i32 6, float %6387)  ; FAbs(value)
  %6394 = call float @dx.op.binary.f32(i32 35, float %6393, float %6392)  ; FMax(a,b)
  %6395 = call float @dx.op.binary.f32(i32 35, float %6394, float %6391)  ; FMax(a,b)
  br label %6396

; <label>:6396                                    ; preds = %6369, %6352
  %6397 = phi float [ %6368, %6352 ], [ %6233, %6369 ]
  %6398 = phi float [ %6366, %6352 ], [ %6232, %6369 ]
  %6399 = phi float [ %6363, %6352 ], [ %6395, %6369 ]
  %6400 = phi float [ %6357, %6352 ], [ %6387, %6369 ]
  %6401 = phi float [ %6359, %6352 ], [ %6389, %6369 ]
  %6402 = phi float [ %6362, %6352 ], [ %6390, %6369 ]
  %6403 = fcmp fast ole float %6399, 1.000000e+00
  %6404 = fmul fast float %6400, %6229
  %6405 = fmul fast float %6401, %6230
  %6406 = fadd fast float %6404, %6398
  %6407 = fadd fast float %6405, %6397
  %6408 = fcmp fast oge float %6398, 0.000000e+00
  %6409 = and i1 %6408, %6403
  %6410 = add i32 %6310, -1
  %6411 = lshr i32 %6410, 1
  %6412 = fmul fast float %6406, %134
  %6413 = fmul fast float %6407, %134
  %6414 = fadd fast float %6412, -5.000000e-01
  %6415 = fadd fast float %6413, -5.000000e-01
  %6416 = call float @dx.op.unary.f32(i32 22, float %6414)  ; Frc(value)
  %6417 = call float @dx.op.unary.f32(i32 22, float %6415)  ; Frc(value)
  %6418 = fsub fast float 1.000000e+00, %6416
  %6419 = fsub fast float 1.000000e+00, %6417
  %6420 = fmul fast float %6419, %6418
  %6421 = fmul fast float %6419, %6416
  %6422 = fmul fast float %6418, %6417
  %6423 = fmul fast float %6417, %6416
  %6424 = call float @dx.op.unary.f32(i32 27, float %6414)  ; Round_ni(value)
  %6425 = fptosi float %6424 to i32
  %6426 = sub i32 %6425, %6411
  %6427 = sitofp i32 %6426 to float
  %6428 = fmul fast float %6427, %135
  %6429 = fadd fast float %6428, %135
  %6430 = fmul fast float %135, 2.000000e+00
  %6431 = icmp eq i32 %6310, 0
  br i1 %6431, label %6519, label %6432

; <label>:6432                                    ; preds = %6396
  %6433 = call float @dx.op.unary.f32(i32 27, float %6415)  ; Round_ni(value)
  %6434 = fptosi float %6433 to i32
  %6435 = sub i32 %6434, %6411
  %6436 = sitofp i32 %6435 to float
  %6437 = fmul fast float %6436, %135
  %6438 = fadd fast float %6437, %135
  br label %6439

; <label>:6439                                    ; preds = %6512, %6432
  %6440 = phi float [ %6513, %6512 ], [ %6438, %6432 ]
  %6441 = phi float [ %6508, %6512 ], [ 0.000000e+00, %6432 ]
  %6442 = phi i32 [ %6515, %6512 ], [ %6311, %6432 ]
  %6443 = phi i32 [ %6516, %6512 ], [ 0, %6432 ]
  br label %6444

; <label>:6444                                    ; preds = %6444, %6439
  %6445 = phi float [ %6508, %6444 ], [ %6441, %6439 ]
  %6446 = phi float [ %6509, %6444 ], [ %6429, %6439 ]
  %6447 = phi i32 [ %6510, %6444 ], [ 0, %6439 ]
  %6448 = add i32 %6447, %6442
  %6449 = add i32 %6448, %6312
  %6450 = add i32 %6448, 35
  %6451 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %6450)  ; CBufferLoadLegacy(handle,regIndex)
  %6452 = extractvalue %dx.types.CBufRet.f32 %6451, 0
  %6453 = fmul fast float %6452, %6423
  %6454 = extractvalue %dx.types.CBufRet.f32 %6451, 1
  %6455 = fmul fast float %6454, %6422
  %6456 = fadd fast float %6455, %6453
  %6457 = extractvalue %dx.types.CBufRet.f32 %6451, 2
  %6458 = fmul fast float %6457, %6421
  %6459 = fadd fast float %6456, %6458
  %6460 = extractvalue %dx.types.CBufRet.f32 %6451, 3
  %6461 = fmul fast float %6460, %6420
  %6462 = fadd fast float %6459, %6461
  %6463 = add i32 %6448, 36
  %6464 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %6463)  ; CBufferLoadLegacy(handle,regIndex)
  %6465 = extractvalue %dx.types.CBufRet.f32 %6464, 0
  %6466 = fmul fast float %6465, %6423
  %6467 = extractvalue %dx.types.CBufRet.f32 %6464, 1
  %6468 = fmul fast float %6467, %6422
  %6469 = fadd fast float %6468, %6466
  %6470 = extractvalue %dx.types.CBufRet.f32 %6464, 2
  %6471 = fmul fast float %6470, %6421
  %6472 = fadd fast float %6469, %6471
  %6473 = extractvalue %dx.types.CBufRet.f32 %6464, 3
  %6474 = fmul fast float %6473, %6420
  %6475 = fadd fast float %6472, %6474
  %6476 = add i32 %6449, 35
  %6477 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %6476)  ; CBufferLoadLegacy(handle,regIndex)
  %6478 = extractvalue %dx.types.CBufRet.f32 %6477, 0
  %6479 = fmul fast float %6478, %6423
  %6480 = extractvalue %dx.types.CBufRet.f32 %6477, 1
  %6481 = fmul fast float %6480, %6422
  %6482 = fadd fast float %6481, %6479
  %6483 = extractvalue %dx.types.CBufRet.f32 %6477, 2
  %6484 = fmul fast float %6483, %6421
  %6485 = fadd fast float %6482, %6484
  %6486 = extractvalue %dx.types.CBufRet.f32 %6477, 3
  %6487 = fmul fast float %6486, %6420
  %6488 = fadd fast float %6485, %6487
  %6489 = add i32 %6449, 36
  %6490 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 %6489)  ; CBufferLoadLegacy(handle,regIndex)
  %6491 = extractvalue %dx.types.CBufRet.f32 %6490, 0
  %6492 = fmul fast float %6491, %6423
  %6493 = extractvalue %dx.types.CBufRet.f32 %6490, 1
  %6494 = fmul fast float %6493, %6422
  %6495 = fadd fast float %6494, %6492
  %6496 = extractvalue %dx.types.CBufRet.f32 %6490, 2
  %6497 = fmul fast float %6496, %6421
  %6498 = fadd fast float %6495, %6497
  %6499 = extractvalue %dx.types.CBufRet.f32 %6490, 3
  %6500 = fmul fast float %6499, %6420
  %6501 = fadd fast float %6498, %6500
  %6502 = call %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32 74, %dx.types.Handle %30, %dx.types.Handle %36, float %6446, float %6440, float undef, float undef, i32 0, i32 0, i32 0, float %6402)  ; TextureGatherCmp(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,channel,compareValue)
  %6503 = extractvalue %dx.types.ResRet.f32 %6502, 0
  %6504 = extractvalue %dx.types.ResRet.f32 %6502, 1
  %6505 = extractvalue %dx.types.ResRet.f32 %6502, 2
  %6506 = extractvalue %dx.types.ResRet.f32 %6502, 3
  %6507 = call float @dx.op.dot4.f32(i32 56, float %6506, float %6505, float %6503, float %6504, float %6462, float %6475, float %6488, float %6501)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %6508 = fadd fast float %6507, %6445
  %6509 = fadd fast float %6446, %6430
  %6510 = add i32 %6447, 2
  %6511 = icmp ult i32 %6510, %6310
  br i1 %6511, label %6444, label %6512

; <label>:6512                                    ; preds = %6444
  %6513 = fadd fast float %6440, %6430
  %6514 = shl i32 %6312, 1
  %6515 = add i32 %6442, %6514
  %6516 = add i32 %6443, 2
  %6517 = icmp ult i32 %6516, %6310
  br i1 %6517, label %6439, label %6518

; <label>:6518                                    ; preds = %6512
  br label %6519

; <label>:6519                                    ; preds = %6518, %6396
  %6520 = phi float [ 0.000000e+00, %6396 ], [ %6508, %6518 ]
  %6521 = call float @dx.op.unary.f32(i32 7, float %6520)  ; Saturate(value)
  %6522 = fadd fast float %6521, -1.000000e+00
  %6523 = select i1 %6409, float %6522, float 0.000000e+00
  %6524 = fmul fast float %6321, %6219
  %6525 = fmul fast float %6524, %6523
  %6526 = fadd fast float %6525, 1.000000e+00
  %6527 = fmul fast float %6526, %6308
  br label %6528

; <label>:6528                                    ; preds = %6519, %6316, %6307, %6175
  %6529 = phi float [ 1.000000e+00, %6175 ], [ %6527, %6519 ], [ %6308, %6316 ], [ %6308, %6307 ]
  %6530 = fmul fast float %6529, %6179
  %6531 = fmul fast float %6529, %6180
  %6532 = fmul fast float %6529, %6181
  %6533 = fadd fast float %6530, %3447
  %6534 = fadd fast float %6531, %3448
  %6535 = fadd fast float %6532, %3449
  %6536 = fmul fast float %6529, %6182
  %6537 = fmul fast float %6529, %6183
  %6538 = fmul fast float %6529, %6184
  %6539 = fadd fast float %6536, %3444
  %6540 = fadd fast float %6537, %3445
  %6541 = fadd fast float %6538, %3446
  br label %3515

; <label>:6542                                    ; preds = %3515
  br label %6543

; <label>:6543                                    ; preds = %6542, %3438
  %6544 = phi float [ %3403, %3438 ], [ %3516, %6542 ]
  %6545 = phi float [ %3404, %3438 ], [ %3517, %6542 ]
  %6546 = phi float [ %3405, %3438 ], [ %3518, %6542 ]
  %6547 = phi float [ %3406, %3438 ], [ %3519, %6542 ]
  %6548 = phi float [ %3407, %3438 ], [ %3520, %6542 ]
  %6549 = phi float [ %3408, %3438 ], [ %3521, %6542 ]
  %6550 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 2)  ; CBufferLoadLegacy(handle,regIndex)
  %6551 = extractvalue %dx.types.CBufRet.f32 %6550, 1
  %6552 = fmul fast float %2756, 0x3F40600000000000
  %6553 = fadd fast float %6552, 0x3FEFFCB940000000
  %6554 = fmul fast float %2757, 0x3F40600000000000
  %6555 = fadd fast float %6554, 0x3FEFFCB940000000
  %6556 = fmul fast float %2758, 0x3F40600000000000
  %6557 = fadd fast float %6556, 0x3FEFFCB940000000
  %6558 = call float @dx.op.unary.f32(i32 7, float %6553)  ; Saturate(value)
  %6559 = call float @dx.op.unary.f32(i32 7, float %6555)  ; Saturate(value)
  %6560 = call float @dx.op.unary.f32(i32 7, float %6557)  ; Saturate(value)
  %6561 = fadd fast float %6558, -1.000000e+00
  %6562 = fadd fast float %6559, -1.000000e+00
  %6563 = fadd fast float %6560, -1.000000e+00
  %6564 = fmul fast float %6561, %6551
  %6565 = fmul fast float %6562, %6551
  %6566 = fmul fast float %6563, %6551
  %6567 = fadd fast float %6564, 1.000000e+00
  %6568 = fadd fast float %6565, 1.000000e+00
  %6569 = fadd fast float %6566, 1.000000e+00
  %6570 = fmul fast float %6567, %6547
  %6571 = fmul fast float %6568, %6548
  %6572 = fmul fast float %6569, %6549
  %6573 = add nuw nsw i32 %3409, 1
  %6574 = icmp eq i32 %3409, %3399
  br i1 %6574, label %6575, label %3402

; <label>:6575                                    ; preds = %6543
  br label %6576

; <label>:6576                                    ; preds = %6575, %3393, %3387
  %6577 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6544, %6575 ]
  %6578 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6545, %6575 ]
  %6579 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6546, %6575 ]
  %6580 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6570, %6575 ]
  %6581 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6571, %6575 ]
  %6582 = phi float [ 0.000000e+00, %3387 ], [ 0.000000e+00, %3393 ], [ %6572, %6575 ]
  %6583 = fmul fast float %6580, %129
  %6584 = fmul fast float %6581, %129
  %6585 = fmul fast float %6582, %129
  %6586 = fmul fast float %6577, %129
  %6587 = fmul fast float %6578, %129
  %6588 = fmul fast float %6579, %129
  %6589 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %6590 = extractvalue %dx.types.CBufRet.f32 %6589, 0
  %6591 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 1)  ; CBufferLoadLegacy(handle,regIndex)
  %6592 = extractvalue %dx.types.CBufRet.f32 %6591, 1
  %6593 = extractvalue %dx.types.CBufRet.f32 %6589, 1
  %6594 = fsub fast float -0.000000e+00, %272
  %6595 = fsub fast float -0.000000e+00, %273
  %6596 = fsub fast float -0.000000e+00, %274
  %6597 = call float @dx.op.dot3.f32(i32 55, float %6594, float %6595, float %6596, float %2879, float %2880, float %2881)  ; Dot3(ax,ay,az,bx,by,bz)
  %6598 = fmul fast float %6597, 2.000000e+00
  %6599 = fmul fast float %6598, %2879
  %6600 = fmul fast float %6598, %2880
  %6601 = fmul fast float %6598, %2881
  %6602 = fsub fast float %6594, %6599
  %6603 = fsub fast float %6595, %6600
  %6604 = fsub fast float %6596, %6601
  %6605 = and i32 %2884, 2
  %6606 = icmp ne i32 %6605, 0
  %6607 = and i32 %2884, 4
  %6608 = icmp ne i32 %6607, 0
  %6609 = icmp eq i32 %3341, 0
  br i1 %6609, label %7302, label %6610

; <label>:6610                                    ; preds = %6576
  %6611 = add i32 %3391, %3389
  %6612 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %21, i32 %6611, i32 0)  ; BufferLoad(srv,index,wot)
  %6613 = extractvalue %dx.types.ResRet.i32 %6612, 0
  %6614 = and i32 %6613, 65535
  %6615 = lshr i32 %6613, 16
  %6616 = lshr i32 %6614, 5
  %6617 = lshr i32 %6613, 21
  %6618 = icmp ugt i32 %6616, %6617
  br i1 %6618, label %7302, label %6619

; <label>:6619                                    ; preds = %6610
  br label %6620

; <label>:6620                                    ; preds = %7294, %6619
  %6621 = phi float [ %7295, %7294 ], [ 0.000000e+00, %6619 ]
  %6622 = phi float [ %7296, %7294 ], [ 0.000000e+00, %6619 ]
  %6623 = phi float [ %7297, %7294 ], [ 0.000000e+00, %6619 ]
  %6624 = phi float [ %7298, %7294 ], [ 1.000000e+00, %6619 ]
  %6625 = phi i32 [ %7299, %7294 ], [ %6616, %6619 ]
  %6626 = add i32 %3390, %3388
  %6627 = add i32 %6626, %6625
  %6628 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %29, i32 %6627, i32 0)  ; BufferLoad(srv,index,wot)
  %6629 = extractvalue %dx.types.ResRet.i32 %6628, 0
  %6630 = shl i32 %6625, 5
  %6631 = sub nsw i32 %6614, %6630
  %6632 = call i32 @dx.op.binary.i32(i32 37, i32 %6631, i32 0)  ; IMax(a,b)
  %6633 = call i32 @dx.op.binary.i32(i32 38, i32 %6632, i32 31)  ; IMin(a,b)
  %6634 = add nuw nsw i32 %6630, 32
  %6635 = icmp uge i32 %6614, %6634
  %6636 = icmp ult i32 %6615, %6630
  %6637 = or i1 %6636, %6635
  br i1 %6637, label %6646, label %6638

; <label>:6638                                    ; preds = %6620
  %6639 = sub nsw i32 %6615, %6630
  %6640 = call i32 @dx.op.binary.i32(i32 37, i32 %6639, i32 0)  ; IMax(a,b)
  %6641 = call i32 @dx.op.binary.i32(i32 38, i32 %6640, i32 31)  ; IMin(a,b)
  %6642 = sub i32 1, %6633
  %6643 = add i32 %6642, %6641
  %6644 = call i32 @dx.op.binary.i32(i32 37, i32 %6643, i32 0)  ; IMax(a,b)
  %6645 = call i32 @dx.op.binary.i32(i32 38, i32 %6644, i32 32)  ; IMin(a,b)
  br label %6646

; <label>:6646                                    ; preds = %6638, %6620
  %6647 = phi i32 [ %6645, %6638 ], [ 0, %6620 ]
  %6648 = icmp eq i32 %6647, 32
  br i1 %6648, label %6655, label %6649

; <label>:6649                                    ; preds = %6646
  %6650 = and i32 %6647, 31
  %6651 = shl i32 1, %6650
  %6652 = add i32 %6651, -1
  %6653 = and i32 %6633, 31
  %6654 = shl i32 %6652, %6653
  br label %6655

; <label>:6655                                    ; preds = %6649, %6646
  %6656 = phi i32 [ %6654, %6649 ], [ -1, %6646 ]
  %6657 = and i32 %6656, %6629
  %6658 = icmp eq i32 %6657, 0
  br i1 %6658, label %7294, label %6659

; <label>:6659                                    ; preds = %6655
  br label %6660

; <label>:6660                                    ; preds = %7285, %6659
  %6661 = phi float [ %7286, %7285 ], [ %6621, %6659 ]
  %6662 = phi float [ %7287, %7285 ], [ %6622, %6659 ]
  %6663 = phi float [ %7288, %7285 ], [ %6623, %6659 ]
  %6664 = phi float [ %7289, %7285 ], [ %6624, %6659 ]
  %6665 = phi i32 [ %6669, %7285 ], [ %6657, %6659 ]
  %6666 = call i32 @dx.op.unaryBits.i32(i32 32, i32 %6665)  ; FirstbitLo(value)
  %6667 = and i32 %6666, 31
  %6668 = shl i32 1, %6667
  %6669 = xor i32 %6668, %6665
  %6670 = add i32 %6666, %6630
  %6671 = add i32 %6670, %3333
  %6672 = shl i32 %6671, 2
  %6673 = call %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32 68, %dx.types.Handle %34, i32 %6672, i32 undef)  ; BufferLoad(srv,index,wot)
  %6674 = extractvalue %dx.types.ResRet.i32 %6673, 0
  %6675 = lshr i32 %6674, 16
  %6676 = and i32 %6675, 3
  %6677 = icmp eq i32 %6676, 1
  br i1 %6677, label %6678, label %6682

; <label>:6678                                    ; preds = %6660
  %6679 = and i32 %6674, 786432
  %6680 = icmp eq i32 %6679, 262144
  %6681 = select i1 %6680, i32 2, i32 1
  br label %6682

; <label>:6682                                    ; preds = %6678, %6660
  %6683 = phi i32 [ %6676, %6660 ], [ %6681, %6678 ]
  switch i32 %6683, label %7285 [
    i32 1, label %6997
    i32 2, label %6684
  ]

; <label>:6684                                    ; preds = %6682
  %6685 = mul i32 %6670, 44
  %6686 = add i32 %6685, %3338
  %6687 = shl i32 %6686, 2
  %6688 = add i32 %6687, 16
  %6689 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6688, i32 undef)  ; BufferLoad(srv,index,wot)
  %6690 = extractvalue %dx.types.ResRet.f32 %6689, 0
  %6691 = extractvalue %dx.types.ResRet.f32 %6689, 1
  %6692 = extractvalue %dx.types.ResRet.f32 %6689, 2
  %6693 = extractvalue %dx.types.ResRet.f32 %6689, 3
  %6694 = add i32 %6687, 32
  %6695 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6694, i32 undef)  ; BufferLoad(srv,index,wot)
  %6696 = extractvalue %dx.types.ResRet.f32 %6695, 0
  %6697 = extractvalue %dx.types.ResRet.f32 %6695, 1
  %6698 = extractvalue %dx.types.ResRet.f32 %6695, 2
  %6699 = extractvalue %dx.types.ResRet.f32 %6695, 3
  %6700 = add i32 %6687, 48
  %6701 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6700, i32 undef)  ; BufferLoad(srv,index,wot)
  %6702 = extractvalue %dx.types.ResRet.f32 %6701, 0
  %6703 = extractvalue %dx.types.ResRet.f32 %6701, 1
  %6704 = extractvalue %dx.types.ResRet.f32 %6701, 2
  %6705 = extractvalue %dx.types.ResRet.f32 %6701, 3
  %6706 = add i32 %6687, 80
  %6707 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6706, i32 undef)  ; BufferLoad(srv,index,wot)
  %6708 = extractvalue %dx.types.ResRet.f32 %6707, 0
  %6709 = extractvalue %dx.types.ResRet.f32 %6707, 1
  %6710 = extractvalue %dx.types.ResRet.f32 %6707, 2
  %6711 = add i32 %6687, 92
  %6712 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6711, i32 undef)  ; BufferLoad(srv,index,wot)
  %6713 = extractvalue %dx.types.ResRet.f32 %6712, 0
  %6714 = add i32 %6687, 96
  %6715 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6714, i32 undef)  ; BufferLoad(srv,index,wot)
  %6716 = extractvalue %dx.types.ResRet.f32 %6715, 0
  %6717 = extractvalue %dx.types.ResRet.f32 %6715, 1
  %6718 = extractvalue %dx.types.ResRet.f32 %6715, 2
  %6719 = add i32 %6687, 108
  %6720 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6719, i32 undef)  ; BufferLoad(srv,index,wot)
  %6721 = extractvalue %dx.types.ResRet.f32 %6720, 0
  %6722 = add i32 %6687, 112
  %6723 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %6722, i32 undef)  ; BufferLoad(srv,index,wot)
  %6724 = extractvalue %dx.types.ResRet.f32 %6723, 0
  %6725 = extractvalue %dx.types.ResRet.f32 %6723, 1
  %6726 = extractvalue %dx.types.ResRet.f32 %6723, 2
  %6727 = and i32 %6674, 4
  %6728 = icmp ne i32 %6727, 0
  %6729 = and i1 %6606, %6728
  br i1 %6729, label %6730, label %6748

; <label>:6730                                    ; preds = %6684
  %6731 = lshr i32 %6674, 5
  %6732 = and i32 %6731, 511
  %6733 = mul nuw nsw i32 %6732, 3
  %6734 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %6733, i32 0)  ; BufferLoad(srv,index,wot)
  %6735 = extractvalue %dx.types.ResRet.f32 %6734, 0
  %6736 = extractvalue %dx.types.ResRet.f32 %6734, 1
  %6737 = extractvalue %dx.types.ResRet.f32 %6734, 2
  %6738 = extractvalue %dx.types.ResRet.f32 %6734, 3
  %6739 = add nuw nsw i32 %6733, 1
  %6740 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %6739, i32 0)  ; BufferLoad(srv,index,wot)
  %6741 = extractvalue %dx.types.ResRet.f32 %6740, 0
  %6742 = extractvalue %dx.types.ResRet.f32 %6740, 1
  %6743 = extractvalue %dx.types.ResRet.f32 %6740, 2
  %6744 = extractvalue %dx.types.ResRet.f32 %6740, 3
  %6745 = add nuw nsw i32 %6733, 2
  %6746 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %6745, i32 0)  ; BufferLoad(srv,index,wot)
  %6747 = extractvalue %dx.types.ResRet.f32 %6746, 0
  br label %6748

; <label>:6748                                    ; preds = %6730, %6684
  %6749 = phi float [ %6747, %6730 ], [ 0.000000e+00, %6684 ]
  %6750 = phi float [ %6741, %6730 ], [ 0.000000e+00, %6684 ]
  %6751 = phi float [ %6742, %6730 ], [ 0.000000e+00, %6684 ]
  %6752 = phi float [ %6743, %6730 ], [ 0.000000e+00, %6684 ]
  %6753 = phi float [ %6744, %6730 ], [ 0.000000e+00, %6684 ]
  %6754 = phi float [ %6735, %6730 ], [ 0.000000e+00, %6684 ]
  %6755 = phi float [ %6736, %6730 ], [ 0.000000e+00, %6684 ]
  %6756 = phi float [ %6737, %6730 ], [ 0.000000e+00, %6684 ]
  %6757 = phi float [ %6738, %6730 ], [ 0.000000e+00, %6684 ]
  %6758 = lshr i32 %6674, 2
  %6759 = zext i1 %6729 to i32
  %6760 = and i32 %6759, %6758
  %6761 = icmp eq i32 %6760, 0
  %6762 = fsub fast float 1.000000e+00, %3283
  %6763 = call float @dx.op.unary.f32(i32 7, float %6762)  ; Saturate(value)
  %6764 = call float @dx.op.unary.f32(i32 24, float %6763)  ; Sqrt(value)
  %6765 = fadd fast float %6764, %3283
  %6766 = fmul fast float %6765, %6762
  %6767 = fsub fast float %6602, %2879
  %6768 = fsub fast float %6603, %2880
  %6769 = fsub fast float %6604, %2881
  %6770 = fmul fast float %6766, %6767
  %6771 = fmul fast float %6766, %6768
  %6772 = fmul fast float %6766, %6769
  %6773 = fadd fast float %6770, %2879
  %6774 = fadd fast float %6771, %2880
  %6775 = fadd fast float %6772, %2881
  %6776 = fmul fast float %6690, %565
  %6777 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6693, float %6776)  ; FMad(a,b,c)
  %6778 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6698, float %6777)  ; FMad(a,b,c)
  %6779 = fadd fast float %6778, %6703
  %6780 = fmul fast float %6691, %565
  %6781 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6696, float %6780)  ; FMad(a,b,c)
  %6782 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6699, float %6781)  ; FMad(a,b,c)
  %6783 = fadd fast float %6782, %6704
  %6784 = fmul fast float %6692, %565
  %6785 = call float @dx.op.tertiary.f32(i32 46, float %566, float %6697, float %6784)  ; FMad(a,b,c)
  %6786 = call float @dx.op.tertiary.f32(i32 46, float %567, float %6702, float %6785)  ; FMad(a,b,c)
  %6787 = fadd fast float %6786, %6705
  %6788 = fmul fast float %6773, %6690
  %6789 = call float @dx.op.tertiary.f32(i32 46, float %6774, float %6693, float %6788)  ; FMad(a,b,c)
  %6790 = call float @dx.op.tertiary.f32(i32 46, float %6775, float %6698, float %6789)  ; FMad(a,b,c)
  %6791 = fmul fast float %6773, %6691
  %6792 = call float @dx.op.tertiary.f32(i32 46, float %6774, float %6696, float %6791)  ; FMad(a,b,c)
  %6793 = call float @dx.op.tertiary.f32(i32 46, float %6775, float %6699, float %6792)  ; FMad(a,b,c)
  %6794 = fmul fast float %6773, %6692
  %6795 = call float @dx.op.tertiary.f32(i32 46, float %6774, float %6697, float %6794)  ; FMad(a,b,c)
  %6796 = call float @dx.op.tertiary.f32(i32 46, float %6775, float %6702, float %6795)  ; FMad(a,b,c)
  %6797 = and i32 %6674, 1
  %6798 = icmp eq i32 %6797, 0
  br i1 %6798, label %6822, label %6799

; <label>:6799                                    ; preds = %6748
  %6800 = fsub fast float -0.000000e+00, %6724
  %6801 = fsub fast float -0.000000e+00, %6725
  %6802 = fsub fast float -0.000000e+00, %6726
  %6803 = fdiv fast float 1.000000e+00, %6790
  %6804 = fdiv fast float 1.000000e+00, %6793
  %6805 = fdiv fast float 1.000000e+00, %6796
  %6806 = fcmp fast ogt float %6790, 0.000000e+00
  %6807 = fcmp fast ogt float %6793, 0.000000e+00
  %6808 = fcmp fast ogt float %6796, 0.000000e+00
  %6809 = select i1 %6806, float %6724, float %6800
  %6810 = fsub float %6809, %6779
  %6811 = fmul float %6810, %6803
  %6812 = select i1 %6807, float %6725, float %6801
  %6813 = fsub float %6812, %6783
  %6814 = fmul float %6813, %6804
  %6815 = select i1 %6808, float %6726, float %6802
  %6816 = fsub float %6815, %6787
  %6817 = fmul float %6816, %6805
  %6818 = call float @dx.op.binary.f32(i32 36, float %6811, float %6814)  ; FMin(a,b)
  %6819 = call float @dx.op.binary.f32(i32 36, float %6818, float %6817)  ; FMin(a,b)
  %6820 = fcmp fast oge float %6819, 0.000000e+00
  %6821 = zext i1 %6820 to i32
  br label %6822

; <label>:6822                                    ; preds = %6799, %6748
  %6823 = phi float [ %6819, %6799 ], [ 1.000000e+00, %6748 ]
  %6824 = phi i32 [ %6821, %6799 ], [ 1, %6748 ]
  %6825 = icmp eq i32 %6824, 0
  br i1 %6825, label %6989, label %6826

; <label>:6826                                    ; preds = %6822
  %6827 = fmul fast float %6823, %6790
  %6828 = fmul fast float %6823, %6793
  %6829 = fmul fast float %6823, %6796
  %6830 = fsub fast float %6779, %6708
  %6831 = fadd fast float %6827, %6830
  %6832 = fsub fast float %6783, %6709
  %6833 = fadd fast float %6828, %6832
  %6834 = fsub fast float %6787, %6710
  %6835 = fadd fast float %6829, %6834
  %6836 = fmul fast float %6831, %6831
  %6837 = fmul fast float %6833, %6833
  %6838 = fadd fast float %6836, %6837
  %6839 = fmul fast float %6835, %6835
  %6840 = fadd fast float %6838, %6839
  %6841 = call float @dx.op.unary.f32(i32 24, float %6840)  ; Sqrt(value)
  br i1 %6798, label %6848, label %6842

; <label>:6842                                    ; preds = %6826
  %6843 = call float @dx.op.unary.f32(i32 7, float %3283)  ; Saturate(value)
  %6844 = fmul fast float %6843, 2.000000e+00
  %6845 = fsub fast float 3.000000e+00, %6844
  %6846 = fmul fast float %6843, %6843
  %6847 = fmul fast float %6846, %6845
  br label %6848

; <label>:6848                                    ; preds = %6842, %6826
  %6849 = phi float [ %6847, %6842 ], [ 1.000000e+00, %6826 ]
  %6850 = fmul fast float %3282, 2.000000e+00
  %6851 = call float @dx.op.unary.f32(i32 7, float %6850)  ; Saturate(value)
  %6852 = fsub fast float 1.000000e+00, %6851
  %6853 = fmul fast float %6852, %2882
  %6854 = fadd fast float %6853, %6851
  %6855 = fmul fast float %6854, %3283
  %6856 = fmul fast float %6855, %6823
  %6857 = fdiv fast float %6856, %6841
  %6858 = fsub fast float %6855, %6857
  %6859 = fmul fast float %6858, %6849
  %6860 = fadd fast float %6859, %6857
  %6861 = fsub fast float %6790, %6831
  %6862 = fsub fast float %6793, %6833
  %6863 = fsub fast float %6796, %6835
  %6864 = fmul fast float %6849, %6861
  %6865 = fmul fast float %6849, %6862
  %6866 = fmul fast float %6849, %6863
  %6867 = fadd fast float %6864, %6831
  %6868 = fadd fast float %6865, %6833
  %6869 = fadd fast float %6866, %6835
  %6870 = lshr i32 %6674, 5
  %6871 = and i32 %6870, 511
  %6872 = uitofp i32 %6871 to float
  %6873 = fmul fast float %6860, %6590
  %6874 = fadd fast float %6873, 1.000000e+00
  %6875 = call float @dx.op.unary.f32(i32 23, float %6874)  ; Log(value)
  %6876 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %31, %dx.types.Handle %39, float %6867, float %6868, float %6869, float %6872, i32 undef, i32 undef, i32 undef, float %6875)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %6877 = extractvalue %dx.types.ResRet.f32 %6876, 0
  %6878 = extractvalue %dx.types.ResRet.f32 %6876, 1
  %6879 = extractvalue %dx.types.ResRet.f32 %6876, 2
  %6880 = extractvalue %dx.types.ResRet.f32 %6876, 3
  %6881 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %26, %dx.types.Handle %39, float %6867, float %6868, float %6869, float %6872, i32 undef, i32 undef, i32 undef, float %6875)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %6882 = extractvalue %dx.types.ResRet.f32 %6881, 0
  %6883 = call float @dx.op.binary.f32(i32 36, float %6880, float %6882)  ; FMin(a,b)
  %6884 = fmul fast float %6592, %3290
  %6885 = fmul fast float %6877, %6884
  %6886 = fmul fast float %6878, %6884
  %6887 = fmul fast float %6879, %6884
  br i1 %6761, label %6938, label %6888

; <label>:6888                                    ; preds = %6848
  %6889 = and i32 %6674, 8
  %6890 = icmp ne i32 %6889, 0
  %6891 = call float @dx.op.dot3.f32(i32 55, float %6867, float %6868, float %6869, float %6867, float %6868, float %6869)  ; Dot3(ax,ay,az,bx,by,bz)
  %6892 = call float @dx.op.unary.f32(i32 25, float %6891)  ; Rsqrt(value)
  %6893 = fmul fast float %6892, %6867
  %6894 = fmul fast float %6892, %6868
  %6895 = fmul fast float %6892, %6869
  %6896 = fmul fast float %6894, 0xBFF05F8CE0000000
  %6897 = fmul fast float %6895, 0x3FF05F8CE0000000
  %6898 = fmul fast float %6893, 0xBFF05F8CE0000000
  %6899 = fmul fast float %6893, 0x3FEB756F20000000
  %6900 = fmul fast float %6899, %6894
  %6901 = fmul fast float %6895, 0xBFEB756F20000000
  %6902 = fmul fast float %6901, %6894
  %6903 = fmul fast float %6895, %6895
  %6904 = fmul fast float %6903, 0x3FE7C7ADC0000000
  %6905 = fadd fast float %6904, 0xBFCFB4E7C0000000
  %6906 = fmul fast float %6901, %6893
  %6907 = fmul fast float %6893, %6893
  %6908 = fmul fast float %6894, %6894
  %6909 = fsub fast float %6907, %6908
  %6910 = fmul fast float %6754, 0x3FEC5BF9E0000000
  %6911 = fmul fast float %6896, %6755
  %6912 = fadd fast float %6911, %6910
  %6913 = fmul fast float %6897, %6756
  %6914 = fadd fast float %6912, %6913
  %6915 = fmul fast float %6898, %6757
  %6916 = fadd fast float %6914, %6915
  %6917 = fmul fast float %6900, %6750
  %6918 = fadd fast float %6916, %6917
  %6919 = fmul fast float %6902, %6751
  %6920 = fadd fast float %6918, %6919
  %6921 = fmul fast float %6905, %6752
  %6922 = fmul fast float %6906, %6753
  %6923 = fmul fast float %6749, 0x3FDB756F20000000
  %6924 = fmul fast float %6923, %6909
  %6925 = fadd fast float %6920, %6922
  %6926 = fadd fast float %6925, %6924
  %6927 = fadd fast float %6926, %6921
  %6928 = fmul fast float %6927, 0x3FD45F3060000000
  %6929 = call float @dx.op.dot3.f32(i32 55, float %2797, float %2836, float %2875, float 0x3FCB38DDA0000000, float 0x3FE6E286E0000000, float 0x3FB27A0FA0000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6930 = call float @dx.op.binary.f32(i32 35, float %6928, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %6931 = fdiv fast float %6929, %6930
  %6932 = select i1 %6890, float 6.550400e+04, float 1.000000e+00
  %6933 = call float @dx.op.binary.f32(i32 35, float %6931, float 0.000000e+00)  ; FMax(a,b)
  %6934 = call float @dx.op.binary.f32(i32 36, float %6933, float %6932)  ; FMin(a,b)
  %6935 = fmul fast float %6934, %6885
  %6936 = fmul fast float %6934, %6886
  %6937 = fmul fast float %6934, %6887
  br label %6938

; <label>:6938                                    ; preds = %6888, %6848
  %6939 = phi float [ %6935, %6888 ], [ %6885, %6848 ]
  %6940 = phi float [ %6936, %6888 ], [ %6886, %6848 ]
  %6941 = phi float [ %6937, %6888 ], [ %6887, %6848 ]
  %6942 = fsub fast float -0.000000e+00, %6716
  %6943 = fsub fast float -0.000000e+00, %6717
  %6944 = fsub fast float -0.000000e+00, %6718
  %6945 = fsub fast float %6942, %6779
  %6946 = fsub fast float %6943, %6783
  %6947 = fsub fast float %6944, %6787
  %6948 = fmul fast float %6945, %6945
  %6949 = fmul fast float %6946, %6946
  %6950 = fmul fast float %6947, %6947
  %6951 = fcmp fast olt float %6779, %6942
  %6952 = fcmp fast olt float %6783, %6943
  %6953 = fcmp fast olt float %6787, %6944
  %6954 = select i1 %6951, float %6948, float 0.000000e+00
  %6955 = select i1 %6952, float %6949, float 0.000000e+00
  %6956 = select i1 %6953, float %6950, float 0.000000e+00
  %6957 = fsub fast float %6779, %6716
  %6958 = fsub fast float %6783, %6717
  %6959 = fsub fast float %6787, %6718
  %6960 = fmul fast float %6957, %6957
  %6961 = fmul fast float %6958, %6958
  %6962 = fmul fast float %6959, %6959
  %6963 = fcmp fast ogt float %6779, %6716
  %6964 = fcmp fast ogt float %6783, %6717
  %6965 = fcmp fast ogt float %6787, %6718
  %6966 = select i1 %6963, float %6960, float 0.000000e+00
  %6967 = select i1 %6964, float %6961, float 0.000000e+00
  %6968 = select i1 %6965, float %6962, float 0.000000e+00
  %6969 = call float @dx.op.dot3.f32(i32 55, float %6954, float %6955, float %6956, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot3(ax,ay,az,bx,by,bz)
  %6970 = call float @dx.op.dot3.f32(i32 55, float %6966, float %6967, float %6968, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot3(ax,ay,az,bx,by,bz)
  %6971 = fadd fast float %6970, %6969
  %6972 = call float @dx.op.unary.f32(i32 24, float %6971)  ; Sqrt(value)
  %6973 = fmul fast float %6972, %6713
  %6974 = call float @dx.op.unary.f32(i32 7, float %6973)  ; Saturate(value)
  %6975 = fsub fast float 1.000000e+00, %6974
  %6976 = fmul fast float %6975, 2.000000e+00
  %6977 = fsub fast float 3.000000e+00, %6976
  %6978 = fmul fast float %6975, %6975
  %6979 = fmul fast float %6978, %6721
  %6980 = fmul fast float %6979, %6977
  %6981 = fmul fast float %6980, %6664
  %6982 = fmul fast float %6981, %6939
  %6983 = fmul fast float %6981, %6940
  %6984 = fmul fast float %6981, %6941
  %6985 = fmul fast float %6980, %6883
  %6986 = fsub fast float 1.000000e+00, %6985
  %6987 = call float @dx.op.unary.f32(i32 7, float %6986)  ; Saturate(value)
  %6988 = fmul fast float %6987, %6664
  br label %6989

; <label>:6989                                    ; preds = %6938, %6822
  %6990 = phi float [ %6988, %6938 ], [ %6664, %6822 ]
  %6991 = phi float [ %6982, %6938 ], [ 0.000000e+00, %6822 ]
  %6992 = phi float [ %6983, %6938 ], [ 0.000000e+00, %6822 ]
  %6993 = phi float [ %6984, %6938 ], [ 0.000000e+00, %6822 ]
  %6994 = fadd fast float %6991, %6661
  %6995 = fadd fast float %6992, %6662
  %6996 = fadd fast float %6993, %6663
  br label %7285

; <label>:6997                                    ; preds = %6682
  %6998 = mul i32 %6670, 44
  %6999 = add i32 %6998, %3338
  %7000 = shl i32 %6999, 2
  %7001 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7000, i32 undef)  ; BufferLoad(srv,index,wot)
  %7002 = extractvalue %dx.types.ResRet.f32 %7001, 0
  %7003 = extractvalue %dx.types.ResRet.f32 %7001, 1
  %7004 = extractvalue %dx.types.ResRet.f32 %7001, 2
  %7005 = add i32 %7000, 16
  %7006 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7005, i32 undef)  ; BufferLoad(srv,index,wot)
  %7007 = extractvalue %dx.types.ResRet.f32 %7006, 0
  %7008 = extractvalue %dx.types.ResRet.f32 %7006, 1
  %7009 = extractvalue %dx.types.ResRet.f32 %7006, 2
  %7010 = extractvalue %dx.types.ResRet.f32 %7006, 3
  %7011 = add i32 %7000, 32
  %7012 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7011, i32 undef)  ; BufferLoad(srv,index,wot)
  %7013 = extractvalue %dx.types.ResRet.f32 %7012, 0
  %7014 = extractvalue %dx.types.ResRet.f32 %7012, 1
  %7015 = extractvalue %dx.types.ResRet.f32 %7012, 2
  %7016 = extractvalue %dx.types.ResRet.f32 %7012, 3
  %7017 = add i32 %7000, 48
  %7018 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7017, i32 undef)  ; BufferLoad(srv,index,wot)
  %7019 = extractvalue %dx.types.ResRet.f32 %7018, 0
  %7020 = extractvalue %dx.types.ResRet.f32 %7018, 1
  %7021 = extractvalue %dx.types.ResRet.f32 %7018, 2
  %7022 = extractvalue %dx.types.ResRet.f32 %7018, 3
  %7023 = add i32 %7000, 64
  %7024 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7023, i32 undef)  ; BufferLoad(srv,index,wot)
  %7025 = extractvalue %dx.types.ResRet.f32 %7024, 0
  %7026 = add i32 %7000, 68
  %7027 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7026, i32 undef)  ; BufferLoad(srv,index,wot)
  %7028 = extractvalue %dx.types.ResRet.f32 %7027, 0
  %7029 = add i32 %7000, 72
  %7030 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7029, i32 undef)  ; BufferLoad(srv,index,wot)
  %7031 = extractvalue %dx.types.ResRet.f32 %7030, 0
  %7032 = add i32 %7000, 80
  %7033 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7032, i32 undef)  ; BufferLoad(srv,index,wot)
  %7034 = extractvalue %dx.types.ResRet.f32 %7033, 0
  %7035 = extractvalue %dx.types.ResRet.f32 %7033, 1
  %7036 = extractvalue %dx.types.ResRet.f32 %7033, 2
  %7037 = add i32 %7000, 92
  %7038 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %34, i32 %7037, i32 undef)  ; BufferLoad(srv,index,wot)
  %7039 = extractvalue %dx.types.ResRet.f32 %7038, 0
  %7040 = and i32 %6674, 4
  %7041 = icmp ne i32 %7040, 0
  %7042 = and i1 %6606, %7041
  br i1 %7042, label %7043, label %7061

; <label>:7043                                    ; preds = %6997
  %7044 = lshr i32 %6674, 5
  %7045 = and i32 %7044, 511
  %7046 = mul nuw nsw i32 %7045, 3
  %7047 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %7046, i32 0)  ; BufferLoad(srv,index,wot)
  %7048 = extractvalue %dx.types.ResRet.f32 %7047, 0
  %7049 = extractvalue %dx.types.ResRet.f32 %7047, 1
  %7050 = extractvalue %dx.types.ResRet.f32 %7047, 2
  %7051 = extractvalue %dx.types.ResRet.f32 %7047, 3
  %7052 = add nuw nsw i32 %7046, 1
  %7053 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %7052, i32 0)  ; BufferLoad(srv,index,wot)
  %7054 = extractvalue %dx.types.ResRet.f32 %7053, 0
  %7055 = extractvalue %dx.types.ResRet.f32 %7053, 1
  %7056 = extractvalue %dx.types.ResRet.f32 %7053, 2
  %7057 = extractvalue %dx.types.ResRet.f32 %7053, 3
  %7058 = add nuw nsw i32 %7046, 2
  %7059 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %32, i32 %7058, i32 0)  ; BufferLoad(srv,index,wot)
  %7060 = extractvalue %dx.types.ResRet.f32 %7059, 0
  br label %7061

; <label>:7061                                    ; preds = %7043, %6997
  %7062 = phi float [ %7060, %7043 ], [ 0.000000e+00, %6997 ]
  %7063 = phi float [ %7054, %7043 ], [ 0.000000e+00, %6997 ]
  %7064 = phi float [ %7055, %7043 ], [ 0.000000e+00, %6997 ]
  %7065 = phi float [ %7056, %7043 ], [ 0.000000e+00, %6997 ]
  %7066 = phi float [ %7057, %7043 ], [ 0.000000e+00, %6997 ]
  %7067 = phi float [ %7048, %7043 ], [ 0.000000e+00, %6997 ]
  %7068 = phi float [ %7049, %7043 ], [ 0.000000e+00, %6997 ]
  %7069 = phi float [ %7050, %7043 ], [ 0.000000e+00, %6997 ]
  %7070 = phi float [ %7051, %7043 ], [ 0.000000e+00, %6997 ]
  %7071 = lshr i32 %6674, 2
  %7072 = zext i1 %7042 to i32
  %7073 = and i32 %7072, %7071
  %7074 = icmp eq i32 %7073, 0
  %7075 = fsub fast float 1.000000e+00, %3283
  %7076 = call float @dx.op.unary.f32(i32 7, float %7075)  ; Saturate(value)
  %7077 = call float @dx.op.unary.f32(i32 24, float %7076)  ; Sqrt(value)
  %7078 = fadd fast float %7077, %3283
  %7079 = fmul fast float %7078, %7075
  %7080 = fsub fast float %6602, %2879
  %7081 = fsub fast float %6603, %2880
  %7082 = fsub fast float %6604, %2881
  %7083 = fmul fast float %7079, %7080
  %7084 = fmul fast float %7079, %7081
  %7085 = fmul fast float %7079, %7082
  %7086 = fadd fast float %7083, %2879
  %7087 = fadd fast float %7084, %2880
  %7088 = fadd fast float %7085, %2881
  %7089 = fadd fast float %7031, %7025
  %7090 = and i32 %6674, 1
  %7091 = icmp eq i32 %7090, 0
  br i1 %7091, label %7111, label %7092

; <label>:7092                                    ; preds = %7061
  %7093 = fsub fast float %565, %7002
  %7094 = fsub fast float %566, %7003
  %7095 = fsub fast float %567, %7004
  %7096 = call float @dx.op.dot3.f32(i32 55, float %7086, float %7087, float %7088, float %7093, float %7094, float %7095)  ; Dot3(ax,ay,az,bx,by,bz)
  %7097 = fmul fast float %7096, 2.000000e+00
  %7098 = call float @dx.op.dot3.f32(i32 55, float %7093, float %7094, float %7095, float %7093, float %7094, float %7095)  ; Dot3(ax,ay,az,bx,by,bz)
  %7099 = fmul fast float %7089, %7089
  %7100 = fsub fast float %7098, %7099
  %7101 = fmul fast float %7097, %7097
  %7102 = fmul fast float %7100, 4.000000e+00
  %7103 = fsub fast float %7101, %7102
  %7104 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7103)  ; FMax(a,b)
  %7105 = call float @dx.op.unary.f32(i32 24, float %7104)  ; Sqrt(value)
  %7106 = fsub fast float %7105, %7097
  %7107 = call float @dx.op.unary.f32(i32 6, float %7106)  ; FAbs(value)
  %7108 = fmul fast float %7107, 5.000000e-01
  %7109 = fcmp fast oge float %7108, 0.000000e+00
  %7110 = zext i1 %7109 to i32
  br label %7111

; <label>:7111                                    ; preds = %7092, %7061
  %7112 = phi float [ %7108, %7092 ], [ 1.000000e+00, %7061 ]
  %7113 = phi i32 [ %7110, %7092 ], [ 1, %7061 ]
  %7114 = icmp eq i32 %7113, 0
  br i1 %7114, label %7277, label %7115

; <label>:7115                                    ; preds = %7111
  %7116 = fmul fast float %7007, %565
  %7117 = call float @dx.op.tertiary.f32(i32 46, float %566, float %7010, float %7116)  ; FMad(a,b,c)
  %7118 = call float @dx.op.tertiary.f32(i32 46, float %567, float %7015, float %7117)  ; FMad(a,b,c)
  %7119 = fmul fast float %7008, %565
  %7120 = call float @dx.op.tertiary.f32(i32 46, float %566, float %7013, float %7119)  ; FMad(a,b,c)
  %7121 = call float @dx.op.tertiary.f32(i32 46, float %567, float %7016, float %7120)  ; FMad(a,b,c)
  %7122 = fmul fast float %7009, %565
  %7123 = call float @dx.op.tertiary.f32(i32 46, float %566, float %7014, float %7122)  ; FMad(a,b,c)
  %7124 = call float @dx.op.tertiary.f32(i32 46, float %567, float %7019, float %7123)  ; FMad(a,b,c)
  %7125 = fmul fast float %7086, %7007
  %7126 = call float @dx.op.tertiary.f32(i32 46, float %7087, float %7010, float %7125)  ; FMad(a,b,c)
  %7127 = call float @dx.op.tertiary.f32(i32 46, float %7088, float %7015, float %7126)  ; FMad(a,b,c)
  %7128 = fmul fast float %7086, %7008
  %7129 = call float @dx.op.tertiary.f32(i32 46, float %7087, float %7013, float %7128)  ; FMad(a,b,c)
  %7130 = call float @dx.op.tertiary.f32(i32 46, float %7088, float %7016, float %7129)  ; FMad(a,b,c)
  %7131 = fmul fast float %7086, %7009
  %7132 = call float @dx.op.tertiary.f32(i32 46, float %7087, float %7014, float %7131)  ; FMad(a,b,c)
  %7133 = call float @dx.op.tertiary.f32(i32 46, float %7088, float %7019, float %7132)  ; FMad(a,b,c)
  %7134 = fmul fast float %7127, %7112
  %7135 = fmul fast float %7130, %7112
  %7136 = fmul fast float %7133, %7112
  %7137 = fsub fast float %7020, %7034
  %7138 = fadd fast float %7137, %7118
  %7139 = fadd fast float %7138, %7134
  %7140 = fsub fast float %7021, %7035
  %7141 = fadd fast float %7140, %7121
  %7142 = fadd fast float %7141, %7135
  %7143 = fsub fast float %7022, %7036
  %7144 = fadd fast float %7143, %7124
  %7145 = fadd fast float %7144, %7136
  %7146 = fmul fast float %7139, %7139
  %7147 = fmul fast float %7142, %7142
  %7148 = fadd fast float %7147, %7146
  %7149 = fmul fast float %7145, %7145
  %7150 = fadd fast float %7148, %7149
  %7151 = call float @dx.op.unary.f32(i32 24, float %7150)  ; Sqrt(value)
  br i1 %7091, label %7158, label %7152

; <label>:7152                                    ; preds = %7115
  %7153 = call float @dx.op.unary.f32(i32 7, float %3283)  ; Saturate(value)
  %7154 = fmul fast float %7153, 2.000000e+00
  %7155 = fsub fast float 3.000000e+00, %7154
  %7156 = fmul fast float %7153, %7153
  %7157 = fmul fast float %7156, %7155
  br label %7158

; <label>:7158                                    ; preds = %7152, %7115
  %7159 = phi float [ %7157, %7152 ], [ 1.000000e+00, %7115 ]
  %7160 = fmul fast float %3282, 2.000000e+00
  %7161 = call float @dx.op.unary.f32(i32 7, float %7160)  ; Saturate(value)
  %7162 = fsub fast float 1.000000e+00, %7161
  %7163 = fmul fast float %7162, %2882
  %7164 = fadd fast float %7163, %7161
  %7165 = fmul fast float %7164, %3283
  %7166 = fmul fast float %7165, %7112
  %7167 = fdiv fast float %7166, %7151
  %7168 = fsub fast float %7165, %7167
  %7169 = fmul fast float %7168, %7159
  %7170 = fadd fast float %7169, %7167
  %7171 = fsub fast float %7127, %7139
  %7172 = fsub fast float %7130, %7142
  %7173 = fsub fast float %7133, %7145
  %7174 = fmul fast float %7159, %7171
  %7175 = fmul fast float %7159, %7172
  %7176 = fmul fast float %7159, %7173
  %7177 = fadd fast float %7174, %7139
  %7178 = fadd fast float %7175, %7142
  %7179 = fadd fast float %7176, %7145
  %7180 = lshr i32 %6674, 5
  %7181 = and i32 %7180, 511
  %7182 = uitofp i32 %7181 to float
  %7183 = fmul fast float %7170, %6590
  %7184 = fadd fast float %7183, 1.000000e+00
  %7185 = call float @dx.op.unary.f32(i32 23, float %7184)  ; Log(value)
  %7186 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %31, %dx.types.Handle %39, float %7177, float %7178, float %7179, float %7182, i32 undef, i32 undef, i32 undef, float %7185)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %7187 = extractvalue %dx.types.ResRet.f32 %7186, 0
  %7188 = extractvalue %dx.types.ResRet.f32 %7186, 1
  %7189 = extractvalue %dx.types.ResRet.f32 %7186, 2
  %7190 = extractvalue %dx.types.ResRet.f32 %7186, 3
  %7191 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %26, %dx.types.Handle %39, float %7177, float %7178, float %7179, float %7182, i32 undef, i32 undef, i32 undef, float %7185)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %7192 = extractvalue %dx.types.ResRet.f32 %7191, 0
  %7193 = call float @dx.op.binary.f32(i32 36, float %7190, float %7192)  ; FMin(a,b)
  %7194 = fmul fast float %6592, %3290
  %7195 = fmul fast float %7187, %7194
  %7196 = fmul fast float %7188, %7194
  %7197 = fmul fast float %7189, %7194
  br i1 %7074, label %7248, label %7198

; <label>:7198                                    ; preds = %7158
  %7199 = and i32 %6674, 8
  %7200 = icmp ne i32 %7199, 0
  %7201 = call float @dx.op.dot3.f32(i32 55, float %7177, float %7178, float %7179, float %7177, float %7178, float %7179)  ; Dot3(ax,ay,az,bx,by,bz)
  %7202 = call float @dx.op.unary.f32(i32 25, float %7201)  ; Rsqrt(value)
  %7203 = fmul fast float %7202, %7177
  %7204 = fmul fast float %7202, %7178
  %7205 = fmul fast float %7202, %7179
  %7206 = fmul fast float %7204, 0xBFF05F8CE0000000
  %7207 = fmul fast float %7205, 0x3FF05F8CE0000000
  %7208 = fmul fast float %7203, 0xBFF05F8CE0000000
  %7209 = fmul fast float %7203, 0x3FEB756F20000000
  %7210 = fmul fast float %7209, %7204
  %7211 = fmul fast float %7205, 0xBFEB756F20000000
  %7212 = fmul fast float %7211, %7204
  %7213 = fmul fast float %7205, %7205
  %7214 = fmul fast float %7213, 0x3FE7C7ADC0000000
  %7215 = fadd fast float %7214, 0xBFCFB4E7C0000000
  %7216 = fmul fast float %7211, %7203
  %7217 = fmul fast float %7203, %7203
  %7218 = fmul fast float %7204, %7204
  %7219 = fsub fast float %7217, %7218
  %7220 = fmul fast float %7067, 0x3FEC5BF9E0000000
  %7221 = fmul fast float %7206, %7068
  %7222 = fadd fast float %7221, %7220
  %7223 = fmul fast float %7207, %7069
  %7224 = fadd fast float %7222, %7223
  %7225 = fmul fast float %7208, %7070
  %7226 = fadd fast float %7224, %7225
  %7227 = fmul fast float %7210, %7063
  %7228 = fadd fast float %7226, %7227
  %7229 = fmul fast float %7212, %7064
  %7230 = fadd fast float %7228, %7229
  %7231 = fmul fast float %7215, %7065
  %7232 = fmul fast float %7216, %7066
  %7233 = fmul fast float %7062, 0x3FDB756F20000000
  %7234 = fmul fast float %7233, %7219
  %7235 = fadd fast float %7230, %7232
  %7236 = fadd fast float %7235, %7234
  %7237 = fadd fast float %7236, %7231
  %7238 = fmul fast float %7237, 0x3FD45F3060000000
  %7239 = call float @dx.op.dot3.f32(i32 55, float %2797, float %2836, float %2875, float 0x3FCB38DDA0000000, float 0x3FE6E286E0000000, float 0x3FB27A0FA0000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7240 = call float @dx.op.binary.f32(i32 35, float %7238, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %7241 = fdiv fast float %7239, %7240
  %7242 = select i1 %7200, float 6.550400e+04, float 1.000000e+00
  %7243 = call float @dx.op.binary.f32(i32 35, float %7241, float 0.000000e+00)  ; FMax(a,b)
  %7244 = call float @dx.op.binary.f32(i32 36, float %7243, float %7242)  ; FMin(a,b)
  %7245 = fmul fast float %7244, %7195
  %7246 = fmul fast float %7244, %7196
  %7247 = fmul fast float %7244, %7197
  br label %7248

; <label>:7248                                    ; preds = %7198, %7158
  %7249 = phi float [ %7245, %7198 ], [ %7195, %7158 ]
  %7250 = phi float [ %7246, %7198 ], [ %7196, %7158 ]
  %7251 = phi float [ %7247, %7198 ], [ %7197, %7158 ]
  %7252 = fsub fast float %565, %7002
  %7253 = fsub fast float %566, %7003
  %7254 = fsub fast float %567, %7004
  %7255 = fmul fast float %7252, %7252
  %7256 = fmul fast float %7253, %7253
  %7257 = fadd fast float %7255, %7256
  %7258 = fmul fast float %7254, %7254
  %7259 = fadd fast float %7257, %7258
  %7260 = call float @dx.op.unary.f32(i32 24, float %7259)  ; Sqrt(value)
  %7261 = fsub fast float %7089, %7260
  %7262 = fmul fast float %7261, %7028
  %7263 = call float @dx.op.unary.f32(i32 7, float %7262)  ; Saturate(value)
  %7264 = fmul fast float %7263, 2.000000e+00
  %7265 = fsub fast float 3.000000e+00, %7264
  %7266 = fmul fast float %7263, %7263
  %7267 = fmul fast float %7266, %7039
  %7268 = fmul fast float %7267, %7265
  %7269 = fmul fast float %7268, %6664
  %7270 = fmul fast float %7269, %7249
  %7271 = fmul fast float %7269, %7250
  %7272 = fmul fast float %7269, %7251
  %7273 = fmul fast float %7268, %7193
  %7274 = fsub fast float 1.000000e+00, %7273
  %7275 = call float @dx.op.unary.f32(i32 7, float %7274)  ; Saturate(value)
  %7276 = fmul fast float %7275, %6664
  br label %7277

; <label>:7277                                    ; preds = %7248, %7111
  %7278 = phi float [ %7276, %7248 ], [ %6664, %7111 ]
  %7279 = phi float [ %7270, %7248 ], [ 0.000000e+00, %7111 ]
  %7280 = phi float [ %7271, %7248 ], [ 0.000000e+00, %7111 ]
  %7281 = phi float [ %7272, %7248 ], [ 0.000000e+00, %7111 ]
  %7282 = fadd fast float %7279, %6661
  %7283 = fadd fast float %7280, %6662
  %7284 = fadd fast float %7281, %6663
  br label %7285

; <label>:7285                                    ; preds = %7277, %6989, %6682
  %7286 = phi float [ %7282, %7277 ], [ %6994, %6989 ], [ %6661, %6682 ]
  %7287 = phi float [ %7283, %7277 ], [ %6995, %6989 ], [ %6662, %6682 ]
  %7288 = phi float [ %7284, %7277 ], [ %6996, %6989 ], [ %6663, %6682 ]
  %7289 = phi float [ %7278, %7277 ], [ %6990, %6989 ], [ %6664, %6682 ]
  %7290 = fcmp ugt float %7289, 0.000000e+00
  %7291 = icmp ne i32 %6665, %6668
  %7292 = and i1 %7291, %7290
  br i1 %7292, label %6660, label %7293

; <label>:7293                                    ; preds = %7285
  br label %7294

; <label>:7294                                    ; preds = %7293, %6655
  %7295 = phi float [ %6621, %6655 ], [ %7286, %7293 ]
  %7296 = phi float [ %6622, %6655 ], [ %7287, %7293 ]
  %7297 = phi float [ %6623, %6655 ], [ %7288, %7293 ]
  %7298 = phi float [ %6624, %6655 ], [ %7289, %7293 ]
  %7299 = add nuw nsw i32 %6625, 1
  %7300 = icmp eq i32 %6625, %6617
  br i1 %7300, label %7301, label %6620

; <label>:7301                                    ; preds = %7294
  br label %7302

; <label>:7302                                    ; preds = %7301, %6610, %6576
  %7303 = phi float [ 0.000000e+00, %6576 ], [ 0.000000e+00, %6610 ], [ %7295, %7301 ]
  %7304 = phi float [ 0.000000e+00, %6576 ], [ 0.000000e+00, %6610 ], [ %7296, %7301 ]
  %7305 = phi float [ 0.000000e+00, %6576 ], [ 0.000000e+00, %6610 ], [ %7297, %7301 ]
  %7306 = phi float [ 1.000000e+00, %6576 ], [ 1.000000e+00, %6610 ], [ %7298, %7301 ]
  %7307 = and i32 %2884, 10
  %7308 = icmp eq i32 %7307, 10
  br i1 %7308, label %7309, label %7324

; <label>:7309                                    ; preds = %7302
  %7310 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %28, i32 0, i32 0)  ; BufferLoad(srv,index,wot)
  %7311 = extractvalue %dx.types.ResRet.f32 %7310, 0
  %7312 = extractvalue %dx.types.ResRet.f32 %7310, 1
  %7313 = extractvalue %dx.types.ResRet.f32 %7310, 2
  %7314 = extractvalue %dx.types.ResRet.f32 %7310, 3
  %7315 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %28, i32 1, i32 0)  ; BufferLoad(srv,index,wot)
  %7316 = extractvalue %dx.types.ResRet.f32 %7315, 0
  %7317 = extractvalue %dx.types.ResRet.f32 %7315, 1
  %7318 = extractvalue %dx.types.ResRet.f32 %7315, 2
  %7319 = extractvalue %dx.types.ResRet.f32 %7315, 3
  %7320 = call %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32 68, %dx.types.Handle %28, i32 2, i32 0)  ; BufferLoad(srv,index,wot)
  %7321 = extractvalue %dx.types.ResRet.f32 %7320, 0
  %7322 = fmul float %7311, 0x3FEC5BF9E0000000
  %7323 = fmul float %7321, 0x3FDB756F20000000
  br label %7324

; <label>:7324                                    ; preds = %7309, %7302
  %7325 = phi float [ %7323, %7309 ], [ 0.000000e+00, %7302 ]
  %7326 = phi float [ %7316, %7309 ], [ 0.000000e+00, %7302 ]
  %7327 = phi float [ %7317, %7309 ], [ 0.000000e+00, %7302 ]
  %7328 = phi float [ %7318, %7309 ], [ 0.000000e+00, %7302 ]
  %7329 = phi float [ %7319, %7309 ], [ 0.000000e+00, %7302 ]
  %7330 = phi float [ %7322, %7309 ], [ 0.000000e+00, %7302 ]
  %7331 = phi float [ %7312, %7309 ], [ 0.000000e+00, %7302 ]
  %7332 = phi float [ %7313, %7309 ], [ 0.000000e+00, %7302 ]
  %7333 = phi float [ %7314, %7309 ], [ 0.000000e+00, %7302 ]
  %7334 = fmul fast float %3282, 2.000000e+00
  %7335 = call float @dx.op.unary.f32(i32 7, float %7334)  ; Saturate(value)
  %7336 = fsub fast float 1.000000e+00, %7335
  %7337 = fmul fast float %7336, %2882
  %7338 = fadd fast float %7337, %7335
  %7339 = fsub fast float 1.000000e+00, %3283
  %7340 = call float @dx.op.unary.f32(i32 7, float %7339)  ; Saturate(value)
  %7341 = call float @dx.op.unary.f32(i32 24, float %7340)  ; Sqrt(value)
  %7342 = fadd fast float %7341, %3283
  %7343 = fmul fast float %7342, %7339
  %7344 = fsub fast float %6602, %2879
  %7345 = fsub fast float %6603, %2880
  %7346 = fsub fast float %6604, %2881
  %7347 = fmul fast float %7343, %7344
  %7348 = fmul fast float %7343, %7345
  %7349 = fmul fast float %7343, %7346
  %7350 = fadd fast float %7347, %2879
  %7351 = fadd fast float %7348, %2880
  %7352 = fadd fast float %7349, %2881
  %7353 = fmul fast float %6593, %3283
  %7354 = fmul fast float %7353, %7338
  %7355 = fadd fast float %7354, 1.000000e+00
  %7356 = call float @dx.op.unary.f32(i32 23, float %7355)  ; Log(value)
  %7357 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %25, %dx.types.Handle %39, float %7350, float %7351, float %7352, float 0.000000e+00, i32 undef, i32 undef, i32 undef, float %7356)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %7358 = extractvalue %dx.types.ResRet.f32 %7357, 0
  %7359 = extractvalue %dx.types.ResRet.f32 %7357, 1
  %7360 = extractvalue %dx.types.ResRet.f32 %7357, 2
  %7361 = fmul fast float %6592, %3290
  %7362 = fmul fast float %7358, %7361
  %7363 = fmul fast float %7359, %7361
  %7364 = fmul fast float %7360, %7361
  br i1 %6606, label %7365, label %7407

; <label>:7365                                    ; preds = %7324
  %7366 = call float @dx.op.dot3.f32(i32 55, float %7350, float %7351, float %7352, float %7350, float %7351, float %7352)  ; Dot3(ax,ay,az,bx,by,bz)
  %7367 = call float @dx.op.unary.f32(i32 25, float %7366)  ; Rsqrt(value)
  %7368 = fmul fast float %7367, %7350
  %7369 = fmul fast float %7367, %7351
  %7370 = fmul fast float %7367, %7352
  %7371 = fmul fast float %7370, %7370
  %7372 = fmul fast float %7371, 0x3FE7C7ADC0000000
  %7373 = fadd fast float %7372, 0xBFCFB4E7C0000000
  %7374 = fmul fast float %7368, %7368
  %7375 = fmul fast float %7369, %7369
  %7376 = fsub fast float %7374, %7375
  %7377 = fmul fast float %7369, %7331
  %7378 = fmul fast float %7370, %7332
  %7379 = fmul fast float %7368, %7333
  %7380 = fmul fast float %7368, %7326
  %7381 = fmul fast float %7370, %7327
  %7382 = fmul fast float %7373, %7328
  %7383 = fmul fast float %7368, %7329
  %7384 = fmul fast float %7383, %7370
  %7385 = fmul fast float %7376, %7325
  %7386 = fsub fast float %7380, %7381
  %7387 = fmul fast float %7386, %7369
  %7388 = fsub fast float %7387, %7384
  %7389 = fmul fast float %7388, 0x3FEB756F20000000
  %7390 = fsub fast float %7378, %7379
  %7391 = fsub fast float %7390, %7377
  %7392 = fmul fast float %7391, 0x3FF05F8CE0000000
  %7393 = fadd fast float %7385, %7330
  %7394 = fadd fast float %7393, %7382
  %7395 = fadd fast float %7394, %7392
  %7396 = fadd fast float %7395, %7389
  %7397 = fmul fast float %7396, 0x3FD45F3060000000
  %7398 = call float @dx.op.dot3.f32(i32 55, float %2797, float %2836, float %2875, float 0x3FCB38DDA0000000, float 0x3FE6E286E0000000, float 0x3FB27A0FA0000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7399 = call float @dx.op.binary.f32(i32 35, float %7397, float 0x3E7AD7F2A0000000)  ; FMax(a,b)
  %7400 = fdiv fast float %7398, %7399
  %7401 = select i1 %6608, float 6.550400e+04, float 1.000000e+00
  %7402 = call float @dx.op.binary.f32(i32 35, float %7400, float 0.000000e+00)  ; FMax(a,b)
  %7403 = call float @dx.op.binary.f32(i32 36, float %7402, float %7401)  ; FMin(a,b)
  %7404 = fmul fast float %7403, %7362
  %7405 = fmul fast float %7403, %7363
  %7406 = fmul fast float %7403, %7364
  br label %7407

; <label>:7407                                    ; preds = %7365, %7324
  %7408 = phi float [ %7404, %7365 ], [ %7362, %7324 ]
  %7409 = phi float [ %7405, %7365 ], [ %7363, %7324 ]
  %7410 = phi float [ %7406, %7365 ], [ %7364, %7324 ]
  %7411 = fmul fast float %7408, %7306
  %7412 = fmul fast float %7409, %7306
  %7413 = fmul fast float %7410, %7306
  %7414 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %88, float %89, float %90)  ; Dot3(ax,ay,az,bx,by,bz)
  %7415 = fsub fast float -0.000000e+00, %98
  %7416 = fcmp fast ule float %7414, %7415
  %7417 = fcmp fast ogt float %7414, %98
  %7418 = or i1 %7416, %7417
  br i1 %7418, label %7458, label %7419

; <label>:7419                                    ; preds = %7407
  %7420 = fmul fast float %7414, %7414
  %7421 = fsub fast float 1.000000e+00, %7420
  %7422 = call float @dx.op.unary.f32(i32 24, float %7421)  ; Sqrt(value)
  %7423 = fdiv fast float %7414, %7422
  %7424 = fmul fast float %7423, %101
  %7425 = fsub fast float -0.000000e+00, %7424
  %7426 = fmul fast float %7424, %7424
  %7427 = fsub fast float 1.000000e+00, %7426
  %7428 = call float @dx.op.unary.f32(i32 24, float %7427)  ; Sqrt(value)
  %7429 = fmul fast float %7428, %7422
  %7430 = call float @dx.op.unary.f32(i32 6, float %7425)  ; FAbs(value)
  %7431 = fmul fast float %7430, 0x3FC593EE60000000
  %7432 = fsub fast float 0x3FF9135FC0000000, %7431
  %7433 = fsub fast float 1.000000e+00, %7430
  %7434 = call float @dx.op.unary.f32(i32 24, float %7433)  ; Sqrt(value)
  %7435 = fmul fast float %7432, %7434
  %7436 = fsub fast float 0x400921FB60000000, %7435
  %7437 = fcmp ole float %7424, -0.000000e+00
  %7438 = select i1 %7437, float %7435, float %7436
  %7439 = fmul fast float %7438, %7414
  %7440 = fmul fast float %7429, %101
  %7441 = fsub fast float %7439, %7440
  %7442 = fmul fast float %7441, %100
  %7443 = fmul fast float %7429, %102
  %7444 = fdiv fast float 1.000000e+00, %7443
  %7445 = fcmp fast olt float %7443, 1.000000e+00
  %7446 = select i1 %7445, float %7443, float %7444
  %7447 = fmul fast float %7446, %7446
  %7448 = fmul fast float %7447, 0x3FB658D4A0000000
  %7449 = fadd fast float %7448, 0xBFD3523E80000000
  %7450 = fmul fast float %7449, %7447
  %7451 = fadd fast float %7450, 1.000000e+00
  %7452 = fmul fast float %7451, %7446
  %7453 = fsub fast float 0x3FF921FB60000000, %7452
  %7454 = select i1 %7445, float %7452, float %7453
  %7455 = fadd fast float %7454, %7442
  %7456 = fmul fast float %7455, 0x3FD45F3060000000
  %7457 = fdiv fast float %7456, %100
  br label %7458

; <label>:7458                                    ; preds = %7419, %7407
  %7459 = phi float [ %7457, %7419 ], [ %7414, %7407 ]
  %7460 = call float @dx.op.unary.f32(i32 7, float %7459)  ; Saturate(value)
  %7461 = call float @dx.op.dot3.f32(i32 55, float %88, float %89, float %90, float %6602, float %6603, float %6604)  ; Dot3(ax,ay,az,bx,by,bz)
  %7462 = fmul fast float %7461, %88
  %7463 = fmul fast float %7461, %89
  %7464 = fmul fast float %7461, %90
  %7465 = fsub fast float %6602, %7462
  %7466 = fsub fast float %6603, %7463
  %7467 = fsub fast float %6604, %7464
  %7468 = fcmp fast olt float %7461, %97
  br i1 %7468, label %7469, label %7487

; <label>:7469                                    ; preds = %7458
  %7470 = fmul fast float %97, %88
  %7471 = fmul fast float %97, %89
  %7472 = fmul fast float %97, %90
  %7473 = call float @dx.op.dot3.f32(i32 55, float %7465, float %7466, float %7467, float %7465, float %7466, float %7467)  ; Dot3(ax,ay,az,bx,by,bz)
  %7474 = call float @dx.op.unary.f32(i32 25, float %7473)  ; Rsqrt(value)
  %7475 = fmul fast float %7474, %98
  %7476 = fmul fast float %7475, %7465
  %7477 = fmul fast float %7475, %7466
  %7478 = fmul fast float %7475, %7467
  %7479 = fadd fast float %7476, %7470
  %7480 = fadd fast float %7477, %7471
  %7481 = fadd fast float %7478, %7472
  %7482 = call float @dx.op.dot3.f32(i32 55, float %7479, float %7480, float %7481, float %7479, float %7480, float %7481)  ; Dot3(ax,ay,az,bx,by,bz)
  %7483 = call float @dx.op.unary.f32(i32 25, float %7482)  ; Rsqrt(value)
  %7484 = fmul fast float %7479, %7483
  %7485 = fmul fast float %7480, %7483
  %7486 = fmul fast float %7481, %7483
  br label %7487

; <label>:7487                                    ; preds = %7469, %7458
  %7488 = phi float [ %7484, %7469 ], [ %6602, %7458 ]
  %7489 = phi float [ %7485, %7469 ], [ %6603, %7458 ]
  %7490 = phi float [ %7486, %7469 ], [ %6604, %7458 ]
  %7491 = fcmp fast ogt float %7460, 0.000000e+00
  br i1 %7491, label %7492, label %7599

; <label>:7492                                    ; preds = %7487
  %7493 = fmul fast float %3311, %3311
  %7494 = fadd fast float %7493, %103
  %7495 = call float @dx.op.unary.f32(i32 7, float %7494)  ; Saturate(value)
  %7496 = fdiv fast float %7493, %7495
  %7497 = fadd fast float %7488, %272
  %7498 = fadd fast float %7489, %273
  %7499 = fadd fast float %7490, %274
  %7500 = call float @dx.op.dot3.f32(i32 55, float %7497, float %7498, float %7499, float %7497, float %7498, float %7499)  ; Dot3(ax,ay,az,bx,by,bz)
  %7501 = call float @dx.op.unary.f32(i32 25, float %7500)  ; Rsqrt(value)
  %7502 = fmul fast float %7501, %7497
  %7503 = fmul fast float %7501, %7498
  %7504 = fmul fast float %7501, %7499
  %7505 = call float @dx.op.unary.f32(i32 6, float %3281)  ; FAbs(value)
  %7506 = call float @dx.op.binary.f32(i32 35, float %7505, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %7507 = call float @dx.op.unary.f32(i32 7, float %7506)  ; Saturate(value)
  %7508 = call float @dx.op.dot3.f32(i32 55, float %7488, float %7489, float %7490, float %7502, float %7503, float %7504)  ; Dot3(ax,ay,az,bx,by,bz)
  %7509 = call float @dx.op.unary.f32(i32 7, float %7508)  ; Saturate(value)
  %7510 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %7502, float %7503, float %7504)  ; Dot3(ax,ay,az,bx,by,bz)
  %7511 = call float @dx.op.unary.f32(i32 7, float %7510)  ; Saturate(value)
  %7512 = call float @dx.op.unary.f32(i32 6, float %7510)  ; FAbs(value)
  %7513 = call float @dx.op.binary.f32(i32 35, float %7512, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %7514 = call float @dx.op.unary.f32(i32 7, float %7513)  ; Saturate(value)
  %7515 = call float @dx.op.dot3.f32(i32 55, float %2879, float %2880, float %2881, float %7488, float %7489, float %7490)  ; Dot3(ax,ay,az,bx,by,bz)
  %7516 = call float @dx.op.unary.f32(i32 7, float %7515)  ; Saturate(value)
  %7517 = fsub fast float 1.000000e+00, %7509
  %7518 = fmul fast float %7517, %7517
  %7519 = fmul fast float %7518, %7518
  %7520 = fmul fast float %7519, %7517
  %7521 = fmul fast float %7520, 0x3FEEB851E0000000
  %7522 = fadd fast float %7521, 0x3FA47AE140000000
  %7523 = call float @dx.op.binary.f32(i32 35, float %7493, float 0x3F60624DE0000000)  ; FMax(a,b)
  %7524 = fmul fast float %7523, %7523
  %7525 = fmul fast float %7524, %7507
  %7526 = fsub fast float %7507, %7525
  %7527 = fmul fast float %7526, %7507
  %7528 = fadd fast float %7527, %7524
  %7529 = call float @dx.op.unary.f32(i32 24, float %7528)  ; Sqrt(value)
  %7530 = fmul fast float %7529, %7516
  %7531 = fmul fast float %7524, %7516
  %7532 = fsub fast float %7516, %7531
  %7533 = fmul fast float %7532, %7516
  %7534 = fadd fast float %7533, %7524
  %7535 = call float @dx.op.unary.f32(i32 24, float %7534)  ; Sqrt(value)
  %7536 = fmul fast float %7535, %7507
  %7537 = fadd fast float %7536, %7530
  %7538 = fdiv fast float 5.000000e-01, %7537
  %7539 = fmul fast float %7524, %7511
  %7540 = fsub fast float %7539, %7511
  %7541 = fmul fast float %7540, %7511
  %7542 = fadd fast float %7541, 1.000000e+00
  %7543 = fmul fast float %7542, %7542
  %7544 = fdiv fast float 1.000000e+00, %7543
  %7545 = fdiv fast float 2.000000e+00, %7524
  %7546 = fadd fast float %7545, -1.000000e+00
  %7547 = call float @dx.op.unary.f32(i32 23, float %7546)  ; Log(value)
  %7548 = fmul fast float %7547, 0x3FAC71C720000000
  %7549 = call float @dx.op.unary.f32(i32 7, float %7548)  ; Saturate(value)
  %7550 = fadd fast float %7520, %7509
  %7551 = fsub fast float 1.000000e+00, %7516
  %7552 = fmul fast float %7551, %7551
  %7553 = fmul fast float %7552, %7552
  %7554 = fmul fast float %7553, %7551
  %7555 = fsub fast float 1.000000e+00, %7554
  %7556 = fsub fast float 1.000000e+00, %7507
  %7557 = fmul fast float %7556, %7556
  %7558 = fmul fast float %7557, %7557
  %7559 = fmul fast float %7558, %7556
  %7560 = fsub fast float 1.000000e+00, %7559
  %7561 = fmul fast float %7555, %7560
  %7562 = fmul fast float %7549, 0x40019999A0000000
  %7563 = fadd fast float %7562, -5.000000e-01
  %7564 = call float @dx.op.unary.f32(i32 7, float %7563)  ; Saturate(value)
  %7565 = fsub fast float %7561, %7550
  %7566 = fmul fast float %7564, %7565
  %7567 = fadd fast float %7566, %7550
  %7568 = fmul fast float %7549, %7549
  %7569 = fmul fast float %7568, 3.450000e+01
  %7570 = fmul fast float %7549, 5.900000e+01
  %7571 = fsub fast float 2.450000e+01, %7570
  %7572 = fadd fast float %7571, %7569
  %7573 = fmul fast float %7572, %7509
  %7574 = fmul fast float %7549, 0x40524CCCC0000000
  %7575 = fadd fast float %7574, 0xC035333340000000
  %7576 = call float @dx.op.binary.f32(i32 35, float %7575, float 0x4021CCCCC0000000)  ; FMax(a,b)
  %7577 = call float @dx.op.unary.f32(i32 24, float %7514)  ; Sqrt(value)
  %7578 = fmul fast float %7576, %7577
  %7579 = fsub fast float -0.000000e+00, %7578
  %7580 = call float @dx.op.unary.f32(i32 21, float %7579)  ; Exp(value)
  %7581 = fmul fast float %7573, %7580
  %7582 = fadd fast float %7567, %7581
  %7583 = call float @dx.op.binary.f32(i32 35, float %7582, float 0.000000e+00)  ; FMax(a,b)
  %7584 = fmul fast float %3280, %7460
  %7585 = fmul fast float %7583, %7584
  %7586 = fmul fast float %7585, %92
  %7587 = fmul fast float %7585, %93
  %7588 = fmul fast float %7585, %94
  %7589 = fmul fast float %7584, %95
  %7590 = fmul fast float %7496, %7496
  %7591 = fmul fast float %7590, %7589
  %7592 = fmul fast float %7591, %7524
  %7593 = fmul fast float %7592, %7538
  %7594 = fmul fast float %7593, %7544
  %7595 = fmul fast float %7594, %7522
  %7596 = fmul fast float %7595, %92
  %7597 = fmul fast float %7595, %93
  %7598 = fmul fast float %7595, %94
  br label %7599

; <label>:7599                                    ; preds = %7492, %7487
  %7600 = phi float [ %7586, %7492 ], [ 0.000000e+00, %7487 ]
  %7601 = phi float [ %7587, %7492 ], [ 0.000000e+00, %7487 ]
  %7602 = phi float [ %7588, %7492 ], [ 0.000000e+00, %7487 ]
  %7603 = phi float [ %7596, %7492 ], [ 0.000000e+00, %7487 ]
  %7604 = phi float [ %7597, %7492 ], [ 0.000000e+00, %7487 ]
  %7605 = phi float [ %7598, %7492 ], [ 0.000000e+00, %7487 ]
  %7606 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %44, i32 2)  ; CBufferLoadLegacy(handle,regIndex)
  %7607 = extractvalue %dx.types.CBufRet.f32 %7606, 0
  %7608 = fmul fast float %2756, 0x3F40600000000000
  %7609 = fadd fast float %7608, 0x3FEFFCB940000000
  %7610 = fmul fast float %2757, 0x3F40600000000000
  %7611 = fadd fast float %7610, 0x3FEFFCB940000000
  %7612 = fmul fast float %2758, 0x3F40600000000000
  %7613 = fadd fast float %7612, 0x3FEFFCB940000000
  %7614 = call float @dx.op.unary.f32(i32 7, float %7609)  ; Saturate(value)
  %7615 = call float @dx.op.unary.f32(i32 7, float %7611)  ; Saturate(value)
  %7616 = call float @dx.op.unary.f32(i32 7, float %7613)  ; Saturate(value)
  %7617 = fadd fast float %7614, -1.000000e+00
  %7618 = fadd fast float %7615, -1.000000e+00
  %7619 = fadd fast float %7616, -1.000000e+00
  %7620 = fmul fast float %7617, %7607
  %7621 = fmul fast float %7618, %7607
  %7622 = fmul fast float %7619, %7607
  %7623 = fadd fast float %7620, 1.000000e+00
  %7624 = fadd fast float %7621, 1.000000e+00
  %7625 = fadd fast float %7622, 1.000000e+00
  %7626 = fmul fast float %7623, %7600
  %7627 = fmul fast float %7624, %7601
  %7628 = fmul fast float %7625, %7602
  %7629 = and i32 %2884, 16
  %7630 = icmp eq i32 %7629, 0
  br i1 %7630, label %7646, label %7631

; <label>:7631                                    ; preds = %7599
  %7632 = fadd fast float %7306, 0xBF9EB851E0000000
  %7633 = fmul fast float %7632, 0x3FF07EAE20000000
  %7634 = call float @dx.op.unary.f32(i32 7, float %7633)  ; Saturate(value)
  %7635 = fmul fast float %7634, 2.000000e+00
  %7636 = fsub fast float 3.000000e+00, %7635
  %7637 = fmul fast float %7634, %7634
  %7638 = fmul fast float %7637, %7636
  %7639 = fadd fast float %3283, -2.500000e-01
  %7640 = call float @dx.op.unary.f32(i32 7, float %7639)  ; Saturate(value)
  %7641 = fadd fast float %7638, %7640
  %7642 = call float @dx.op.unary.f32(i32 7, float %7641)  ; Saturate(value)
  %7643 = fmul fast float %7642, %7603
  %7644 = fmul fast float %7642, %7604
  %7645 = fmul fast float %7642, %7605
  br label %7646

; <label>:7646                                    ; preds = %7631, %7599
  %7647 = phi float [ %7643, %7631 ], [ %7603, %7599 ]
  %7648 = phi float [ %7644, %7631 ], [ %7604, %7599 ]
  %7649 = phi float [ %7645, %7631 ], [ %7605, %7599 ]
  %7650 = fdiv fast float 0x3FA47AE140000000, %3285
  %7651 = fadd fast float %7650, 0x3FEEB851E0000000
  %7652 = fadd fast float %7303, %6586
  %7653 = fadd fast float %7652, %7411
  %7654 = fadd fast float %7653, %7647
  %7655 = fadd fast float %7304, %6587
  %7656 = fadd fast float %7655, %7412
  %7657 = fadd fast float %7656, %7648
  %7658 = fadd fast float %7305, %6588
  %7659 = fadd fast float %7658, %7413
  %7660 = fadd fast float %7659, %7649
  %7661 = fmul fast float %3287, %2797
  %7662 = fmul fast float %3287, %2836
  %7663 = fmul fast float %3287, %2875
  %7664 = fmul fast float %7661, %7614
  %7665 = fmul fast float %7662, %7615
  %7666 = fmul fast float %7663, %7616
  %7667 = fadd fast float %7664, %6583
  %7668 = fadd fast float %7667, %7626
  %7669 = fmul fast float %7668, %2756
  %7670 = fadd fast float %7665, %6584
  %7671 = fadd fast float %7670, %7627
  %7672 = fmul fast float %7671, %2757
  %7673 = fadd fast float %7666, %6585
  %7674 = fadd fast float %7673, %7628
  %7675 = fmul fast float %7674, %2758
  %7676 = and i32 %2884, 1
  %7677 = icmp ne i32 %7676, 0
  %7678 = select i1 %7677, float 1.000000e+00, float 0.000000e+00
  %7679 = fmul fast float %7678, %7654
  %7680 = fmul fast float %7679, %7651
  %7681 = fmul fast float %7678, %7657
  %7682 = fmul fast float %7681, %7651
  %7683 = fmul fast float %7678, %7651
  %7684 = fmul fast float %7683, %7660
  %7685 = fmul fast float %893, %870
  %7686 = fmul fast float %893, %871
  %7687 = fmul fast float %893, %872
  %7688 = fmul fast float %903, 0x3FB331E1E0000000
  %7689 = fmul fast float %903, 0x3FB0A84FE0000000
  %7690 = fmul fast float %903, 0x3FA2806880000000
  %7691 = fadd fast float %7688, %7685
  %7692 = fadd fast float %7689, %7686
  %7693 = fadd fast float %7690, %7687
  %7694 = fmul fast float %7691, 1.000000e+02
  %7695 = fmul fast float %7692, 1.000000e+02
  %7696 = fmul fast float %7693, 1.000000e+02
  %7697 = fadd fast float %7669, %7694
  %7698 = fadd fast float %7697, %7680
  %7699 = fadd fast float %7672, %7695
  %7700 = fadd fast float %7699, %7682
  %7701 = fadd fast float %7675, %7696
  %7702 = fadd fast float %7701, %7684
  %7703 = call %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32 62, %dx.types.Handle %11, %dx.types.Handle %38, float %661, float %662, float undef, float undef, i32 0, i32 0, i32 undef, float 0.000000e+00)  ; SampleLevel(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,LOD)
  %7704 = extractvalue %dx.types.ResRet.f32 %7703, 0
  %7705 = fsub fast float %7704, %660
  %7706 = fdiv fast float 1.000000e+00, %7705
  %7707 = fmul fast float %7706, %659
  %7708 = fsub fast float %7707, %50
  %7709 = fmul fast float %7708, 5.000000e-01
  %7710 = call float @dx.op.unary.f32(i32 7, float %7709)  ; Saturate(value)
  %7711 = fmul fast float %7710, %7710
  %7712 = fmul fast float %7711, 5.000000e-01
  %7713 = fadd fast float %727, 5.000000e-01
  %7714 = fadd fast float %7713, %7712
  %7715 = call float @dx.op.unary.f32(i32 7, float %7714)  ; Saturate(value)
  %7716 = fmul fast float %7715, %60
  %7717 = fsub fast float 1.000000e+00, %67
  %7718 = fmul fast float %7698, %7717
  %7719 = fmul fast float %7700, %7717
  %7720 = fmul fast float %7702, %7717
  %7721 = fadd fast float %7718, %64
  %7722 = fmul fast float %7716, %127
  %7723 = fmul fast float %7722, %7721
  %7724 = fadd fast float %7719, %65
  %7725 = fmul fast float %7722, %7724
  %7726 = fadd fast float %7720, %66
  %7727 = fmul fast float %7722, %7726
  %glass_r5_spec_r = fmul float %7654, %7651
  %glass_r5_exposed_r = fmul float %glass_r5_spec_r, %127
  %r9Scaled_r = fmul float %glass_r5_exposed_r, %setting_reflection_strength
  %glass_r5_out_r = fmul float %r9Scaled_r, %glass_r5_reflection_scale
  %glass_r5_spec_g = fmul float %7657, %7651
  %glass_r5_exposed_g = fmul float %glass_r5_spec_g, %127
  %r9Scaled_g = fmul float %glass_r5_exposed_g, %setting_reflection_strength
  %glass_r5_out_g = fmul float %r9Scaled_g, %glass_r5_reflection_scale
  %glass_r5_spec_b = fmul float %7660, %7651
  %glass_r5_exposed_b = fmul float %glass_r5_spec_b, %127
  %r9Scaled_b = fmul float %glass_r5_exposed_b, %setting_reflection_strength
  %glass_r5_out_b = fmul float %r9Scaled_b, %glass_r5_reflection_scale
  %r8Output0 = select i1 %r8Marked, float %glass_r5_out_r, float %7723
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %r8Output0)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  %r8Output1 = select i1 %r8Marked, float %glass_r5_out_g, float %7725
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %r8Output1)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  %r8Output2 = select i1 %r8Marked, float %glass_r5_out_b, float %7727
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %r8Output2)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  %r8Output3 = select i1 %r8Marked, float %glass_r5_alpha, float %7716
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %r8Output3)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32, %dx.types.Handle, %dx.types.Handle, float, float, float, float, i32, i32, i32, float, float) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureGatherCmp.f32(i32, %dx.types.Handle, %dx.types.Handle, float, float, float, float, i32, i32, i32, float) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.sampleLevel.f32(i32, %dx.types.Handle, %dx.types.Handle, float, float, float, float, i32, i32, i32, float) #2

; Function Attrs: nounwind readnone
declare i32 @dx.op.legacyF32ToF16(i32, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.i32 @dx.op.bufferLoad.i32(i32, %dx.types.Handle, i32, i32) #2

; Function Attrs: nounwind readnone
declare i32 @dx.op.unaryBits.i32(i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot2.f32(i32, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.i32 @dx.op.textureLoad.i32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.bufferLoad.f32(i32, %dx.types.Handle, i32, i32) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.entryPoints = !{!61}

!0 = !{!"dxcoob 1.8.2505.0"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, !48, !52}
!5 = !{!6, !8, !9, !10, !12, !13, !14, !16, !17, !18, !19, !20, !21, !22, !23, !24, !26, !27, !28, !29, !30, !31, !32, !34, !35, !36, !38, !40, !41, !42, !43, !44, !45, !46, !47}
!6 = !{i32 0, %"class.Texture2D<float>"* undef, !"", i32 0, i32 65, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %struct.ByteAddressBuffer* undef, !"", i32 0, i32 66, i32 1, i32 11, i32 0, null}
!9 = !{i32 2, %"class.Texture2DArray<float>"* undef, !"", i32 0, i32 67, i32 1, i32 7, i32 0, !7}
!10 = !{i32 3, %"class.StructuredBuffer<vector<float, 4> >"* undef, !"", i32 0, i32 69, i32 1, i32 12, i32 0, !11}
!11 = !{i32 1, i32 16}
!12 = !{i32 4, %"class.TextureCubeArray<vector<float, 4> >"* undef, !"", i32 0, i32 70, i32 1, i32 9, i32 0, !7}
!13 = !{i32 5, %"class.Texture2D<float>"* undef, !"", i32 0, i32 71, i32 1, i32 2, i32 0, !7}
!14 = !{i32 6, %"class.StructuredBuffer<unsigned int>"* undef, !"", i32 0, i32 73, i32 1, i32 12, i32 0, !15}
!15 = !{i32 1, i32 4}
!16 = !{i32 7, %"class.StructuredBuffer<vector<float, 4> >"* undef, !"", i32 0, i32 74, i32 1, i32 12, i32 0, !11}
!17 = !{i32 8, %"class.Texture2DArray<float>"* undef, !"", i32 0, i32 76, i32 1, i32 7, i32 0, !7}
!18 = !{i32 9, %"class.TextureCubeArray<float>"* undef, !"", i32 0, i32 78, i32 1, i32 9, i32 0, !7}
!19 = !{i32 10, %"class.TextureCubeArray<vector<float, 4> >"* undef, !"", i32 0, i32 80, i32 1, i32 9, i32 0, !7}
!20 = !{i32 11, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 81, i32 1, i32 2, i32 0, !7}
!21 = !{i32 12, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 82, i32 1, i32 2, i32 0, !7}
!22 = !{i32 13, %"class.Texture2DArray<vector<float, 4> >"* undef, !"", i32 0, i32 84, i32 1, i32 7, i32 0, !7}
!23 = !{i32 14, %"class.StructuredBuffer<unsigned int>"* undef, !"", i32 0, i32 85, i32 1, i32 12, i32 0, !15}
!24 = !{i32 15, %"class.Texture3D<vector<unsigned int, 2> >"* undef, !"", i32 0, i32 91, i32 1, i32 4, i32 0, !25}
!25 = !{i32 0, i32 5}
!26 = !{i32 16, %"class.Texture3D<vector<float, 4> >"* undef, !"", i32 0, i32 95, i32 1, i32 4, i32 0, !7}
!27 = !{i32 17, %"class.Buffer<unsigned int>"* undef, !"", i32 0, i32 98, i32 1, i32 10, i32 0, !25}
!28 = !{i32 18, %"class.Buffer<unsigned int>"* undef, !"", i32 0, i32 100, i32 1, i32 10, i32 0, !25}
!29 = !{i32 19, %"class.Texture3D<unsigned int>"* undef, !"", i32 0, i32 105, i32 1, i32 4, i32 0, !25}
!30 = !{i32 20, %"class.Texture3D<vector<float, 4> >"* undef, !"", i32 0, i32 106, i32 1, i32 4, i32 0, !7}
!31 = !{i32 21, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 107, i32 1, i32 2, i32 0, !7}
!32 = !{i32 22, %"class.StructuredBuffer<GiGridCellDesc>"* undef, !"", i32 0, i32 108, i32 1, i32 12, i32 0, !33}
!33 = !{i32 1, i32 32}
!34 = !{i32 23, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 109, i32 1, i32 2, i32 0, !7}
!35 = !{i32 24, %"class.Texture2D<float>"* undef, !"", i32 0, i32 114, i32 1, i32 2, i32 0, !7}
!36 = !{i32 25, %"class.StructuredBuffer<ProbeContainer>"* undef, !"", i32 0, i32 116, i32 1, i32 12, i32 0, !37}
!37 = !{i32 1, i32 144}
!38 = !{i32 26, %"hostlayout.class.StructuredBuffer<DenseProbeVolume>"* undef, !"", i32 0, i32 117, i32 1, i32 12, i32 0, !39}
!39 = !{i32 1, i32 112}
!40 = !{i32 27, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 121, i32 1, i32 2, i32 0, !7}
!41 = !{i32 28, %"class.StructuredBuffer<GiGridCellTreeOffsets>"* undef, !"", i32 0, i32 123, i32 1, i32 12, i32 0, !11}
!42 = !{i32 29, %"class.StructuredBuffer<GiGridNode>"* undef, !"", i32 0, i32 128, i32 1, i32 12, i32 0, !11}
!43 = !{i32 30, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 32, i32 1, i32 2, i32 0, !7}
!44 = !{i32 31, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 33, i32 1, i32 2, i32 0, !7}
!45 = !{i32 32, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 34, i32 1, i32 2, i32 0, !7}
!46 = !{i32 33, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 35, i32 1, i32 2, i32 0, !7}
!47 = !{i32 34, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 36, i32 1, i32 2, i32 0, !7}
!48 = !{!49, !50, !51}
!49 = !{i32 0, %common_shadercomponents_configuration_collections_worldglobal_collection* undef, !"", i32 0, i32 2, i32 1, i32 212, null}
!50 = !{i32 1, %common_shadercomponents_configuration_collections_worldseasonalevent_collection* undef, !"", i32 0, i32 3, i32 1, i32 76, null}
!51 = !{i32 2, %hostlayout.PerPassConstants* undef, !"", i32 0, i32 4, i32 1, i32 7804, null}
!52 = !{!53, !54, !55, !56, !57, !58, !59, !60}
!53 = !{i32 0, %struct.SamplerState* undef, !"", i32 0, i32 0, i32 1, i32 0, null}
!54 = !{i32 1, %struct.SamplerState* undef, !"", i32 0, i32 1, i32 1, i32 0, null}
!55 = !{i32 2, %struct.SamplerState* undef, !"", i32 0, i32 2, i32 1, i32 0, null}
!56 = !{i32 3, %struct.SamplerState* undef, !"", i32 0, i32 4, i32 1, i32 0, null}
!57 = !{i32 4, %struct.SamplerState* undef, !"", i32 0, i32 5, i32 1, i32 0, null}
!58 = !{i32 5, %struct.SamplerState* undef, !"", i32 0, i32 7, i32 1, i32 0, null}
!59 = !{i32 6, %struct.SamplerState* undef, !"", i32 0, i32 8, i32 1, i32 0, null}
!60 = !{i32 7, %struct.SamplerComparisonState* undef, !"", i32 0, i32 9, i32 1, i32 1, null}
!61 = !{void ()* @ShaderDomain_Ps, !"ShaderDomain_Ps", !62, !4, !79}
!62 = !{!63, !77, null}
!63 = !{!64, !67, !70, !72, !74, !76}
!64 = !{i32 0, !"TEXCOORD", i8 9, i8 0, !65, i8 2, i32 1, i8 4, i32 0, i8 0, !66}
!65 = !{i32 0}
!66 = !{i32 3, i32 15}
!67 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !68, i8 2, i32 1, i8 3, i32 1, i8 0, !69}
!68 = !{i32 1}
!69 = !{i32 3, i32 7}
!70 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !71, i8 2, i32 1, i8 4, i32 2, i8 0, !66}
!71 = !{i32 2}
!72 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !73, i8 2, i32 1, i8 3, i32 3, i8 0, !69}
!73 = !{i32 3}
!74 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !75, i8 2, i32 1, i8 3, i32 4, i8 0, !69}
!75 = !{i32 4}
!76 = !{i32 5, !"SV_Position", i8 9, i8 3, !65, i8 4, i32 1, i8 4, i32 5, i8 0, !66}
!77 = !{!78}
!78 = !{i32 0, !"SV_Target", i8 9, i8 16, !65, i8 0, i32 1, i8 4, i32 0, i8 0, !66}
!79 = !{i32 0, i64 16}
!80 = distinct !{!80, !"dx.controlflow.hints", i32 1}
!81 = distinct !{!81, !"dx.controlflow.hints", i32 1}
!82 = distinct !{!82, !"dx.controlflow.hints", i32 1}
!83 = !{!84, !84, i64 0}
!84 = !{!"float", !85, i64 0}
!85 = !{!"omnipotent char", !86, i64 0}
!86 = !{!"Simple C/C++ TBAA"}
!87 = !{!88, !90, !91, !93, !95, !96, !98, !99, !101, !102}
!88 = distinct !{!88, !89, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z: %lodId"}
!89 = distinct !{!89, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z"}
!90 = distinct !{!90, !89, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z: %lodT"}
!91 = distinct !{!91, !92, !"\01?getCell@GiGridProbeResources@@QAA?AUGiGridProbeCellResources@@IV?$vector@I$01@@M@Z: %agg.result"}
!92 = distinct !{!92, !"\01?getCell@GiGridProbeResources@@QAA?AUGiGridProbeCellResources@@IV?$vector@I$01@@M@Z"}
!93 = distinct !{!93, !94, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %agg.result"}
!94 = distinct !{!94, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z"}
!95 = distinct !{!95, !94, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %debug"}
!96 = distinct !{!96, !97, !"\01?sampleProbe2@GiGridProbeSampler_SHL1@@QAA?AUWeightedProbeSample@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %agg.result"}
!97 = distinct !{!97, !"\01?sampleProbe2@GiGridProbeSampler_SHL1@@QAA?AUWeightedProbeSample@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z"}
!98 = distinct !{!98, !97, !"\01?sampleProbe2@GiGridProbeSampler_SHL1@@QAA?AUWeightedProbeSample@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %debug"}
!99 = distinct !{!99, !100, !"\01?sampleProbe2@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@UProbeDebug@@@Z: %agg.result"}
!100 = distinct !{!100, !"\01?sampleProbe2@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@UProbeDebug@@@Z"}
!101 = distinct !{!101, !100, !"\01?sampleProbe2@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@UProbeDebug@@@Z: %debug"}
!102 = distinct !{!102, !103, !"\01?sampleProbe@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@@Z: %agg.result"}
!103 = distinct !{!103, !"\01?sampleProbe@ProbeSampler_SHL1@@QAA?AUProbeSample@@UProbeSamplePosition@@@Z"}
!104 = distinct !{!104, !105}
!105 = !{!"llvm.loop.unroll.disable"}
!106 = !{!107, !109, !110, !112, !114, !115, !96, !98, !99, !101, !102}
!107 = distinct !{!107, !108, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z: %lodId"}
!108 = distinct !{!108, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z"}
!109 = distinct !{!109, !108, !"\01?getLodInfo@GpuProbesLodDistances@@QAAXMAIAHAIAM@Z: %lodT"}
!110 = distinct !{!110, !111, !"\01?getCell@GiGridProbeResources@@QAA?AUGiGridProbeCellResources@@IV?$vector@I$01@@M@Z: %agg.result"}
!111 = distinct !{!111, !"\01?getCell@GiGridProbeResources@@QAA?AUGiGridProbeCellResources@@IV?$vector@I$01@@M@Z"}
!112 = distinct !{!112, !113, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %agg.result"}
!113 = distinct !{!113, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z"}
!114 = distinct !{!114, !113, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@UGiGridProbeDebug@@@Z: %debug"}
!115 = distinct !{!115, !116, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@@Z: %agg.result"}
!116 = distinct !{!116, !"\01?sampleProbe@@YA?AUWeightedProbeSample@@UGiGridProbeResources@@UProbeSamplePosition@@@Z"}
!117 = distinct !{!117, !"dx.controlflow.hints", i32 1}

