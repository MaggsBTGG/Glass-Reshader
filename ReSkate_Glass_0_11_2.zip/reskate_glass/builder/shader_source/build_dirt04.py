from pathlib import Path
import re,subprocess
base=Path('glass_builder04/reskate_glass/builder');source=Path('glass_builder03/reskate_glass/builder/shader_source')
# Decode integer preset plus 5-bit dirt amount from POSITION.w, and transport unchanged.
s=(source/'universal_vs.ll').read_text()
s=s.replace('  %profileNegative = fsub float 0.000000e+00, %glassMarkerInput','  %profileInteger = call float @dx.op.unary.f32(i32 27, float %glassMarkerInput)\n  %profileNegative = fsub float 0.000000e+00, %profileInteger\n  %dirtTransport = fsub float 0.000000e+00, %glassMarkerInput')
s=s.replace('select i1 %glassMarked, float %profileNegative, float %965','select i1 %glassMarked, float %dirtTransport, float %965')
path=Path('builder03_tools/dirt_vs.ll');path.write_text(s);subprocess.run(['builder03_tools/assemble',str(path),str(base/'shaders/vs.dxil')],check=True)
for i in [6,7,8,9]:
 s=(source/f'universal_ps_{i}.ll').read_text();m=re.search(r'%profile42 = fcmp oeq float (%\d+),',s);carrier=m.group(1)
 insert=f'''  %dirtPositive = fsub float 0.000000e+00, {carrier}
  %dirtPresetInteger = call float @dx.op.unary.f32(i32 27, float %dirtPositive)
  %dirtPresetNegative = fsub float 0.000000e+00, %dirtPresetInteger
  %dirtFraction = fsub float %dirtPositive, %dirtPresetInteger
  %dirtRaw = fmul float %dirtFraction, 0x3FF0842100000000
  %dirtAmount = call float @dx.op.unary.f32(i32 7, float %dirtRaw)
'''
 # 32/31 rounded float, expressed as LLVM double representation.
 import struct
 factor='0x'+struct.pack('>d',struct.unpack('<f',struct.pack('<f',32/31))[0]).hex().upper()
 insert=insert.replace('0x3FF0842100000000',factor)
 pos=s.index('  %profile42 =');s=s[:pos]+insert+s[pos:]
 for val in [42,43,44,45,46]:s=s.replace(f'%profile{val} = fcmp oeq float {carrier},',f'%profile{val} = fcmp oeq float %dirtPresetNegative,')
 # Dirty regions move towards 0.7 roughness, high opacity and muted reflection.
 n=4530 if i in [6,8] else 2876
 pos=s.index(f'  %r8Glass{n} =')
 code='''  %dirtRoughGap = fsub float 0x3FE6666660000000, %setting_roughness
  %dirtRoughDelta = fmul float %dirtAmount, %dirtRoughGap
  %dirtRoughness = fadd float %setting_roughness, %dirtRoughDelta
  %dirtSmoothness = fsub float 1.000000e+00, %dirtRoughness
'''
 s=s[:pos]+code+s[pos:];s=s.replace(f'%r8Glass{n} = fadd float %setting_smoothness,',f'%r8Glass{n} = fadd float %dirtSmoothness,')
 old='  %glass_r5_alpha = fadd float %glass_r5_glass_alpha, 0.000000e+00'
 new='''  %dirtOpacityGap = fsub float 0x3FEE666660000000, %glass_r5_glass_alpha
  %dirtOpacityDelta = fmul float %dirtAmount, %dirtOpacityGap
  %glass_r5_alpha = fadd float %glass_r5_glass_alpha, %dirtOpacityDelta'''
 assert old in s;s=s.replace(old,new)
 for ch in 'rgb':
  old=f'  %glass_r5_out_{ch} = fmul float %r9Scaled_{ch}, %glass_r5_reflection_scale'
  # Keep part of the reflection and add an exposure-scaled neutral grime contribution.
  exposure='%117' if i in [6,8] else '%127'
  new=f'''  %dirtReflection{ch} = fmul float %r9Scaled_{ch}, %glass_r5_reflection_scale
  %dirtReflectionLoss{ch} = fmul float %dirtAmount, 0x3FE6666660000000
  %dirtReflectionKeep{ch} = fsub float 1.000000e+00, %dirtReflectionLoss{ch}
  %dirtKept{ch} = fmul float %dirtReflection{ch}, %dirtReflectionKeep{ch}
  %dirtGrey{ch} = fmul float %dirtAmount, 0x3FB47AE140000000
  %dirtExposed{ch} = fmul float %dirtGrey{ch}, {exposure}
  %glass_r5_out_{ch} = fadd float %dirtKept{ch}, %dirtExposed{ch}'''
  assert old in s;s=s.replace(old,new)
 path=Path(f'builder03_tools/dirt_ps_{i}.ll');path.write_text(s);subprocess.run(['builder03_tools/assemble',str(path),str(base/f'shaders/Universal/ps_{i}.dxil')],check=True)
print('Dirt carrier shaders assembled and validated')
