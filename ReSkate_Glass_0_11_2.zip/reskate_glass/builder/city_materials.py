"""Per-material texture payloads; six lossless float32 parameter texels."""
import math,struct
FIELDS=('reflection_strength','roughness','face_opacity','edge_opacity')

def validate(settings):
    if set(settings)!=set(FIELDS):raise ValueError('Invalid glass settings fields')
    for k in FIELDS:
        v=settings[k]
        if isinstance(v,bool) or not isinstance(v,(float,int)) or not math.isfinite(v) or not 0<=v<=(4 if k==FIELDS[0] else 1):raise ValueError('Invalid '+k)
    if settings['face_opacity']>settings['edge_opacity']:raise ValueError('Edge opacity must be at least face opacity')

def payload(settings,coverage,data=None,width=1,height=1,rgba=True):
    validate(settings)
    if not math.isfinite(coverage) or not 0<=coverage<=8:raise ValueError('Coverage must be within 0..8')
    if not isinstance(width,int) or not isinstance(height,int) or not 1<=width<=1024 or not 1<=height<=1024:raise ValueError('Invalid dirt dimensions')
    if data is None:data=b'\0\0\0\0';width=height=1;coverage=0;rgba=True
    if len(data)!=width*height*(4 if rgba else 1):raise ValueError('Dirt pixel length mismatch')
    tw=max(6,width);th=height+1;raw=bytearray(tw*th*4)
    for i,value in enumerate([settings[k] for k in FIELDS]+[coverage,float(width)]):struct.pack_into('<f',raw,i*4,value)
    for y in range(height):
        for x in range(width):
            source=((height-1-y)*width+x)*(4 if rgba else 1)
            if rgba:
                r,g,b,a=data[source:source+4];pixel=bytes((round(r*a/255),round(g*a/255),round(b*a/255),a))
            else:
                a=data[source];pixel=bytes((round(.08*a),)*3+(a,))
            raw[((y+1)*tw+x)*4:((y+1)*tw+x+1)*4]=pixel
    return bytes(raw),tw,th

def decode_parameters(raw):return dict(zip(FIELDS+('coverage',),struct.unpack_from('<5f',raw)))

def texture_payload(header,raw,width,height):
    if len(header)!=180 or len(raw)!=width*height*4 or not 6<=width<=1024 or not 2<=height<=1025:raise ValueError('Invalid material texture')
    h=bytearray(header);struct.pack_into('<I',h,12,18);struct.pack_into('<4H',h,22,width,height,1,1)
    h[30]=1;h[31]=0;struct.pack_into('<15I',h,56,len(raw),*([0]*14));struct.pack_into('<I',h,116,len(raw))
    return bytes(h),raw
