"""Private texture-slot experiment. No stock texture or shared material is modified."""
import hashlib, math, struct

# Runtime slot diagnostic: this private parameter feeds t33, not t36.
WATER_TEXTURE_KEY=0xc5c55c4e068ff0b4
FLOOR_TEXTURE_KEY=0x79a348610bb23445

def texture_reference(data,key):
    token=struct.pack('<QI',key,0x14c5fc30)
    positions=[i for i in range(len(data)) if data.startswith(token,i)]
    if len(positions)!=1:raise ValueError('Pixel dirt needs one private water material and one floor carrier material')
    p=positions[0]
    if data[p+12:p+14]!=b'\x01\x00' or data[p+16]!=1 or p+49>len(data):raise ValueError('Unexpected shader texture-reference layout')
    return p+17

def bind_mask(data):
    b=bytearray(data);water=texture_reference(b,WATER_TEXTURE_KEY);floor=texture_reference(b,FLOOR_TEXTURE_KEY)
    replacement=bytes(b[floor:floor+32])
    if not any(replacement):raise ValueError('Empty private texture reference')
    b[water:water+32]=replacement
    assert len(b)==len(data)
    assert all(b[i]==data[i] for i in range(len(data)) if not water<=i<water+32)
    return bytes(b)

def rgba_mips(mask,width,height):
    if not 1<=width<=1024 or not 1<=height<=1024 or len(mask)!=width*height:raise ValueError('Invalid pixel dirt image dimensions')
    # Blender image rows are bottom-up; native texture chunks are top-down.
    values=[mask[y*width:(y+1)*width] for y in reversed(range(height))]
    data=bytearray();sizes=[]
    while True:
        raw=bytes(c for row in values for v in row for c in (v,v,v,255));sizes.append(len(raw));data.extend(raw)
        if width==height==1:break
        neww,newh=max(1,width//2),max(1,height//2)
        # Area averaging also includes the last texel of odd-sized images.
        values=[bytes(round(sum(values[sy][sx] for sy in range(y*height//newh,(y+1)*height//newh) for sx in range(x*width//neww,(x+1)*width//neww))/(((y+1)*height//newh-y*height//newh)*((x+1)*width//neww-x*width//neww))) for x in range(neww)) for y in range(newh)]
        width,height=neww,newh
    return bytes(data),sizes

def color_mips(rgba,width,height):
    if not 1<=width<=1024 or not 1<=height<=1024 or len(rgba)!=width*height*4:
        raise ValueError('Invalid RGBA dirt image dimensions')
    # Store premultiplied linear RGB, including the base level. This prevents dark/color
    # fringes from fully transparent pixels during GPU filtering and mip selection.
    values=[]
    for y in reversed(range(height)):
        row=[]
        for x in range(width):
            r,g,b,a=rgba[(y*width+x)*4:(y*width+x)*4+4]
            row.append((r*a/255,g*a/255,b*a/255,float(a)))
        values.append(row)
    data=bytearray();sizes=[]
    while True:
        raw=bytes(round(c) for row in values for pixel in row for c in pixel)
        data.extend(raw);sizes.append(len(raw))
        if width==height==1:break
        nw,nh=max(1,width//2),max(1,height//2)
        reduced=[]
        for y in range(nh):
            row=[]
            for x in range(nw):
                area=[values[sy][sx] for sy in range(y*height//nh,(y+1)*height//nh) for sx in range(x*width//nw,(x+1)*width//nw)]
                row.append(tuple(sum(p[k] for p in area)/len(area) for k in range(4)))
            reduced.append(row)
        values=reduced;width,height=nw,nh
    return bytes(data),sizes

def texture_payload(header,mask,width,height,encoding=None):
    if len(header)!=180 or struct.unpack_from('<I',header,8)[0]!=0:raise ValueError('Pixel dirt expects the pinned compiler 2D texture header')
    if encoding not in (None,'linear-rgba8'):raise ValueError('Unsupported dirt texture encoding')
    data,sizes=color_mips(mask,width,height) if encoding=='linear-rgba8' else rgba_mips(mask,width,height)
    b=bytearray(header)
    struct.pack_into('<I',b,12,18) # linear RGBA8_UNORM; masks must not use sRGB decoding
    struct.pack_into('<4H',b,22,width,height,1,1)
    b[30]=len(sizes);b[31]=0
    struct.pack_into('<15I',b,56,*(sizes+[0]*(15-len(sizes))))
    struct.pack_into('<I',b,116,len(data))
    return bytes(b),data

def material_texture_positions(data,shader_keys,key=WATER_TEXTURE_KEY,table_end=None):
    """Resolve a section's shader key through its private depot table, never by global key alone."""
    positions=[]
    sizes={0x2bb65c2d:4,0x885eff59:12,0x36ed3444:4,0x7826e998:4,0x8e4a817e:4,0x2a36e9d5:8,0x57f970ca:4}
    for shader_key in shader_keys:
        token=struct.pack('<Q',shader_key)
        matches=[i for i in range(16,table_end if table_end is not None else len(data)-15,16) if data.startswith(token,i)]
        if len(matches)!=1:raise ValueError('Private glass shader key not found uniquely')
        block=struct.unpack_from('<Q',data,matches[0]+8)[0]
        if block+8>len(data):raise ValueError('Private shader block exceeds depot')
        start=struct.unpack_from('<Q',data,block)[0]
        if start+4>len(data):raise ValueError('Private shader parameters exceed depot')
        count=struct.unpack_from('<I',data,start)[0];pos=start+4;found=[]
        if count>256:raise ValueError('Unexpected material parameter count')
        for _ in range(count):
            k,t,n=struct.unpack_from('<QIH',data,pos)
            if t==0x14c5fc30:
                if n!=1 or data[pos+16]!=1:raise ValueError('Unsupported texture parameter reference')
                if k==key:found.append(pos+17)
                pos+=49
            else:
                if t not in sizes:raise ValueError('Unsupported private material parameter type')
                pos+=20+sizes[t]*n
            if pos>len(data):raise ValueError('Material parameter exceeds depot')
        if len(found)!=1:raise ValueError('Glass material needs one water texture slot')
        positions.extend(found)
    return sorted(set(positions))

def apply_private_mask(rows,bundle,owned_bytes,add,recipe,job,shader_keys=None):
    spec=recipe['pixel_texture_mask'];mask=(job/spec['file']).read_bytes()
    if hashlib.sha256(mask).hexdigest()!=spec['sha256']:raise ValueError('Pixel mask hash mismatch')
    carrier=recipe.get('mask_carrier_texture','floor_basecolor_')
    headers=[r for r in rows if r[0]==bundle and r[2]=='1' and '/textures/'+carrier in r[3] and r[9]=='1']
    assets=[r for r in rows if r[0]==bundle and r[2]=='0' and '/textures/'+carrier in r[3] and r[9]=='1']
    depots=[r for r in rows if r[0]==bundle and r[2]=='1' and r[3].startswith('levels/game/dingolevel_reskate_') and '/shaderblockdepot_' in r[3] and r[9]=='1']
    if len(headers)!=1 or len(assets)!=1 or len(depots)!=1:raise ValueError('Private mask texture carrier or material depot is missing/ambiguous')
    ebx=owned_bytes(assets[0])
    if ebx[:4]!=b'RIFF' or len(ebx)<48:raise ValueError('Unexpected private texture EBX')
    file_guid=ebx[32:48]
    row=headers[0];header=owned_bytes(row)
    import uuid
    guid=str(uuid.UUID(bytes_le=header[40:56]));chunks=[r for r in rows if r[0]==bundle and r[2]=='2' and r[4]==guid]
    if len(chunks)!=1:raise ValueError('Private mask texture chunk not found')
    owned_bytes(chunks[0])
    depot=owned_bytes(depots[0]);needle=struct.pack('<QI',FLOOR_TEXTURE_KEY,0x14c5fc30)
    refs=[i+17 for i in range(len(depot)-49) if depot.startswith(needle,i) and depot[i+17:i+33]==file_guid]
    if len(refs)!=1:raise ValueError('Private carrier material reference is missing/ambiguous')
    replacement=depot[refs[0]:refs[0]+32];patched=bytearray(depot)
    targets=material_texture_positions(depot,shader_keys) if shader_keys else [texture_reference(depot,WATER_TEXTURE_KEY)]
    for offset in targets:patched[offset:offset+32]=replacement
    changed,pixels=texture_payload(header,mask,spec['width'],spec['height'],spec.get('encoding'))
    add(row,changed);add(chunks[0],pixels);add(depots[0],bytes(patched))


def pack_uv(uv):
    if len(uv)!=2 or any(not math.isfinite(v) or not -16<=v<=16 for v in uv):
        raise ValueError('Pixel dirt UVs must be within -16..16 in this compatibility test; reduce UV tiling on a test copy')
    return struct.pack('<2H',*(round((v+16)*65535/32) for v in uv))

def unpack_uv(data):
    return tuple(v*32/65535-16 for v in struct.unpack('<2H',data))


def apply_private_materials(rows,bundle,owned_bytes,add,recipe,job,material_keys):
    """Bind each authored material only to its own private carrier texture."""
    from city_materials import texture_payload as material_payload
    import uuid
    depots=[r for r in rows if r[0]==bundle and r[2]=='1' and r[3].startswith('levels/game/dingolevel_reskate_') and '/shaderblockdepot_' in r[3] and r[9]=='1']
    if len(depots)!=1:raise ValueError('Expected one owned material depot for this native map')
    depot=owned_bytes(depots[0])
    from material_depot import MaterialDepot
    if len(depots[0])<12:raise ValueError('Update the add-on native helper before using independent materials')
    editor=MaterialDepot(depot,bytes.fromhex(depots[0][11]));claimed={}
    for mid,spec in recipe['pixel_materials'].items():
        keys=material_keys.get(mid)
        if not keys:raise ValueError('No native glass sections for '+mid)
        raw=(job/spec['file']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=spec['sha256']:raise ValueError('Private material payload hash mismatch')
        carrier=spec['carrier_texture']
        headers=[r for r in rows if r[0]==bundle and r[2]=='1' and '/textures/'+carrier in r[3] and r[9]=='1']
        assets=[r for r in rows if r[0]==bundle and r[2]=='0' and '/textures/'+carrier in r[3] and r[9]=='1']
        if len(headers)!=1 or len(assets)!=1:raise ValueError('Private material carrier missing/ambiguous: '+mid)
        ebx=owned_bytes(assets[0]);header=owned_bytes(headers[0])
        if ebx[:4]!=b'RIFF' or len(ebx)<48 or len(header)!=180:raise ValueError('Unexpected material texture layout')
        guid=str(uuid.UUID(bytes_le=header[40:56]))
        chunks=[r for r in rows if r[0]==bundle and r[2]=='2' and r[4]==guid]
        if len(chunks)!=1:raise ValueError('Private material image chunk missing')
        owned_bytes(chunks[0])
        needle=struct.pack('<QI',FLOOR_TEXTURE_KEY,0x14c5fc30)
        refs=[i+17 for i in range(len(depot)-48) if depot.startswith(needle,i) and depot[i+17:i+33]==ebx[32:48]]
        if len(refs)!=1:raise ValueError('Private material carrier reference missing/ambiguous')
        replacement=depot[refs[0]:refs[0]+32]
        for key in keys:
            if key in claimed and claimed[key]!=mid:raise ValueError('Different authored materials share a native shader key; binding refused')
            claimed[key]=mid
        editor.bind(mid,keys,replacement)
        changed,pixels=material_payload(header,raw,spec['width'],spec['height'])
        add(headers[0],changed);add(chunks[0],pixels)
    changed,metadata=editor.finish();add(depots[0],changed,metadata.hex())
    return editor.audit
