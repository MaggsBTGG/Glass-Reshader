[CmdletBinding()]
param(
 [string]$ModsFolder,
 [string]$WorkFolder = (Join-Path $env:LOCALAPPDATA 'ReSkateGlass\InstallHistory')
)
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'Install-Glass-Test.ps1') -Action Remove -ModsFolder $ModsFolder -WorkFolder $WorkFolder
