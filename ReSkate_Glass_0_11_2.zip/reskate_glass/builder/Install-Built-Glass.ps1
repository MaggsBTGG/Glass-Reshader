[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][string]$PackageFolder,
 [Parameter(Mandatory=$true)][string]$GameRoot,
 [Parameter(Mandatory=$true)][string]$WorkFolder
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
if (Get-Process -Name 'Skate','ReSkateLauncher' -ErrorAction SilentlyContinue) {
 throw 'Close skate and ReSkateLauncher before installing. The completed package is retained; use its installer without rebuilding.'
}
$installer=Join-Path $PackageFolder 'Install-Glass-Test.ps1'
if (-not (Test-Path -LiteralPath $installer -PathType Leaf)) { throw 'Completed package installer was not found.' }
$mods=Join-Path $GameRoot 'Mods'
if (-not (Test-Path -LiteralPath $mods -PathType Container)) {
 throw "ReSkate Mods folder not found: $mods. Start ReSkateLauncher once to set up this game folder, then use the completed package installer."
}
# Use the same hash-checked, backup-and-rollback installer as manual packages.
& $installer -Action Install -ModsFolder $mods -WorkFolder $WorkFolder
