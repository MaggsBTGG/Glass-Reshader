﻿[CmdletBinding()]
param(
 [string]$AuthoringZip,
 [string]$ResultFile,
 [string]$BaseBlend,
 [switch]$PixelDirt,
 [switch]$InstallAfterBuild,
 [string]$BlenderPath,
 [string]$CliPath,
 [string]$GameRoot,
 [string]$OutputRoot = (Join-Path $env:LOCALAPPDATA 'ReSkateGlass\Builds')
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$job = ''
$deployed = $false
$buildComplete = $false
function Write-GlassStatus([string]$Status,[string]$Stage,[string]$Message='') {
 if (-not $ResultFile) { return }
 $package = ''
 if ($job) { $package = Join-Path $job 'Installable-Glass-Test.zip' }
 $record = [ordered]@{status=$Status;stage=$Stage;job=$job;package=$package;error=$Message}
 $temporary = $ResultFile + '.tmp'
 $record | ConvertTo-Json | Set-Content -LiteralPath $temporary -Encoding UTF8
 Move-Item -LiteralPath $temporary -Destination $ResultFile -Force
}
trap {
 $message = $_.Exception.Message
 try { Write-GlassStatus 'failed' 'Build stopped' $message } catch {}
 Write-Host "BUILD STOPPED: $message"
 break
}
Write-GlassStatus 'running' 'Checking tools and supported game'
if ($InstallAfterBuild -and (Get-Process -Name 'Skate','ReSkateLauncher' -ErrorAction SilentlyContinue)) {
 throw 'Close skate and ReSkateLauncher, then click Build Map with Glass again.'
}

if (-not $AuthoringZip) {
 Add-Type -AssemblyName System.Windows.Forms
 $dialog = New-Object System.Windows.Forms.OpenFileDialog
 try {
  $dialog.Title = 'Select the ZIP exported by ReSkate Glass Authoring'
  $dialog.Filter = 'Authoring ZIP|*.zip'
  if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Selection cancelled.' }
  $AuthoringZip = $dialog.FileName
 } finally { $dialog.Dispose() }
}
if (-not $BlenderPath) {
 $candidates = @(Get-ChildItem 'C:\Program Files\Blender Foundation' -Filter blender.exe -Recurse -File -ErrorAction SilentlyContinue | Sort-Object FullName -Descending)
 if ($candidates.Count -gt 0) { $BlenderPath = $candidates[0].FullName }
 else { throw 'Blender was not found. Run again with -BlenderPath pointing to blender.exe.' }
}
if (-not $CliPath) {
 foreach ($relative in @('OneDrive\Desktop\Reskate Studio\ReSkate Studio\reskate_cli.exe','Desktop\Reskate Studio\ReSkate Studio\reskate_cli.exe')) {
  $candidate = Join-Path $env:USERPROFILE $relative
  if (Test-Path -LiteralPath $candidate) { $CliPath = $candidate; break }
 }
 if (-not $CliPath) {
  Add-Type -AssemblyName System.Windows.Forms
  $dialog = New-Object System.Windows.Forms.OpenFileDialog
  try { $dialog.Title = 'Select installed Studio reskate_cli.exe'; $dialog.Filter = 'ReSkate CLI|reskate_cli.exe'; if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'CLI selection cancelled.' }; $CliPath = $dialog.FileName } finally { $dialog.Dispose() }
 }
}
# ReSkate installs its pinned game beside the launcher, separate from Steam updates.
$expectedGameHash = 'FBCE74D5E28EF525DBBA2CB4ADBEBC13405BDBD88F31BC940BCA45E4AE88B8F9'
function Test-SupportedGlassGame([string]$Folder) {
 $exe = Join-Path $Folder 'Skate.exe'
 if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { return $false }
 if (-not (Test-Path -LiteralPath (Join-Path $Folder 'Data\layout.toc') -PathType Leaf)) { return $false }
 if ((Get-Item -LiteralPath $exe).Length -ne 144567168) { return $false }
 return ((Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash -eq $expectedGameHash)
}
if (-not $GameRoot) {
 $candidates = @(
  (Join-Path $env:USERPROFILE 'OneDrive\Desktop\Reskate'),
  (Join-Path $env:USERPROFILE 'Desktop\Reskate'),
  'C:\Games\ReSkate',
  'C:\Program Files (x86)\Steam\steamapps\common\Skate'
 )
 foreach ($candidate in $candidates) {
  if (Test-SupportedGlassGame $candidate) { $GameRoot = $candidate; break }
 }
 if (-not $GameRoot) {
  Add-Type -AssemblyName System.Windows.Forms
  $dialog = New-Object System.Windows.Forms.OpenFileDialog
  try {
   $dialog.Title = 'Select supported Skate.exe beside ReSkateLauncher.exe (build 25414733)'
   $dialog.Filter = 'Supported game|Skate.exe'
   if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Game selection cancelled.' }
   $GameRoot = Split-Path -Parent $dialog.FileName
  } finally { $dialog.Dispose() }
 }
}
$GameRoot = [IO.Path]::GetFullPath($GameRoot)
if (-not (Test-SupportedGlassGame $GameRoot)) {
 throw "Unsupported game executable or missing Data\layout.toc in $GameRoot. Use ReSkateLauncher to install/verify build 25414733, then select Skate.exe from that folder."
}
if ($InstallAfterBuild -and -not (Test-Path -LiteralPath (Join-Path $GameRoot 'Mods') -PathType Container)) { throw 'The supported game folder has no ReSkate Mods folder. Start its ReSkateLauncher once before using automatic installation.' }
Write-Host "GAME SOURCE: $GameRoot (supported executable verified; CLI will validate asset data)"
foreach ($path in @($AuthoringZip,$BlenderPath,$CliPath,(Join-Path $GameRoot 'Skate.exe'))) {
 if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "File not found: $path" }
}
$helper = Join-Path $PSScriptRoot 'native\package_io.exe'
$expectedCli = '001F613310E263F06B3479129E0E314D71BE703989D2A84178332BF4F43B1248'
if ((Get-FileHash -LiteralPath $CliPath -Algorithm SHA256).Hash -ne $expectedCli) { throw 'This developer builder requires the Studio CLI version used by the validated glass tests.' }
$helperSourceHash = (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'native\package_io.cpp') -Algorithm SHA256).Hash
$helperStamp = Join-Path $PSScriptRoot 'native\build-helper.sha256'
$helperNeedsBuild = -not (Test-Path -LiteralPath $helper -PathType Leaf)
if (-not (Test-Path -LiteralPath $helperStamp -PathType Leaf)) { $helperNeedsBuild = $true }
elseif ((Get-Content -LiteralPath $helperStamp -Raw).Trim() -ne $helperSourceHash) { $helperNeedsBuild = $true }
if ($helperNeedsBuild) {
 $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
 if (-not (Test-Path -LiteralPath $vswhere)) { throw 'Visual Studio C++ Build Tools are required for the package helper.' }
 $vs = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
 if (-not $vs) { throw 'Visual Studio C++ tools were not found.' }
 $vcvars = Join-Path $vs 'VC\Auxiliary\Build\vcvars64.bat'
 $native = Join-Path $PSScriptRoot 'native'
 $batch = Join-Path $native 'build-helper.cmd'
 @"
@echo off
call "$vcvars"
if errorlevel 1 exit /b 1
cd /d "$native"
cl /nologo /std:c++20 /EHsc /O2 /W4 /WX /I . package_io.cpp Engine\Resource\toc.cpp Engine\Resource\binary_bundle.cpp Engine\Resource\binary_io.cpp /Fe:package_io.exe
exit /b %errorlevel%
"@ | Set-Content -LiteralPath $batch -Encoding ASCII
 & $env:ComSpec /d /c "`"$batch`""
 if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $helper)) { throw 'Native package helper build failed.' }
 $helperSourceHash | Set-Content -LiteralPath $helperStamp -Encoding ASCII
}
$job = Join-Path $OutputRoot ('Glass_Authoring_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Path $job -Force | Out-Null
$inputFolder = Join-Path $job 'normalized'
$staging = Join-Path $job 'compiled'
$exitCode = 1
try {
 Write-GlassStatus 'running' 'Preparing scene and glass'
 if ($BaseBlend) {
  if (-not (Test-Path -LiteralPath $BaseBlend -PathType Leaf)) { throw 'Saved base blend was not found.' }
  $converter = Join-Path (Split-Path -Parent $CliPath) 'Native\Blender\studio_map_import.py'
  if (-not (Test-Path -LiteralPath $converter -PathType Leaf)) { throw 'Stock Studio converter was not found beside this CLI.' }
  $sourceHashBefore = (Get-FileHash -LiteralPath $BaseBlend -Algorithm SHA256).Hash
  $baseFolder = Join-Path $job 'base-normalized'
  $ErrorActionPreference = 'Continue'
  & $BlenderPath --background --factory-startup --python-exit-code 1 --python $converter -- --input $BaseBlend --output $baseFolder --map-id ('glass_base_' + [guid]::NewGuid().ToString('N').Substring(0,8)) --scale 1 2>&1 | ForEach-Object { $_.ToString() } | Tee-Object -FilePath (Join-Path $job 'Scene-Export.log') | Out-Host
  $sceneCode = $LASTEXITCODE
  $ErrorActionPreference = 'Stop'
  if ((Get-FileHash -LiteralPath $BaseBlend -Algorithm SHA256).Hash -ne $sourceHashBefore) { throw 'Source blend changed during scene export. Save it and start a fresh build.' }
  if ($sceneCode -ne 0) { throw "Full scene export failed: $sceneCode" }
  $prepareScript = 'prepare_full_map.py'
  $prepareArguments = @($baseFolder,$AuthoringZip,$inputFolder)
  if ($PixelDirt) { $prepareArguments += '--pixel-dirt' }
 } else {
  $prepareScript = 'prepare_native.py'
  $prepareArguments = @($AuthoringZip,$inputFolder)
  if ($PixelDirt) { $prepareArguments += '--pixel-dirt' }
 }
 $ErrorActionPreference = 'Continue'
 & $BlenderPath --background --factory-startup --python-exit-code 1 --python (Join-Path $PSScriptRoot $prepareScript) -- @prepareArguments 2>&1 | ForEach-Object { $_.ToString() } | Tee-Object -FilePath (Join-Path $job 'Prepare.log') | Out-Host
 $prepareCode = $LASTEXITCODE
 $ErrorActionPreference = 'Stop'
 if ($prepareCode -ne 0 -or -not (Test-Path (Join-Path $inputFolder 'map.json'))) { throw "Preparation failed: $prepareCode" }
 $ErrorActionPreference = 'Continue'
 Write-GlassStatus 'running' 'Compiling native map'
 $compileArguments = @('compile-map',$GameRoot,$inputFolder,$staging,'--no-lods','--no-stream')
 if (-not $BaseBlend) { $compileArguments += @('--no-gi','--no-bam-lighting','--time-of-day','noon') }
 & $CliPath @compileArguments 2>&1 | ForEach-Object { $_.ToString() } | Tee-Object -FilePath (Join-Path $job 'Compile.log') | Out-Host
 $exitCode = $LASTEXITCODE
 $ErrorActionPreference = 'Stop'
 if ($exitCode -ne 0) { throw "Native compile failed: $exitCode" }
 if (@(Get-ChildItem -LiteralPath $staging -Filter '*.toc' -Recurse -File).Count -eq 0) { throw 'No compiled TOC found.' }
 $ErrorActionPreference = 'Continue'
 Write-GlassStatus 'running' 'Packaging glass and checking both components'
 & $BlenderPath --background --factory-startup --python-exit-code 1 --python (Join-Path $PSScriptRoot 'patch_native.py') -- --job $job --game-root $GameRoot --helper $helper 2>&1 | ForEach-Object { $_.ToString() } | Tee-Object -FilePath (Join-Path $job 'Patch.log') | Out-Host
 $exitCode = $LASTEXITCODE
 $ErrorActionPreference = 'Stop'
 if ($exitCode -ne 0) { throw "Glass patch failed: $exitCode" }
 $buildComplete = $true
 if ($InstallAfterBuild) {
  Write-GlassStatus 'running' 'Installing map and shader support; backing up previous build'
  & (Join-Path $PSScriptRoot 'Install-Built-Glass.ps1') -PackageFolder (Join-Path $job 'playable') -GameRoot $GameRoot -WorkFolder (Join-Path (Split-Path -Parent $OutputRoot) 'InstallHistory') *>&1 | Tee-Object -FilePath (Join-Path $job 'Install.log') | Out-Host
  $deployed = $true
 }


} catch {
 Write-Host $_.Exception.Message
 $_.Exception.ToString() | Set-Content (Join-Path $job 'FAILURE.txt') -Encoding UTF8
 $exitCode = 1
 if ($buildComplete) { Write-GlassStatus 'failed' 'Installation stopped; package retained' $_.Exception.Message }
 else { Write-GlassStatus 'failed' 'Build stopped' $_.Exception.Message }
}
[ordered]@{stage='automatic-glass-test-build';exit_code=$exitCode;deployed=$deployed;glass_shader_patch_applied=$buildComplete;install_requested=[bool]$InstallAfterBuild;no_lods=$true;game_root=$GameRoot;supported_executable_verified=$true;source_zip_sha256=(Get-FileHash -LiteralPath $AuthoringZip -Algorithm SHA256).Hash} | ConvertTo-Json | Set-Content (Join-Path $job 'BUILD_REPORT.json') -Encoding UTF8
if ($exitCode -ne 0) { Write-Host "BUILD STOPPED. Logs: $job"; exit $exitCode }
if ($deployed) {
 Write-GlassStatus 'installed' 'Map and glass support installed'
 Write-Host 'INSTALLED: Start ReSkate and load the map ending in - Glass Preview. Previous recognized builds were retained outside Mods.'
 Write-Host "PACKAGE BACKUP: $(Join-Path $job 'Installable-Glass-Test.zip')"
 exit 0
}
Write-GlassStatus 'ready' 'Installable package ready'
Write-Host "READY: $(Join-Path $job 'Installable-Glass-Test.zip')"
if ($BaseBlend) { Write-Host 'Extract that ZIP, close skate and run Install-Glass-Test.ps1. Load the map ending in - Glass Preview.' }
elseif ($PixelDirt) { Write-Host 'Extract that ZIP, close skate, run Install-Glass-Test.ps1 and load Glass Materials - City Test.' }
else { Write-Host 'Extract that ZIP, close skate, then run its Install-Glass-Test.ps1. Load Glass Authoring - Dirt Bake.' }
Write-Host 'The builder does not deploy automatically.'
