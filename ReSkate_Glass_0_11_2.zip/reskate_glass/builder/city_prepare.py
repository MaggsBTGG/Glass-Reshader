"""Prepare spatially bounded glass with independent private materials."""
import hashlib,json,pathlib,struct,zipfile,zlib
from prepare_native import parse_glb,positions,write_glb,IDENTITY
from city_materials import payload
from spatial_glass import pieces

def png(seed):
    def chunk(kind,b):return struct.pack('>I',len(b))+kind+b+struct.pack('>I',zlib.crc32(kind+b)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>2I5B',2,2,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b'\0'+seed[:8]+b'\0'+seed[8:16]))+chunk(b'IEND',b'')

def prepare_materials(source,destination):
    destination=pathlib.Path(destination)
    if destination.exists():raise ValueError('Choose a fresh output folder')
    files={};rows=[];recipes=[];specs={};materials={};origins={};placements=set()
    with zipfile.ZipFile(source) as z:
        manifest=json.loads(z.read('glass-authoring.json'))
        if manifest.get('schema')!=1 or manifest.get('kind')!='reskate-glass-authoring':raise ValueError('Unexpected authoring package')
        for obj in manifest['objects']:
            data=z.read(obj['mesh'])
            if hashlib.sha256(data).hexdigest()!=manifest['files'][obj['mesh']]:raise ValueError('GLB hash mismatch')
            doc,binary=parse_glb(data);named=[n.get('name') for n in doc.get('nodes',[]) if 'mesh' in n and n.get('name')]
            if named and named!=[obj['name']]:raise ValueError('GLB contains other mesh objects; re-export authoring data')
            slots=obj['material_slots'];slotnames=obj.get('material_slot_names')
            for pts,idx,uvs,material_index in positions(doc,binary,True,True):
                if slots and all(k is not None for k in slots) and len(set(slots))==1:key=slots[0];sources=list(range(len(slots)))
                elif slotnames is not None and material_index is not None:
                    name=doc['materials'][material_index].get('name');sources=[i for i,n in enumerate(slotnames) if n==name]
                    keys={slots[i] for i in sources}
                    if len(keys)!=1:raise ValueError('Ambiguous glass slot mapping')
                    key=next(iter(keys))
                    if key is None:continue
                elif material_index is None:continue
                else:raise ValueError('Mixed glass slots need a fresh authoring export')
                record=manifest['materials'][key]
                if key not in specs:
                    mid='mat_%04d'%len(specs);texture=record.get('dirt_texture');mask=texture or record.get('dirt_mask');coverage=0;image=None;w=h=1
                    if mask:
                        if uvs is None:raise ValueError(obj['name']+': dirt needs an active UV map')
                        image=z.read(mask['file'])
                        if hashlib.sha256(image).hexdigest()!=mask['sha256']:raise ValueError('Dirt image hash mismatch')
                        if texture and mask.get('encoding')!='linear-rgba8':raise ValueError('Unsupported color encoding')
                        coverage=mask['strength']*mask.get('boost',1);w,h=mask['width'],mask['height']
                    raw,tw,th=payload(record['settings'],coverage,image,w,h,texture is not None)
                    path='materials/'+mid+'.bin';files[path]=raw
                    specs[key]={'id':mid,'file':'normalized/'+path,'width':tw,'height':th,'sha256':hashlib.sha256(raw).hexdigest(),'settings':record['settings'],'coverage':coverage,'mode':'RGBA' if texture else ('MASK' if mask else 'CLEAN'),'carrier_texture':'rg_carrier_'+mid+'_basecolor_'}
                spec=specs[key];coverage=spec['coverage']
                if (record.get('dirt_texture') or record.get('dirt_mask')) and uvs is None:raise ValueError('Dirt requires UVs on every section')
                for p,i,u,origin,cell in pieces(pts,idx,uvs):
                    name='glass_%06d'%len(recipes)
                    # Distinct placement/material pairs prevent native prototype/section merging.
                    # A float32 origin is used by the native compiler; keep it exact here too.
                    f32=lambda v:struct.unpack('<f',struct.pack('<f',v))[0]
                    origin=[f32((min(v[k] for v in p)+max(v[k] for v in p))/2) for k in range(3)]
                    while tuple(origin) in placements:
                        bits=struct.unpack('<I',struct.pack('<f',origin[0]))[0]
                        origin[0]=struct.unpack('<f',struct.pack('<I',bits+1 if origin[0]>=0 else bits-1))[0] if origin[0]!=0 else f32(.0001)
                    placements.add(tuple(origin))
                    reach=max(abs(v[k]-origin[k]) for v in p for k in range(3))
                    if reach>17:raise ValueError('Too many coincident sections for bounded native placement')
                    material='ocean_'+spec['id']+'_'+name
                    materials[material]={'domain':'ocean','shader_override':'ocean','alpha':'opaque','double_sided':True,'cast_shadows':False}
                    path='meshes/'+name+'.glb';files[path]=write_glb(p,i,u)
                    rows.append({'name':name,'mesh':path,'material':material,'placement_mode':'authored_mesh','transform':IDENTITY,'world_transform_baked':True,'native_render_origin':origin,'max_local_reach':reach,'static':True,'collision_mode':'none'})
                    recipes.append({'object':name,'source_object':obj['name'],'source_material_slots':sources,'material_id':spec['id'],'settings':record['settings'],'native_render_origin':origin,'pixel_strength':coverage,'dirt_samples':None})
                    origins.setdefault(tuple(cell),[(v+.5)*32 for v in cell]);spec.setdefault('origin',origin)
    if not recipes:raise ValueError('No glass geometry')
    table={s['id']:s for s in specs.values() if 'origin' in s}
    for mid,s in table.items():
        name='rg_carrier_'+mid;origin=s['origin'];x,y,z=origin;y-=40
        path='meshes/'+name+'.glb';files[path]=write_glb([(x,y,z),(x+.01,y,z),(x,y,z+.01)],[0,1,2])
        tex='textures/'+name+'.png';files[tex]=png(hashlib.sha256(name.encode()).digest())
        materials[name]={'domain':'surface','shader_override':'surface','alpha':'opaque','double_sided':False,'cast_shadows':False,'texture':tex,'base_color_texture':tex,'srgb':False}
        rows.append({'name':name,'mesh':path,'material':name,'placement_mode':'authored_mesh','transform':IDENTITY,'world_transform_baked':True,'native_render_origin':[x,y,z],'static':True,'collision_mode':'none'})
    first=next(iter(origins.values()));x,y,z=first;y-=17
    files['meshes/test_floor.glb']=write_glb([(x-20,y,z-20),(x+20,y,z-20),(x+20,y,z+20),(x-20,y,z+20)],[0,2,1,0,3,2])
    materials['floor']={'domain':'surface','alpha':'opaque','base_color_factor':[.35,.35,.35,1]}
    rows.append({'name':'test_floor','mesh':'meshes/test_floor.glb','material':'floor','placement_mode':'authored_mesh','transform':IDENTITY,'collision_mode':'triangle_mesh','collision_mesh':'meshes/test_floor.glb','native_render_origin':[x,y,z],'world_transform_baked':True,'static':True})
    mapid='glass_author_'+hashlib.sha256(pathlib.Path(source).read_bytes()+b'city-materials-v1').hexdigest()[:8]
    probes=[{'name':'GLASS_CELL_%d'%i,'influence':'box','transform':[40,0,0,0,40,0,0,0,40,*o],'falloff':.2,'clip_end':100,'intensity':1} for i,o in enumerate(origins.values())]
    doc={'format':1,'name':mapid,'display_name':'Glass Material Test','units':'meters','up':'y','forward':'-z','materials':materials,'objects':rows,'spawn':{'position':[x,y+1.5,z-3],'yaw':0},'reflection_probes':probes}
    recipe={'schema':2,'map_id':mapid,'objects':recipes,'pixel_materials':table,'material_pipeline':True,'shader_patch_applied':False,'scope':'isolated glass test','probe_policy':'local probes per occupied glass cell','uv_policy':'active UV; tiled on GPU','display_name':'Glass Materials - City Test'}
    files['map.json']=json.dumps(doc,indent=2).encode();files['glass-build-recipe.json']=json.dumps(recipe,indent=2).encode()
    destination.mkdir(parents=True)
    for name,data in files.items():
        p=destination/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    return mapid
