"""Clip triangle/UV pairs into bounded world cells without moving the scene."""
import itertools,math
CELL=32.0
MAX_VERTICES=60000

def area(points):
    a,b,c=points;u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
    return math.sqrt(sum(x*x for x in (u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])))/2

def clip(poly,axis,bound,greater):
    out=[]
    if not poly:return out
    previous=poly[-1];pin=(previous[0][axis]>=bound if greater else previous[0][axis]<=bound)
    for current in poly:
        cin=(current[0][axis]>=bound if greater else current[0][axis]<=bound)
        if cin!=pin:
            t=(bound-previous[0][axis])/(current[0][axis]-previous[0][axis])
            pos=tuple(previous[0][i]+t*(current[0][i]-previous[0][i]) for i in range(3))
            uv=tuple(previous[1][i]+t*(current[1][i]-previous[1][i]) for i in range(2))
            out.append((pos,uv))
        if cin:out.append(current)
        previous=current;pin=cin
    return out

def pieces(points,indices,uvs=None):
    if not all(math.isfinite(v) and abs(v)<1e6 for p in points for v in p):raise ValueError('Non-finite or extreme world coordinates')
    uvs=uvs or [(0.,0.)]*len(points);buckets={}
    for j in range(0,len(indices),3):
        tri=[(points[i],uvs[i]) for i in indices[j:j+3]]
        if area([p for p,u in tri])<1e-10:continue
        ranges=[]
        for axis in range(3):
            lo=min(p[axis] for p,u in tri);hi=max(p[axis] for p,u in tri)
            first=math.floor(lo/CELL);last=first if hi==lo else max(first,math.ceil(hi/CELL)-1)
            ranges.append(range(first,last+1))
        if math.prod(len(r) for r in ranges)>100000:raise ValueError('A glass triangle crosses too many cells; subdivide the source mesh')
        for cell in itertools.product(*ranges):
            poly=tri
            for axis in range(3):
                poly=clip(poly,axis,cell[axis]*CELL,True);poly=clip(poly,axis,(cell[axis]+1)*CELL,False)
            for k in range(1,len(poly)-1):
                chunk=[poly[0],poly[k],poly[k+1]]
                if area([p for p,u in chunk])>=1e-10:buckets.setdefault(cell,[]).extend(chunk)
    for cell,vertices in sorted(buckets.items()):
        origin=[(v+.5)*CELL for v in cell]
        for offset in range(0,len(vertices),MAX_VERTICES):
            part=vertices[offset:offset+MAX_VERTICES]
            pts=[p for p,u in part];uv=[u for p,u in part]
            assert all(abs(p[i]-origin[i])<=CELL/2+1e-5 for p in pts for i in range(3))
            yield pts,list(range(len(pts))),uv,origin,cell
