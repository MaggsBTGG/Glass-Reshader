"""Convert an alpha authoring ZIP into isolated native compiler input.
No shader patch or deployment is performed. Standard library only.
"""
import argparse, json, struct, math, zipfile, pathlib, hashlib, sys, zlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from dirt_bake import bake
IDENTITY=[1,0,0,0,1,0,0,0,1,0,0,0]

def multiply(a,b):
    return [sum(a[k*4+r]*b[c*4+k] for k in range(4)) for c in range(4) for r in range(4)]

def matrix(node):
    if 'matrix' in node:
        result=node['matrix']
        if len(result)!=16 or not all(math.isfinite(x) for x in result):raise ValueError('Invalid node matrix')
        return result
    x,y,z,w=node.get('rotation',[0,0,0,1]);sx,sy,sz=node.get('scale',[1,1,1]);tx,ty,tz=node.get('translation',[0,0,0])
    return [(1-2*y*y-2*z*z)*sx,(2*x*y+2*z*w)*sx,(2*x*z-2*y*w)*sx,0,
            (2*x*y-2*z*w)*sy,(1-2*x*x-2*z*z)*sy,(2*y*z+2*x*w)*sy,0,
            (2*x*z+2*y*w)*sz,(2*y*z-2*x*w)*sz,(1-2*x*x-2*y*y)*sz,0,tx,ty,tz,1]

def parse_glb(data):
    if len(data)<20 or struct.unpack_from('<4sII',data)!=(b'glTF',2,len(data)):raise ValueError('Invalid GLB')
    offset=12;doc=None;binary=b''
    while offset<len(data):
        size,kind=struct.unpack_from('<II',data,offset);offset+=8
        if offset+size>len(data):raise ValueError('Truncated GLB')
        chunk=data[offset:offset+size];offset+=size
        if kind==0x4e4f534a:doc=json.loads(chunk)
        elif kind==0x004e4942:binary=chunk
    if doc is None:raise ValueError('GLB has no JSON')
    if any('uri' in b for b in doc.get('buffers',[])):raise ValueError('External GLB buffers unsupported')
    return doc,binary

def accessor(doc,binary,index):
    a=doc['accessors'][index]
    if 'sparse' in a:raise ValueError('Sparse accessors unsupported')
    count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];formats={5126:'f',5125:'I',5123:'H',5121:'B'}
    fmt='<'+formats[a['componentType']]*count;size=struct.calcsize(fmt);v=doc['bufferViews'][a['bufferView']]
    if v.get('buffer',0)!=0:raise ValueError('Multiple GLB buffers unsupported')
    start=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size)
    if stride<size or (a['count'] and start+(a['count']-1)*stride+size>v.get('byteOffset',0)+v['byteLength']):raise ValueError('Accessor exceeds buffer view')
    return [struct.unpack_from(fmt,binary,start+i*stride) for i in range(a['count'])]

def positions(doc,binary,with_uv=False,with_material=False):
    # Exporter-generated GLBs are traversed through the active scene only.
    result=[];ident=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
    def walk(index,parent,ancestors):
        if index in ancestors:raise ValueError('Cyclic node graph')
        node=doc['nodes'][index];m=multiply(parent,matrix(node))
        if 'skin' in node:raise ValueError('Skinned glass unsupported')
        if 'mesh' in node:
            for primitive in doc['meshes'][node['mesh']]['primitives']:
                if primitive.get('mode',4)!=4 or primitive.get('targets'):raise ValueError('Only static triangle glass is supported')
                points=accessor(doc,binary,primitive['attributes']['POSITION'])
                transformed=[tuple(sum(m[c*4+r]*p[c] for c in range(3))+m[12+r] for r in range(3)) for p in points]
                if not all(math.isfinite(v) for p in transformed for v in p):raise ValueError('Non-finite vertex')
                indices=[v[0] for v in accessor(doc,binary,primitive['indices'])] if 'indices' in primitive else list(range(len(points)))
                if len(indices)%3 or any(i<0 or i>=len(points) for i in indices):raise ValueError('Invalid triangle indices')
                det=m[0]*(m[5]*m[10]-m[9]*m[6])-m[4]*(m[1]*m[10]-m[9]*m[2])+m[8]*(m[1]*m[6]-m[5]*m[2])
                if abs(det)<1e-12:raise ValueError('Collapsed object transform')
                if det<0:
                    for i in range(0,len(indices),3):indices[i+1],indices[i+2]=indices[i+2],indices[i+1]
                uvs=accessor(doc,binary,primitive['attributes']['TEXCOORD_0']) if 'TEXCOORD_0' in primitive['attributes'] else None
                entry=(transformed,indices,uvs) if with_uv else (transformed,indices)
                result.append(entry+(primitive.get('material'),) if with_material else entry)
        for child in node.get('children',[]):walk(child,m,ancestors|{index})
    for node in doc['scenes'][doc.get('scene',0)]['nodes']:walk(node,ident,set())
    return result

def write_glb(points,indices,uvs=None):
    # Flat geometric normals suit the proven planar glass shader.
    vertices=[];normals=[];vertex_uvs=[]
    for i in range(0,len(indices),3):
        a,b,c=[points[k] for k in indices[i:i+3]];u=[b[k]-a[k] for k in range(3)];v=[c[k]-a[k] for k in range(3)]
        n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];length=math.sqrt(sum(x*x for x in n))
        if length<1e-12:continue
        if uvs is not None:vertex_uvs.extend(uvs[k] for k in indices[i:i+3])
        vertices.extend([a,b,c]);normals.extend([tuple(x/length for x in n)]*3)
    if not vertices:raise ValueError('Mesh has no non-degenerate triangles')
    vbytes=b''.join(struct.pack('<3f',*v) for v in vertices);nbytes=b''.join(struct.pack('<3f',*n) for n in normals)
    binary=vbytes+nbytes;count=len(vertices)
    doc={'asset':{'version':'2.0'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'mesh':0}],
         'meshes':[{'primitives':[{'attributes':{'POSITION':0,'NORMAL':1},'mode':4}]}],
         'buffers':[{'byteLength':len(binary)}], 'bufferViews':[{'buffer':0,'byteOffset':0,'byteLength':len(vbytes)},{'buffer':0,'byteOffset':len(vbytes),'byteLength':len(nbytes)}],
         'accessors':[{'bufferView':0,'componentType':5126,'count':count,'type':'VEC3','min':[min(v[k] for v in vertices) for k in range(3)],'max':[max(v[k] for v in vertices) for k in range(3)]},{'bufferView':1,'componentType':5126,'count':count,'type':'VEC3'}]}
    if uvs is not None:
        uvraw=b''.join(struct.pack('<2f',*uv) for uv in vertex_uvs)
        doc['bufferViews'].append({'buffer':0,'byteOffset':len(binary),'byteLength':len(uvraw)})
        doc['accessors'].append({'bufferView':2,'componentType':5126,'count':count,'type':'VEC2'})
        doc['meshes'][0]['primitives'][0]['attributes']['TEXCOORD_0']=2
        binary+=uvraw;doc['buffers'][0]['byteLength']=len(binary)
    j=json.dumps(doc,separators=(',',':')).encode();j+=b' '*((-len(j))%4);binary+=b'\0'*((-len(binary))%4)
    return struct.pack('<4sII',b'glTF',2,28+len(j)+len(binary))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(binary),0x004e4942)+binary

def prepare(source,destination,pixel_dirt=False):
    if pixel_dirt:
        from city_prepare import prepare_materials
        return prepare_materials(source,destination)
    destination=pathlib.Path(destination)
    if destination.exists():raise ValueError('Choose a new output folder; existing folders are not overwritten')
    files={};allpoints=[];objects=[];recipes=[];pixel_mask=None
    with zipfile.ZipFile(source) as z:
        manifest=json.loads(z.read('glass-authoring.json'))
        if manifest.get('schema')!=1 or manifest.get('kind')!='reskate-glass-authoring':raise ValueError('Unexpected authoring package')
        for obj in manifest['objects']:
            slots=obj['material_slots']
            if not slots:raise ValueError(obj['name']+': no material slots')
            raw=z.read(obj['mesh'])
            if hashlib.sha256(raw).hexdigest()!=manifest['files'][obj['mesh']]:raise ValueError('GLB hash mismatch')
            doc,binary=parse_glb(raw)
            named_meshes=[n.get('name') for n in doc.get('nodes',[]) if 'mesh' in n and n.get('name')]
            if named_meshes and named_meshes != [obj['name']]:
                raise ValueError(obj['name']+': GLB contains other mesh objects; re-export with add-on 0.9.1 or newer to avoid duplicated glass')
            slot_names=obj.get('material_slot_names')
            if slot_names is not None and len(slot_names)!=len(slots):raise ValueError('Material slot name count mismatch')
            uniform=all(key is not None for key in slots) and len(set(slots))==1
            for pts,idx,uvs,material_index in positions(doc,binary,with_uv=True,with_material=True):
                if uniform:
                    key=slots[0];source_slots=list(range(len(slots)))
                elif slot_names is not None:
                    if material_index is None:
                        # A glTF primitive without material is an unassigned section.
                        continue
                    material_name=doc['materials'][material_index].get('name')
                    source_slots=[i for i,n in enumerate(slot_names) if n is not None and n==material_name]
                    if not source_slots:raise ValueError(obj['name']+': cannot match exported material '+str(material_name)+' to Blender slots')
                    keys={slots[i] for i in source_slots}
                    if len(keys)!=1:raise ValueError('Ambiguous material slot mapping')
                    key=next(iter(keys))
                    if key is None:continue
                else:
                    raise ValueError(obj['name']+': mixed material slots require a fresh authoring export from add-on 0.5.2')
                record=manifest['materials'][key]
                samples=None
                texture=record.get('dirt_texture')
                if texture and not pixel_dirt:raise ValueError('Color + Alpha needs Build Map with Glass, Full Map Preview or Pixel Dirt Test')
                if texture or 'dirt_mask' in record:
                    mask=texture or record['dirt_mask']
                    if uvs is None:raise ValueError(obj['name']+': unwrap the pane; dirt requires the active UV map')
                    data=z.read(mask['file'])
                    if hashlib.sha256(data).hexdigest()!=mask['sha256']:raise ValueError('Dirt mask hash mismatch')
                    strength=mask['strength']*mask.get('boost',1)
                    if not math.isfinite(strength) or not 0<=strength<=8:raise ValueError('Dirt strength times boost must be within 0..8')
                    width,height=mask['width'],mask['height']
                    if not isinstance(width,int) or not isinstance(height,int) or not 1<=width<=1024 or not 1<=height<=1024:raise ValueError('Invalid mask dimensions')
                    if pixel_dirt:
                        rgba=texture is not None
                        if rgba and mask.get('encoding')!='linear-rgba8':raise ValueError('Unsupported color dirt encoding')
                        if len(data)!=width*height*(4 if rgba else 1):raise ValueError('Unexpected dirt image data size')
                        spec={'file':'normalized/pixel_mask.mask','width':width,'height':height,'sha256':mask['sha256']}
                        if rgba:spec['encoding']='linear-rgba8'
                        if pixel_mask is not None and pixel_mask!=spec:raise ValueError('One shared dirt image AND mode is supported per map; use the same image and mode or leave the other panes clean')
                        pixel_mask=spec;files['pixel_mask.mask']=data
                    else:
                        pts,idx,samples=bake(pts,idx,uvs,data,width,height,strength)
                name='glass_%04d'%len(objects);path='meshes/'+name+'.glb';files[path]=write_glb(pts,idx,uvs if pixel_dirt else None);allpoints.extend(pts)
                objects.append({'name':name,'mesh':path,'material':'ocean_probe','placement_mode':'authored_mesh','transform':IDENTITY,'static':True,'collision_mode':'none'})
                recipes.append({'object':name,'source_object':obj['name'],'source_material_slots':source_slots,'settings':record['settings'],'dirt_samples':samples,'pixel_strength':(record.get('dirt_texture',record.get('dirt_mask',{})).get('strength',0)*record.get('dirt_texture',record.get('dirt_mask',{})).get('boost',1)) if pixel_dirt else None})
    if pixel_dirt and pixel_mask is None:
        files['pixel_mask.mask']=b'\0'
        pixel_mask={'file':'normalized/pixel_mask.mask','width':1,'height':1,'sha256':hashlib.sha256(b'\0').hexdigest()}
    if not allpoints:raise ValueError('No glass geometry')
    lo=[min(p[k] for p in allpoints) for k in range(3)];hi=[max(p[k] for p in allpoints) for k in range(3)]
    if max(hi[k]-lo[k] for k in range(3))>100:raise ValueError('Use a small test area (under 100 metres) for this bridge')
    center=[(lo[k]+hi[k])/2 for k in range(3)];y=lo[1]-0.3
    pts=[(lo[0]-5,y,lo[2]-5),(hi[0]+5,y,lo[2]-5),(hi[0]+5,y,hi[2]+5),(lo[0]-5,y,hi[2]+5)]
    files['meshes/test_floor.glb']=write_glb(pts,[0,2,1,0,3,2]);objects.append({'name':'test_floor','mesh':'meshes/test_floor.glb','material':'floor','placement_mode':'authored_mesh','transform':IDENTITY,'static':True,'collision_mode':'triangle_mesh','collision_mesh':'meshes/test_floor.glb'})
    mapid='glass_author_'+hashlib.sha256(pathlib.Path(source).read_bytes()).hexdigest()[:8]
    mapdoc={'format':1,'name':mapid,'display_name':'Glass Authoring Bridge - '+mapid[-8:], 'units':'meters','up':'y','forward':'-z',
            'materials':{'ocean_probe':{'domain':'ocean','shader_override':'ocean','alpha':'opaque','double_sided':True,'cast_shadows':False},'floor':{'domain':'surface','shader_override':'surface','alpha':'opaque','base_color_factor':[0.35,0.35,0.35,1],'metallic_factor':0,'roughness_factor':0.7}},
            'objects':objects,'spawn':{'position':[center[0],y+1.5,lo[2]-3],'yaw':0},
            'reflection_probes':[{'name':'AUTHORING_TEST_PROBE','influence':'box','transform':[max(20,hi[0]-lo[0]+10),0,0,0,max(20,hi[1]-lo[1]+10),0,0,0,max(20,hi[2]-lo[2]+10),*center],'falloff':0.2,'clip_end':100,'intensity':1}]}
    def png_chunk(kind,data):
        return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    files['textures/floor.png']=b'\x89PNG\r\n\x1a\n'+png_chunk(b'IHDR',struct.pack('>2I5B',1,1,8,6,0,0,0))+png_chunk(b'IDAT',zlib.compress(b'\x00\x60\x60\x60\xff'))+png_chunk(b'IEND',b'')
    mapdoc['materials']['floor'].update(texture='textures/floor.png',base_color_texture='textures/floor.png',srgb=True)
    files['map.json']=json.dumps(mapdoc,indent=2).encode();recipe={'schema':1,'map_id':mapid,'objects':recipes,'shader_patch_applied':False,'scope':'isolated glass-only test; original city excluded','probe_policy':'one generated test probe; imported probes not transferred yet','uv_policy':'UV0 sampled into subdivided vertex dirt; no native texture binding'}
    if pixel_dirt:
        recipe.update(pixel_gain_scale=(8 if any(o.get('pixel_strength',0)>1 for o in recipes) else 1),pixel_texture_mask=pixel_mask,display_name='Glass Authoring - Pixel Dirt Test',uv_policy='UV0 passed to pixel shader; private texture-slot experiment')
    files['glass-build-recipe.json']=json.dumps(recipe,indent=2).encode()
    destination.mkdir(parents=True)
    for name,data in files.items():
        path=destination/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    return mapid

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('authoring_zip');p.add_argument('output_folder');p.add_argument('--pixel-dirt',action='store_true');args=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else None)
    print('Prepared native test input:',prepare(args.authoring_zip,args.output_folder,args.pixel_dirt));print('Shader patch and deployment have NOT been performed.')
