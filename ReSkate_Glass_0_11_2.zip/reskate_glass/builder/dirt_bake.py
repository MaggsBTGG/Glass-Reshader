"""Experimental UV-space dirt mask sampled into mesh vertices."""
import math

def sample(mask,width,height,u,v,strength):
    if not all(math.isfinite(t) for t in (u,v)):
        raise ValueError('Dirt mask UVs must be finite')
    # Repeat a single image in both axes, including negative UV tiles.
    # Interpolate unwrapped coordinates during subdivision; wrap only here.
    u=u-math.floor(u);v=v-math.floor(v)
    # glTF V is opposite Blender image buffer's bottom-up rows.
    x=max(0,min(width-1,int(u*width)));y=max(0,min(height-1,int((1-v)*height)))
    return min(1,mask[y*width+x]/255*strength)

def bake(points,indices,uvs,mask,width,height,strength):
    if len(mask)!=width*height or len(uvs)!=len(points):raise ValueError('Mask or UV length mismatch')
    if width<1 or height<1 or not math.isfinite(strength) or not 0<=strength<=8:raise ValueError('Invalid dirt input')
    for uv in uvs:sample(mask,width,height,*uv,strength)
    result=[];amounts=[]
    def midpoint(a,b):return (tuple((a[0][k]+b[0][k])/2 for k in range(3)),tuple((a[1][k]+b[1][k])/2 for k in range(2)))
    def triangle(a,b,c,depth):
        span=max(abs(x[1][k]-y[1][k]) for x,y in [(a,b),(b,c),(c,a)] for k in range(2))
        if span>1/32 and depth<10:
            ab,bc,ca=midpoint(a,b),midpoint(b,c),midpoint(c,a)
            for t in [(a,ab,ca),(ab,b,bc),(ca,bc,c),(ab,bc,ca)]:triangle(*t,depth+1)
        else:
            if span>1/32:
                raise ValueError('Dirt UV tiling is too dense; reduce UV scale for this experimental bake')
            if len(result)+3>60000:
                raise ValueError('Dirt subdivision exceeds 60,000 vertices on a pane; reduce UV tiling or split it into smaller objects')
            for p,uv in (a,b,c):result.append(p);amounts.append(sample(mask,width,height,*uv,strength))
    if len(indices)%3:raise ValueError('Only triangles can be baked')
    for i in range(0,len(indices),3):triangle(*[(points[j],uvs[j]) for j in indices[i:i+3]],0)
    filtered=[];filtered_amounts=[]
    for i in range(0,len(result),3):
        a,b,c=result[i:i+3];u=[b[k]-a[k] for k in range(3)];v=[c[k]-a[k] for k in range(3)]
        n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
        if math.sqrt(sum(x*x for x in n))<1e-12:continue
        filtered.extend(result[i:i+3]);filtered_amounts.extend(amounts[i:i+3])
    result,amounts=filtered,filtered_amounts
    if len(result)>60000:raise ValueError('Dirt subdivision exceeds 60,000 vertices on a pane; split it into smaller objects')
    return result,list(range(len(result))),amounts

def encode_marker(profile,amount):
    if profile not in [42,43,44,45,46] or not math.isfinite(amount) or not 0<=amount<=1:raise ValueError('Invalid glass marker input')
    return profile+round(amount*31)/32
