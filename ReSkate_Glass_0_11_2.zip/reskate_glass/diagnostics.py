"""Small, read-only material/UV diagnostics included in authoring ZIPs."""
DIAGNOSTIC_VERSION='0.11.2'

def report(objects):
    materials={};meshes=[]
    for obj in objects:
        uv=[]
        for layer in obj.data.uv_layers:
            coords=[v.uv[:] for v in layer.data]
            uv.append({'name':layer.name,'active':layer==obj.data.uv_layers.active,'active_render':layer.active_render,
                       'range':[[min(t[k] for t in coords),max(t[k] for t in coords)] for k in range(2)] if coords else None})
        meshes.append({'name':obj.name,'uv_layers':uv,'materials':[s.material.name if s.material else None for s in obj.material_slots]})
        for slot in obj.material_slots:
            m=slot.material
            if not m or not m.reskate_glass.enabled or m.name in materials:continue
            p=m.reskate_glass;image=p.dirt_image
            record={'dirt_mode':p.dirt_mode,'strength':p.dirt_strength,'boost':p.dirt_boost,'coverage':p.dirt_coverage,'preview_test':p.preview_test,'image':None,
                    'outputs':[{'target':n.target,'active':n.is_active_output,'surface_sources':[l.from_node.name for l in n.inputs['Surface'].links]} for n in m.node_tree.nodes if n.type=='OUTPUT_MATERIAL'],
                    'preview_version':m.get('reskate_glass_preview_version'),'preview_groups':[]}
            if image:
                record['image']={'name':image.name,'size':list(image.size),'color_space':image.colorspace_settings.name,'alpha_mode':image.alpha_mode,'packed':bool(image.packed_file)}
            for n in m.node_tree.nodes:
                if n.type=='GROUP' and n.get('reskate_glass_preview'):
                    record['preview_groups'].append({'name':n.node_tree.name,'users':n.node_tree.users,'math_values':{t.name:{'operation':t.operation,'defaults':[v.default_value for v in t.inputs], 'linked':[v.is_linked for v in t.inputs]} for t in n.node_tree.nodes if t.type=='MATH'},'textures':[{'name':t.image.name if t.image else None,'extension':t.extension,'vector_sources':[l.from_node.name for l in t.inputs['Vector'].links]} for t in n.node_tree.nodes if t.type=='TEX_IMAGE']})
            materials[m.name]=record
    return {'objects':meshes,'materials':materials}
