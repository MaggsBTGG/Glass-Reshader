import math

PROFILES = {
    'LowReflection': dict(reflection_strength=0.25, roughness=0.05, face_opacity=0.08, edge_opacity=0.8),
    'Balanced': dict(reflection_strength=1.0, roughness=0.05, face_opacity=0.08, edge_opacity=0.8),
    'HighReflection': dict(reflection_strength=2.0, roughness=0.05, face_opacity=0.08, edge_opacity=0.8),
    'ExtraClear': dict(reflection_strength=1.0, roughness=0.05, face_opacity=0.02, edge_opacity=0.35),
    'Rough': dict(reflection_strength=1.0, roughness=0.4, face_opacity=0.08, edge_opacity=0.8),
}

def validate_settings(values):
    if set(values) != set(PROFILES['Balanced']):
        raise ValueError('Glass settings have missing or unknown fields')
    for name, value in values.items():
        maximum = 4 if name == 'reflection_strength' else 1
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= maximum:
            raise ValueError('Invalid glass setting: ' + name)
    if values['face_opacity'] > values['edge_opacity']:
        raise ValueError('Edge opacity must be at least face-on opacity')
    return values
