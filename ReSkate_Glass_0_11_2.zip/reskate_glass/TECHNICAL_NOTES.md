# Technical history — ReSkate Glass 0.11.2

The notes below were written during development. Statements that an in-game city test is pending are historical: the creator subsequently reported a successful 0.11.2 Kamurocho build and in-game test. Broad hardware compatibility remains unverified. For installation, use README.md.

# ReSkate Glass 0.11.2 — experimental beta

A Blender add-on for authoring reflective, see-through glass with a custom dirt image, then building and installing the map through **Build Map with Glass**. The add-on does not modify your saved blend, Studio installation, launcher, game executable or runtime DLLs during a build.

## Install or upgrade

1. In Blender, install `ReSkate_Glass_0_11_2_City_Experimental.zip` using **Preferences > Add-ons > Install from Disk**. Replace the older ReSkate Glass Authoring add-on and enable it. Fully restart Blender after upgrading.
2. Check the sidebar reads **ReSkate Glass — 0.11.2 City Experimental**.
3. In the add-on's preferences, optionally set **Studio CLI**, **ReSkate game folder** and **Build output folder**. Blank tool paths use discovery/selection dialogs. Save Preferences to retain your choices. The default output is `%LOCALAPPDATA%\ReSkateGlass\Builds`.
4. Open a COPY of your map. Existing glass settings, dirt images and coverage values are retained. Click **Refresh Blender Preview** on existing glass materials to rebuild their preview nodes.

The native builder requires Windows, Blender, the supported ReSkate game **build 25414733**, the Studio installation/CLI used by the glass tests, and Visual Studio C++ Build Tools (Desktop development with C++, x64 tools). The builder verifies the pinned game and CLI hashes. Updated Steam data is not interchangeable with the supported ReSkate game folder. Other Studio CLI versions are not supported by this beta; do not bypass the checks. The baseline was tested with Blender 5.2.2; this update passed local authoring/export checks in Blender 4.5.3. A fresh Windows build is still required.

## Add glass and your own dirt

1. Select the actual glass geometry. Use **Assign New Glass Material** to replace its material; do not add a second coplanar pane in front of existing glass. Mixed material objects retain their other slots. Back up your blend first.
2. Choose a preset and **Apply Preset**. The presets set reflection, roughness and face/edge opacity. You can then edit the reflection, roughness and face/edge opacity values freely within their displayed ranges. The current values export independently for each material; presets are optional starting points.
3. Choose **Color + Alpha** for an ordinary transparent dirt PNG. Load it using the **Dirt image** picker. RGB supplies the dirt color; alpha supplies coverage. Transparent areas retain the underlying glass.
4. Set **Dirt coverage**. Start around 0.5–1 for the included example. Values above 1 are allowed up to 8 and can make much of the pane opaque. This control is exported; editing generated Multiply nodes directly is not a supported authoring workflow.
5. UV-map the glass using the active UV layer. Repeat tiling is supported within -16..16 UV coordinates. Use **Dirt Color Only** or **Dirt Alpha Only** to inspect placement, then return to **Glass + Dirt** for the normal preview.
6. Use **Material Preview** or Rendered mode. Normal dirt now uses a diffuse shader and responds to Blender lighting; inspection modes remain unlit. The preview is approximate, not a match for the game's exposure or reflection captures.

**Grayscale Mask** uses the image's red channel to add neutral grime. It does not retain image colors. Different materials may use different images, modes and coverage values in the same build. Clean panes are also supported. Use Make Material Unique before changing only one group of windows that shares a material. Images are limited to 1024x1024 at export; larger inputs are reduced. Color + Alpha supports straight-alpha byte-buffer images in sRGB or linear Rec.709. HDR, other color spaces, UDIM, videos and sequences are refused.

## Build and install

1. Ensure the saved scene contains a floor/collision and an Empty named `spawn` above the floor. Save all edits. Start with a small scene copy before your full project.
2. Close skate and ReSkateLauncher.
3. Click **Build Map with Glass**. It creates the intermediate authoring ZIP automatically.
4. Let the PowerShell window finish. The button exports the saved scene through the installed stock Studio converter, replaces marked glass sections, compiles a native package and installs it automatically. You do not need to open Studio or run diagnostic scripts 10/11.
5. When Blender reports **Installed in ReSkate**, start ReSkate and load the map ending in **- Glass Preview**.

Your existing lights, spawn, probes, collision and other scene geometry pass through the normalized export/merge. Existing reflection probes are retained. If there are none, local probes are generated for occupied glass cells; review their cost and placement for a large city. No LODs or streaming are generated, so there is no in-game LOD setting to change. The former 100-metre glass-subset limit is replaced by 32-metre glass cells with local geometry origins. Generated sections use separate native placement/material identities to prevent prototype merging. World positions stay fixed. Large triangles are clipped with interpolated UVs and each section stays within a 60,000-vertex budget. Instanced native glass is still refused.

If a completed build fails to install, its package and logs are retained. Use **Open Build Folder** and **Copy Build Details**. The extracted `Install-Glass-Test.ps1` accepts `-ModsFolder` and `-WorkFolder`; without a Mods path it asks you to select the folder. You can retry installation without compiling again. Game shader/support changes require a game restart; changing the game's time of day does not require reinstalling the shaders.

## Upgrading from the temporary dirt tests

The installer recognizes exact known temporary shader-support file sets, including test 11, when their original build validation/audit records are present. It backs them up outside Mods as part of the paired install. History is read from the chosen output folder and the earlier `C:\KamurochoPort\GlassAutoBuilder\Builds` location if present. Unknown or edited folders still stop installation; they are not overwritten. Keep the old build records until the new build is installed. If records were moved or deleted, use the old test package's **Restore-Original-Glass.cmd** before building.

The installer backs up and replaces the map and its shader-support component together, with rollback on failure. It retires only recognized historical glass tests, not unrelated mods. Backups are under the chosen build location's sibling `InstallHistory` folder for automatic installs.

## Give a map to a player

The generated **Installable-Glass-Test.zip** contains the compiled map, its matching `glass_shader_...` support component, an installer and a remover. Give the player that generated ZIP, not this Blender add-on or the intermediate authoring ZIP. Players do not need Blender, Studio, C++ Build Tools or an extra runtime DLL for these compiled packages. They do need the compatible game/ReSkate setup.

The map and shader support are two components packaged in one download; both must be installed/enabled. Disabling only the map does not disable the shared shader override. Remove both with the package's `Remove-Glass-Test.ps1` while the game/launcher are closed. Thunderstore metadata/automatic dependency packaging is not supplied in this beta. General coexistence with other shader mods or multiple glass maps has not been validated.

## Export isolation fix in 0.11.2

A full-city authoring export stopped when glTF included an unrelated mesh alongside the target glass object. Selection-only glTF export can include selected meshes from other scenes. The previous current-view-layer selection guard did not cover those scenes.

Each glass export now uses a temporary scene containing one parentless, evaluated mesh with the source world transform. Modifiers are evaluated in the original scene before the temporary scene is used. The GLB is restricted to the active temporary scene; its single node name is restored to the source name after validation. Object-linked materials, polygon material indices, empty slots, UVs and world placement are preserved. Temporary data is cleaned up on success and failure; the original scene, active view layer and selections are restored. The duplicate-mesh guard remains active.

A Blender 4.5.3 reproduction exported two meshes through the previous selection-only method and exactly one through the isolated method. Five Blender regression scripts and fourteen Python scripts pass. Shader binaries, native material patching and the paired installer are unchanged from 0.11.1. A fresh build of the actual Windows/Blender 5.2 Kamurocho source remains the next validation step.

Install the new ZIP, fully restart Blender, open the same saved city copy, then click Build Map with Glass with skate and its launcher closed. No shader or glass-setting adjustments are required for this fix.

## Fix in 0.11.1

The first Windows build compiled, then stopped because the native compiler deduplicated all 12 glass material keys into one shared parameter block. The patcher now copies each authored material's parameter block, gives it a private identity, retargets only that material's existing keys, and rebuilds the resource relocation table and metadata. Existing parameter bytes and unrelated table entries stay unchanged. The native helper reports the metadata needed for this operation and rebuilds automatically after upgrading.

The uploaded compiled fixture passes the corrected material binding, geometry checks and CAS/TOC repack verification. Its 12 panes now resolve to four private parameter blocks, while all 17 other keys and original parameter storage are unchanged. Texture payload hashes and pointer relocations verify. A fresh complete Windows build and in-game test are still required.

## City features

- Independent private material textures carry each material's reflection, roughness, face/edge opacity, dirt coverage and image. Custom values are stored as float32 instead of choosing one of five native presets; coverage no longer uses the old 5-bit vertex encoding.
- Each private linear RGBA texture contains a small parameter row plus premultiplied dirt pixels. Integer loads read the parameters; filtered dirt sampling skips the parameter row. The existing t33 slot and original input/output signatures are retained. No new shader attributes or runtime DLLs are required.
- Geometry uses 32-metre cells and native local origins instead of requiring all glass to fit under 100 metres. Exact source-object/material-slot replacement preserves opaque frames and separate collision.
- The previous scene-lit dirt equations and paired map/support installer are retained. These are new shader binaries and a new native material path: the earlier successful in-game tests do not validate this update.

## First test for this update

Open `examples/City_Materials_Test.blend` from the installed add-on folder, save a working copy, close the game and launcher, then click **Build Map with Glass**. Its four near panes use warm RGBA dirt, cool RGBA dirt, a grayscale mask, and clean glass with deliberately different numeric settings. Matching groups sit 160 metres to either side. All images are packed in the blend. This test scene uses Blender 4.5 file format so it can also open in newer Blender versions.

Check that the nearby panes keep separate colors and reflection strengths, the clean pane remains clear, and the distant groups stay in their correct positions. Change one material's reflection strength or dirt coverage, save and build again: other materials should remain unchanged. Then test a saved copy of Kamurocho. Do not overwrite the working 0.10.0 package.

For a build failure send **Copy Build Details**, `Compile.log` and `Patch.log`. For visual failures also send the new `BUILD_AUDIT.json`, a screenshot, GPU model and game/add-on versions. If the native compiler merges incompatible material bindings or geometry, this update refuses the patch and keeps installation untouched.

## Evidence and remaining limits

The previous 0.10.0 Color + Alpha candidate has user-provided day/night screenshots showing visible dirt, transparency and darker dirt at night. That supports the scene-lit approach; it does not establish accurate lighting in every scene, moving-object reflections, local-light behavior, shadows or compatibility with every mod. Native reflection probes do not guarantee live mirror reflections of moving skaters.

This beta deliberately uses full-resolution dirt sampling. Automatic mip selection/distance filtering is not finished; check shimmer and quality at distance and oblique angles. Preview/game appearance can differ. Material settings and coverage now retain float32 values; dirt image pixels remain 8-bit. Glass vertices are locally bounded to reduce half-position rounding. UV transport remains limited to -16..16. A single enormous triangle crossing more than 100,000 candidate cells is refused; subdivide it first. Full-map performance, multiple glass maps and broad mod compatibility need further testing. Fresh Windows native compilation, in-game visuals, city performance and hardware compatibility for 0.11.1 are pending. This is an experimental build, not a production release.

## First beta test to report

Build a saved copy using Color + Alpha and your own PNG. Check daylight/night, look through both sides, walk past reflections, and inspect the dirt close up and farther away. Try two noticeably different coverage values through separate builds. Report game and Blender versions, add-on version, a screenshot/video and **Copy Build Details**. For a failed build include `Prepare.log`, `Compile.log`, `Patch.log` and/or `Install.log` from its build folder. Do not send the entire city blend unless requested.

## Examples and source

`examples/City_Materials_Test.blend`, `examples/Color_Alpha_Demo.blend`, `examples/Glass_Preview_Demo.blend` and `examples/Window_Dirt_RGBA.png` are included. Refresh existing demo materials after opening them. Reference renders are Blender renders, not game screenshots.

The native helper's GPLv3 source and `builder/native/COPYING` are included. Developer tool downloads, analysis decoders and temporary runtime diagnostic kits are not included.
