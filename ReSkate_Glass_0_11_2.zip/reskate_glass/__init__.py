bl_info = {"name": "ReSkate Glass Authoring", "author": "Kamurocho Glass Project", "version": (0, 11, 2), "blender": (4, 3, 0), "location": "View3D > Sidebar > ReSkate Glass", "description": "Author reflective glass, preview dirt and build native full-map tests", "category": "Material"}

import bpy
import json
import hashlib
import shutil
import tempfile
import uuid
from pathlib import Path
from bpy.props import BoolProperty, EnumProperty, FloatProperty, PointerProperty, StringProperty
from bpy_extras.io_utils import ExportHelper
from .schema import PROFILES, validate_settings
from .preview import update as preview_update
from . import build_status


def settings(material):
    p = material.reskate_glass
    return {"reflection_strength": p.reflection_strength, "roughness": p.roughness,
            "face_opacity": p.face_opacity, "edge_opacity": p.edge_opacity}


def preview(material):
    from .preview import refresh
    refresh(material)


class RGPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    cli_path: StringProperty(name='Studio CLI', subtype='FILE_PATH', description='Supported reskate_cli.exe; leave blank to locate it when building')
    game_root: StringProperty(name='ReSkate game folder', subtype='DIR_PATH', description='Folder containing the supported Skate.exe, Data and Mods')
    build_root: StringProperty(name='Build output folder', subtype='DIR_PATH', description='Leave blank to use Local AppData/ReSkateGlass/Builds')

    def draw(self, context):
        for name in ('cli_path', 'game_root', 'build_root'):
            self.layout.prop(self, name)
        self.layout.label(text='Requires game build 25414733 and the supported Studio CLI.')
        self.layout.label(text='Blank tool paths prompt for selection during the first build.')


def builder_options(context):
    entry = context.preferences.addons.get(__package__)
    if not entry:
        return []
    options = []
    for name, argument in [('cli_path', '-CliPath'), ('game_root', '-GameRoot'), ('build_root', '-OutputRoot')]:
        value = getattr(entry.preferences, name, '').strip()
        if value:
            options.extend([argument, str(Path(bpy.path.abspath(value)).resolve())])
    return options

def export_dirt_mask(root, image):
    from array import array
    import math
    if image.source not in {'FILE', 'GENERATED'}:
        raise ValueError('Dirt mask must be a single image; UDIM, movie and sequence inputs are unsupported')
    width, height = image.size[:]
    if width < 1 or height < 1:
        raise ValueError('Load the dirt mask image before exporting')
    pixels = array('f', [0.0]) * len(image.pixels)
    image.pixels.foreach_get(pixels)
    channels = len(pixels) // (width * height)
    if channels < 1 or len(pixels) != width * height * channels:
        raise ValueError('Unexpected dirt image pixel layout')
    target_w, target_h = min(width, 1024), min(height, 1024)
    values = bytearray()
    for y in range(target_h):
        sy = min(height - 1, int((y + 0.5) * height / target_h))
        for x in range(target_w):
            sx = min(width - 1, int((x + 0.5) * width / target_w))
            value = float(pixels[(sy * width + sx) * channels])
            if not math.isfinite(value):
                raise ValueError('Dirt image contains non-finite pixels')
            if image.colorspace_settings.name == 'sRGB' and not image.is_float:
                from .dirt_image import srgb_linear
                value = srgb_linear(max(0, min(1, value)))
            values.append(round(max(0, min(1, value)) * 255))
    name = 'dirt_' + hashlib.sha256(values).hexdigest()[:16] + '.mask'
    (root / name).write_bytes(values)
    return {'file': name, 'width': target_w, 'height': target_h,
            'channel': 'red', 'row_origin': 'bottom', 'sha256': hashlib.sha256(values).hexdigest()}


class RGSettings(bpy.types.PropertyGroup):
    preview_test: EnumProperty(name='Preview test', items=[('GLASS', 'Glass + Dirt', 'Normal approximate glass preview'), ('COLOR', 'Dirt Color Only', 'Show image color without transparency to check placement'), ('ALPHA', 'Dirt Alpha Only', 'Show image alpha: black clear, white opaque')], default='GLASS', update=preview_update)
    dirt_mode: EnumProperty(name='Dirt mode', items=[('MASK', 'Grayscale Mask', 'Red channel changes the glass surface'), ('RGBA', 'Color + Alpha', 'Image colors over the glass; alpha controls coverage')], default='MASK', update=preview_update)
    dirt_image: PointerProperty(name='Dirt image', type=bpy.types.Image, update=preview_update)
    def coverage_get(self):
        return float(self.get('dirt_coverage', self.dirt_strength*self.dirt_boost))

    def coverage_set(self, value):
        self['dirt_coverage'] = float(value)

    dirt_coverage: FloatProperty(name='Dirt coverage', description='Multiplier applied to the dirt mask or PNG alpha; exported to the game build', min=0, max=8, get=coverage_get, set=coverage_set, update=preview_update)
    dirt_boost: FloatProperty(name='Dirt opacity boost', default=1, min=0, max=8, update=preview_update)
    dirt_strength: FloatProperty(name='Dirt strength', default=0.6, min=0, max=1, update=preview_update)
    enabled: BoolProperty(name='Glass', default=False)
    identity: StringProperty(default='')
    preset: EnumProperty(name='Preset', items=[(k, k, '') for k in PROFILES] + [('Custom', 'Custom', 'Independent settings exported to the native glass build')], default='Balanced')
    reflection_strength: FloatProperty(name='Reflection strength', default=1, min=0, max=4, update=preview_update)
    roughness: FloatProperty(name='Roughness', default=0.05, min=0, max=1, update=preview_update)
    face_opacity: FloatProperty(name='Face-on opacity', default=0.08, min=0, max=1, update=preview_update)
    edge_opacity: FloatProperty(name='Edge opacity', default=0.8, min=0, max=1, update=preview_update)


class RGAssign(bpy.types.Operator):
    bl_idname = 'reskate_glass.assign'
    bl_label = 'Assign New Glass Material'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'ERROR'}, 'Switch to Object Mode first')
            return {'CANCELLED'}
        objects = [o for o in context.selected_objects if o.type == 'MESH' and not o.library]
        if not objects:
            self.report({'ERROR'}, 'Select editable mesh objects first')
            return {'CANCELLED'}
        mat = bpy.data.materials.new('ReSkate Glass')
        mat.reskate_glass.enabled = True
        mat.reskate_glass.identity = str(uuid.uuid4())
        preview(mat)
        for obj in objects:
            # Object-linked slots preserve other instances that share this mesh.
            if len(obj.material_slots) == 0:
                if obj.data.users > 1:
                    obj.data = obj.data.copy()
                obj.data.materials.append(mat)
            else:
                slot = obj.material_slots[obj.active_material_index]
                slot.link = 'OBJECT'
                slot.material = mat
        self.report({'INFO'}, 'Glass assigned to active material slots; other slots preserved')
        return {'FINISHED'}


class RGUnique(bpy.types.Operator):
    bl_idname = 'reskate_glass.make_unique'
    bl_label = 'Make Active Glass Material Independent'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if context.mode != 'OBJECT' or not obj or obj.type != 'MESH' or not obj.active_material or not obj.active_material.reskate_glass.enabled:
            self.report({'ERROR'}, 'Select a glass mesh in Object Mode')
            return {'CANCELLED'}
        mat = obj.active_material.copy()
        mat.reskate_glass.identity = str(uuid.uuid4())
        slot = obj.material_slots[obj.active_material_index]
        slot.link = 'OBJECT'
        slot.material = mat
        preview(mat)
        self.report({'INFO'}, 'This active material slot now has independent glass settings')
        return {'FINISHED'}


class RGApply(bpy.types.Operator):
    bl_idname = 'reskate_glass.apply_preset'
    bl_label = 'Apply Preset and Refresh Preview'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mat = context.object.active_material if context.object else None
        if not mat or not mat.reskate_glass.enabled:
            return {'CANCELLED'}
        p = mat.reskate_glass
        if p.preset in PROFILES:
            for key, value in PROFILES[p.preset].items():
                setattr(p, key, value)
        preview(mat)
        self.report({'INFO'}, 'Approximate Blender preview updated; verify appearance in skate')
        return {'FINISHED'}


class RGExport(bpy.types.Operator, ExportHelper):
    bl_idname = 'reskate_glass.export_authoring'
    bl_label = 'Export Glass Authoring Package'
    filename_ext = '.zip'
    filter_glob: StringProperty(default='*.zip', options={'HIDDEN'})

    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'ERROR'}, 'Switch to Object Mode before exporting')
            return {'CANCELLED'}
        objects = [o for o in context.scene.objects if o.type == 'MESH' and any(s.material and s.material.reskate_glass.enabled for s in o.material_slots)]
        if not objects:
            self.report({'ERROR'}, 'No assigned glass objects in this scene')
            return {'CANCELLED'}
        if any(o.hide_get() or o.hide_viewport or o.name not in context.view_layer.objects for o in objects):
            self.report({'ERROR'}, 'Make glass objects visible in the current view layer first')
            return {'CANCELLED'}
        selected = [o for o in context.view_layer.objects if o.select_get()]
        active = context.view_layer.objects.active
        try:
            with tempfile.TemporaryDirectory(prefix='reskate_glass_') as directory:
                root = Path(directory)
                manifest = {"schema": 1, "kind": "reskate-glass-authoring", "addon_version": "0.11.2", "native_map_ready": False,
                            "coordinate_system": "GLB glTF Y-up; matrices in objects are Blender Z-up",
                            "materials": {}, "objects": [], "reflection_probes": [],
                            "limitations": ["Full-map preview requires saved source scene; general compatibility pending", "Color + Alpha requires the pixel-dirt or full-map builder", "Preview is approximate", "City material pipeline requires native/GPU validation; multi-map compatibility pending"]}
                material_ids = {}
                for obj in objects:
                    slots = []
                    for slot in obj.material_slots:
                        mat = slot.material
                        if not mat or not mat.reskate_glass.enabled:
                            slots.append(None)
                            continue
                        if mat not in material_ids:
                            # Export-local IDs do not rely on duplicated Blender custom IDs.
                            key = 'glass_' + str(len(material_ids))
                            material_ids[mat] = key
                            values = settings(mat)
                            validate_settings(values)
                            manifest['materials'][key] = {"name": mat.name, "settings": values, "preset": mat.reskate_glass.preset}
                            if mat.reskate_glass.dirt_image and mat.reskate_glass.dirt_coverage > 0:
                                if mat.reskate_glass.dirt_mode == 'RGBA':
                                    from .dirt_image import export_rgba
                                    mask = export_rgba(root, mat.reskate_glass.dirt_image)
                                else:
                                    mask = export_dirt_mask(root, mat.reskate_glass.dirt_image)
                                mask['strength'] = 1.0
                                mask['boost'] = mat.reskate_glass.dirt_coverage
                                manifest['materials'][key]['dirt_texture' if mat.reskate_glass.dirt_mode == 'RGBA' else 'dirt_mask'] = mask
                        slots.append(material_ids[mat])
                    from .export_isolation import export_object
                    filename = 'mesh_%04d.glb' % len(manifest['objects'])
                    export_object(context, obj, root / filename)
                    manifest['objects'].append({"name": obj.name, "mesh": filename, "material_slots": slots,
                                                "material_slot_names": [slot.material.name if slot.material else None for slot in obj.material_slots],
                                                "matrix_world_blender": [list(row) for row in obj.matrix_world],
                                                "glb_contains_object_transform": True})
                for obj in context.scene.objects:
                    if obj.type == 'LIGHT_PROBE':
                        manifest['reflection_probes'].append({"name": obj.name, "type": obj.data.type,
                                                            "matrix_world_blender": [list(row) for row in obj.matrix_world]})
                from .diagnostics import report
                (root / 'glass-diagnostics.json').write_text(json.dumps(report(objects), indent=2))
                manifest['files'] = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in root.iterdir() if f.suffix in {'.glb', '.mask', '.rgba'}}
                (root / 'glass-authoring.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
                (root / 'README.txt').write_text('AUTHORING PACKAGE ONLY. This ZIP is not an installable ReSkate map. Use Build Map with Glass or a diagnostic builder to compile this authoring data. Do not put this ZIP in Mods. GLB carries transforms; do not apply the diagnostic Blender matrix again.\n')
                destination = Path(self.filepath)
                destination.parent.mkdir(parents=True, exist_ok=True)
                import zipfile
                temporary = destination.with_name(destination.name + '.tmp-' + uuid.uuid4().hex)
                try:
                    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as z:
                        for f in root.iterdir():
                            z.write(f, f.name)
                    temporary.replace(destination)
                finally:
                    if temporary.exists():
                        temporary.unlink()
            self.report({'INFO'}, 'Authoring package exported; use a build button for the installable map')
            return {'FINISHED'}
        except Exception as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        finally:
            for other in context.view_layer.objects:
                other.select_set(False)
            for obj in selected:
                obj.select_set(True)
            context.view_layer.objects.active = active


class RGBuild(bpy.types.Operator, ExportHelper):
    bl_idname = 'reskate_glass.build_test'
    bl_label = 'Build Isolated Glass Test'
    filename_ext = '.zip'
    filter_glob: StringProperty(default='*.zip', options={'HIDDEN'})
    pixel_dirt: BoolProperty(default=False, options={'HIDDEN'})

    def execute(self, context):
        import os
        import subprocess
        if os.name != 'nt':
            self.report({'ERROR'}, 'Native test building currently requires Windows')
            return {'CANCELLED'}
        if build_status.STATE.get('status') == 'running':
            self.report({'ERROR'}, 'A glass build is already running; check Build Status below')
            return {'CANCELLED'}
        result = bpy.ops.reskate_glass.export_authoring(filepath=self.filepath)
        if result != {'FINISHED'}:
            return {'CANCELLED'}
        script = Path(__file__).parent / 'builder' / 'Build-Glass-Test.ps1'
        try:
            result_file = build_status.begin()
            process = subprocess.Popen(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-NoExit', '-File',
                              str(script), '-AuthoringZip', str(Path(self.filepath).resolve()),
                              '-BlenderPath', bpy.app.binary_path, '-ResultFile', result_file] + builder_options(context) + (['-PixelDirt'] if self.pixel_dirt else []), creationflags=subprocess.CREATE_NEW_CONSOLE)
        except (OSError, ValueError) as error:
            build_status.STATE.update(status='failed', stage='Could not start builder', error=str(error))
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        build_status.start_watch(process)
        self.report({'INFO'}, 'Builder started in PowerShell; follow its output to the installable test ZIP')
        return {'FINISHED'}


class RGBuildFullMap(bpy.types.Operator, ExportHelper):
    bl_idname = 'reskate_glass.build_full_map'
    bl_label = 'Build Full Map Preview'
    install_after_build: BoolProperty(default=False, options={'HIDDEN'})
    filename_ext = '.zip'
    filter_glob: StringProperty(default='*.zip', options={'HIDDEN'})

    def execute(self, context):
        import os
        import subprocess
        if os.name != 'nt':
            self.report({'ERROR'}, 'Native map building currently requires Windows')
            return {'CANCELLED'}
        if not bpy.data.filepath or bpy.data.is_dirty:
            self.report({'ERROR'}, 'Save a COPY of this scene first (Ctrl+Shift+S); then save all current edits before building')
            return {'CANCELLED'}
        source = str(Path(bpy.data.filepath).resolve())
        if not any(o.type == 'EMPTY' and o.name.lower() == 'spawn' for o in context.scene.objects):
            self.report({'ERROR'}, 'Add an Empty named spawn, position it above the floor, and save the test scene')
            return {'CANCELLED'}
        if build_status.STATE.get('status') == 'running':
            self.report({'ERROR'}, 'A glass build is already running; check Build Status below')
            return {'CANCELLED'}
        result = bpy.ops.reskate_glass.export_authoring(filepath=self.filepath)
        if result != {'FINISHED'}:
            return {'CANCELLED'}
        try:
            result_file = build_status.begin()
            process = subprocess.Popen(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-NoExit', '-File',
                              str(Path(__file__).parent / 'builder' / 'Build-Glass-Test.ps1'),
                              '-AuthoringZip', str(Path(self.filepath).resolve()),
                              '-BlenderPath', bpy.app.binary_path, '-BaseBlend', source, '-PixelDirt', '-ResultFile', result_file] + builder_options(context) + (['-InstallAfterBuild'] if self.install_after_build else []),
                             creationflags=subprocess.CREATE_NEW_CONSOLE)
        except (OSError, ValueError) as error:
            build_status.STATE.update(status='failed', stage='Could not start builder', error=str(error))
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        build_status.start_watch(process)
        self.report({'INFO'}, 'Full scene preview builder started; keep this saved source file unchanged until export finishes')
        return {'FINISHED'}


class RGBuildMapWithGlass(bpy.types.Operator):
    bl_idname = 'reskate_glass.build_map_with_glass'
    bl_label = 'Build Map with Glass'
    bl_description = 'Build the saved scene and install it into ReSkate; close skate and its launcher first'

    def execute(self, context):
        import os
        if os.name != 'nt':
            self.report({'ERROR'}, 'Native map building currently requires Windows')
            return {'CANCELLED'}
        if not bpy.data.filepath or bpy.data.is_dirty:
            self.report({'ERROR'}, 'Save your test scene and all current edits before building')
            return {'CANCELLED'}
        authoring = Path(os.environ.get('LOCALAPPDATA', tempfile.gettempdir())) / 'ReSkateGlass' / 'Authoring'
        try:
            authoring.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        destination = authoring / ('glass_' + uuid.uuid4().hex + '.zip')
        return bpy.ops.reskate_glass.build_full_map('EXEC_DEFAULT', filepath=str(destination), install_after_build=True)


class RGRefreshPreview(bpy.types.Operator):
    bl_idname = 'reskate_glass.refresh_preview'
    bl_label = 'Refresh Blender Preview'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mat=context.object.active_material if context.object else None
        if not mat or not mat.reskate_glass.enabled:
            self.report({'ERROR'}, 'Select an assigned glass material first')
            return {'CANCELLED'}
        preview(mat)
        return {'FINISHED'}


class RGMaterialView(bpy.types.Operator):
    bl_idname = 'reskate_glass.material_view'
    bl_label = 'Use Material Preview'

    def execute(self, context):
        if context.space_data and context.space_data.type == 'VIEW_3D':
            context.space_data.shading.type='MATERIAL'
            context.space_data.shading.use_scene_world=False
            context.space_data.shading.use_scene_lights=False
            return {'FINISHED'}
        return {'CANCELLED'}


class RGCopyBuildDetails(bpy.types.Operator):
    bl_idname = 'reskate_glass.copy_build_details'
    bl_label = 'Copy Build Details'

    def execute(self, context):
        state = build_status.STATE
        lines = ['ReSkate Glass Builder 0.11.2']
        lines += [key + ': ' + str(state[key]) for key in ('status', 'stage', 'job', 'package', 'error') if state.get(key)]
        context.window_manager.clipboard = '\n'.join(lines)
        self.report({'INFO'}, 'Build details copied; paste them into the work chat if needed')
        return {'FINISHED'}


class RGOpenBuildFolder(bpy.types.Operator):
    bl_idname = 'reskate_glass.open_build_folder'
    bl_label = 'Open Build Folder'

    def execute(self, context):
        folder = build_status.STATE.get('job')
        if not folder or not Path(folder).is_dir():
            self.report({'ERROR'}, 'No build folder is available yet')
            return {'CANCELLED'}
        bpy.ops.wm.path_open(filepath=folder)
        return {'FINISHED'}


class RGPanel(bpy.types.Panel):
    bl_label = 'ReSkate Glass — 0.11.2 City Experimental'
    bl_idname = 'RG_PT_authoring'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ReSkate Glass'

    def draw(self, context):
        layout = self.layout
        layout.operator('reskate_glass.assign')
        mat = context.object.active_material if context.object and context.object.type == 'MESH' else None
        if mat and mat.reskate_glass.enabled:
            p = mat.reskate_glass
            layout.label(text=mat.name, icon='MATERIAL')
            layout.operator('reskate_glass.make_unique')
            layout.prop(p, 'preset')
            layout.operator('reskate_glass.apply_preset')
            layout.operator('reskate_glass.refresh_preview')
            layout.operator('reskate_glass.material_view')
            for name in ('reflection_strength', 'roughness', 'face_opacity', 'edge_opacity'):
                layout.prop(p, name)
            layout.prop(p, 'dirt_mode')
            layout.label(text='RGBA: color with transparent coverage' if p.dirt_mode == 'RGBA' else 'Mask: black clean, white dirty')
            layout.template_ID(p, 'dirt_image', open='image.open')
            layout.prop(p, 'dirt_coverage')
            layout.label(text='Dirt follows the active UV map')
            layout.prop(p, 'preview_test')
            if p.preview_test != 'GLASS':
                layout.label(text='Preview test only; game build still uses glass', icon='INFO')
            layout.label(text='Custom settings export per material')
            layout.label(text='Preview is approximate')
        layout.separator()
        layout.operator('reskate_glass.build_map_with_glass', icon='IMPORT')
        layout.label(text='Close skate and its launcher before installing')
        layout.label(text='Beta: build a saved copy of your map')
        advanced = layout.box()
        advanced.prop(context.window_manager, 'reskate_glass_diagnostics', text='Manual export and test builds', icon='TRIA_DOWN' if context.window_manager.reskate_glass_diagnostics else 'TRIA_RIGHT', emboss=False)
        if context.window_manager.reskate_glass_diagnostics:
            advanced.operator('reskate_glass.export_authoring')
            advanced.operator('reskate_glass.build_test', text='Legacy Vertex Test (presets only)')
            advanced.operator('reskate_glass.build_test', text='Build Glass Material Test').pixel_dirt = True
            advanced.operator('reskate_glass.build_full_map')
            advanced.label(text='These buttons do not install automatically')
        state = build_status.STATE
        if state.get('status') != 'idle':
            box = layout.box()
            box.label(text='Build Status', icon='INFO')
            box.label(text=state.get('stage', 'Starting builder'))
            if state.get('status') == 'installed':
                box.label(text='Installed in ReSkate', icon='CHECKMARK')
                box.label(text='Start ReSkate and select the Glass Preview map')
            if state.get('status') == 'ready':
                box.label(text='Extract Installable-Glass-Test.zip')
                box.label(text='Close skate; run its installer')
            if state.get('error'):
                box.label(text='Build stopped; see PowerShell for details', icon='ERROR')
            box.operator('reskate_glass.copy_build_details')
            if state.get('job'):
                box.operator('reskate_glass.open_build_folder')


CLASSES = (RGPreferences, RGSettings, RGAssign, RGUnique, RGApply, RGExport, RGBuild, RGBuildFullMap, RGBuildMapWithGlass, RGRefreshPreview, RGMaterialView, RGOpenBuildFolder, RGCopyBuildDetails, RGPanel)

def register():
    # Blender may reload only this package during add-on upgrades and retain old
    # submodule functions. Reload preview code before registering its callbacks.
    import importlib
    module = importlib.import_module(__name__ + '.preview')
    if getattr(module, 'PREVIEW_VERSION', None) != '0.11.2':
        importlib.invalidate_caches()
        importlib.reload(module)
    diagnostic = importlib.import_module(__name__ + '.diagnostics')
    if getattr(diagnostic, 'DIAGNOSTIC_VERSION', None) != '0.11.2':
        importlib.reload(diagnostic)
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Material.reskate_glass = PointerProperty(type=RGSettings)
    bpy.types.WindowManager.reskate_glass_diagnostics = BoolProperty(default=False, options={'SKIP_SAVE'})


def unregister():
    build_status.stop_watch()
    del bpy.types.Material.reskate_glass
    del bpy.types.WindowManager.reskate_glass_diagnostics
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
