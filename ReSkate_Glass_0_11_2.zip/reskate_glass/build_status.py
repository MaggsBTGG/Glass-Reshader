"""Session-only build tracking; never writes properties into the creator's scene."""
import json
from pathlib import Path
import tempfile
import uuid

STATE = {'status': 'idle'}
PROCESS = None


def begin():
    global PROCESS
    if STATE.get('status') == 'running':
        raise ValueError('A glass build is already running. Finish it before starting another.')
    path = Path(tempfile.gettempdir()) / ('reskate-glass-' + uuid.uuid4().hex + '.json')
    STATE.clear()
    PROCESS = None
    STATE.update(status='running', stage='Starting builder', result_file=str(path))
    return str(path)


def refresh():
    if STATE.get('status') != 'running':
        return False
    try:
        report = json.loads(Path(STATE['result_file']).read_text(encoding='utf-8-sig'))
        if report.get('status') not in ('running', 'ready', 'installed', 'failed'):
            raise ValueError('Unknown build result')
        STATE.update({k: report[k] for k in ('status', 'stage', 'job', 'package', 'error') if k in report})
    except (OSError, ValueError):
        pass  # Atomic replacement may briefly race a filesystem reader.
    if STATE.get('status') == 'running' and PROCESS is not None and PROCESS.poll() is not None:
        STATE.update(status='failed', stage='Builder window closed', error='Builder closed before reporting a package. See its logs.')
    return STATE.get('status') == 'running'


def watch():
    import bpy
    running = refresh()
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
    return 1.0 if running else None


def start_watch(process):
    global PROCESS
    PROCESS = process
    import bpy
    if not bpy.app.timers.is_registered(watch):
        bpy.app.timers.register(watch, first_interval=1.0)


def stop_watch():
    import bpy
    if bpy.app.timers.is_registered(watch):
        bpy.app.timers.unregister(watch)
