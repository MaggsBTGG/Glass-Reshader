"""Export straight-alpha linear RGBA bytes without changing source image settings."""
from array import array
import hashlib
import math


def srgb_linear(x):
    return x / 12.92 if x <= .04045 else ((x + .055) / 1.055) ** 2.4


def export_rgba(root, image):
    if image.source not in {'FILE', 'GENERATED'}:
        raise ValueError('Color dirt needs a single image, not a UDIM, movie or sequence')
    if image.alpha_mode != 'STRAIGHT':
        raise ValueError('Set the color dirt image Alpha Mode to Straight before exporting')
    space = image.colorspace_settings.name
    if space not in {'sRGB', 'Non-Color', 'Linear', 'Linear Rec.709'}:
        raise ValueError('Color dirt supports sRGB or linear Rec.709 images; convert other color spaces first')
    if image.is_float:
        raise ValueError('Use a regular PNG for color dirt; HDR/float image inputs are not supported yet')
    width, height = image.size[:]
    if min(width, height) < 1:
        raise ValueError('Load the dirt image before building')
    pixels = array('f', [0]) * len(image.pixels)
    image.pixels.foreach_get(pixels)
    if len(pixels) != width * height * 4:
        raise ValueError('Color dirt requires RGBA image pixels')
    tw, th = min(width, 1024), min(height, 1024)
    data = bytearray()
    # Byte-buffer pixels are in the image's source color space. Alpha is always linear.
    # Average premultiplied colors during reduction, then store straight linear RGBA.
    for y in range(th):
        for x in range(tw):
            total = [0., 0., 0., 0.]; count = 0
            for sy in range(y * height // th, (y + 1) * height // th):
                for sx in range(x * width // tw, (x + 1) * width // tw):
                    values = pixels[(sy * width + sx) * 4:(sy * width + sx) * 4 + 4]
                    if not all(math.isfinite(c) for c in values):
                        raise ValueError('Dirt image contains non-finite pixels')
                    rgb = [max(0., min(1., c)) for c in values[:3]]
                    if space == 'sRGB':
                        rgb = [srgb_linear(c) for c in rgb]
                    alpha = max(0., min(1., values[3]))
                    for k in range(3): total[k] += rgb[k] * alpha
                    total[3] += alpha; count += 1
            color = [c / total[3] if total[3] else 0 for c in total[:3]]
            data.extend(round(c * 255) for c in color + [total[3] / count])
    digest = hashlib.sha256(data).hexdigest()
    name = 'dirt_' + digest[:16] + '.rgba'
    (root / name).write_bytes(data)
    return {'file': name, 'width': tw, 'height': th, 'encoding': 'linear-rgba8',
            'row_origin': 'bottom', 'sha256': digest}
