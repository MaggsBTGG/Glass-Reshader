"""Run in Blender after enabling the add-on, in a disposable scene."""
import bpy
import json
import tempfile
import zipfile
from pathlib import Path

assert hasattr(bpy.types.Material, 'reskate_glass'), 'Enable the add-on first'
bpy.ops.object.select_all(action='DESELECT')
bpy.ops.mesh.primitive_plane_add()
a = bpy.context.object
a.name = 'RG_SMOKE_TEST_PANE'
original = bpy.data.materials.new('RG_SMOKE_ORIGINAL')
a.data.materials.append(original)
try:
    assert bpy.ops.reskate_glass.assign() == {'FINISHED'}
    assert a.active_material != original
    mat = a.active_material
    assert mat.reskate_glass.enabled
    mat.reskate_glass.preset = 'ExtraClear'
    assert bpy.ops.reskate_glass.apply_preset() == {'FINISHED'}
    assert abs(mat.reskate_glass.face_opacity - 0.02) < 0.00001
    with tempfile.TemporaryDirectory() as directory:
        dest = Path(directory) / 'authoring.zip'
        assert bpy.ops.reskate_glass.export_authoring(filepath=str(dest)) == {'FINISHED'}
        with zipfile.ZipFile(dest) as z:
            manifest = json.loads(z.read('glass-authoring.json'))
            assert manifest['native_map_ready'] is False
            entry = next(o for o in manifest['objects'] if o['name'] == a.name)
            assert z.read(entry['mesh'])[:4] == b'glTF'
    print('RESKATE GLASS AUTHORING SMOKE TEST PASSED')
finally:
    bpy.data.objects.remove(a, do_unlink=True)
